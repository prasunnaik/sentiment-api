package com.insurewise;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InsurewiseApplication {

    public static void main(String[] args) {
        SpringApplication.run(InsurewiseApplication.class, args);
    }
}

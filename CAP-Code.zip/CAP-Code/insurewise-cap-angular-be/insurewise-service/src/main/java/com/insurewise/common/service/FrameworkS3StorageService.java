package com.insurewise.common.service;

import com.insurewise.common.dto.PresignedUrlResponse;
import com.insurewise.framework.s3.service.S3FileService;
import java.util.UUID;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

@Service
public class FrameworkS3StorageService implements S3StorageService {

    private final S3FileService fileService;

    public FrameworkS3StorageService(S3FileService fileService) {
        this.fileService = fileService;
    }

    @Override
    public String upload(
            MultipartFile file,
            String folder,
            UUID ownerId) {
        return fileService.upload(file, folder, ownerId);
    }

    @Override
    public String uploadGenerated(
            byte[] content,
            String fileName,
            String contentType,
            String folder,
            UUID ownerId) {
        return fileService.uploadGenerated(
                content,
                fileName,
                contentType,
                folder,
                ownerId);
    }

    @Override
    public PresignedUrlResponse getPresignedDownloadUrl(
            String s3Key) {

        var response = fileService.getPresignedDownloadUrl(s3Key);
        return new PresignedUrlResponse(
                response.url(),
                response.expiresAt());
    }

    @Override
    public void delete(String s3Key) {
        fileService.delete(s3Key);
    }
}

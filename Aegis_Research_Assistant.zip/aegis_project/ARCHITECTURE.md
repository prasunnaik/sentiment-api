# Aegis Architecture

```text
CLI input
   |
   v
AegisAssistant.handle()
   |
   +--> direct response ----------------------+
   +--> custom tools                           |
   |      +--> watchlist -> FAISS              |
   |      +--> position size                   |
   +--> external tools                         |
   |      +--> Wikipedia API                   |
   |      +--> Yahoo Finance / yfinance        |
   +--> structured research                    |
          +--> price/news/background           |
          +--> PydanticOutputParser            |
          +--> one corrective retry             |
                                                v
                                     Azure OpenAI chat model
                                                |
                                  +-------------+-------------+
                                  |                           |
                           session history               long-term memory
                      InMemoryChatMessageHistory             FAISS
                                  |                           |
                            current run only           disk persistence
```

## FR mapping

| Requirement | Implementation |
|---|---|
| FR-1 Configuration | `aegis/config.py` loads `.env` and validates required variables. |
| FR-2 Long-term memory | `aegis/memory.py` uses persistent FAISS with semantic retrieval. |
| FR-3 Short-term memory | `InMemoryChatMessageHistory` in `MemoryStore.session_history`. |
| FR-4 Custom tools | `aegis/tools.py` uses LangChain `@tool`. |
| FR-5 External tools | Wikipedia API + `yfinance` for news and price. |
| FR-6 Structured output | `ResearchSummary` + `PydanticOutputParser`, with one retry. |
| FR-7 Persistence | `FAISS.save_local()` on mutations and graceful shutdown; load at startup. |
| FR-8 CLI orchestration | `aegis/cli.py` and `AegisAssistant.handle()` route requests. |

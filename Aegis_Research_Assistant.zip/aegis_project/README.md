# Aegis — Memory-Augmented Research & Advisory Assistant

A working Python/LangChain capstone implementing FR-1 through FR-8 from the provided case study.

## Features

- Azure OpenAI credentials loaded from `.env` / environment variables; no secrets hardcoded.
- Short-term conversation memory with `InMemoryChatMessageHistory`.
- Persistent long-term semantic memory using FAISS, saved to disk and reloaded at startup.
- Custom LangChain tools using `@tool`:
  - `add_to_watchlist(ticker)`
  - `list_watchlist()`
  - `calculate_position_size(capital, risk_pct, entry, stop)`
- External tools:
  - `search_wikipedia(topic)`
  - `get_stock_news(ticker)`
  - `get_stock_price(ticker)`
- Schema-validated research summaries with Pydantic and `PydanticOutputParser`.
- One corrective retry when structured-output parsing fails.
- CLI orchestration for direct responses, tools, memory queries, research summaries, confirmations, and graceful persistence.
- Tests covering validation, persistence, routing, and tool behavior without requiring Azure credentials.

> This project is for educational/research workflow demonstration. It does **not** provide financial advice.

## Project structure

```text
Aegis/
├── aegis/
│   ├── __init__.py
│   ├── config.py
│   ├── memory.py
│   ├── models.py
│   ├── tools.py
│   ├── external_tools.py
│   ├── prompts.py
│   ├── assistant.py
│   └── cli.py
├── tests/
│   ├── test_tools.py
│   ├── test_memory.py
│   └── test_models.py
├── .env.example
├── .gitignore
├── requirements.txt
└── README.md
```

## Setup

### 1. Create a virtual environment

Windows PowerShell:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
```

macOS/Linux:

```bash
python3 -m venv .venv
source .venv/bin/activate
```

### 2. Install dependencies

```bash
pip install -r requirements.txt
```

### 3. Configure Azure OpenAI

Copy `.env.example` to `.env` and fill in your organization's Azure OpenAI values.

Required:

```text
AZURE_OPENAI_API_KEY=...
AZURE_OPENAI_ENDPOINT=https://<resource>.openai.azure.com/
AZURE_OPENAI_API_VERSION=2024-02-01
AZURE_OPENAI_CHAT_DEPLOYMENT=<your-chat-deployment>
```

The application fails with an actionable message if required values are missing. It never passes `None` into the SDK.

### 4. Run

```bash
python -m aegis.cli
```

Example commands:

```text
Add AAPL to my watchlist
List my watchlist
Calculate position size: capital 100000, risk 1%, entry 200, stop 190
What is Microsoft?
Give me the latest news for AAPL
What is the latest price of MSFT?
Remember that I prefer large-cap technology companies
What companies do I track?
Research AAPL and return the structured summary
exit
```

## Memory

Long-term memories are stored under `data/aegis_memory/` and survive process restarts. The watchlist and preferences are stored as memory records, so the same FAISS index is used for semantic retrieval.

Short-term session history exists only for the current process and is implemented with `InMemoryChatMessageHistory`.

On `exit` / `quit`, the CLI saves FAISS state before terminating. It also saves after mutations so that a forced interruption is less likely to lose state.

## Notes on live data

- Wikipedia uses its public API over HTTPS.
- Stock price/news use `yfinance`.
- External failures return readable messages rather than exposing unhandled exceptions.
- Network-dependent tests use mocks and do not require internet access.

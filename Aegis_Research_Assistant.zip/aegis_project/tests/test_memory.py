from pathlib import Path

import pytest

from aegis.memory import MemoryStore


class FakeEmbeddings:
    def embed_documents(self, texts):
        return [[float(len(text)), 1.0] for text in texts]

    def embed_query(self, text):
        return [float(len(text)), 1.0]


def test_memory_persists_and_reloads(tmp_path: Path):
    first = MemoryStore(tmp_path / "memory", FakeEmbeddings(), top_k=2)
    first.add("WATCHLIST:AAPL", {"type": "watchlist"})
    first.save()

    second = MemoryStore(tmp_path / "memory", FakeEmbeddings(), top_k=2)
    assert second.index_exists
    assert second.search("watchlist", 1)

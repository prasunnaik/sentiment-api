import pytest
from pydantic import ValidationError

from aegis.models import ResearchSummary


def test_research_summary_validates_schema():
    result = ResearchSummary(
        ticker="aapl",
        summary="Example summary",
        recent_headlines=["Headline"],
        recommendation="HOLD",
        confidence=0.75,
    )
    assert result.ticker == "AAPL"
    assert result.confidence == 0.75


def test_research_summary_rejects_invalid_confidence():
    with pytest.raises(ValidationError):
        ResearchSummary(
            ticker="AAPL",
            summary="Example",
            recommendation="BUY",
            confidence=1.5,
        )

"""Aegis memory-augmented research assistant."""

__version__ = "1.0.0"

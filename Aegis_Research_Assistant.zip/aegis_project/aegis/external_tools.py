from __future__ import annotations

import html
from typing import Any

import requests
import yfinance as yf
from langchain_core.tools import tool


@tool
def search_wikipedia(topic: str) -> str:
    """Search Wikipedia for company or sector background research."""
    topic = topic.strip()
    if not topic:
        return "Wikipedia search requires a non-empty topic."
    try:
        response = requests.get(
            "https://en.wikipedia.org/w/api.php",
            params={
                "action": "query",
                "list": "search",
                "srsearch": topic,
                "format": "json",
                "utf8": 1,
                "srlimit": 3,
            },
            timeout=8,
            headers={"User-Agent": "AegisResearchAssistant/1.0"},
        )
        response.raise_for_status()
        results = response.json().get("query", {}).get("search", [])
        if not results:
            return f"No Wikipedia results found for '{topic}'."
        cleaned = []
        for item in results:
            snippet = html.unescape(item.get("snippet", ""))
            cleaned.append(f"{item.get('title', 'Untitled')}: {snippet}")
        return "\n".join(cleaned)
    except Exception as exc:
        return f"Wikipedia lookup unavailable: {exc}"


@tool
def get_stock_news(ticker: str) -> str:
    """Get recent stock headlines using Yahoo Finance/yfinance."""
    ticker = ticker.strip().upper()
    if not ticker:
        return "Ticker is required."
    try:
        news: list[dict[str, Any]] = yf.Ticker(ticker).news or []
        if not news:
            return f"No recent news was returned for {ticker}."
        lines = []
        for item in news[:5]:
            content = item.get("content", item)
            title = content.get("title") or item.get("title") or "Untitled headline"
            publisher = content.get("provider", {}).get("displayName") or item.get("publisher") or "Unknown source"
            lines.append(f"- {title} ({publisher})")
        return "\n".join(lines)
    except Exception as exc:
        return f"Stock news unavailable for {ticker}: {exc}"


@tool
def get_stock_price(ticker: str) -> str:
    """Get the latest available closing/market price using Yahoo Finance."""
    ticker = ticker.strip().upper()
    if not ticker:
        return "Ticker is required."
    try:
        data = yf.Ticker(ticker).history(period="5d", auto_adjust=False)
        if data.empty:
            return f"No price data was returned for {ticker}."
        row = data.iloc[-1]
        price = row.get("Close")
        if price is None:
            return f"Price data for {ticker} did not contain a Close value."
        date = data.index[-1]
        return f"{ticker} latest available close: {float(price):.2f} on {date:%Y-%m-%d}."
    except Exception as exc:
        return f"Stock price unavailable for {ticker}: {exc}"

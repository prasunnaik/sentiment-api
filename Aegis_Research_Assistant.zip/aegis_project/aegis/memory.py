from __future__ import annotations

from pathlib import Path
from typing import Iterable

from langchain_community.vectorstores import FAISS
from langchain_core.documents import Document
from langchain_core.embeddings import Embeddings
from langchain_core.chat_history import InMemoryChatMessageHistory


class MemoryStore:
    """Persistent FAISS long-term memory plus in-memory session history."""

    def __init__(self, path: Path, embeddings: Embeddings, top_k: int = 5):
        self.path = Path(path)
        self.embeddings = embeddings
        self.top_k = top_k
        self.path.mkdir(parents=True, exist_ok=True)
        self.vector_store: FAISS | None = None
        self.session_history = InMemoryChatMessageHistory()
        self._load()

    @property
    def index_exists(self) -> bool:
        return (self.path / "index.faiss").exists() and (self.path / "index.pkl").exists()

    def _load(self) -> None:
        if self.index_exists:
            try:
                self.vector_store = FAISS.load_local(
                    str(self.path),
                    self.embeddings,
                    allow_dangerous_deserialization=True,
                )
            except Exception as exc:
                raise RuntimeError(
                    f"Unable to load FAISS memory from {self.path}: {exc}. "
                    "Back up the directory and remove/rebuild a corrupted index if necessary."
                ) from exc

    def add(self, text: str, metadata: dict | None = None) -> None:
        text = text.strip()
        if not text:
            raise ValueError("Memory text cannot be empty.")
        document = Document(page_content=text, metadata=metadata or {})
        if self.vector_store is None:
            self.vector_store = FAISS.from_documents([document], self.embeddings)
        else:
            self.vector_store.add_documents([document])

    def add_many(self, texts: Iterable[str], metadata: dict | None = None) -> None:
        docs = [Document(page_content=t.strip(), metadata=metadata or {}) for t in texts if t.strip()]
        if not docs:
            return
        if self.vector_store is None:
            self.vector_store = FAISS.from_documents(docs, self.embeddings)
        else:
            self.vector_store.add_documents(docs)

    def search(self, query: str, k: int | None = None) -> list[str]:
        if self.vector_store is None:
            return []
        docs = self.vector_store.similarity_search(query, k=k or self.top_k)
        return [doc.page_content for doc in docs]

    def save(self) -> None:
        if self.vector_store is not None:
            self.path.mkdir(parents=True, exist_ok=True)
            self.vector_store.save_local(str(self.path))

    def clear_session(self) -> None:
        self.session_history.clear()

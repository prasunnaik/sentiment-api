from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder


SYSTEM_PROMPT = """You are Aegis, an internal research assistant for an investment research analyst.
Use supplied analyst memory and tool results as evidence. Never invent unavailable data.
Clearly say when live data or a source is unavailable. Keep financial outputs informational,
not personalized financial advice.

Relevant long-term memory:
{memory_context}
"""

DIRECT_PROMPT = ChatPromptTemplate.from_messages([
    ("system", SYSTEM_PROMPT),
    MessagesPlaceholder("history"),
    ("human", "{input}"),
])

RESEARCH_PROMPT = ChatPromptTemplate.from_messages([
    ("system", SYSTEM_PROMPT + "\nReturn only the requested structured research object."),
    MessagesPlaceholder("history"),
    ("human", """Research ticker {ticker}.

Live/background evidence:
{research_context}

{format_instructions}
"""),
])

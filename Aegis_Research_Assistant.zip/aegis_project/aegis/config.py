from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from dotenv import load_dotenv


class ConfigurationError(RuntimeError):
    """Raised when required application configuration is missing."""


@dataclass(frozen=True)
class Settings:
    azure_api_key: str
    azure_endpoint: str
    azure_api_version: str
    azure_chat_deployment: str
    azure_embedding_deployment: str
    memory_path: Path
    memory_top_k: int = 5


def load_settings() -> Settings:
    """Load settings from .env/environment and fail early with a useful message."""
    load_dotenv()

    required = {
        "AZURE_OPENAI_API_KEY": os.getenv("AZURE_OPENAI_API_KEY"),
        "AZURE_OPENAI_ENDPOINT": os.getenv("AZURE_OPENAI_ENDPOINT"),
        "AZURE_OPENAI_API_VERSION": os.getenv("AZURE_OPENAI_API_VERSION"),
        "AZURE_OPENAI_CHAT_DEPLOYMENT": os.getenv("AZURE_OPENAI_CHAT_DEPLOYMENT"),
        "AZURE_OPENAI_EMBEDDING_DEPLOYMENT": os.getenv("AZURE_OPENAI_EMBEDDING_DEPLOYMENT"),
    }
    missing = [name for name, value in required.items() if not value or not value.strip()]
    if missing:
        raise ConfigurationError(
            "Missing required Azure OpenAI environment variable(s): "
            + ", ".join(missing)
            + ". Copy .env.example to .env and provide the values; "
              "do not hardcode secrets."
        )

    try:
        top_k = int(os.getenv("AEGIS_MEMORY_TOP_K", "5"))
        if top_k < 1:
            raise ValueError
    except ValueError as exc:
        raise ConfigurationError("AEGIS_MEMORY_TOP_K must be a positive integer.") from exc

    return Settings(
        azure_api_key=required["AZURE_OPENAI_API_KEY"].strip(),
        azure_endpoint=required["AZURE_OPENAI_ENDPOINT"].strip(),
        azure_api_version=required["AZURE_OPENAI_API_VERSION"].strip(),
        azure_chat_deployment=required["AZURE_OPENAI_CHAT_DEPLOYMENT"].strip(),
        azure_embedding_deployment=required["AZURE_OPENAI_EMBEDDING_DEPLOYMENT"].strip(),
        memory_path=Path(os.getenv("AEGIS_MEMORY_PATH", "./data/aegis_memory")),
        memory_top_k=top_k,
    )

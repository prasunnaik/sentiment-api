from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field, field_validator


class ResearchSummary(BaseModel):
    """Required machine-readable format for research summaries."""

    ticker: str = Field(min_length=1)
    summary: str = Field(min_length=1)
    recent_headlines: list[str] = Field(default_factory=list)
    recommendation: Literal["BUY", "HOLD", "SELL"]
    confidence: float = Field(ge=0.0, le=1.0)

    @field_validator("ticker")
    @classmethod
    def normalize_ticker(cls, value: str) -> str:
        value = value.strip().upper()
        if not value:
            raise ValueError("ticker cannot be empty")
        return value

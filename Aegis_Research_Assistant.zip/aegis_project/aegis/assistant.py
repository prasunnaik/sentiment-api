from __future__ import annotations

import json
import re
from typing import Callable

from langchain_core.messages import AIMessage, HumanMessage, SystemMessage
from langchain_core.output_parsers import PydanticOutputParser
from langchain_openai import AzureChatOpenAI, AzureOpenAIEmbeddings

from .config import Settings
from .external_tools import get_stock_news, get_stock_price, search_wikipedia
from .memory import MemoryStore
from .models import ResearchSummary
from .prompts import DIRECT_PROMPT, RESEARCH_PROMPT
from .tools import build_custom_tools


class AegisAssistant:
    """Orchestrates prompts, Azure OpenAI, tools, short-term history and long-term memory."""

    def __init__(self, settings: Settings):
        self.settings = settings
        self.llm = AzureChatOpenAI(
            azure_deployment=settings.azure_chat_deployment,
            azure_endpoint=settings.azure_endpoint,
            api_version=settings.azure_api_version,
            api_key=settings.azure_api_key,
            temperature=0,
        )
        self.embeddings = AzureOpenAIEmbeddings(
            azure_deployment=settings.azure_embedding_deployment,
            azure_endpoint=settings.azure_endpoint,
            api_version=settings.azure_api_version,
            api_key=settings.azure_api_key,
        )
        self.memory = MemoryStore(settings.memory_path, self.embeddings, settings.memory_top_k)
        self.custom_tools = build_custom_tools(self.memory)
        self.external_tools = [search_wikipedia, get_stock_news, get_stock_price]
        self.all_tools = self.custom_tools + self.external_tools
        self.tool_map = {t.name: t for t in self.all_tools}
        self.parser = PydanticOutputParser(pydantic_object=ResearchSummary)

    def _history_messages(self):
        return self.memory.session_history.messages

    def _remember(self, user_text: str, answer: str) -> None:
        self.memory.session_history.add_message(HumanMessage(content=user_text))
        self.memory.session_history.add_message(AIMessage(content=answer))

    def save(self) -> None:
        self.memory.save()

    def _memory_context(self, query: str) -> str:
        hits = self.memory.search(query, self.settings.memory_top_k)
        return "\n".join(f"- {h}" for h in hits) if hits else "No relevant long-term memory found."

    def add_memory(self, text: str) -> str:
        self.memory.add(text, {"type": "analyst_fact"})
        self.memory.save()
        return "Saved to long-term memory."

    def _invoke_direct(self, user_text: str) -> str:
        messages = DIRECT_PROMPT.format_messages(
            memory_context=self._memory_context(user_text),
            history=self._history_messages(),
            input=user_text,
        )
        response = self.llm.invoke(messages)
        answer = response.content if isinstance(response.content, str) else str(response.content)
        self._remember(user_text, answer)
        return answer

    @staticmethod
    def _extract_ticker(text: str) -> str | None:
        patterns = [
            r"\b(?:ticker|symbol)\s*[:=]?\s*\$?([A-Za-z]{1,5}(?:\.[A-Za-z]{1,2})?)\b",
            r"\b(?:for|of|on)\s+\$?([A-Za-z]{1,5}(?:\.[A-Za-z]{1,2})?)\b",
            r"\$([A-Za-z]{1,5}(?:\.[A-Za-z]{1,2})?)\b",
        ]
        for pattern in patterns:
            match = re.search(pattern, text, flags=re.IGNORECASE)
            if match:
                return match.group(1).upper()
        return None

    def _call_tool(self, name: str, **kwargs) -> str:
        tool = self.tool_map[name]
        try:
            result = tool.invoke(kwargs)
            return str(result)
        except Exception as exc:
            return f"{name} failed safely: {exc}"

    def research(self, ticker: str) -> ResearchSummary | str:
        ticker = ticker.strip().upper()
        if not ticker:
            return "Ticker is required for research."

        evidence = []
        for name, args in [
            ("get_stock_price", {"ticker": ticker}),
            ("get_stock_news", {"ticker": ticker}),
            ("search_wikipedia", {"topic": ticker}),
        ]:
            evidence.append(f"{name}:\n{self._call_tool(name, **args)}")
        research_context = "\n\n".join(evidence)
        format_instructions = self.parser.get_format_instructions()

        for attempt in range(2):
            prompt = RESEARCH_PROMPT.format_messages(
                memory_context=self._memory_context(ticker),
                history=self._history_messages(),
                ticker=ticker,
                research_context=research_context,
                format_instructions=format_instructions,
            )
            if attempt == 1:
                prompt.append(HumanMessage(
                    content=(
                        "Correct your previous response. Output ONLY valid JSON matching the schema. "
                        "Do not add markdown fences or commentary."
                    )
                ))
            try:
                raw = self.llm.invoke(prompt)
                content = raw.content if isinstance(raw.content, str) else json.dumps(raw.content)
                result = self.parser.parse(content)
                self._remember(f"Research {ticker}", result.model_dump_json())
                return result
            except Exception as exc:
                last_error = exc
                continue
        return f"Structured research parsing failed after one corrective retry: {last_error}"

    def handle(self, user_text: str) -> str:
        text = user_text.strip()
        lower = text.lower()
        if not text:
            return "Please enter a request."

        # Explicit memory actions.
        if lower.startswith("remember that "):
            return self.add_memory(text[len("remember that "):].strip())
        if lower in {"list watchlist", "show watchlist", "what companies do i track", "my watchlist"}:
            answer = self._call_tool("list_watchlist")
            self._remember(text, answer)
            return answer
        if "add" in lower and "watchlist" in lower:
            ticker = self._extract_ticker(text)
            if not ticker:
                return "Please provide a ticker, for example: Add AAPL to my watchlist."
            answer = self._call_tool("add_to_watchlist", ticker=ticker)
            self._remember(text, answer)
            return answer

        # Structured research route.
        if any(word in lower for word in ["structured summary", "research summary", "return json", "research "]):
            ticker = self._extract_ticker(text)
            if not ticker:
                # Last-resort extraction for phrases such as "Research AAPL".
                match = re.search(r"\bresearch\s+\$?([A-Za-z]{1,5})\b", text, re.I)
                ticker = match.group(1).upper() if match else None
            if ticker:
                result = self.research(ticker)
                return result.model_dump_json(indent=2) if isinstance(result, ResearchSummary) else result

        # External tool routing.
        ticker = self._extract_ticker(text)
        if any(k in lower for k in ["latest price", "stock price", "closing price", "share price"]):
            if not ticker:
                return "Please provide a ticker, for example: What is the latest price of MSFT?"
            answer = self._call_tool("get_stock_price", ticker=ticker)
            self._remember(text, answer)
            return answer
        if any(k in lower for k in ["latest news", "recent news", "headlines", "recent headlines"]):
            if not ticker:
                return "Please provide a ticker, for example: Give me the latest news for AAPL."
            answer = self._call_tool("get_stock_news", ticker=ticker)
            self._remember(text, answer)
            return answer
        if "wikipedia" in lower or lower.startswith("what is ") or "background" in lower:
            topic = text
            answer = self._call_tool("search_wikipedia", topic=topic)
            self._remember(text, answer)
            return answer

        # Position-size route. Input is intentionally strict to reject negative values.
        if "position size" in lower:
            nums = re.findall(r"-?\d+(?:\.\d+)?", text)
            if len(nums) >= 4:
                capital, risk_pct, entry, stop = map(float, nums[:4])
                answer = self._call_tool(
                    "calculate_position_size",
                    capital=capital,
                    risk_pct=risk_pct,
                    entry=entry,
                    stop=stop,
                )
                self._remember(text, answer)
                return answer
            return "Provide capital, risk %, entry, and stop. Example: capital 100000, risk 1%, entry 200, stop 190."

        # Default direct response with memory + session context.
        return self._invoke_direct(text)

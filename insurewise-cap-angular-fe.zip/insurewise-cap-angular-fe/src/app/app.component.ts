import { Component } from '@angular/core';

@Component({
  selector: 'iw-root',
  template: `
    <main class="blank-shell" aria-label="InsureWise scaffold">
      <h1>InsureWise</h1>
    </main>
  `,
})
export class AppComponent {}
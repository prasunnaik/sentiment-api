ALTER TABLE application_documents
    ADD COLUMN IF NOT EXISTS file_size BIGINT;

UPDATE application_documents
SET file_size = 0
WHERE file_size IS NULL;

ALTER TABLE application_documents
    ALTER COLUMN file_size SET NOT NULL;

ALTER TABLE application_documents
    ADD COLUMN IF NOT EXISTS uploaded_at TIMESTAMP;

UPDATE application_documents
SET uploaded_at = created_at
WHERE uploaded_at IS NULL;

ALTER TABLE application_documents
    ALTER COLUMN uploaded_at SET NOT NULL;

ALTER TABLE application_documents
    ALTER COLUMN uploaded_at SET DEFAULT now();

ALTER TABLE application_documents
    DROP COLUMN IF EXISTS created_at;

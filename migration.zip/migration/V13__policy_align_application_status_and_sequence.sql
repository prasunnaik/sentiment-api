CREATE SEQUENCE IF NOT EXISTS application_code_seq START WITH 1000 INCREMENT BY 1;

ALTER TABLE policy_applications
    DROP CONSTRAINT IF EXISTS ck_applications_status;

ALTER TABLE policy_applications
    ADD CONSTRAINT ck_applications_status
        CHECK (status IN ('PENDING', 'APPROVED', 'REJECTED'));

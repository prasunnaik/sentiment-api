package com.insurewise.common.security;

import java.util.UUID;

public record JwtPrincipal(UUID userId, JwtRole role, String email) {}

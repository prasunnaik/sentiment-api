package com.insurewise.common.security;

import java.time.Duration;
import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties("insurewise.security")
public record SecurityProperties(
        String issuer,
        String jwtSecret,
        Duration tokenTtl
) {}

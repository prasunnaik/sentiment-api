package com.insurewise.policy.entity;

public enum NomineeRelationship {
    SPOUSE,
    PARENT,
    CHILD,
    SIBLING,
    OTHER
}

package com.insurewise.policy.entity;

public enum CoverageType {
    SINGLE,
    GROUP
}

package com.insurewise.auth.exception;

import java.util.UUID;

public class StaffUserNotFoundException extends RuntimeException {

    public StaffUserNotFoundException(UUID id) {
        super("Staff user not found: " + id);
    }
}
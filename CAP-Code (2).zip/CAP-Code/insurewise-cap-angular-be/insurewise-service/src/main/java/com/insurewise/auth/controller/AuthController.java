package com.insurewise.auth.controller;

import com.insurewise.auth.dto.request.CustomerLoginRequest;
import com.insurewise.auth.dto.request.CustomerRegistrationRequest;
import com.insurewise.auth.dto.request.StaffLoginRequest;
import com.insurewise.auth.dto.response.AuthResponse;
import com.insurewise.auth.service.AuthService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/auth")
public class AuthController {
    private final AuthService authService;

    public AuthController(AuthService authService) {
        this.authService = authService;
    }

    @PostMapping("/customers")
    public ResponseEntity<AuthResponse> registerCustomer(
            @Valid @RequestBody CustomerRegistrationRequest request) {
        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(authService.registerCustomer(request));
    }

    @PostMapping("/customers/login")
    public AuthResponse loginCustomer(
            @Valid @RequestBody CustomerLoginRequest request) {
        return authService.loginCustomer(request);
    }

    @PostMapping("/staff/login")
    public AuthResponse loginStaff(
            @Valid @RequestBody StaffLoginRequest request) {
        return authService.loginStaff(request);
    }
}

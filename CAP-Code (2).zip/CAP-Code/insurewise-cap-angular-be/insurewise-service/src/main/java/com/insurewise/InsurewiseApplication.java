package com.insurewise;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;

@SpringBootApplication
@ConfigurationPropertiesScan
public class InsurewiseApplication {

    public static void main(String[] args) {
        SpringApplication.run(InsurewiseApplication.class, args);
    }
}

package com.insurewise.auth.dto.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.UUID;

public record CustomerProfileResponse(
        UUID id,

        @JsonProperty("full_name")
        String fullName,

        String phone,
        String email
) {
}

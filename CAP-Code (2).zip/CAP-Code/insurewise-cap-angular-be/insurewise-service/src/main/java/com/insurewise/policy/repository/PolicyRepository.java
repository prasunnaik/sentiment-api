package com.insurewise.policy.repository;

import com.insurewise.policy.entity.Policy;
import com.insurewise.policy.entity.PolicyStatus;
import java.util.List;
import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PolicyRepository extends JpaRepository<Policy, UUID> {
    List<Policy> findAllByStatusOrderByCreatedAtDesc(PolicyStatus status);
    long countByStatus(
            com.insurewise.policy.entity.PolicyStatus status);
}



package com.insurewise.common.security;

public enum JwtRole {
    CUSTOMER,
    STAFF
}

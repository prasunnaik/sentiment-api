package com.insurewise.policy.exception;

public class DuplicatePendingApplicationException
        extends RuntimeException {

    public DuplicatePendingApplicationException() {
        super("A pending application already exists for this policy");
    }
}

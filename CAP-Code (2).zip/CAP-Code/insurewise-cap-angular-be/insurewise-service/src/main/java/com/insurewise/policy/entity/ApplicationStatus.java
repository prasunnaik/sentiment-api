package com.insurewise.policy.entity;

public enum ApplicationStatus {
    PENDING,
    ACTIVE,
    REJECTED,
    EXPIRED
}

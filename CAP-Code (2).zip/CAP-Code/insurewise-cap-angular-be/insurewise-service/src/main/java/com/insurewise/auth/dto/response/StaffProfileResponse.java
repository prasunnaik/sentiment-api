package com.insurewise.auth.dto.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.UUID;

public record StaffProfileResponse(
        UUID id,

        @JsonProperty("full_name")
        String fullName,

        String email,
        String address
) {
}

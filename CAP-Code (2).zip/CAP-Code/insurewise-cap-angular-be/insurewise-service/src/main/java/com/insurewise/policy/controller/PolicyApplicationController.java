package com.insurewise.policy.controller;

import com.insurewise.common.security.JwtPrincipal;
import com.insurewise.policy.dto.request.PolicyApplicationCreateRequest;
import com.insurewise.policy.dto.response.*;
import com.insurewise.policy.entity.ApplicationStatus;
import com.insurewise.policy.service.PolicyApplicationService;
import jakarta.validation.Valid;
import java.util.List;
import java.util.UUID;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/applications")
public class PolicyApplicationController {
    private final PolicyApplicationService service;

    public PolicyApplicationController(
            PolicyApplicationService service) {
        this.service = service;
    }

    @PostMapping
    @PreAuthorize("hasRole('CUSTOMER')")
    public PolicyApplicationResponse create(
            @AuthenticationPrincipal JwtPrincipal principal,
            @Valid @RequestBody PolicyApplicationCreateRequest request) {
        return service.createApplication(principal.userId(), request);
    }

    @GetMapping
    @PreAuthorize("hasAnyRole('CUSTOMER', 'STAFF')")
    public List<PolicyApplicationResponse> list(
            @AuthenticationPrincipal JwtPrincipal principal,
            @RequestParam(required = false) ApplicationStatus status) {
        return service.listApplications(principal, status);
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('CUSTOMER', 'STAFF')")
    public PolicyApplicationResponse get(
            @AuthenticationPrincipal JwtPrincipal principal,
            @PathVariable UUID id) {
        return service.getApplication(principal, id);
    }

    @PutMapping("/{id}/approve")
    @PreAuthorize("hasRole('STAFF')")
    public ApplicationDecisionResponse approve(
            @AuthenticationPrincipal JwtPrincipal principal,
            @PathVariable UUID id) {
        return service.approveApplication(principal.userId(), id);
    }

    @PutMapping("/{id}/reject")
    @PreAuthorize("hasRole('STAFF')")
    public ApplicationDecisionResponse reject(
            @AuthenticationPrincipal JwtPrincipal principal,
            @PathVariable UUID id) {
        return service.rejectApplication(principal.userId(), id);
    }
}

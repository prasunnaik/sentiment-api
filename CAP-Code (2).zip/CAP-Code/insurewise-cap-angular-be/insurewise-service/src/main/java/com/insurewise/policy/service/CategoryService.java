package com.insurewise.policy.service;

import com.insurewise.policy.dto.request.CategoryCreateRequest;
import com.insurewise.policy.dto.request.CategoryUpdateRequest;
import com.insurewise.policy.dto.response.CategoryResponse;
import com.insurewise.policy.entity.Category;
import com.insurewise.policy.repository.CategoryRepository;
import java.util.List;
import java.util.UUID;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.insurewise.policy.exception.CategoryNotFoundException;

@Service
@Transactional
public class CategoryService {
    private final CategoryRepository repository;

    public CategoryService(CategoryRepository repository) {
        this.repository = repository;
    }

    public CategoryResponse create(CategoryCreateRequest request) {

        try {
            Category category = repository.save(new Category(
                    request.name(),
                    request.description(),
                    request.status()));

            return toResponse(category);

        } catch (Exception exception) {
            System.err.println(
                    "Error in CategoryService.create: "
                            + exception.getMessage());
            throw exception;
        }
    }

    @Transactional(readOnly = true)
    public List<CategoryResponse> list() {

        try {
            return repository.findAll()
                    .stream()
                    .map(this::toResponse)
                    .toList();

        } catch (Exception exception) {
            System.err.println(
                    "Error in CategoryService.list: "
                            + exception.getMessage());
            throw exception;
        }
    }

    public CategoryResponse update(
            UUID id,
            CategoryUpdateRequest request) {

        try {
            Category category = find(id);

            category.update(
                    request.name(),
                    request.description(),
                    request.status());

            return toResponse(category);

        } catch (Exception exception) {
            System.err.println(
                    "Error in CategoryService.update: "
                            + exception.getMessage());
            throw exception;
        }
    }

    public void delete(UUID id) {

        try {
            repository.delete(find(id));

        } catch (Exception exception) {
            System.err.println(
                    "Error in CategoryService.delete: "
                            + exception.getMessage());
            throw exception;
        }
    }

    public Category find(UUID id) {
        return repository.findById(id)
                .orElseThrow(() -> new CategoryNotFoundException(id));
    }

    private CategoryResponse toResponse(Category category) {
        return new CategoryResponse(
                category.getId(),
                category.getName(),
                category.getDescription(),
                category.getStatus());
    }
}

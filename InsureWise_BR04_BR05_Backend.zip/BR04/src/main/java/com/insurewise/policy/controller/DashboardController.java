package com.insurewise.policy.controller;

import com.insurewise.policy.dto.response.DashboardMetricsResponse;
import com.insurewise.policy.service.DashboardService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/dashboard")
@PreAuthorize("hasRole('STAFF')")
public class DashboardController {
    private final DashboardService service;

    public DashboardController(DashboardService service) {
        this.service = service;
    }

    @GetMapping("/metrics")
    public DashboardMetricsResponse metrics() {
        return service.getMetrics();
    }
}

package com.insurewise.policy.dto.response;

public record DashboardMetricsResponse(
        long totalCustomers,
        long totalStaff,
        long totalCategories,
        long totalPolicies,
        long activePolicies,
        long totalApplications,
        long pendingApplications,
        long activeApplications,
        long totalClaims,
        long pendingClaims,
        long totalPayments,
        long successfulPayments
) {
}

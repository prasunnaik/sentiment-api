package com.insurewise.policy.entity;

public enum PolicyStatus {
    DRAFT,
    ACTIVE,
    INACTIVE
}

package com.insurewise.policy.service;

import com.insurewise.policy.dto.request.CategoryCreateRequest;
import com.insurewise.policy.dto.request.CategoryUpdateRequest;
import com.insurewise.policy.dto.response.CategoryResponse;
import com.insurewise.policy.entity.Category;
import com.insurewise.policy.repository.CategoryRepository;
import java.util.List;
import java.util.UUID;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.insurewise.policy.exception.CategoryNotFoundException;

@Service
@Transactional
public class CategoryService {
    private final CategoryRepository repository;

    public CategoryService(CategoryRepository repository) {
        this.repository = repository;
    }

    public CategoryResponse create(CategoryCreateRequest request) {
        Category category = repository.save(new Category(
                request.name(),
                request.description(),
                request.status()));

        return toResponse(category);
    }

    @Transactional(readOnly = true)
    public List<CategoryResponse> list() {
        return repository.findAll()
                .stream()
                .map(this::toResponse)
                .toList();
    }

    public CategoryResponse update(
            UUID id,
            CategoryUpdateRequest request) {
        Category category = find(id);

        category.update(
                request.name(),
                request.description(),
                request.status());

        return toResponse(category);
    }

    public void delete(UUID id) {
        repository.delete(find(id));
    }

    public Category find(UUID id) {
        return repository.findById(id)
                .orElseThrow(() -> new CategoryNotFoundException(id));
    }

    private CategoryResponse toResponse(Category category) {
        return new CategoryResponse(
                category.getId(),
                category.getName(),
                category.getDescription(),
                category.getStatus());
    }
}

package com.insurewise.policy.service;

import com.insurewise.policy.dto.request.PolicyCreateRequest;
import com.insurewise.policy.dto.request.PolicyUpdateRequest;
import com.insurewise.policy.dto.response.PolicyResponse;
import com.insurewise.policy.entity.Policy;
import com.insurewise.policy.entity.PolicyStatus;
import com.insurewise.policy.repository.PolicyRepository;
import java.util.List;
import java.util.UUID;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.insurewise.policy.exception.PolicyNotFoundException;

@Service
@Transactional
public class PolicyService {
    private final PolicyRepository policyRepository;
    private final CategoryService categoryService;

    public PolicyService(
            PolicyRepository policyRepository,
            CategoryService categoryService) {
        this.policyRepository = policyRepository;
        this.categoryService = categoryService;
    }

    public PolicyResponse create(PolicyCreateRequest request) {
        Policy policy = policyRepository.save(new Policy(
                request.name(),
                categoryService.find(request.categoryId()),
                request.coverageAmount(),
                request.premiumAmount(),
                request.durationLabel(),
                request.status()));

        return toResponse(policy);
    }

    @Transactional(readOnly = true)
    public List<PolicyResponse> listActive() {
        return policyRepository
                .findAllByStatusOrderByCreatedAtDesc(PolicyStatus.ACTIVE)
                .stream()
                .filter(Policy::isActiveForCustomer)
                .map(this::toResponse)
                .toList();
    }

    @Transactional(readOnly = true)
    public PolicyResponse get(UUID id) {
        return toResponse(find(id));
    }

    public PolicyResponse update(
            UUID id,
            PolicyUpdateRequest request) {
        Policy policy = find(id);

        policy.update(
                request.name(),
                categoryService.find(request.categoryId()),
                request.coverageAmount(),
                request.premiumAmount(),
                request.durationLabel(),
                request.status());

        return toResponse(policy);
    }

    public void delete(UUID id) {
        policyRepository.delete(find(id));
    }

    public Policy find(UUID id) {
        return policyRepository.findById(id)
                .orElseThrow(() -> new PolicyNotFoundException(id));
    }

    private PolicyResponse toResponse(Policy policy) {
        return new PolicyResponse(
                policy.getId(),
                policy.getName(),
                policy.getCategory().getId(),
                policy.getCategory().getName(),
                policy.getCoverageAmount(),
                policy.getPremiumAmount(),
                policy.getDurationLabel(),
                policy.getStatus());
    }
}




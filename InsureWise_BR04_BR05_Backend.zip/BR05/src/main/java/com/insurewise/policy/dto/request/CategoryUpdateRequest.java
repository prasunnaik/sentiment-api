package com.insurewise.policy.dto.request;

import com.insurewise.policy.entity.CategoryStatus;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public record CategoryUpdateRequest(
        @NotBlank
        @Size(max = 80)
        String name,

        @NotBlank
        @Size(max = 500)
        String description,

        @NotNull
        CategoryStatus status
) {
}

package com.insurewise.policy.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Table(name = "policy_applications")
public class PolicyApplication {
    @Id
    @GeneratedValue
    private UUID id;

    @Column(name = "application_code", nullable = false, unique = true, length = 40)
    private String applicationCode;

    @Column(name = "customer_id", nullable = false)
    private UUID customerId;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "policy_id", nullable = false)
    private Policy policy;

    @Enumerated(EnumType.STRING)
    @Column(name = "coverage_type", nullable = false, length = 20)
    private CoverageType coverageType;

    @Column(name = "coverage_amount", nullable = false, precision = 14, scale = 2)
    private BigDecimal coverageAmount;

    @Column(name = "premium_amount", nullable = false, precision = 10, scale = 2)
    private BigDecimal premiumAmount;

    @Column(name = "date_of_birth", nullable = false)
    private LocalDate dateOfBirth;

    @Column(nullable = false, length = 500)
    private String address;

    @Column(name = "preferred_start_date")
    private LocalDate preferredStartDate;

    @Column(name = "nominee_name", length = 120)
    private String nomineeName;

    @Enumerated(EnumType.STRING)
    @Column(name = "nominee_relationship", length = 20)
    private NomineeRelationship nomineeRelationship;

    @Column(name = "start_date")
    private LocalDate startDate;

    @Column(name = "end_date")
    private LocalDate endDate;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private ApplicationStatus status;

    @Column(name = "decided_by")
    private UUID decidedBy;

    @Column(name = "decided_at")
    private LocalDateTime decidedAt;

    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;

    protected PolicyApplication() {
    }

    public PolicyApplication(
            String applicationCode,
            UUID customerId,
            Policy policy,
            CoverageType coverageType,
            LocalDate dateOfBirth,
            String address,
            LocalDate preferredStartDate,
            String nomineeName,
            NomineeRelationship nomineeRelationship) {
        this.applicationCode = applicationCode;
        this.customerId = customerId;
        this.policy = policy;
        this.coverageType = coverageType;
        this.coverageAmount = policy.getCoverageAmount();
        this.premiumAmount = policy.getPremiumAmount();
        this.dateOfBirth = dateOfBirth;
        this.address = address;
        this.preferredStartDate = preferredStartDate;
        this.nomineeName = nomineeName;
        this.nomineeRelationship = nomineeRelationship;
        this.status = ApplicationStatus.PENDING;
    }

    @PrePersist
    void initialize() {
        if (createdAt == null) {
            createdAt = LocalDateTime.now();
        }
    }

    public void approve(
            UUID staffUserId,
            LocalDate startDate,
            LocalDate endDate) {
        ensurePending();
        this.status = ApplicationStatus.ACTIVE;
        this.decidedBy = staffUserId;
        this.decidedAt = LocalDateTime.now();
        this.startDate = startDate;
        this.endDate = endDate;
    }

    public void reject(UUID staffUserId) {
        ensurePending();
        this.status = ApplicationStatus.REJECTED;
        this.decidedBy = staffUserId;
        this.decidedAt = LocalDateTime.now();
    }

    private void ensurePending() {
        if (status != ApplicationStatus.PENDING) {
            throw new IllegalStateException(
                    "Only pending applications can be decided");
        }
    }

    public boolean isOwnedBy(UUID customerId) {
        return this.customerId.equals(customerId);
    }

    public boolean isActive() {
        return status == ApplicationStatus.ACTIVE;
    }

    public UUID getId() {
        return id;
    }

    public String getApplicationCode() {
        return applicationCode;
    }

    public UUID getCustomerId() {
        return customerId;
    }

    public Policy getPolicy() {
        return policy;
    }

    public CoverageType getCoverageType() {
        return coverageType;
    }

    public BigDecimal getCoverageAmount() {
        return coverageAmount;
    }

    public BigDecimal getPremiumAmount() {
        return premiumAmount;
    }

    public LocalDate getDateOfBirth() {
        return dateOfBirth;
    }

    public String getAddress() {
        return address;
    }

    public LocalDate getPreferredStartDate() {
        return preferredStartDate;
    }

    public String getNomineeName() {
        return nomineeName;
    }

    public NomineeRelationship getNomineeRelationship() {
        return nomineeRelationship;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public ApplicationStatus getStatus() {
        return status;
    }

    public UUID getDecidedBy() {
        return decidedBy;
    }

    public LocalDateTime getDecidedAt() {
        return decidedAt;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }
}
// Code Generated by Sidekick is for learning and experimentation purposes only.
// filename: src/main/java/com/insurewise/policy/entity/PolicyStatus.java

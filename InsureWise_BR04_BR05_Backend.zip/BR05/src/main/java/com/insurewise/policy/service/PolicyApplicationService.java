package com.insurewise.policy.service;

import com.insurewise.common.security.JwtPrincipal;
import com.insurewise.policy.dto.request.PolicyApplicationCreateRequest;
import com.insurewise.policy.dto.response.*;
import com.insurewise.policy.entity.*;
import com.insurewise.policy.exception.*;
import com.insurewise.policy.repository.PolicyApplicationRepository;
import java.time.LocalDate;
import java.time.Period;
import java.util.List;
import java.util.UUID;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


@Service
@Transactional
public class PolicyApplicationService {
    private final PolicyApplicationRepository applicationRepository;
    private final PolicyService policyService;

    public PolicyApplicationService(
            PolicyApplicationRepository applicationRepository,
            PolicyService policyService) {
        this.applicationRepository = applicationRepository;
        this.policyService = policyService;
    }

    public PolicyApplicationResponse createApplication(
            UUID customerId,
            PolicyApplicationCreateRequest request) {

        Policy policy = policyService.find(request.policyId());

        if (!policy.isActiveForCustomer()) {
            throw new ApplicationStateException(
                    "Applications can only be created for active policies");
        }

        boolean duplicate = applicationRepository
                .existsByCustomerIdAndPolicyIdAndStatus(
                        customerId,
                        request.policyId(),
                        ApplicationStatus.PENDING);

        if (duplicate) {
            throw new DuplicatePendingApplicationException();
        }

        Long sequence = applicationRepository.nextApplicationCodeSequence();

        PolicyApplication application = new PolicyApplication(
                "APP-" + sequence,
                customerId,
                policy,
                request.coverageType(),
                request.dateOfBirth(),
                request.address(),
                request.preferredStartDate(),
                request.nomineeName(),
                request.nomineeRelationship());

        return toResponse(applicationRepository.save(application));
    }

    @Transactional(readOnly = true)
    public List<PolicyApplicationResponse> listApplications(
            JwtPrincipal principal,
            ApplicationStatus status) {

        List<PolicyApplication> applications;

        if (principal.role().name().equals("STAFF")) {
            applications = status == null
                    ? applicationRepository.findAll()
                    : applicationRepository.findByStatusOrderByCreatedAtDesc(
                    status);
        } else {
            applications = status == null
                    ? applicationRepository
                    .findByCustomerIdOrderByCreatedAtDesc(
                            principal.userId())
                    : applicationRepository
                    .findByCustomerIdAndStatusOrderByCreatedAtDesc(
                            principal.userId(),
                            status);
        }

        return applications.stream()
                .map(this::toResponse)
                .toList();
    }

    @Transactional(readOnly = true)
    public PolicyApplicationResponse getApplication(
            JwtPrincipal principal,
            UUID applicationId) {

        PolicyApplication application = getApplicationEntity(applicationId);

        if (principal.role().name().equals("CUSTOMER")
                && !application.isOwnedBy(principal.userId())) {
            throw new ApplicationNotFoundException(applicationId);
        }

        return toResponse(application);
    }

    public ApplicationDecisionResponse approveApplication(
            UUID staffUserId,
            UUID applicationId) {

        PolicyApplication application = getApplicationEntity(applicationId);
        LocalDate startDate = application.getPreferredStartDate() == null
                ? LocalDate.now()
                : application.getPreferredStartDate();

        LocalDate endDate = calculateEndDate(
                startDate,
                application.getPolicy().getDurationLabel());

        application.approve(staffUserId, startDate, endDate);

        return toDecisionResponse(application);
    }

    public ApplicationDecisionResponse rejectApplication(
            UUID staffUserId,
            UUID applicationId) {

        PolicyApplication application = getApplicationEntity(applicationId);
        application.reject(staffUserId);

        return toDecisionResponse(application);
    }

    public PolicyApplication getApplicationEntityForInternalUse(
            UUID applicationId) {
        return getApplicationEntity(applicationId);
    }

    private PolicyApplication getApplicationEntity(UUID applicationId) {
        return applicationRepository.findById(applicationId)
                .orElseThrow(() -> new ApplicationNotFoundException(
                        applicationId));
    }

    private LocalDate calculateEndDate(
            LocalDate startDate,
            String durationLabel) {

        String digits = durationLabel.replaceAll("[^0-9]", "");

        if (!digits.isBlank()) {
            int years = Integer.parseInt(digits);
            return startDate.plusYears(Math.max(years, 1));
        }

        return startDate.plusYears(1);
    }

    private PolicyApplicationResponse toResponse(
            PolicyApplication application) {

        return new PolicyApplicationResponse(
                application.getId(),
                application.getApplicationCode(),
                application.getCustomerId(),
                application.getPolicy().getId(),
                application.getPolicy().getName(),
                application.getCoverageType(),
                application.getCoverageAmount(),
                application.getPremiumAmount(),
                application.getDateOfBirth(),
                application.getAddress(),
                application.getPreferredStartDate(),
                application.getNomineeName(),
                application.getNomineeRelationship(),
                application.getStartDate(),
                application.getEndDate(),
                application.getStatus(),
                application.getDecidedBy(),
                application.getDecidedAt(),
                application.getCreatedAt());
    }

    private ApplicationDecisionResponse toDecisionResponse(
            PolicyApplication application) {

        return new ApplicationDecisionResponse(
                application.getId(),
                application.getApplicationCode(),
                application.getStatus(),
                application.getStartDate(),
                application.getEndDate(),
                application.getDecidedBy());
    }
}
// Code Generated by Sidekick is for learning and experimentation purposes only.
// filename: src/main/java/com/insurewise/policy/service/PolicyService.java

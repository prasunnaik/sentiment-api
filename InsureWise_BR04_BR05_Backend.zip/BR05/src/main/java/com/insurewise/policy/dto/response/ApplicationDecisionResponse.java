package com.insurewise.policy.dto.response;

import com.insurewise.policy.entity.ApplicationStatus;
import java.time.LocalDate;
import java.util.UUID;

public record ApplicationDecisionResponse(
        UUID applicationId,
        String applicationCode,
        ApplicationStatus status,
        LocalDate startDate,
        LocalDate endDate,
        UUID decidedBy
) {
}

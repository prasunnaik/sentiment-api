InsureWise Backend — BR04 and BR05

Source: exact code extracted from the uploaded backend code dump (Pasted text(20260910-141308).txt).
No frontend code is included. No business logic was invented or rewritten.

BR04 — Dashboard + Staff User Management
- auth/controller/StaffUserManagementController.java
- auth/dto/request/StaffCreateRequest.java
- auth/dto/request/StaffUpdateRequest.java
- auth/dto/response/StaffProfileResponse.java
- auth/service/StaffUserService.java
- auth/exception/StaffUserNotFoundException.java
- policy/controller/DashboardController.java
- policy/dto/response/DashboardMetricsResponse.java
- policy/service/DashboardService.java

BR05 — Add Policy + Approve Policies
- policy/controller/CategoryController.java
- policy/controller/PolicyController.java
- policy/controller/PolicyApplicationController.java
- policy/dto/request/CategoryCreateRequest.java
- policy/dto/request/CategoryUpdateRequest.java
- policy/dto/request/PolicyCreateRequest.java
- policy/dto/request/PolicyUpdateRequest.java
- policy/dto/request/PolicyApplicationCreateRequest.java
- policy/dto/response/CategoryResponse.java
- policy/dto/response/PolicyResponse.java
- policy/dto/response/PolicyApplicationResponse.java
- policy/dto/response/ApplicationDecisionResponse.java
- policy/entity/Category.java
- policy/entity/CategoryStatus.java
- policy/entity/CoverageType.java
- policy/entity/Policy.java
- policy/entity/PolicyStatus.java
- policy/entity/ApplicationStatus.java
- policy/entity/NomineeRelationship.java
- policy/entity/PolicyApplication.java
- policy/exception/CategoryNotFoundException.java
- policy/exception/PolicyNotFoundException.java
- policy/exception/ApplicationNotFoundException.java
- policy/exception/ApplicationStateException.java
- policy/exception/DuplicatePendingApplicationException.java
- policy/repository/CategoryRepository.java
- policy/repository/PolicyRepository.java
- policy/repository/PolicyApplicationRepository.java
- policy/service/CategoryService.java
- policy/service/PolicyService.java
- policy/service/PolicyApplicationService.java

Important merge note:
These are feature files only. Shared/common files used by these classes (for example security, common DTO/exception handling, and repositories/entities owned by other BRs) are intentionally not duplicated here, so they do not create unnecessary duplicate ownership.

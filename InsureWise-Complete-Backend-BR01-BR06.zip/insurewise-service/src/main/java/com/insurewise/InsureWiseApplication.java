package com.insurewise;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication
public class InsureWiseApplication { public static void main(String[] args){ SpringApplication.run(InsureWiseApplication.class,args); } }

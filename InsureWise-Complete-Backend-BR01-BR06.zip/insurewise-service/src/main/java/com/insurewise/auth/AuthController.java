package com.insurewise.auth;
import com.insurewise.security.*; import jakarta.validation.constraints.*; import org.springframework.jdbc.core.JdbcTemplate; import org.springframework.web.bind.annotation.*; import java.util.*;
@RestController @RequestMapping("/api/auth") public class AuthController {
 private final JdbcTemplate db; private final Passwords passwords; private final JwtService jwt;
 public AuthController(JdbcTemplate db,Passwords passwords,JwtService jwt){this.db=db;this.passwords=passwords;this.jwt=jwt;}
 record CustomerSignup(@NotBlank @Size(max=120) String fullName,@NotBlank @Size(max=30) String phone,@NotBlank @Email @Size(max=160) String email,@NotBlank @Size(min=8,max=72) String password){}
 record Login(@NotBlank @Email String email,@NotBlank String password){}
 record AuthResponse(String token,String role,UUID userId,String fullName,String email){}
 @PostMapping("/customer/signup") AuthResponse signup(@jakarta.validation.Valid @RequestBody CustomerSignup r){String e=r.email().trim().toLowerCase(); if(count("customers",e)>0)throw new IllegalStateException("Email is already registered."); UUID id=db.queryForObject("INSERT INTO customers(full_name,phone,email,password_hash) VALUES(?,?,?,?) RETURNING id",UUID.class,r.fullName().trim(),r.phone().trim(),e,passwords.hash(r.password()));return response(id,"CUSTOMER",r.fullName().trim(),e);}
 @PostMapping("/customer/login") AuthResponse customer(@jakarta.validation.Valid @RequestBody Login r){return login("customers",r.email(),r.password(),"CUSTOMER");}
 @PostMapping("/staff/login") AuthResponse staff(@jakarta.validation.Valid @RequestBody Login r){return login("staff_users",r.email(),r.password(),"STAFF");}
 @GetMapping("/me") Map<String,Object> me(){var t=CurrentUser.get(); return Map.of("userId",t.id(),"role",t.role(),"email",t.email());}
 private AuthResponse login(String table,String email,String raw,String role){String e=email.trim().toLowerCase();var rows=db.query("SELECT id,full_name,password_hash FROM "+table+" WHERE lower(email)=lower(?)",(rs,n)->new Object[]{rs.getObject("id",UUID.class),rs.getString("full_name"),rs.getString("password_hash")},e);if(rows.isEmpty()||!passwords.matches(raw,(String)rows.get(0)[2]))throw new org.springframework.web.server.ResponseStatusException(org.springframework.http.HttpStatus.UNAUTHORIZED,"Invalid email or password.");return response((UUID)rows.get(0)[0],role,(String)rows.get(0)[1],e);}
 private AuthResponse response(UUID id,String role,String name,String email){return new AuthResponse(jwt.issue(id,role,email),role,id,name,email);}
 private int count(String table,String email){return db.queryForObject("SELECT count(*) FROM "+table+" WHERE lower(email)=lower(?)",Integer.class,email);}
}

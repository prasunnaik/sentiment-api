package com.insurewise.security;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder; import org.springframework.stereotype.Component;
@Component public class Passwords { private final BCryptPasswordEncoder encoder=new BCryptPasswordEncoder(); public String hash(String s){return encoder.encode(s);} public boolean matches(String raw,String hash){return encoder.matches(raw,hash);} }

package com.insurewise.security; public final class Auth { private Auth(){} }

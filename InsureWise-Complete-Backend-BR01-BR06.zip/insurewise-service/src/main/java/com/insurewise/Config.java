package com.insurewise;
import com.insurewise.security.JwtFilter; import org.springframework.context.annotation.*; import org.springframework.security.config.annotation.web.builders.HttpSecurity; import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder; import org.springframework.security.web.SecurityFilterChain; import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
@Configuration public class Config {
 @Bean SecurityFilterChain security(HttpSecurity http,JwtFilter filter)throws Exception{http.csrf(c->c.disable()).cors(c->{}).authorizeHttpRequests(a->a.requestMatchers("/api/auth/**","/actuator/health","/error").permitAll().requestMatchers("/api/staff/**").hasRole("STAFF").requestMatchers("/api/customer/**").hasRole("CUSTOMER").anyRequest().authenticated()).addFilterBefore(filter,UsernamePasswordAuthenticationFilter.class);return http.build();}
 @Bean BCryptPasswordEncoder passwordEncoder(){return new BCryptPasswordEncoder();}
 @Bean org.springframework.web.servlet.config.annotation.WebMvcConfigurer cors(){return new org.springframework.web.servlet.config.annotation.WebMvcConfigurer(){public void addCorsMappings(org.springframework.web.servlet.config.annotation.CorsRegistry r){r.addMapping("/**").allowedOrigins("http://localhost:4200").allowedMethods("GET","POST","PUT","DELETE","OPTIONS").allowedHeaders("*");}};}
}

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map, tap } from 'rxjs/operators';

import { API_CONFIG } from '../../core/environment/api.config';

import {
  Policy,
  PolicyCreateRequest,
  Category
} from '../../types/br04-05.types';

@Injectable({
  providedIn: 'root'
})
export class PolicyApiService {

  private readonly policyUrl =
    `${API_CONFIG.baseUrl}/api/policies`;

  private readonly categoryUrl =
    `${API_CONFIG.baseUrl}/api/categories`;

  private readonly staffPolicyCacheKey =
    'insurewise.staff.policies';

  constructor(
    private readonly http: HttpClient
  ) {}

  /**
   * GET /api/policies
   */
  getAll(): Observable<Policy[]> {
    return this.http.get<Policy[]>(
      this.policyUrl
    );
  }

  /**
   * GET /api/policies
   * The backend policy list returns customer-eligible active policies only.
   * Staff screens merge locally known inactive policies so edits do not disappear from the UI.
   */
  getAllForStaff(): Observable<Policy[]> {
    return this.http.get<Policy[]>(
      this.policyUrl
    ).pipe(
      map((policies: Policy[]) =>
        this.mergeWithCachedPolicies(policies)
      ),
      tap((policies: Policy[]) =>
        this.writeCachedPolicies(policies)
      )
    );
  }

  /**
   * POST /api/policies
   */
  create(
    request: PolicyCreateRequest
  ): Observable<Policy> {
    return this.http.post<Policy>(
      this.policyUrl,
      request
    ).pipe(
      tap((policy: Policy) =>
        this.cachePolicy(policy)
      )
    );
  }

  /**
   * PUT /api/policies/{id}
   */
  update(
    id: string,
    request: PolicyCreateRequest
  ): Observable<Policy> {
    return this.http.put<Policy>(
      `${this.policyUrl}/${id}`,
      request
    ).pipe(
      tap((policy: Policy) =>
        this.cachePolicy(policy)
      )
    );
  }

  /**
   * DELETE /api/policies/{id}
   */
  delete(id: string): Observable<void> {
    return this.http.delete<void>(
      `${this.policyUrl}/${id}`
    ).pipe(
      tap(() =>
        this.removeCachedPolicy(id)
      )
    );
  }

  /**
   * GET /api/categories
   */
  getCategories(): Observable<Category[]> {
    return this.http.get<Category[]>(
      this.categoryUrl
    );
  }

  private mergeWithCachedPolicies(
    policies: Policy[]
  ): Policy[] {

    const mergedPolicies =
      new Map<string, Policy>();

    this.readCachedPolicies().forEach(
      (policy: Policy) =>
        mergedPolicies.set(
          policy.id,
          policy
        )
    );

    policies.forEach(
      (policy: Policy) =>
        mergedPolicies.set(
          policy.id,
          policy
        )
    );

    return Array.from(
      mergedPolicies.values()
    );
  }

  private cachePolicy(policy: Policy): void {

    this.writeCachedPolicies(
      this.mergeWithCachedPolicies([
        policy
      ])
    );
  }

  private removeCachedPolicy(id: string): void {

    this.writeCachedPolicies(
      this.readCachedPolicies().filter(
        (policy: Policy) =>
          policy.id !== id
      )
    );
  }

  private readCachedPolicies(): Policy[] {

    try {

      const storedPolicies =
        localStorage.getItem(
          this.staffPolicyCacheKey
        );

      if (!storedPolicies) {
        return [];
      }

      const policies =
        JSON.parse(storedPolicies);

      return Array.isArray(policies)
        ? policies
        : [];

    } catch (error: unknown) {

      console.warn(
        'Unable to read cached staff policies.',
        error
      );

      return [];
    }
  }

  private writeCachedPolicies(
    policies: Policy[]
  ): void {

    try {

      localStorage.setItem(
        this.staffPolicyCacheKey,
        JSON.stringify(policies)
      );

    } catch (error: unknown) {

      console.warn(
        'Unable to cache staff policies.',
        error
      );
    }
  }
}
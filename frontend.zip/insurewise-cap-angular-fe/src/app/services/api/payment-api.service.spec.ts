import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';

import { API_CONFIG } from '../../core/environment/api.config';
import { PaymentApiService } from './payment-api.service';

describe('PaymentApiService', () => {
  let service: PaymentApiService;
  let http: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [provideHttpClient(), provideHttpClientTesting()]
    });
    service = TestBed.inject(PaymentApiService);
    http = TestBed.inject(HttpTestingController);
  });

  afterEach(() => http.verify());

  it('maps the backend data and pagination envelope', () => {
    service.list().subscribe(page => {
      expect(page.items).toHaveLength(1);
      expect(page.total).toBe(1);
      expect(page.items[0]).toEqual(expect.objectContaining({
        id: 'payment-1',
        policyName: 'Health Policy',
        amount: 5000,
        status: 'SUCCESS',
        transactionRef: 'TXN-1000'
      }));
    });

    http.expectOne(request => request.url === `${API_CONFIG.baseUrl}/api/payments`).flush({
      data: [{
        id: 'payment-1',
        policy_application_id: 'application-1',
        policy_name: 'Health Policy',
        amount: '5000',
        method: 'upi',
        status: 'success',
        transaction_ref: 'TXN-1000'
      }],
      pagination: { limit: 50, offset: 0, total: 1, hasMore: false }
    });
  });

  it('maps staff payment summary aliases', () => {
    service.getSummary().subscribe(summary => {
      expect(summary).toEqual({
        totalRevenue: 5000,
        successfulPayments: 1,
        failedPayments: 0,
        pendingPayments: 0
      });
    });

    http.expectOne(`${API_CONFIG.baseUrl}/api/payments/summary`).flush({
      total_revenue: '5000',
      successful_payments: 1,
      failed_payments: 0,
      pending_payments: 0
    });
  });
});
import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpParams } from '@angular/common/http';
import { map, Observable } from 'rxjs';

import { API_CONFIG } from '../../core/environment/api.config';
import {
  Payment,
  PaymentCreateRequest,
  PaymentDocument,
  PaymentSummary,
  PageResponse
} from '../../types/br04-05.types';

@Injectable({ providedIn: 'root' })
export class PaymentApiService {

  private readonly url = `${API_CONFIG.baseUrl}/api/payments`;

  constructor(private readonly http: HttpClient) {}

  list(status?: string, limit = 50, offset = 0): Observable<PageResponse<Payment>> {
    let params = new HttpParams().set('limit', limit).set('offset', offset);
    if (status) {
      params = params.set('status', status);
    }
    return this.http.get<unknown>(this.url, { params }).pipe(
      map(response => this.normalizePage(response, limit, offset))
    );
  }

  getById(id: string): Observable<Payment> {
    return this.http.get<Payment>(`${this.url}/${id}`);
  }

  getSummary(): Observable<PaymentSummary> {
    return this.http.get<unknown>(`${this.url}/summary`).pipe(
      map(response => this.normalizeSummary(response))
    );
  }

  makePayment(request: PaymentCreateRequest): Observable<Payment> {
    return this.http.post<Payment>(this.url, request);
  }

  listDocuments(paymentId: string): Observable<PaymentDocument[]> {
    return this.http.get<PaymentDocument[]>(`${this.url}/${paymentId}/documents`);
  }

  uploadDocument(paymentId: string, file: File): Observable<PaymentDocument> {
    const data = new FormData();
    data.append('file', file);
    return this.http.post<PaymentDocument>(`${this.url}/${paymentId}/documents`, data);
  }

  deleteDocument(paymentId: string, documentId: string): Observable<void> {
    return this.http.delete<void>(`${this.url}/${paymentId}/documents/${documentId}`);
  }

  errorMessage(error: unknown, action: 'receipt'): string {
    if (!(error instanceof HttpErrorResponse)) {
      return `Unable to load the payment ${action}. Try again.`;
    }

    const backendMessage = typeof error.error?.message === 'string' ? error.error.message : null;
    switch (error.status) {
      case 401:
        return 'Your session has expired. Sign in again.';
      case 403:
        return 'You are not authorized to view this receipt.';
      case 404:
        return 'The receipt endpoint or payment could not be found.';
      case 500:
        return backendMessage ?? 'The receipt service is unavailable. Try again later.';
      default:
        return backendMessage ?? `Unable to load the payment ${action}. Try again.`;
    }
  }

  private normalizePage(response: unknown, limit: number, offset: number): PageResponse<Payment> {
    const page = response as {
      items?: unknown[];
      data?: unknown[];
      content?: unknown[];
      total?: number;
      limit?: number;
      offset?: number;
      pagination?: { total?: number; limit?: number; offset?: number };
    };
    const rawPayments = Array.isArray(response)
      ? response
      : page.items ?? page.data ?? page.content ?? [];

    return {
      items: rawPayments.map(payment => this.normalizePayment(payment)),
      total: Number(page.total ?? page.pagination?.total ?? rawPayments.length),
      limit: Number(page.limit ?? page.pagination?.limit ?? limit),
      offset: Number(page.offset ?? page.pagination?.offset ?? offset)
    };
  }

  private normalizePayment(response: unknown): Payment {
    const payment = response as Partial<Payment> & {
      idempotency_key?: string;
      customer_id?: string;
      policy_application_id?: string;
      policy_name?: string;
      transaction_ref?: string;
      paid_at?: string;
      created_at?: string;
    };

    return {
      ...payment,
      id: String(payment.id ?? ''),
      idempotencyKey: payment.idempotencyKey ?? payment.idempotency_key,
      customerId: payment.customerId ?? payment.customer_id,
      policyApplicationId: String(payment.policyApplicationId ?? payment.policy_application_id ?? ''),
      policyName: payment.policyName ?? payment.policy_name,
      amount: Number(payment.amount ?? 0),
      method: String(payment.method ?? '').toUpperCase() as Payment['method'],
      status: String(payment.status ?? '').toUpperCase() as Payment['status'],
      transactionRef: payment.transactionRef ?? payment.transaction_ref,
      paidAt: payment.paidAt ?? payment.paid_at,
      createdAt: payment.createdAt ?? payment.created_at
    };
  }

  private normalizeSummary(response: unknown): PaymentSummary {
    const summary = response as Partial<PaymentSummary> & {
      total_revenue?: number | string;
      successful_payments?: number | string;
      failed_payments?: number | string;
      pending_payments?: number | string;
    };

    return {
      totalRevenue: Number(summary.totalRevenue ?? summary.total_revenue ?? 0),
      successfulPayments: Number(summary.successfulPayments ?? summary.successful_payments ?? 0),
      failedPayments: Number(summary.failedPayments ?? summary.failed_payments ?? 0),
      pendingPayments: Number(summary.pendingPayments ?? summary.pending_payments ?? 0)
    };
  }
}

import { TestBed } from '@angular/core/testing';
import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';

import { API_CONFIG } from '../../core/environment/api.config';
import { CustomerApiService } from './customer-api.service';

describe('CustomerApiService', () => {
  let service: CustomerApiService;
  let http: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [provideHttpClient(), provideHttpClientTesting()]
    });
    service = TestBed.inject(CustomerApiService);
    http = TestBed.inject(HttpTestingController);
  });

  afterEach(() => http.verify());

  it('treats a 204 profile-picture response as no picture', () => {
    service.getProfilePicture().subscribe(response => expect(response).toBeNull());
    http.expectOne(`${API_CONFIG.baseUrl}/auth/profile-picture`).flush(null, { status: 204, statusText: 'No Content' });
  });

  it('treats a 404 profile-picture response as no picture', () => {
    service.getProfilePicture().subscribe(response => expect(response).toBeNull());
    http.expectOne(`${API_CONFIG.baseUrl}/auth/profile-picture`).flush({}, { status: 404, statusText: 'Not Found' });
  });

  it('normalizes policy status and premium aliases without a profile request', () => {
    service.getApplications().subscribe(applications => {
      expect(applications[0].status).toBe('APPROVED');
      expect(applications[0].premiumAmount).toBe(500000);
      expect(applications[0].coverageAmount).toBe(1000000);
    });

    http.expectOne(`${API_CONFIG.baseUrl}/api/policy-applications`).flush([{
      id: 'application-1',
      application_status: 'approved',
      premium_amount: '500000',
      coverage_amount: '1000000'
    }]);
  });
});
import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpParams } from '@angular/common/http';
import { map, Observable } from 'rxjs';

import { API_CONFIG } from '../../core/environment/api.config';
import {
  Claim,
  ClaimCreateRequest,
  ClaimDetail,
  ClaimDocument,
  ClaimSubmission,
  ClaimDependent,
  DependentRequest,
  PageResponse,
  PresignedUrl
} from '../../types/br04-05.types';

@Injectable({ providedIn: 'root' })
export class ClaimApiService {

  private readonly url = `${API_CONFIG.baseUrl}/api/claims`;

  constructor(private readonly http: HttpClient) {}

  list(status?: string, limit = 50, offset = 0): Observable<PageResponse<Claim>> {
    let params = new HttpParams().set('limit', limit).set('offset', offset);
    if (status) {
      params = params.set('status', status);
    }
    return this.http.get<unknown>(this.url, { params }).pipe(
      map(response => this.normalizePage(response, limit, offset))
    );
  }

  getById(id: string): Observable<Claim> {
    return this.http.get<unknown>(`${this.url}/${id}`).pipe(
      map(response => this.normalizeClaim(response))
    );
  }

  getDetail(id: string): Observable<ClaimDetail> {
    return this.getById(id).pipe(
      map(claim => ({
        ...claim,
        claimCode: claim.claimCode ?? claim.id
      }))
    );
  }

  file(request: ClaimCreateRequest): Observable<Claim> {
    return this.http.post<Claim>(this.url, request);
  }

  fileWithDocument(request: ClaimCreateRequest, file: File): Observable<ClaimSubmission> {
    const data = new FormData();
    data.append('claim', new Blob([JSON.stringify(request)], { type: 'application/json' }));
    data.append('file', file, file.name);
    return this.http.post<ClaimSubmission>(`${this.url}/with-document`, data);
  }

  approve(id: string, remarks: string, file?: File): Observable<Claim>;
  approve(id: string, file?: File): Observable<Claim>;
  approve(id: string, remarksOrFile: string | File = '', file?: File): Observable<Claim> {
    const remarks = typeof remarksOrFile === 'string' ? remarksOrFile : '';
    const decisionFile = typeof remarksOrFile === 'string' ? file : remarksOrFile;
    if (!decisionFile) {
      return this.http.put<Claim>(`${this.url}/${id}/approve`, { remarks });
    }

    const data = new FormData();
    data.append('remarks', remarks);
    data.append('file', decisionFile, decisionFile.name);
    return this.http.put<Claim>(`${this.url}/${id}/approve`, data);
  }

  reject(id: string, remarks: string, file?: File): Observable<Claim> {
    if (!file) {
      return this.http.put<Claim>(`${this.url}/${id}/reject`, { remarks });
    }

    const data = new FormData();
    data.append('remarks', remarks);
    data.append('file', file, file.name);
    return this.http.put<Claim>(`${this.url}/${id}/reject`, data);
  }

  uploadDocument(claimId: string, file: File): Observable<ClaimDocument> {
    const data = new FormData();
    data.append('file', file);
    return this.http.post<ClaimDocument>(`${this.url}/${claimId}/documents`, data);
  }

  listDocuments(claimId: string): Observable<ClaimDocument[]> {
    return this.http.get<unknown[]>(`${this.url}/${claimId}/documents`).pipe(
      map(documents => documents.map(document => this.normalizeDocument(document)))
    );
  }

  getDocumentDownloadUrl(claimId: string, documentId: string): Observable<PresignedUrl> {
    return this.http.get<PresignedUrl>(
      `${this.url}/${claimId}/documents/${documentId}/download`
    );
  }

  downloadDocumentContent(claimId: string, documentId: string): Observable<Blob> {
    return this.http.get(
      `${this.url}/${claimId}/documents/${documentId}/content`,
      { responseType: 'blob' }
    );
  }

  addDependent(claimId: string, request: DependentRequest): Observable<ClaimDependent> {
    return this.http.post<ClaimDependent>(`${this.url}/${claimId}/dependents`, request);
  }

  listDependents(claimId: string): Observable<ClaimDependent[]> {
    return this.http.get<ClaimDependent[]>(`${this.url}/${claimId}/dependents`);
  }

  private normalizePage(response: unknown, limit: number, offset: number): PageResponse<Claim> {
    const page = response as {
      items?: unknown[];
      data?: unknown[];
      content?: unknown[];
      total?: number;
      limit?: number;
      offset?: number;
      pagination?: { total?: number; limit?: number; offset?: number };
    };
    const rawClaims = Array.isArray(response)
      ? response
      : page.items ?? page.data ?? page.content ?? [];

    return {
      items: rawClaims.map(claim => this.normalizeClaim(claim)),
      total: Number(page.total ?? page.pagination?.total ?? rawClaims.length),
      limit: Number(page.limit ?? page.pagination?.limit ?? limit),
      offset: Number(page.offset ?? page.pagination?.offset ?? offset)
    };
  }

  private normalizeClaim(response: unknown): Claim {
    const claim = response as Partial<Claim> & {
      claim_code?: string;
      customer_id?: string;
      policy_application_id?: string;
      policy_name?: string;
      incident_type?: string;
      incident_date?: string;
      document_ref?: string;
      processed_by?: string;
      processed_by_name?: string;
      processed_at?: string;
      created_at?: string;
    };

    return {
      ...claim,
      id: String(claim.id ?? ''),
      claimCode: claim.claimCode ?? claim.claim_code,
      customerId: claim.customerId ?? claim.customer_id,
      policyApplicationId: String(claim.policyApplicationId ?? claim.policy_application_id ?? ''),
      policyName: claim.policyName ?? claim.policy_name,
      incidentType: String(claim.incidentType ?? claim.incident_type ?? 'OTHER').toUpperCase() as Claim['incidentType'],
      incidentDate: String(claim.incidentDate ?? claim.incident_date ?? ''),
      amount: Number(claim.amount ?? 0),
      description: String(claim.description ?? ''),
      documentRef: claim.documentRef ?? claim.document_ref,
      status: String(claim.status ?? '').toUpperCase() as Claim['status'],
      processedBy: claim.processedBy ?? claim.processed_by,
      processedByName: claim.processedByName ?? claim.processed_by_name,
      processedAt: claim.processedAt ?? claim.processed_at,
      createdAt: claim.createdAt ?? claim.created_at
    };
  }

  private normalizeDocument(response: unknown): ClaimDocument {
    const document = response as Partial<ClaimDocument> & {
      claim_id?: string;
      file_name?: string;
      content_type?: string;
      uploaded_by?: string;
      uploaded_by_name?: string;
      created_at?: string;
    };

    return {
      ...document,
      id: String(document.id ?? ''),
      claimId: String(document.claimId ?? document.claim_id ?? ''),
      fileName: String(document.fileName ?? document.file_name ?? ''),
      contentType: String(document.contentType ?? document.content_type ?? ''),
      download: document.download,
      preview: document.preview,
      uploadedBy: document.uploadedBy ?? document.uploaded_by,
      uploadedByName: document.uploadedByName ?? document.uploaded_by_name,
      createdAt: document.createdAt ?? document.created_at
    };
  }

  errorMessage(error: unknown, action: 'upload' | 'submit'): string {
    if (!(error instanceof HttpErrorResponse)) {
      return `Unable to ${action} the claim document. Try again.`;
    }

    const backendMessage = typeof error.error?.message === 'string'
      ? error.error.message
      : null;

    switch (error.status) {
      case 401:
        return 'Your session has expired. Sign in again.';
      case 403:
        return 'You are not authorized to upload documents for this claim.';
      case 404:
        return 'The claim document upload route or claim could not be found.';
      case 413:
        return 'The document is too large. The maximum size is 10 MB.';
      case 500:
        return backendMessage ?? 'Document storage is unavailable. Check the S3 configuration and try again.';
      default:
        return backendMessage ?? `Unable to ${action} the claim document. Try again.`;
    }
  }
}

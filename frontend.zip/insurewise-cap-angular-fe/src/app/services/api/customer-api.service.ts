import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http';
import { catchError, map, Observable, of, throwError } from 'rxjs';

import { API_CONFIG } from '../../core/environment/api.config';
import { ApplicationDocument, Policy, PolicyApplication, PolicyApplicationCreateRequest } from '../../types/br04-05.types';

export interface ProfilePictureResponse {
  customer_id?: string;
  s3_key?: string;
  download?: { url?: string; expiresAt?: string };
}

@Injectable({ providedIn: 'root' })
export class CustomerApiService {
  constructor(private readonly http: HttpClient) {}

  getPolicies(): Observable<Policy[]> {
    return this.http.get<Policy[]>(`${API_CONFIG.baseUrl}/api/policies`);
  }

  getPolicy(id: string): Observable<Policy> {
    return this.http.get<Policy>(`${API_CONFIG.baseUrl}/api/policies/${id}`);
  }

  getApplications(status?: string): Observable<PolicyApplication[]> {
    const url = status
      ? `${API_CONFIG.baseUrl}/api/policy-applications?status=${status}`
      : `${API_CONFIG.baseUrl}/api/policy-applications`;
    return this.http.get<unknown[]>(url).pipe(
      map(applications => applications.map(application => this.normalizeApplication(application)))
    );
  }

  getApplication(id: string): Observable<PolicyApplication> {
    return this.http.get<unknown>(`${API_CONFIG.baseUrl}/api/policy-applications/${id}`).pipe(
      map(application => this.normalizeApplication(application))
    );
  }

  createApplication(request: PolicyApplicationCreateRequest): Observable<PolicyApplication> {
    return this.http.post<unknown>(`${API_CONFIG.baseUrl}/api/policy-applications`, request).pipe(
      map(application => this.normalizeApplication(application))
    );
  }

  getApplicationDocuments(applicationId: string): Observable<ApplicationDocument[]> {
    return this.http.get<ApplicationDocument[]>(`${API_CONFIG.baseUrl}/api/applications/${applicationId}/documents`);
  }

  uploadApplicationDocument(applicationId: string, file: File): Observable<ApplicationDocument> {
    const data = new FormData();
    data.append('file', file);
    return this.http.post<ApplicationDocument>(`${API_CONFIG.baseUrl}/api/applications/${applicationId}/documents`, data);
  }

  deleteApplicationDocument(applicationId: string, documentId: string): Observable<void> {
    return this.http.delete<void>(`${API_CONFIG.baseUrl}/api/applications/${applicationId}/documents/${documentId}`);
  }

  getProfilePicture(): Observable<ProfilePictureResponse | null> {
    return this.http.get<ProfilePictureResponse | null>(`${API_CONFIG.baseUrl}/auth/profile-picture`).pipe(
      catchError((error: HttpErrorResponse) =>
        error.status === 404 ? of(null) : throwError(() => error)
      )
    );
  }

  uploadProfilePicture(file: File): Observable<{ download?: { url?: string } }> {
    const data = new FormData();
    data.append('file', file);
    return this.http.post<{ download?: { url?: string } }>(`${API_CONFIG.baseUrl}/auth/profile-picture/upload`, data);
  }

  private normalizeApplication(response: unknown): PolicyApplication {
    const application = response as Partial<PolicyApplication> & {
      application_code?: string;
      customer_id?: string;
      policy_id?: string;
      policy_name?: string;
      coverage_type?: string;
      coverage_amount?: number | string;
      premium_amount?: number | string;
      applicationStatus?: string;
      application_status?: string;
      date_of_birth?: string;
      preferred_start_date?: string;
      nominee_name?: string;
      nominee_relationship?: string;
      start_date?: string;
      end_date?: string;
      decided_by?: string;
      decided_at?: string;
      created_at?: string;
    };

    return {
      ...application,
      id: String(application.id ?? ''),
      applicationCode: application.applicationCode ?? application.application_code,
      customerId: application.customerId ?? application.customer_id,
      policyId: application.policyId ?? application.policy_id,
      policyName: application.policyName ?? application.policy_name,
      coverageType: application.coverageType ?? application.coverage_type,
      coverageAmount: this.toNumber(application.coverageAmount ?? application.coverage_amount),
      premiumAmount: this.toNumber(application.premiumAmount ?? application.premium_amount),
      status: String(application.status ?? application.applicationStatus ?? application.application_status ?? '').toUpperCase(),
      dateOfBirth: application.dateOfBirth ?? application.date_of_birth,
      preferredStartDate: application.preferredStartDate ?? application.preferred_start_date,
      nomineeName: application.nomineeName ?? application.nominee_name,
      nomineeRelationship: application.nomineeRelationship ?? application.nominee_relationship,
      startDate: application.startDate ?? application.start_date,
      endDate: application.endDate ?? application.end_date,
      decidedBy: application.decidedBy ?? application.decided_by,
      decidedAt: application.decidedAt ?? application.decided_at,
      createdAt: application.createdAt ?? application.created_at
    };
  }

  private toNumber(value: number | string | undefined): number | undefined {
    if (value === undefined || value === null || value === '') {
      return undefined;
    }

    const numberValue = Number(value);
    return Number.isFinite(numberValue) ? numberValue : undefined;
  }
}
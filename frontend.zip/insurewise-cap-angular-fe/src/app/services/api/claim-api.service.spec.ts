import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';

import { API_CONFIG } from '../../core/environment/api.config';
import { ClaimApiService } from './claim-api.service';

describe('ClaimApiService', () => {
  let service: ClaimApiService;
  let http: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [provideHttpClient(), provideHttpClientTesting()]
    });
    service = TestBed.inject(ClaimApiService);
    http = TestBed.inject(HttpTestingController);
  });

  afterEach(() => http.verify());

  it('maps the backend data and pagination envelope', () => {
    service.list().subscribe(page => {
      expect(page.items).toHaveLength(1);
      expect(page.total).toBe(1);
      expect(page.items[0]).toEqual(expect.objectContaining({
        id: 'claim-1',
        claimCode: 'CLM-1000',
        policyName: 'Health Policy',
        amount: 2500,
        status: 'PENDING',
        processedByName: 'Alex Morgan'
      }));
    });

    http.expectOne(request => request.url === `${API_CONFIG.baseUrl}/api/claims`).flush({
      data: [{
        id: 'claim-1',
        claim_code: 'CLM-1000',
        policy_application_id: 'application-1',
        policy_name: 'Health Policy',
        incident_type: 'accident',
        incident_date: '2026-09-17',
        amount: '2500',
        description: 'Incident details',
        status: 'pending',
        processed_by_name: 'Alex Morgan'
      }],
      pagination: { limit: 50, offset: 0, total: 1, hasMore: false }
    });
  });

  it('loads staff claim review from the supported claim endpoint', () => {
    service.getDetail('claim-1').subscribe(claim => {
      expect(claim).toEqual(expect.objectContaining({
        id: 'claim-1',
        claimCode: 'CLM-1000',
        policyName: 'Health Policy',
        amount: 2500,
        status: 'PENDING'
      }));
    });

    const request = http.expectOne(`${API_CONFIG.baseUrl}/api/claims/claim-1`);
    expect(request.request.method).toBe('GET');
    request.flush({
      id: 'claim-1',
      claim_code: 'CLM-1000',
      policy_application_id: 'application-1',
      policy_name: 'Health Policy',
      incident_type: 'accident',
      incident_date: '2026-09-17',
      amount: '2500',
      description: 'Incident details',
      status: 'pending'
    });
  });

  it('submits claim JSON and file through the atomic multipart endpoint', () => {
    const file = new File(['evidence'], 'evidence.pdf', { type: 'application/pdf' });
    const claim = {
      idempotencyKey: 'request-1',
      policyApplicationId: 'application-1',
      incidentType: 'ACCIDENT' as const,
      incidentDate: '2026-09-17',
      amount: 500,
      description: 'Incident details'
    };

    service.fileWithDocument(claim, file).subscribe();

    const request = http.expectOne(`${API_CONFIG.baseUrl}/api/claims/with-document`);
    expect(request.request.method).toBe('POST');
    expect(request.request.headers.has('Content-Type')).toBe(false);
    const body = request.request.body as FormData;
    expect(body.get('claim')).toBeInstanceOf(Blob);
    expect((body.get('file') as File).name).toBe('evidence.pdf');
    request.flush({ claim: { id: 'claim-1' }, document: { id: 'document-1' } });
  });

  it('sends an optional decision document with an approval request', () => {
    const file = new File(['decision'], 'approval.pdf', { type: 'application/pdf' });

    service.approve('claim-1', file).subscribe();

    const request = http.expectOne(`${API_CONFIG.baseUrl}/api/claims/claim-1/approve`);
    expect(request.request.method).toBe('PUT');
    expect(request.request.headers.has('Content-Type')).toBe(false);
    const uploadedFile = (request.request.body as FormData).get('file') as File;
    expect(uploadedFile).toBeInstanceOf(File);
    expect(uploadedFile.name).toBe('approval.pdf');
    expect(uploadedFile.type).toBe('application/pdf');
    request.flush({});
  });

  it('sends rejection remarks and an optional decision document as multipart data', () => {
    const file = new File(['decision'], 'rejection.png', { type: 'image/png' });

    service.reject('claim-1', 'Coverage does not apply.', file).subscribe();

    const request = http.expectOne(`${API_CONFIG.baseUrl}/api/claims/claim-1/reject`);
    expect(request.request.method).toBe('PUT');
    expect(request.request.headers.has('Content-Type')).toBe(false);
    const body = request.request.body as FormData;
    expect(body.get('remarks')).toBe('Coverage does not apply.');
    const uploadedFile = body.get('file') as File;
    expect(uploadedFile).toBeInstanceOf(File);
    expect(uploadedFile.name).toBe('rejection.png');
    expect(uploadedFile.type).toBe('image/png');
    request.flush({});
  });

  it('loads and normalizes claim supporting documents', () => {
    service.listDocuments('claim-1').subscribe(documents => {
      expect(documents[0]).toEqual(expect.objectContaining({
        id: 'document-1',
        claimId: 'claim-1',
        fileName: 'evidence.pdf',
        contentType: 'application/pdf',
        uploadedBy: 'customer-1',
        createdAt: '2026-09-17T10:00:00'
      }));
      expect(documents[0].download?.url).toBe('https://signed.example/evidence');
    });

    const request = http.expectOne(`${API_CONFIG.baseUrl}/api/claims/claim-1/documents`);
    expect(request.request.method).toBe('GET');
    request.flush([{
      id: 'document-1',
      claim_id: 'claim-1',
      file_name: 'evidence.pdf',
      content_type: 'application/pdf',
      uploaded_by: 'customer-1',
      created_at: '2026-09-17T10:00:00',
      download: { url: 'https://signed.example/evidence' }
    }]);
  });

  it('requests a fresh claim document download URL', () => {
    service.getDocumentDownloadUrl('claim-1', 'document-1').subscribe(response => {
      expect(response.url).toBe('https://signed.example/download');
    });

    const request = http.expectOne(
      `${API_CONFIG.baseUrl}/api/claims/claim-1/documents/document-1/download`
    );
    expect(request.request.method).toBe('GET');
    request.flush({ url: 'https://signed.example/download' });
  });

  it('downloads the claim document content as a blob', () => {
    let receivedBlob: Blob | undefined;
    service.downloadDocumentContent('claim-1', 'document-1').subscribe(blob => {
      receivedBlob = blob;
    });

    const request = http.expectOne(
      `${API_CONFIG.baseUrl}/api/claims/claim-1/documents/document-1/content`
    );
    expect(request.request.method).toBe('GET');
    expect(request.request.responseType).toBe('blob');
    const blob = new Blob(['file content'], { type: 'application/pdf' });
    request.flush(blob);

    expect(receivedBlob).toBeInstanceOf(Blob);
  });
});
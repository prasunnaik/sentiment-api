import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

import { API_CONFIG } from '../../core/environment/api.config';

import {
  PolicyApplication
} from '../../types/br04-05.types';

@Injectable({
  providedIn: 'root'
})
export class PolicyApplicationApiService {

  private readonly url =
    `${API_CONFIG.baseUrl}/api/policy-applications`;

  constructor(private http: HttpClient) {}

  getAll(): Observable<PolicyApplication[]> {
    return this.http.get<PolicyApplication[]>(
      this.url
    );
  }

  getPending(): Observable<PolicyApplication[]> {
    return this.http.get<PolicyApplication[]>(
      `${this.url}?status=PENDING`
    );
  }

  getById(id: string): Observable<PolicyApplication> {
    return this.http.get<PolicyApplication>(
      `${this.url}/${id}`
    );
  }

  approve(id: string, remarks: string): Observable<PolicyApplication> {
    return this.http.put<PolicyApplication>(
      `${this.url}/${id}/approve`,
      { remarks }
    );
  }

  reject(id: string, remarks: string): Observable<PolicyApplication> {
    return this.http.put<PolicyApplication>(
      `${this.url}/${id}/reject`,
      { remarks }
    );
  }
}
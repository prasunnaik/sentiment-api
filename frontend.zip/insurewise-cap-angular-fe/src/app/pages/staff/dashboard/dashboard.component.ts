import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';

import { DashboardApiService } from '../../../services/api/dashboard-api.service';
import { DashboardMetrics } from '../../../types/br04-05.types';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  metrics: DashboardMetrics = {
    customers: 0,
    staff: 0,
    categories: 0,
    policies: 0,
    activePolicies: 0,
    applications: 0,
    claims: 0,
    payments: 0
  };

  loading = true;
  error = '';

  constructor(
    private readonly dashboardApi: DashboardApiService,
    private readonly router: Router
  ) {}

  ngOnInit(): void {
    this.loadDashboard();
  }

  loadDashboard(): void {
    this.loading = true;
    this.error = '';

    this.dashboardApi.getMetrics().subscribe({
      next: (response) => {
        this.metrics = response;
        this.loading = false;
      },
      error: () => {
        this.error = 'Unable to load dashboard data.';
        this.loading = false;
      }
    });
  }

  // Staff User Management
  addStaffUser(): void {
    this.router.navigate(['/staff/manage-users/new']);
  }

  manageStaffUsers(): void {
    this.router.navigate(['/staff/manage-users']);
  }

  // Policy Management
  addPolicy(): void {
    this.router.navigate(['/staff/policies/new']);
  }

  managePolicies(): void {
    this.router.navigate(['/staff/policies']);
  }

  // Policy Application Approval/Rejection
  approvePolicies(): void {
    this.router.navigate(['/staff/approve-policies']);
  }
}
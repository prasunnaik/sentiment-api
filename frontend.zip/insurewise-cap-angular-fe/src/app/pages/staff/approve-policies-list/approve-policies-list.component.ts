import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';

import {
  PolicyApplication
} from '../../../types/br04-05.types';

import {
  PolicyApplicationApiService
} from '../../../services/api/policy-application-api.service';

@Component({
  selector: 'app-approve-policies-list',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './approve-policies-list.component.html',
  styleUrls: ['./approve-policies-list.component.css']
})
export class ApprovePoliciesListComponent implements OnInit {

  applications: PolicyApplication[] = [];

  loading = true;
  error = '';

  constructor(
    private applicationApi: PolicyApplicationApiService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.loadApplications();
  }

  loadApplications(): void {

    this.loading = true;

    this.applicationApi.getPending().subscribe({

      next: applications => {
        this.applications = applications;
        this.loading = false;
      },

      error: () => {
        this.error =
          'Unable to load pending applications.';
        this.loading = false;
      }

    });
  }

  review(id: string): void {
    this.router.navigate([
      '/staff/approve-policies',
      id
    ]);
  }
}

import { CommonModule } from '@angular/common';
import { Component, inject, OnInit } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { catchError, EMPTY, map, switchMap } from 'rxjs';

import { AuthService } from '../../../core/auth/auth.service';
import { getApiError } from '../../../core/errors/api-error.util';
import {
  PROFILE_PICTURE_MAX_SIZE,
  PROFILE_PICTURE_TYPES,
  validateFile
} from '../../../components/common/file-upload/file-upload.validation';

@Component({
  selector: 'app-customer-auth',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink],
  templateUrl: './customer-auth.component.html',
  styleUrls: ['./customer-auth.component.css']
})
export class CustomerAuthComponent implements OnInit {
  register = false;
  loading = false;
  error = '';
  success = '';
  selectedProfilePicture: File | null = null;
  profilePicturePreview = '';

  private readonly formBuilder = inject(FormBuilder);

  readonly form = this.formBuilder.group({
    fullName: [''],
    phone: [''],
    email: ['', [Validators.required, Validators.email]],
    password: ['', [Validators.required, Validators.minLength(8)]]
  });

  constructor(
    private readonly auth: AuthService,
    private readonly router: Router,
    private readonly route: ActivatedRoute
  ) {}

  ngOnInit(): void {
    this.register = this.router.url.includes('/register');

    if (this.register) {
      this.form.controls.fullName.setValidators(Validators.required);
      this.form.controls.phone.setValidators(Validators.required);
      this.form.controls.fullName.updateValueAndValidity();
      this.form.controls.phone.updateValueAndValidity();
    }

    this.route.queryParamMap.subscribe(params => {
      this.success = params.get('success') ?? '';
    });
  }

  selectProfilePicture(event: Event): void {
    const input = event.target as HTMLInputElement;
    const file = input.files?.[0] ?? null;
    const validationError = validateFile(
      file,
      PROFILE_PICTURE_TYPES,
      PROFILE_PICTURE_MAX_SIZE,
      'A profile picture is required.',
      'Only JPG, PNG, or WEBP images are allowed.',
      'Profile picture must be 5 MB or smaller.'
    );

    if (validationError) {
      this.selectedProfilePicture = null;
      this.profilePicturePreview = '';
      this.error = validationError;
      input.value = '';
      return;
    }

    this.error = '';
    this.selectedProfilePicture = file;
    const reader = new FileReader();
    reader.onload = () => this.profilePicturePreview = String(reader.result ?? '');
    reader.readAsDataURL(file as File);
  }

  submit(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }

    if (this.register && !this.selectedProfilePicture) {
      this.error = 'A profile picture is required.';
      return;
    }

    this.loading = true;
    this.error = '';
    const value = this.form.getRawValue();
    if (this.register) {
      const profilePicture = this.selectedProfilePicture;
      if (!profilePicture) {
        this.loading = false;
        this.error = 'A profile picture is required.';
        return;
      }

      this.auth.registerCustomer({
        fullName: value.fullName ?? '',
        phone: value.phone ?? '',
        email: value.email ?? '',
        password: value.password ?? ''
      }).pipe(
        switchMap(response =>
          this.auth.uploadCustomerProfilePicture(response.access_token, profilePicture).pipe(
            map(() => response),
            catchError(() => {
              this.loading = false;
              this.error = 'Your account was created, but the profile picture could not be uploaded. Please sign in and upload it from your profile.';
              return EMPTY;
            })
          )
        )
      ).subscribe({
        next: () => this.router.navigate(
          ['/login'],
          { queryParams: { success: 'Account created successfully. Please sign in.' } }
        ),
        error: error => this.handleError(error)
      });
      return;
    }

    this.auth.loginCustomer({
          email: value.email ?? '',
          password: value.password ?? ''
    }).subscribe({
      next: () => this.router.navigate(['/customer/browse-policies']),
      error: error => this.handleError(error)
    });
  }

  private handleError(error: unknown): void {
    const apiError = getApiError(error);
    this.error = apiError?.message
      ?? 'We could not complete your request. Check your details and try again.';
    this.loading = false;
  }
}

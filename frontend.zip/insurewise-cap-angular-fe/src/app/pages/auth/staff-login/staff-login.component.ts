import { CommonModule } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import { Component } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';

import { AuthService } from '../../../core/auth/auth.service';
import { getApiError } from '../../../core/errors/api-error.util';

@Component({
  selector: 'app-staff-login',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink],
  templateUrl: './staff-login.component.html',
  styleUrls: ['./staff-login.component.css']
})
export class StaffLoginComponent {
  loading = false;
  error = '';
  form: FormGroup;

  constructor(
    private readonly formBuilder: FormBuilder,
    private readonly authService: AuthService,
    private readonly router: Router
  ) {
    this.form = this.formBuilder.nonNullable.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required]
    });
  }

  login(): void {
    this.error = '';

    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }

    this.loading = true;
    const request = {
      email: this.form.get('email')?.value?.trim(),
      password: this.form.get('password')?.value
    };

    this.authService.login(request).subscribe({
      next: () => {
        this.loading = false;

        if (this.authService.isStaff()) {
          this.router.navigate(['/staff/dashboard']);
        } else {
          this.authService.logout();
          this.error = 'You are not authorized as a staff user.';
        }
      },
      error: (error: HttpErrorResponse) => {
        this.loading = false;
        this.error = getApiError(error)?.message ?? 'Invalid email or password.';
      }
    });
  }
}

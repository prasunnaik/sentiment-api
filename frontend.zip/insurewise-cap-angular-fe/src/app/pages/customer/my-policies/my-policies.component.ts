import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';

import { PolicyApplication } from '../../../types/br04-05.types';
import { CustomerApiService } from '../../../services/api/customer-api.service';

@Component({
  selector: 'app-my-policies',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './my-policies.component.html',
  styleUrls: ['./my-policies.component.css']
})
export class MyPoliciesComponent implements OnInit {

  applications: PolicyApplication[] = [];
  loading = true;
  error = '';

  constructor(
    private readonly customerApi: CustomerApiService,
    private readonly router: Router
  ) {}

  ngOnInit(): void {
    this.loadApplications();
  }

  loadApplications(): void {
    this.loading = true;

    this.customerApi.getApplications().subscribe({
      next: applications => {
        this.applications = applications;
        this.loading = false;
      },
      error: () => {
        this.error = 'Unable to load your policies.';
        this.loading = false;
      }
    });
  }

  get activeCount(): number {
    return this.applications.filter(item => item.status === 'APPROVED').length;
  }

  get totalPremium(): number {
    return this.applications
      .filter(item => item.status === 'APPROVED')
      .reduce((sum, item) => sum + (item.premiumAmount || 0), 0);
  }

  isActionEnabled(application: PolicyApplication): boolean {
    return application.status === 'APPROVED';
  }

  browseMore(): void {
    this.router.navigate(['/customer/browse-policies']);
  }

  makePayment(application: PolicyApplication): void {
    this.router.navigate(['/customer/policies', application.id, 'pay']);
  }

  fileClaim(application: PolicyApplication): void {
    this.router.navigate(['/customer/claims/new'], { queryParams: { applicationId: application.id } });
  }

  viewDocuments(application: PolicyApplication): void {
    this.router.navigate(['/customer/policies', application.id, 'documents']);
  }
}

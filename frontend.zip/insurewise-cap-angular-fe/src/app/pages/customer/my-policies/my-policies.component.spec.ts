import { MyPoliciesComponent } from './my-policies.component';
import { PolicyApplication } from '../../../types/br04-05.types';

describe('MyPoliciesComponent', () => {
  const approvedApplication: PolicyApplication = {
    id: 'application-1',
    status: 'APPROVED'
  };

  it('enables actions only for approved applications', () => {
    const component = new MyPoliciesComponent({} as never, {} as never);

    expect(component.isActionEnabled(approvedApplication)).toBe(true);
    expect(component.isActionEnabled({ ...approvedApplication, status: 'PENDING' })).toBe(false);
  });

  it('navigates to payment and preselected claim routes', () => {
    const router = { navigate: vi.fn() };
    const component = new MyPoliciesComponent({} as never, router as never);

    component.makePayment(approvedApplication);
    expect(router.navigate).toHaveBeenCalledWith([
      '/customer/policies',
      'application-1',
      'pay'
    ]);

    component.fileClaim(approvedApplication);
    expect(router.navigate).toHaveBeenCalledWith(
      ['/customer/claims/new'],
      { queryParams: { applicationId: 'application-1' } }
    );
  });
});
import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';

import { Payment } from '../../../types/br04-05.types';
import { PaymentApiService } from '../../../services/api/payment-api.service';

@Component({
  selector: 'app-my-payments',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './my-payments.component.html',
  styleUrls: ['./my-payments.component.css']
})
export class MyPaymentsComponent implements OnInit {

  payments: Payment[] = [];
  loading = true;
  error = '';

  constructor(
    private readonly paymentApi: PaymentApiService,
    private readonly router: Router
  ) {}

  ngOnInit(): void {
    this.loadPayments();
  }

  loadPayments(): void {
    this.loading = true;

    this.paymentApi.list().subscribe({
      next: response => {
        this.payments = response.items ?? [];
        this.loading = false;
      },
      error: () => {
        this.error = 'Unable to load your payments.';
        this.loading = false;
      }
    });
  }

  makeNewPayment(): void {
    this.router.navigate(['/customer/payments/new']);
  }

  viewReceipt(payment: Payment): void {
    this.router.navigate(['/customer/payments', payment.id, 'documents']);
  }
}

import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';

import { PolicyApplication } from '../../../types/br04-05.types';
import { CustomerApiService } from '../../../services/api/customer-api.service';

@Component({
  selector: 'app-make-new-payment',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './make-new-payment.component.html',
  styleUrls: ['./make-new-payment.component.css']
})
export class MakeNewPaymentComponent implements OnInit {

  applications: PolicyApplication[] = [];
  loading = true;
  error = '';

  constructor(
    private readonly customerApi: CustomerApiService,
    private readonly router: Router
  ) {}

  ngOnInit(): void {
    this.customerApi.getApplications('APPROVED').subscribe({
      next: applications => {
        this.applications = applications;
        this.loading = false;
      },
      error: () => {
        this.error = 'Unable to load your approved policies.';
        this.loading = false;
      }
    });
  }

  pay(application: PolicyApplication): void {
    this.router.navigate(['/customer/policies', application.id, 'pay']);
  }
}

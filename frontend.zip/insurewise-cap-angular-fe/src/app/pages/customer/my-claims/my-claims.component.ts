import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';

import { Claim } from '../../../types/br04-05.types';
import { ClaimApiService } from '../../../services/api/claim-api.service';

@Component({
  selector: 'app-my-claims',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './my-claims.component.html',
  styleUrls: ['./my-claims.component.css']
})
export class MyClaimsComponent implements OnInit {

  claims: Claim[] = [];
  loading = true;
  error = '';

  constructor(
    private readonly claimApi: ClaimApiService,
    private readonly router: Router
  ) {}

  ngOnInit(): void {
    this.loadClaims();
  }

  loadClaims(): void {
    this.loading = true;

    this.claimApi.list().subscribe({
      next: response => {
        this.claims = response.items ?? [];
        this.loading = false;
      },
      error: () => {
        this.error = 'Unable to load your claims.';
        this.loading = false;
      }
    });
  }

  fileNewClaim(): void {
    this.router.navigate(['/customer/claims/new']);
  }

  viewDocuments(claim: Claim): void {
    this.router.navigate(['/customer/claims', claim.id, 'documents']);
  }
}

import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';

import { ClaimDocument } from '../../../types/br04-05.types';
import { ClaimApiService } from '../../../services/api/claim-api.service';
import { getApiError } from '../../../core/errors/api-error.util';

@Component({
  selector: 'app-claim-documents',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './claim-documents.component.html',
  styleUrls: ['./claim-documents.component.css']
})
export class ClaimDocumentsComponent implements OnInit {

  claimId = '';
  documents: ClaimDocument[] = [];

  loading = true;
  uploading = false;
  error = '';
  message = '';

  constructor(
    private readonly route: ActivatedRoute,
    private readonly router: Router,
    private readonly claimApi: ClaimApiService
  ) {}

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id');

    if (!id) {
      this.error = 'Claim ID is missing.';
      this.loading = false;
      return;
    }

    this.claimId = id;
    this.loadDocuments();
  }

  loadDocuments(): void {
    this.loading = true;

    this.claimApi.listDocuments(this.claimId).subscribe({
      next: documents => {
        this.documents = documents;
        this.loading = false;
      },
      error: error => {
        this.error = getApiError(error)?.message ?? 'Unable to load claim documents.';
        this.loading = false;
      }
    });
  }

  upload(event: Event): void {
    const file = (event.target as HTMLInputElement).files?.[0];
    if (!file) { return; }

    this.uploading = true;
    this.message = '';

    this.claimApi.uploadDocument(this.claimId, file).subscribe({
      next: document => {
        this.documents = [...this.documents, document];
        this.message = 'Document uploaded successfully.';
        this.uploading = false;
      },
      error: error => {
        this.error = getApiError(error)?.message ?? 'Document upload failed.';
        this.uploading = false;
      }
    });
  }

  openDocument(document: ClaimDocument): void {
    if (document.download?.url) {
      this.error = '';
      window.open(document.download.url, '_blank', 'noopener,noreferrer');
      return;
    }

    this.error = 'The document link has expired or is unavailable. Try reloading the page.';
  }

  back(): void {
    this.router.navigate(['/customer/claims']);
  }
}

import { of, Subject } from 'rxjs';

import { ClaimSubmission } from '../../../types/br04-05.types';

import { FileClaimComponent } from './file-claim.component';

describe('FileClaimComponent', () => {
  function createComponent() {
    const submissionResult = new Subject<ClaimSubmission>();
    const claimApi = {
      fileWithDocument: vi.fn(() => submissionResult.asObservable()),
      errorMessage: vi.fn()
    };
    const customerApi = { getApplications: vi.fn(() => of([])) };
    const component = new FileClaimComponent(
      { snapshot: { queryParamMap: { get: () => null } } } as never,
      { navigate: vi.fn() } as never,
      customerApi as never,
      claimApi as never
    );

    return { component, claimApi, submissionResult };
  }

  it('requires an incident name when Other is selected', () => {
    const { component } = createComponent();
    component.ngOnInit();

    component.form.controls.incidentType.setValue('OTHER');
    component.form.controls.otherIncident.markAsTouched();
    expect(component.form.controls.otherIncident.hasError('required')).toBe(true);

    component.form.controls.otherIncident.setValue('Falling object');
    expect(component.form.controls.otherIncident.valid).toBe(true);
  });

  it('includes the Other incident name in the claim description', () => {
    const { component, claimApi } = createComponent();
    component.ngOnInit();
    component.applications = [{
      id: 'application-1',
      status: 'APPROVED',
      coverageAmount: 10000
    }];
    component.form.setValue({
      policyApplicationId: 'application-1',
      incidentType: 'OTHER',
      otherIncident: 'Falling object',
      incidentDate: '2026-09-17',
      amount: '500',
      description: 'Damage occurred near the entrance.'
    });
    component.selectedDocument = new File(['evidence'], 'evidence.pdf', { type: 'application/pdf' });

    component.submit();

    expect(claimApi.fileWithDocument).toHaveBeenCalledWith(
      expect.objectContaining({
        incidentType: 'OTHER',
        description: 'Other incident: Falling object\n\nDamage occurred near the entrance.'
      }),
      component.selectedDocument
    );
  });

  it('requires a supporting document before creating a claim', () => {
    const { component, claimApi } = createComponent();
    component.ngOnInit();
    component.applications = [{ id: 'application-1', status: 'APPROVED', coverageAmount: 10000 }];
    component.form.patchValue({
      policyApplicationId: 'application-1',
      incidentDate: '2026-09-17',
      amount: '500',
      description: 'Incident details'
    });

    component.submit();

    expect(component.error).toContain('supporting document');
    expect(claimApi.fileWithDocument).not.toHaveBeenCalled();
  });

  it('shows success only after the supporting document upload completes', () => {
    const { component, claimApi, submissionResult } = createComponent();
    component.ngOnInit();
    component.applications = [{ id: 'application-1', status: 'APPROVED', coverageAmount: 10000 }];
    component.form.patchValue({
      policyApplicationId: 'application-1',
      incidentDate: '2026-09-17',
      amount: '500',
      description: 'Incident details'
    });
    const file = new File(['evidence'], 'evidence.pdf', { type: 'application/pdf' });
    component.selectedDocument = file;

    component.submit();

    expect(claimApi.fileWithDocument).toHaveBeenCalledWith(expect.any(Object), file);
    expect(component.message).toBe('');
    expect(component.submissionComplete).toBe(false);

    submissionResult.next({
      claim: {
        id: 'claim-1',
        policyApplicationId: 'application-1',
        incidentType: 'ACCIDENT',
        incidentDate: '2026-09-17',
        amount: 500,
        description: 'Incident details',
        status: 'PENDING'
      },
      document: {
        id: 'document-1',
        claimId: 'claim-1',
        fileName: 'evidence.pdf',
        contentType: 'application/pdf'
      }
    });

    expect(component.message).toContain('submitted successfully');
    expect(component.submissionComplete).toBe(true);
  });
});
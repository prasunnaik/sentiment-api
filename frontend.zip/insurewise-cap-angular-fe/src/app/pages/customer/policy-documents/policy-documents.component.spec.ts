import { HttpEvent, HttpEventType, HttpResponse, HttpUploadProgressEvent } from '@angular/common/http';
import { of, Subject } from 'rxjs';

import { ApplicationDocument } from '../../../types/br04-05.types';
import { PolicyDocumentsComponent } from './policy-documents.component';

describe('PolicyDocumentsComponent', () => {
  it('updates progress, disables upload, and refreshes documents after success', () => {
    const events = new Subject<HttpEvent<ApplicationDocument>>();
    const documentApi = {
      validateFile: vi.fn(() => null),
      upload: vi.fn(() => events.asObservable()),
      list: vi.fn(() => of([])),
      delete: vi.fn(),
      errorMessage: vi.fn()
    };
    const component = new PolicyDocumentsComponent(
      { snapshot: { paramMap: { get: () => 'application-1' } } } as never,
      { navigate: vi.fn() } as never,
      documentApi as never
    );
    component.applicationId = 'application-1';
    component.selectedFile = new File(['pdf'], 'policy.pdf', { type: 'application/pdf' });

    component.upload();
    expect(component.uploading).toBe(true);

    events.next({ type: HttpEventType.UploadProgress, loaded: 5, total: 10 } as HttpUploadProgressEvent);
    expect(component.uploadProgress).toBe(50);

    events.next(new HttpResponse({
      body: { id: 'document-1', fileName: 'policy.pdf', contentType: 'application/pdf' }
    }));

    expect(component.uploading).toBe(false);
    expect(component.message).toContain('successfully');
    expect(documentApi.list).toHaveBeenCalledWith('application-1');
  });

  it('does not upload when no valid file is selected', () => {
    const documentApi = {
      validateFile: vi.fn(() => 'Select a PDF document to upload.'),
      upload: vi.fn()
    };
    const component = new PolicyDocumentsComponent({} as never, {} as never, documentApi as never);

    component.upload();

    expect(component.error).toContain('Select');
    expect(documentApi.upload).not.toHaveBeenCalled();
  });

  it('fetches a fresh presigned URL and opens it in an isolated window', () => {
    const popup = {
      opener: window,
      location: { href: 'about:blank' },
      close: vi.fn()
    };
    vi.spyOn(window, 'open').mockReturnValue(popup as unknown as Window);
    const documentApi = {
      preview: vi.fn(() => of({ url: 'https://signed.example/policy.pdf' })),
      errorMessage: vi.fn()
    };
    const component = new PolicyDocumentsComponent({} as never, {} as never, documentApi as never);
    component.applicationId = 'application-1';

    component.openDocument({ id: 'document-1', fileName: 'policy.pdf', contentType: 'application/pdf' });

    expect(documentApi.preview).toHaveBeenCalledWith('application-1', 'document-1');
    expect(popup.opener).toBeNull();
    expect(popup.location.href).toBe('https://signed.example/policy.pdf');
    expect(component.openingDocumentId).toBe('');
  });
});
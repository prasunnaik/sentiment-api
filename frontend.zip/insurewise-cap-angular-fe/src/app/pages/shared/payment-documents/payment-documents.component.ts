import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';

import { PaymentDocument } from '../../../types/br04-05.types';
import { PaymentApiService } from '../../../services/api/payment-api.service';

@Component({
  selector: 'app-payment-documents',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './payment-documents.component.html',
  styleUrls: ['./payment-documents.component.css']
})
export class PaymentDocumentsComponent implements OnInit {

  paymentId = '';
  documents: PaymentDocument[] = [];

  loading = true;
  error = '';

  constructor(
    private readonly route: ActivatedRoute,
    private readonly router: Router,
    private readonly paymentApi: PaymentApiService
  ) {}

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id');

    if (!id) {
      this.error = 'Payment ID is missing.';
      this.loading = false;
      return;
    }

    this.paymentId = id;
    this.loadDocuments();
  }

  loadDocuments(): void {
    this.loading = true;

    this.paymentApi.listDocuments(this.paymentId).subscribe({
      next: documents => {
        this.documents = documents;
        this.loading = false;
      },
      error: error => {
        this.error = this.paymentApi.errorMessage(error, 'receipt');
        this.loading = false;
      }
    });
  }

  openDocument(document: PaymentDocument): void {
    if (document.preview?.url) {
      window.open(document.preview.url, '_blank', 'noopener,noreferrer');
      return;
    }

    this.error = 'A preview link is not available for this receipt.';
  }

  back(): void {
    this.router.navigate(['..'], { relativeTo: this.route });
  }
}

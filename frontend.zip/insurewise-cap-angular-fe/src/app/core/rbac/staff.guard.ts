import { inject } from '@angular/core';
import {
  CanActivateFn,
  Router
} from '@angular/router';

import { AuthService } from '../auth/auth.service';

export const staffGuard: CanActivateFn = () => {

  const authService = inject(AuthService);
  const router = inject(Router);

  if (
    authService.isLoggedIn() &&
    authService.isStaff()
  ) {
    return true;
  }

  authService.logout();

  return router.createUrlTree(['/auth/staff-login']);
};
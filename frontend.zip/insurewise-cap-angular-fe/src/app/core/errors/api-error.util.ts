import { HttpErrorResponse } from '@angular/common/http';
import { ApiError } from './api-error.model';

/**
 * Extracts the normalized `ApiError` from an error thrown by an HTTP call.
 * Returns null when the error does not carry the standardized shape
 * (for example when the error interceptor is not present, such as in unit tests).
 */
export function getApiError(error: unknown): ApiError | null {
  if (!(error instanceof HttpErrorResponse)) {
    return null;
  }

  const body = error.error;
  if (body && typeof body === 'object' && typeof (body as ApiError).message === 'string') {
    return body as ApiError;
  }

  return null;
}

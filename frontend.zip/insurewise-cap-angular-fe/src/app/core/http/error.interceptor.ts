import { Injectable } from '@angular/core';
import {
  HttpErrorResponse,
  HttpEvent,
  HttpHandler,
  HttpInterceptor,
  HttpRequest
} from '@angular/common/http';
import { Observable, catchError, throwError } from 'rxjs';

import { ApiError } from '../errors/api-error.model';
import { ToastService } from '../../components/common/toast/toast.service';

const CORRELATION_HEADER = 'X-Correlation-Id';

/**
 * Normalizes every backend/network failure into the standardized `ApiError` shape,
 * logs diagnostics (with correlation id) without exposing stack traces to the UI,
 * and surfaces unexpected failures (network/5xx) as a toast. Expected, request-specific
 * failures (validation, conflicts, not-found, etc.) are left for the calling component
 * to render inline via its existing banner/form-error pattern.
 */
@Injectable()
export class ErrorInterceptor implements HttpInterceptor {

  constructor(private readonly toast: ToastService) {}

  intercept(req: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>> {
    return next.handle(req).pipe(
      catchError((error: HttpErrorResponse) => {
        const apiError = this.normalize(error);

        console.error(
          `[HTTP ${apiError.status}] ${req.method} ${req.urlWithParams} errorCode=${apiError.errorCode} correlationId=${apiError.correlationId ?? 'unknown'}`
        );

        if (this.isUnexpected(apiError)) {
          this.toast.error(apiError.message, apiError.correlationId);
        }

        const normalized = new HttpErrorResponse({
          error: apiError,
          headers: error.headers,
          status: error.status,
          statusText: error.statusText,
          url: error.url ?? undefined
        });

        return throwError(() => normalized);
      })
    );
  }

  private normalize(error: HttpErrorResponse): ApiError {
    const correlationId = error.headers?.get(CORRELATION_HEADER) ?? this.bodyCorrelationId(error);

    if (error.status === 0) {
      return {
        timestamp: new Date().toISOString(),
        status: 0,
        errorCode: 'NETWORK_ERROR',
        message: 'Unable to reach the server. Check your connection and try again.',
        correlationId
      };
    }

    const body = error.error;
    if (body && typeof body === 'object' && typeof (body as ApiError).message === 'string') {
      const backendError = body as ApiError;
      return {
        timestamp: backendError.timestamp ?? new Date().toISOString(),
        status: backendError.status ?? error.status,
        errorCode: backendError.errorCode ?? 'UNKNOWN_ERROR',
        message: backendError.message,
        path: backendError.path,
        correlationId: backendError.correlationId ?? correlationId,
        fieldErrors: backendError.fieldErrors
      };
    }

    // Non-JSON or unrecognized error body: never surface the raw payload/stack trace.
    return {
      timestamp: new Date().toISOString(),
      status: error.status,
      errorCode: 'UNKNOWN_ERROR',
      message: 'Something went wrong. Please try again.',
      correlationId
    };
  }

  private bodyCorrelationId(error: HttpErrorResponse): string | undefined {
    const body = error.error;
    return body && typeof body === 'object' ? (body as ApiError).correlationId : undefined;
  }

  private isUnexpected(apiError: ApiError): boolean {
    return apiError.errorCode === 'NETWORK_ERROR'
      || apiError.errorCode === 'UNKNOWN_ERROR'
      || apiError.status >= 500;
  }
}

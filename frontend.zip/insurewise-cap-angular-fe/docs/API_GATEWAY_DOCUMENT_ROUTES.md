# Policy application document routes

The Angular production environment uses an empty `apiBaseUrl`, so requests are sent to the current origin and can be forwarded by the production API Gateway. The development environment uses `http://localhost:8080` for direct local backend testing. Change environment values at deployment time; do not add AWS credentials, permanent S3 URLs, or deployment hostnames to source code.

## Application-side contract

All requests require `Authorization: Bearer <jwt>`. The existing Angular HTTP interceptor supplies this header.

| Method | Application route | Purpose | Access |
|---|---|---|---|
| `POST` | `/api/applications/{applicationId}/documents` | Upload `multipart/form-data` field `file` | Customer |
| `GET` | `/api/applications/{applicationId}/documents` | List documents | Customer, Staff |
| `GET` | `/api/applications/{applicationId}/documents/{documentId}` | Get document metadata | Customer, Staff |
| `GET` | `/api/applications/{applicationId}/documents/{documentId}/preview` | Get a short-lived preview URL | Staff |
| `GET` | `/api/applications/{applicationId}/documents/{documentId}/download` | Get a short-lived download URL | Staff |
| `DELETE` | `/api/applications/{applicationId}/documents/{documentId}` | Delete a document | Customer |

Uploads currently accept PDF (`application/pdf`) files up to 10 MB. Angular sends `FormData` without setting `Content-Type`, allowing the browser to add the multipart boundary.

## Required Gateway forwarding

Gateway configuration is not present in this repository, so these routes are not confirmed as deployed. DevOps must expose all six routes above and preserve:

- The `Authorization` header
- Multipart request bodies and boundaries
- Both path variables
- Response status and JSON bodies
- Non-public authorization behavior

The Gateway/deployment repository must be updated and tested separately. End-to-end Gateway and S3 testing remains pending until that configuration exists and a valid `S3_BUCKET`, AWS region, active profile or IAM identity are available.
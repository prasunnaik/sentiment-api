package com.insurewise.auth.controller;

import com.insurewise.auth.dto.request.CustomerLoginRequest;
import com.insurewise.auth.dto.request.CustomerRegistrationRequest;
import com.insurewise.auth.dto.request.StaffLoginRequest;
import com.insurewise.auth.dto.response.AuthResponse;
import com.insurewise.auth.service.AuthService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
/**
 * Exposes authentication endpoints for customer and staff sign-in flows.
 *
*/
@RestController
@RequestMapping("/auth")
public class AuthController {
    private final AuthService authService;

    /**
     * Creates the authentication controller with the service used to validate credentials and issue tokens.
     *
     * @param authService the authentication service that handles registrations and login attempts
*/
    public AuthController(AuthService authService) {
        this.authService = authService;
    }

    /**
     * Registers a new customer account and returns an authenticated response payload.
     *
     * @param request the customer registration details including personal and account information
     * @return a 201-created response containing the newly issued authentication token and user details
*/
    @PostMapping("/customers")
    public ResponseEntity<AuthResponse> registerCustomer(
            @Valid @RequestBody CustomerRegistrationRequest request) {
        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(authService.registerCustomer(request));
    }

    /**
     * Authenticates an existing customer using email and password credentials.
     *
     * @param request the login request containing the customer credentials
     * @return an authentication response with the generated JWT token and profile information
*/
    @PostMapping("/customers/login")
    public AuthResponse loginCustomer(
            @Valid @RequestBody CustomerLoginRequest request) {
        return authService.loginCustomer(request);
    }

    /**
     * Authenticates a staff user using the internal staff login credentials.
     *
     * @param request the staff login credentials supplied by the staff portal
     * @return an authentication response with the staff session token and user details
*/
    @PostMapping("/staff/login")
    public AuthResponse loginStaff(
            @Valid @RequestBody StaffLoginRequest request) {
        return authService.loginStaff(request);
    }
}

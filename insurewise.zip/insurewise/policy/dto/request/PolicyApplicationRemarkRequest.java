package com.insurewise.policy.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

/**
 * Remarks supplied when approving or rejecting a policy application.
 */
public record PolicyApplicationRemarkRequest(
        @NotBlank
        @Size(max = 1000)
        String remarks) {
}

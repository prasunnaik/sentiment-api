package com.insurewise.policy.dto.request;

import com.insurewise.policy.entity.ApplicationStatus;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
/**
 * Represents the record Policy Application Decision Request.
*/

public record PolicyApplicationDecisionRequest(
        @NotNull
        ApplicationStatus status,
        @NotBlank
        @Size(max = 1000)
        String remarks
) {
    public PolicyApplicationDecisionRequest(ApplicationStatus status) {
        this(status, null);
    }
}

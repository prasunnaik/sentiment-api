// (Apply for Policy / My Policies). The
// original class also contained staff-only approve/reject methods
// (BR-05: Approve Policy), which have been removed here since they are a
// teammate's requirement. getApplicationEntityForInternalUse() is kept
// because DependentService and ApplicationDocumentService (also BR-02)
// call it to resolve/validate ownership of the parent application.
package com.insurewise.policy.service;

import com.insurewise.common.security.JwtPrincipal;
import com.insurewise.common.security.JwtRole;
import com.insurewise.policy.dto.request.PolicyApplicationDecisionRequest;
import com.insurewise.policy.dto.request.PolicyApplicationCreateRequest;
import com.insurewise.policy.dto.response.PolicyApplicationResponse;
import com.insurewise.policy.entity.ApplicationStatus;
import com.insurewise.policy.entity.Policy;
import com.insurewise.policy.entity.PolicyApplication;
import com.insurewise.policy.exception.ApplicationNotFoundException;
import com.insurewise.policy.exception.ApplicationStateException;
import com.insurewise.policy.exception.DuplicatePendingApplicationException;
import com.insurewise.policy.repository.PolicyApplicationRepository;
import java.time.LocalDate;
import java.util.List;
import java.util.UUID;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Provides operations for creating, listing, and reviewing policy applications.
 *
*/
@Service
@Transactional
public class PolicyApplicationService {
    private final PolicyApplicationRepository applicationRepository;
    private final PolicyService policyService;

    /**
     * Creates a service with the required policy and application repository dependencies.
     *
     * @param applicationRepository the repository used to persist application records
     * @param policyService the policy service used to resolve policy catalog entries
*/
    public PolicyApplicationService(
            PolicyApplicationRepository applicationRepository,
            PolicyService policyService) {
        this.applicationRepository = applicationRepository;
        this.policyService = policyService;
    }

    /**
     * Creates a policy application for the specified customer.
     *
     * @param customerId the customer identifier creating the application
     * @param request the application creation payload
     * @return the created application response
     * @throws ApplicationStateException when the policy is inactive or the date is invalid
     * @throws DuplicatePendingApplicationException when a duplicate pending application exists
*/
    public PolicyApplicationResponse createApplication(
            UUID customerId,
            PolicyApplicationCreateRequest request) {
        Policy policy = policyService.find(request.policyId());

        if (!policy.isActiveForCustomer()) {
            throw new ApplicationStateException(
                    "Applications can only be created for active policies");
        }

        if (request.preferredStartDate() != null
                && request.preferredStartDate().isBefore(LocalDate.now())) {
            throw new ApplicationStateException(
                    "Preferred start date cannot be in the past");
        }

        validateNominee(request);

        boolean duplicate = applicationRepository.existsByCustomerIdAndPolicyIdAndStatus(
                customerId,
                request.policyId(),
                ApplicationStatus.PENDING);

        if (duplicate) {
            throw new DuplicatePendingApplicationException();
        }

        Long sequence = applicationRepository.nextApplicationCodeSequence();

        PolicyApplication application = new PolicyApplication(
                "APP-" + sequence,
                customerId,
                policy,
                request.coverageType(),
                request.dateOfBirth(),
                request.address(),
                request.preferredStartDate(),
                normalizeNomineeName(request.nomineeName()),
                request.nomineeRelationship());

        return toResponse(applicationRepository.saveAndFlush(application));
    }

    /**
     * Lists policy applications visible to the authenticated user.
     *
     * @param principal the authenticated principal requesting the operation
     * @param status the optional status filter
     * @return the matching list of policy applications
*/
    @Transactional(readOnly = true)
    public List<PolicyApplicationResponse> listApplications(
            JwtPrincipal principal,
            ApplicationStatus status) {
        List<PolicyApplication> applications;

        if (principal.role().name().equals("STAFF")) {
            applications = status == null
                    ? applicationRepository.findAllByOrderByCreatedAtDesc()
                    : applicationRepository.findByStatusOrderByCreatedAtDesc(status);
        } else {
            applications = status == null
                    ? applicationRepository.findByCustomerIdOrderByCreatedAtDesc(principal.userId())
                    : applicationRepository.findByCustomerIdAndStatusOrderByCreatedAtDesc(
                            principal.userId(),
                            status);
        }

        return applications.stream().map(this::toResponse).toList();
    }

    /**
     * Reads a single policy application for the authenticated user.
     *
     * @param principal the authenticated principal requesting the operation
     * @param applicationId the policy application identifier
     * @return the matching application response
*/
    @Transactional(readOnly = true)
    public PolicyApplicationResponse getApplication(
            JwtPrincipal principal,
            UUID applicationId) {
        PolicyApplication application = getApplicationEntity(applicationId);

        if (principal.role().name().equals("CUSTOMER") && !application.isOwnedBy(principal.userId())) {
            throw new ApplicationNotFoundException(applicationId);
        }

        return toResponse(application);
    }

    /**
     * Resolves a policy application without performing ownership checks for internal use.
     *
     * @param applicationId the policy application identifier
     * @return the application entity
*/
    public PolicyApplication getApplicationEntityForInternalUse(UUID applicationId) {
        return getApplicationEntity(applicationId);
    }

    /**
     * Updates the status of an existing policy application.
     *
     * @param principal the authenticated principal requesting the operation
     * @param applicationId the policy application identifier
     * @param request the decision payload
     * @return the updated policy application response
     * @throws ApplicationStateException when the caller is not staff or the decision is invalid
*/
    public PolicyApplicationResponse updateApplicationStatus(
            JwtPrincipal principal,
            UUID applicationId,
            PolicyApplicationDecisionRequest request) {
        if (principal.role() != JwtRole.STAFF) {
            throw new ApplicationStateException(
                    "Only staff users can review policy applications");
        }

        PolicyApplication application = getApplicationEntity(applicationId);
        String remarks = normalizeRemarks(request.remarks());
        if (remarks == null) {
            throw new ApplicationStateException(
                    "Remarks are required when deciding a policy application");
        }

        if (request.status() == ApplicationStatus.APPROVED) {
            LocalDate startDate = application.getPreferredStartDate() != null
                    ? application.getPreferredStartDate()
                    : LocalDate.now();
            LocalDate endDate = startDate.plusYears(1);
            application.approve(principal.userId(), startDate, endDate, remarks);
        } else if (request.status() == ApplicationStatus.REJECTED) {
            application.reject(principal.userId(), remarks);
        } else {
            throw new ApplicationStateException(
                    "Application status must be APPROVED or REJECTED");
        }

        return toResponse(applicationRepository.save(application));
    }

    /**
     * Resolves a policy application entity by identifier.
     *
     * @param applicationId the policy application identifier
     * @return the policy application entity
     * @throws ApplicationNotFoundException when no matching application exists
*/
    private PolicyApplication getApplicationEntity(UUID applicationId) {
        return applicationRepository.findById(applicationId)
                .orElseThrow(() -> new ApplicationNotFoundException(applicationId));
    }

    /**
     * Converts a policy application entity into an API response model.
     *
     * @param application the application entity to convert
     * @return the API response representation
*/
    private PolicyApplicationResponse toResponse(PolicyApplication application) {
        return new PolicyApplicationResponse(
                application.getId(),
                application.getApplicationCode(),
                application.getCustomerId(),
                application.getPolicy().getId(),
                application.getPolicy().getName(),
                application.getCoverageType(),
                application.getCoverageAmount(),
                application.getPremiumAmount(),
                application.getDateOfBirth(),
                application.getAddress(),
                application.getPreferredStartDate(),
                application.getNomineeName(),
                application.getNomineeRelationship(),
                application.getStartDate(),
                application.getEndDate(),
                application.getStatus(),
                application.getDecidedBy(),
                application.getDecidedAt(),
                application.getRemarks(),
                application.getCreatedAt());
    }

    private void validateNominee(PolicyApplicationCreateRequest request) {
        boolean hasRelationship = request.nomineeRelationship() != null;
        boolean hasName = request.nomineeName() != null && !request.nomineeName().isBlank();

        if (hasRelationship && !hasName) {
            throw new ApplicationStateException(
                    "nomineeName is required when nomineeRelationship is provided");
        }

        if (!hasRelationship && request.nomineeName() != null) {
            throw new ApplicationStateException(
                    "nomineeName must be omitted when nomineeRelationship is not provided");
        }
    }

    private String normalizeNomineeName(String nomineeName) {
        if (nomineeName == null) {
            return null;
        }
        String trimmed = nomineeName.trim();
        return trimmed.isEmpty() ? null : trimmed;
    }

    private String normalizeRemarks(String remarks) {
        if (remarks == null) {
            return null;
        }
        String trimmed = remarks.trim();
        return trimmed.isEmpty() ? null : trimmed;
    }
}

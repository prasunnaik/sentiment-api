package com.insurewise.common.security;

import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

// Spring Security configuration enabling method-level security and stateless JWT-based authentication
@Configuration
@EnableMethodSecurity
@EnableConfigurationProperties(SecurityProperties.class)
public class SecurityConfig {

    // Defines the security filter chain: CORS on, CSRF off, stateless sessions, public endpoints permitted, everything else authenticated, with the JWT filter running before the username/password filter
    @Bean
    SecurityFilterChain securityFilterChain(
            HttpSecurity http,
            JwtAuthenticationFilter jwtFilter,
            SecurityProperties properties)
            throws Exception {

        return http
                .cors(Customizer.withDefaults())
                .csrf(csrf -> csrf.disable())
                .sessionManagement(session -> session
                        .sessionCreationPolicy(
                                SessionCreationPolicy.STATELESS))
                .authorizeHttpRequests(auth -> auth
                        .requestMatchers(
                                HttpMethod.OPTIONS,
                                properties.preflightPattern())
                        .permitAll()
                        .requestMatchers(
                                HttpMethod.POST,
                                properties.publicPostEndpoints()
                                        .toArray(String[]::new))
                        .permitAll()
                        .requestMatchers(
                                properties.publicEndpoints()
                                        .toArray(String[]::new))
                        .permitAll()
                        .anyRequest()
                        .authenticated())
                .addFilterBefore(
                        jwtFilter,
                        UsernamePasswordAuthenticationFilter.class)
                .build();
    }

    // Builds the CORS configuration source from the configured origins, methods, headers, credentials flag, and max-age, mapped to the configured path pattern
    @Bean
    CorsConfigurationSource corsConfigurationSource(
            SecurityProperties properties) {

        var cors = properties.cors();
        var configuration = new CorsConfiguration();

        configuration.setAllowedOrigins(
                cors.allowedOrigins());
        configuration.setAllowedMethods(
                cors.allowedMethods());
        configuration.setAllowedHeaders(
                cors.allowedHeaders());
        configuration.setAllowCredentials(
                cors.allowCredentials());
        configuration.setMaxAge(
                cors.maxAge());

        var source =
                new UrlBasedCorsConfigurationSource();

        source.registerCorsConfiguration(
                cors.pathPattern(),
                configuration);

        return source;
    }
}

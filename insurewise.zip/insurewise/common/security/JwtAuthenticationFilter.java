package com.insurewise.common.security;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import org.springframework.security.web.util.matcher.OrRequestMatcher;
import org.springframework.security.web.util.matcher.RequestMatcher;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

// Servlet filter that authenticates requests by parsing a Bearer JWT and populating the SecurityContext; public endpoints are skipped
@Component
public class JwtAuthenticationFilter
        extends OncePerRequestFilter {

    private final JwtService jwtService;
    private final RequestMatcher publicEndpoints;

    // Builds the matcher for public endpoints (public POST paths, public GET paths, and CORS preflight OPTIONS) and stores the JWT service
    public JwtAuthenticationFilter(
            JwtService jwtService,
            SecurityProperties properties) {

        this.jwtService = jwtService;

        List<RequestMatcher> matchers =
                new ArrayList<>();

        properties.publicPostEndpoints()
                .forEach(path -> matchers.add(
                        new AntPathRequestMatcher(
                                path,
                                HttpMethod.POST.name())));

        properties.publicEndpoints()
                .forEach(path -> matchers.add(
                        new AntPathRequestMatcher(path)));

        matchers.add(
                new AntPathRequestMatcher(
                        properties.preflightPattern(),
                        HttpMethod.OPTIONS.name()));

        this.publicEndpoints =
                new OrRequestMatcher(
                        matchers.toArray(
                                new RequestMatcher[0]));
    }

    // Skips this filter for requests matching a public endpoint, so no JWT is required there
    @Override
    protected boolean shouldNotFilter(
            HttpServletRequest request) {

        return publicEndpoints.matches(request);
    }

    // Extracts and validates the Bearer token; on success sets the authenticated principal, on failure clears the context; always continues the chain
    @Override
    protected void doFilterInternal(
            HttpServletRequest request,
            HttpServletResponse response,
            FilterChain chain)
            throws ServletException, IOException {

        String header =
                request.getHeader("Authorization");

        if (header == null
                || !header.startsWith("Bearer ")) {
            chain.doFilter(request, response);
            return;
        }

        String token = header.substring(7).trim();

        if (token.isEmpty()) {
            chain.doFilter(request, response);
            return;
        }

        try {
            JwtPrincipal principal =
                    jwtService.parse(token);

            var authorities = List.of(
                    new SimpleGrantedAuthority(
                            "ROLE_"
                                    + principal.role().name()));

            var authentication =
                    new UsernamePasswordAuthenticationToken(
                            principal,
                            null,
                            authorities);

            SecurityContextHolder.getContext()
                    .setAuthentication(authentication);

        } catch (RuntimeException exception) {
            SecurityContextHolder.clearContext();
        }

        chain.doFilter(request, response);
    }
}

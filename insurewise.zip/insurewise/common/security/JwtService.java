//creates and validates JWTs
package com.insurewise.common.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.springframework.stereotype.Service;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.Date;
import java.util.UUID;

// Service that issues and verifies HMAC-signed JWTs using the configured secret, issuer, and TTL
@Service
public class JwtService {
    private final SecurityProperties properties;
    private final SecretKey signingKey;

    // Stores security properties and derives the HMAC-SHA signing key from the configured secret
    public JwtService(SecurityProperties properties) {
        this.properties = properties;
        this.signingKey = Keys.hmacShaKeyFor(
                properties.jwtSecret().getBytes(StandardCharsets.UTF_8));
    }

    // Builds a signed JWT for the given user carrying email and role claims, expiring after the configured TTL
    public String generate(UUID userId, String email, JwtRole role) {
        Instant now = Instant.now();

        return Jwts.builder()
                .issuer(properties.issuer())
                .subject(userId.toString())
                .claim("email", email)
                .claim("role", role.name())
                .issuedAt(Date.from(now))
                .expiration(Date.from(now.plus(properties.tokenTtl())))
                .signWith(signingKey)
                .compact();
    }

    // Verifies the token's signature and issuer, then extracts the principal (user ID, role, email) from its claims
    public JwtPrincipal parse(String token) {
        Jws<Claims> parsed = Jwts.parser()
                .verifyWith(signingKey)
                .requireIssuer(properties.issuer())
                .build()
                .parseSignedClaims(token);

        Claims claims = parsed.getPayload();

        return new JwtPrincipal(
                UUID.fromString(claims.getSubject()),
                JwtRole.valueOf(claims.get("role", String.class)),
                claims.get("email", String.class));
    }
}

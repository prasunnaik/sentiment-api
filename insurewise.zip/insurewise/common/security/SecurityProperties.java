package com.insurewise.common.security;

import org.springframework.boot.context.properties.ConfigurationProperties;

import java.time.Duration;
import java.util.List;

@ConfigurationProperties(prefix = "insurewise.security")
public record SecurityProperties(
        String issuer,
        String jwtSecret,
        Duration tokenTtl,
        List<String> publicPostEndpoints,
        List<String> publicEndpoints,
        String preflightPattern,
        CorsProperties cors
) {
    public record CorsProperties(
            String pathPattern,
            List<String> allowedOrigins,
            List<String> allowedMethods,
            List<String> allowedHeaders,
            boolean allowCredentials,
            long maxAge
    ) {
    }
}

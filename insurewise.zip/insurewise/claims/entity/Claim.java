package com.insurewise.claims.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Table(
        name = "claims",
        uniqueConstraints = {
                @UniqueConstraint(
                        name = "uq_claims_idempotency_key",
                        columnNames = "idempotency_key"),
                @UniqueConstraint(
                        name = "uq_claims_claim_code",
                        columnNames = "claim_code")
        })
/**
 * Represents the class Claim.
*/
public class Claim {
    @Id
    @GeneratedValue
    private UUID id;

    @Column(name = "claim_code", nullable = false, length = 20)
    private String claimCode;

    @Column(name = "idempotency_key", nullable = false, length = 80)
    private String idempotencyKey;

    @Column(name = "customer_id", nullable = false)
    private UUID customerId;

    @Column(name = "policy_application_id", nullable = false)
    private UUID policyApplicationId;

    @Column(name = "policy_name_snapshot", nullable = false, length = 120)
    private String policyNameSnapshot;

    @Enumerated(EnumType.STRING)
    @Column(name = "incident_type", nullable = false, length = 40)
    private IncidentType incidentType;

    @Column(name = "incident_date", nullable = false)
    private LocalDate incidentDate;

    @Column(nullable = false, precision = 14, scale = 2)
    private BigDecimal amount;

    @Column(nullable = false, length = 1000)
    private String description;

    @Column(length = 1000)
    private String remarks;

    @Column(name = "document_ref", length = 300)
    private String documentRef;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private ClaimStatus status;

    @Column(name = "processed_by")
    private UUID processedBy;

    @Column(name = "processed_at")
    private LocalDateTime processedAt;

    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;
/**
 * Claim.
 * @return the result of the operation.
*/

    protected Claim() {
    }
/**
 * Claim.
 * @param claimCode the value supplied for the claimCode.
 * @param idempotencyKey the value supplied for the idempotencyKey.
 * @param customerId the value supplied for the customerId.
 * @param policyApplicationId the value supplied for the policyApplicationId.
 * @param policyNameSnapshot the value supplied for the policyNameSnapshot.
 * @param incidentType the value supplied for the incidentType.
 * @param incidentDate the value supplied for the incidentDate.
 * @param amount the value supplied for the amount.
 * @param description the value supplied for the description.
 * @param documentRef the value supplied for the documentRef.
 * @return the result of the operation.
*/

    public Claim(
            String claimCode,
            String idempotencyKey,
            UUID customerId,
            UUID policyApplicationId,
            String policyNameSnapshot,
            IncidentType incidentType,
            LocalDate incidentDate,
            BigDecimal amount,
            String description,
            String documentRef) {
        this.claimCode = claimCode;
        this.idempotencyKey = idempotencyKey;
        this.customerId = customerId;
        this.policyApplicationId = policyApplicationId;
        this.policyNameSnapshot = policyNameSnapshot;
        this.incidentType = incidentType;
        this.incidentDate = incidentDate;
        this.amount = amount;
        this.description = description;
        this.documentRef = documentRef;
        this.status = ClaimStatus.PENDING;
    }

    @PrePersist
    void initialize() {
        if (createdAt == null) {
            createdAt = LocalDateTime.now();
        }
    }
/**
 * Mark Under Review.
 * @param staffUserId the value supplied for the staffUserId.
*/

    public void markUnderReview(UUID staffUserId) {
        requirePending();
        status = ClaimStatus.UNDER_REVIEW;
        processedBy = staffUserId;
        processedAt = LocalDateTime.now();
    }
/**
 * Approve.
 * @param staffUserId the value supplied for the staffUserId.
*/

    public void approve(UUID staffUserId) {
        approve(staffUserId, null);
    }

    public void approve(UUID staffUserId, String remarks) {
        if (status != ClaimStatus.PENDING
                && status != ClaimStatus.UNDER_REVIEW) {
            throw new IllegalStateException(
                    "Only pending or under-review claims can be approved");
        }

        status = ClaimStatus.APPROVED;
        processedBy = staffUserId;
        processedAt = LocalDateTime.now();
        this.remarks = remarks;
    }
/**
 * Reject.
 * @param staffUserId the value supplied for the staffUserId.
*/

    public void reject(UUID staffUserId) {
        reject(staffUserId, null);
    }

    public void reject(UUID staffUserId, String remarks) {
        if (status != ClaimStatus.PENDING
                && status != ClaimStatus.UNDER_REVIEW) {
            throw new IllegalStateException(
                    "Only pending or under-review claims can be rejected");
        }

        status = ClaimStatus.REJECTED;
        processedBy = staffUserId;
        processedAt = LocalDateTime.now();
        this.remarks = remarks;
    }

    public String getRemarks() {
        return remarks;
    }
/**
 * Require Pending.
*/

    private void requirePending() {
        if (status != ClaimStatus.PENDING) {
            throw new IllegalStateException(
                    "Only pending claims can enter review");
        }
    }
/**
 * Is Owned By.
 * @param customerId the value supplied for the customerId.
 * @return the result of the operation.
*/

    public boolean isOwnedBy(UUID customerId) {
        return this.customerId.equals(customerId);
    }
/**
 * Get Id.
 * @return the result of the operation.
*/

    public UUID getId() {
        return id;
    }
/**
 * Get Claim Code.
 * @return the result of the operation.
*/

    public String getClaimCode() {
        return claimCode;
    }
/**
 * Get Idempotency Key.
 * @return the result of the operation.
*/

    public String getIdempotencyKey() {
        return idempotencyKey;
    }
/**
 * Get Customer Id.
 * @return the result of the operation.
*/

    public UUID getCustomerId() {
        return customerId;
    }
/**
 * Get Policy Application Id.
 * @return the result of the operation.
*/

    public UUID getPolicyApplicationId() {
        return policyApplicationId;
    }
/**
 * Get Policy Name Snapshot.
 * @return the result of the operation.
*/

    public String getPolicyNameSnapshot() {
        return policyNameSnapshot;
    }
/**
 * Get Incident Type.
 * @return the result of the operation.
*/

    public IncidentType getIncidentType() {
        return incidentType;
    }
/**
 * Get Incident Date.
 * @return the result of the operation.
*/

    public LocalDate getIncidentDate() {
        return incidentDate;
    }
/**
 * Get Amount.
 * @return the result of the operation.
*/

    public BigDecimal getAmount() {
        return amount;
    }
/**
 * Get Description.
 * @return the result of the operation.
*/

    public String getDescription() {
        return description;
    }
/**
 * Get Document Ref.
 * @return the result of the operation.
*/

    public String getDocumentRef() {
        return documentRef;
    }
/**
 * Get Status.
 * @return the result of the operation.
*/

    public ClaimStatus getStatus() {
        return status;
    }
/**
 * Get Processed By.
 * @return the result of the operation.
*/

    public UUID getProcessedBy() {
        return processedBy;
    }
/**
 * Get Processed At.
 * @return the result of the operation.
*/

    public LocalDateTime getProcessedAt() {
        return processedAt;
    }
/**
 * Get Created At.
 * @return the result of the operation.
*/

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }
}
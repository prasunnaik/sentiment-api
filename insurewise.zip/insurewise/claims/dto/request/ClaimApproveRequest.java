package com.insurewise.claims.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public record ClaimApproveRequest(
        @NotBlank @Size(max = 1000) String remarks) {
}

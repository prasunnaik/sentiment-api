package com.insurewise.claims.dto.response;

import com.insurewise.claims.entity.ClaimStatus;
import com.insurewise.claims.entity.IncidentType;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.UUID;
/**
 * Represents the record Claim Response.
*/

public record ClaimResponse(
        UUID id,
        String claimCode,
        UUID customerId,
        UUID policyApplicationId,
        String policyName,
        IncidentType incidentType,
        LocalDate incidentDate,
        BigDecimal amount,
        String description,
        String remarks,
        String documentRef,
        ClaimStatus status,
        UUID processedBy,
        String processedByName,
        LocalDateTime processedAt,
        LocalDateTime createdAt
) {
    public ClaimResponse(
            UUID id,
            String claimCode,
            UUID customerId,
            UUID policyApplicationId,
            String policyName,
            IncidentType incidentType,
            LocalDate incidentDate,
            BigDecimal amount,
            String description,
            String documentRef,
            ClaimStatus status,
            UUID processedBy,
            String processedByName,
            LocalDateTime processedAt,
            LocalDateTime createdAt) {
        this(id, claimCode, customerId, policyApplicationId, policyName, incidentType,
                incidentDate, amount, description, null, documentRef, status, processedBy,
                processedByName, processedAt, createdAt);
    }
}
package com.insurewise.claims.service;

import com.insurewise.claims.dto.response.ClaimDocumentContentResponse;
import com.insurewise.claims.dto.response.ClaimDocumentResponse;
import com.insurewise.claims.entity.Claim;
import com.insurewise.claims.entity.ClaimDocument;
import com.insurewise.claims.exception.ClaimDocumentNotFoundException;
import com.insurewise.claims.exception.ClaimNotFoundException;
import com.insurewise.claims.repository.ClaimDocumentRepository;
import com.insurewise.claims.repository.ClaimRepository;
import com.insurewise.auth.repository.CustomerRepository;
import com.insurewise.common.exception.BusinessException;
import com.insurewise.common.dto.PresignedUrlResponse;
import com.insurewise.common.exception.FileStorageException;
import com.insurewise.common.service.S3StorageService;
import java.util.List;
import java.util.UUID;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;
import com.insurewise.common.exception.InvalidFileException;
/**
 * Represents the class Claim Document Service.
*/


@Service
@Transactional
public class ClaimDocumentService {
    private static final Logger log = LoggerFactory.getLogger(ClaimDocumentService.class);
    private final ClaimRepository claimRepository;
    private final ClaimDocumentRepository documentRepository;
    private final S3StorageService storageService;
    private final CustomerRepository customerRepository;
/**
 * Claim Document Service.
 * @param claimRepository the value supplied for the claimRepository.
 * @param documentRepository the value supplied for the documentRepository.
 * @param storageService the value supplied for the storageService.
 * @param customerRepository repository used to resolve the display name of the document uploader.
*/

    public ClaimDocumentService(
            ClaimRepository claimRepository,
            ClaimDocumentRepository documentRepository,
            S3StorageService storageService,
            CustomerRepository customerRepository) {
        this.claimRepository = claimRepository;
        this.documentRepository = documentRepository;
        this.storageService = storageService;
        this.customerRepository = customerRepository;
    }
/**
 * Upload Document.
 * @param customerId the value supplied for the customerId.
 * @param claimId the value supplied for the claimId.
 * @param file the value supplied for the file.
 * @return the result of the operation.
*/

    public ClaimDocumentResponse uploadDocument(
            UUID customerId,
            UUID claimId,
            MultipartFile file) {

        try {
            Claim claim = requireOwnedClaim(customerId, claimId);

            if (file == null || file.isEmpty()) {
                throw new InvalidFileException(
                        "A non-empty file is required");
            }

            String s3Key = storageService.upload(
                    file,
                    "claim-documents",
                    customerId);

            String fileName = file.getOriginalFilename() == null
                    ? "unnamed-file"
                    : file.getOriginalFilename();

            try {
                ClaimDocument document = documentRepository.saveAndFlush(
                        new ClaimDocument(
                                claim,
                                fileName,
                                file.getContentType(),
                                s3Key,
                                customerId));
                return toResponse(document);
            } catch (RuntimeException exception) {
                cleanupUploadedFile(s3Key, exception);
                throw new BusinessException(
                        "CLAIM_DOCUMENT_UPLOAD_FAILED",
                        HttpStatus.INTERNAL_SERVER_ERROR,
                        "Unable to upload claim document at this time.",
                        exception);
            }

        } catch (InvalidFileException | ClaimNotFoundException | BusinessException exception) {
            throw exception;
        } catch (RuntimeException exception) {
            log.error("Failed to upload claim document for customerId={}, claimId={}", customerId, claimId, exception);
            throw new BusinessException(
                    "CLAIM_DOCUMENT_UPLOAD_FAILED",
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unable to upload claim document at this time.",
                    exception);
        }
    }
/**
 * List Documents.
 * @param customerId the value supplied for the customerId.
 * @param claimId the value supplied for the claimId.
 * @return the result of the operation.
*/

    public ClaimDocumentResponse uploadDocumentForStaff(
            UUID staffUserId,
            UUID claimId,
            MultipartFile file) {
        if (file == null || file.isEmpty()) {
            throw new InvalidFileException("A non-empty file is required");
        }

        Claim claim = claimRepository.findById(claimId)
                .orElseThrow(() -> new ClaimNotFoundException(claimId));
        String s3Key = storageService.upload(file, "claim-documents", staffUserId);
        String fileName = file.getOriginalFilename() == null
                ? "unnamed-file"
                : file.getOriginalFilename();

        try {
            return toResponse(documentRepository.saveAndFlush(
                    new ClaimDocument(
                            claim,
                            fileName,
                            file.getContentType(),
                            s3Key,
                            staffUserId)));
        } catch (RuntimeException exception) {
            cleanupUploadedFile(s3Key, exception);
            throw new BusinessException(
                    "CLAIM_DOCUMENT_UPLOAD_FAILED",
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unable to upload claim document at this time.",
                    exception);
        }
    }

    @Transactional(readOnly = true)
    public List<ClaimDocumentResponse> listClaimDocuments(
            UUID customerId,
            UUID claimId) {

        try {
            requireOwnedClaim(customerId, claimId);

            return documentRepository.findByClaimId(claimId)
                    .stream()
                    .map(this::toResponse)
                    .toList();
        } catch (ClaimNotFoundException | BusinessException exception) {
            throw exception;
        } catch (RuntimeException exception) {
            log.error("Failed to list claim documents for customerId={}, claimId={}", customerId, claimId, exception);
            throw new BusinessException(
                    "CLAIM_DOCUMENT_LIST_FAILED",
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unable to load claim documents at this time.",
                    exception);
        }
    }

    @Transactional(readOnly = true)
    public List<ClaimDocumentResponse> listClaimDocumentsForStaff(UUID claimId) {
        if (!claimRepository.existsById(claimId)) {
            throw new ClaimNotFoundException(claimId);
        }

        return documentRepository.findByClaimId(claimId)
                .stream()
                .map(this::toResponse)
                .toList();
    }

    @Transactional(readOnly = true)
    public PresignedUrlResponse previewDocumentForStaff(
            UUID claimId,
            UUID documentId) {
        return getDocumentUrlForStaff(claimId, documentId);
    }

    @Transactional(readOnly = true)
    public PresignedUrlResponse downloadDocumentForStaff(
            UUID claimId,
            UUID documentId) {
        return getDocumentUrlForStaff(claimId, documentId);
    }

    /**
     * Retrieves the raw bytes of a claim document so the backend can stream it directly to the
     * staff client with a forced-download response header, avoiding any need for the browser to
     * fetch the file from S3 directly.
     *
     * @param claimId the claim identifier that owns the document
     * @param documentId the document to download
     * @return the document bytes together with its file name and content type
     */
    @Transactional(readOnly = true)
    public ClaimDocumentContentResponse downloadDocumentContentForStaff(
            UUID claimId,
            UUID documentId) {
        if (!claimRepository.existsById(claimId)) {
            throw new ClaimNotFoundException(claimId);
        }

        ClaimDocument document = documentRepository.findById(documentId)
                .filter(item -> item.getClaim().getId().equals(claimId))
                .orElseThrow(() -> new ClaimDocumentNotFoundException(documentId));

        byte[] content = storageService.downloadObject(document.getS3Key());

        return new ClaimDocumentContentResponse(
                document.getFileName(),
                document.getContentType(),
                content);
    }
/**
 * Delete Document.
 * @param customerId the value supplied for the customerId.
 * @param claimId the value supplied for the claimId.
 * @param documentId the value supplied for the documentId.
*/

    public void deleteDocument(
            UUID customerId,
            UUID claimId,
            UUID documentId) {

        try {
            requireOwnedClaim(customerId, claimId);

            ClaimDocument document =
                    documentRepository.findById(documentId)
                            .filter(item -> item.getClaim().getId()
                                    .equals(claimId))
                            .orElseThrow(
                                    () -> new ClaimDocumentNotFoundException(
                                            documentId));

            storageService.delete(document.getS3Key());
            documentRepository.delete(document);
        } catch (ClaimNotFoundException | ClaimDocumentNotFoundException | BusinessException exception) {
            throw exception;
        } catch (RuntimeException exception) {
            log.error(
                    "Failed to delete claim document for customerId={}, claimId={}, documentId={}",
                    customerId,
                    claimId,
                    documentId,
                    exception);
            throw new BusinessException(
                    "CLAIM_DOCUMENT_DELETE_FAILED",
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unable to delete claim document at this time.",
                    exception);
        }
    }
/**
 * Require Owned Claim.
 * @param customerId the value supplied for the customerId.
 * @param claimId the value supplied for the claimId.
 * @return the result of the operation.
*/

    private Claim requireOwnedClaim(
            UUID customerId,
            UUID claimId) {

        return claimRepository.findById(claimId)
                .filter(claim -> claim.isOwnedBy(customerId))
                .orElseThrow(ClaimNotFoundException::new);
    }
/**
 * To Response.
 * @param document the value supplied for the document.
 * @return the result of the operation.
*/

    private ClaimDocumentResponse toResponse(
            ClaimDocument document) {
        return toResponse(document, true);
    }

    private ClaimDocumentResponse toResponse(
            ClaimDocument document,
            boolean includeDownloadUrl) {
        PresignedUrlResponse download = includeDownloadUrl
                ? storageService.getPresignedDownloadUrl(
                        document.getS3Key())
                : null;
        PresignedUrlResponse preview = includeDownloadUrl
                ? storageService.getPresignedPreviewUrl(document.getS3Key())
                : null;

        return new ClaimDocumentResponse(
                document.getId(),
                document.getClaim().getId(),
                document.getFileName(),
                document.getContentType(),
                preview,
                download,
                document.getUploadedBy(),
                resolveUploaderName(document.getUploadedBy()),
                document.getCreatedAt());
    }

    /**
     * Resolves the display name of the customer who uploaded a claim document, falling back to their
     * email and finally to the raw id when no customer record can be found.
     *
     * @param uploadedBy id of the customer who uploaded the document
     * @return a human-readable uploader label
     */
    private String resolveUploaderName(UUID uploadedBy) {
        if (uploadedBy == null) {
            return null;
        }

        return customerRepository.findById(uploadedBy)
                .map(customer -> {
                    String fullName = customer.getFullName();
                    return fullName != null && !fullName.isBlank() ? fullName : customer.getEmail();
                })
                .orElse(uploadedBy.toString());
    }

    private PresignedUrlResponse getDocumentUrlForStaff(
            UUID claimId,
            UUID documentId) {
        if (!claimRepository.existsById(claimId)) {
            throw new ClaimNotFoundException(claimId);
        }

        ClaimDocument document = documentRepository.findById(documentId)
                .filter(item -> item.getClaim().getId().equals(claimId))
                .orElseThrow(() -> new ClaimDocumentNotFoundException(documentId));

        return storageService.getPresignedDownloadUrl(document.getS3Key());
    }

    private void cleanupUploadedFile(String s3Key, RuntimeException exception) {
        try {
            storageService.delete(s3Key);
        } catch (FileStorageException cleanupException) {
            exception.addSuppressed(cleanupException);
            log.error("Failed to clean up uploaded claim document. key={}", s3Key, cleanupException);
        }
    }
}

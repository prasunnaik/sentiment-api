package com.insurewise.framework.s3.service;

import com.amazonaws.AmazonClientException;
import com.amazonaws.HttpMethod;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.GeneratePresignedUrlRequest;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.insurewise.framework.s3.config.S3FileStorageProperties;
import com.insurewise.framework.s3.exception.S3StorageException;
import java.io.IOException;
import java.time.Duration;
import java.time.Instant;
import java.util.Date;
import java.util.Set;
import java.util.UUID;
import org.springframework.web.multipart.MultipartFile;

public class AwsS3FileStorageService
        implements S3FileStorageService {

    private static final Set<String> ALLOWED_FOLDERS = Set.of(
            "profile-pictures",
            "application-documents",
            "claim-documents",
            "payment-documents");

    private final AmazonS3 amazonS3;
    private final S3FileStorageProperties properties;

    public AwsS3FileStorageService(
            AmazonS3 amazonS3,
            S3FileStorageProperties properties) {

        this.amazonS3 = amazonS3;
        this.properties = properties;
    }

    @Override
    public String upload(
            MultipartFile file,
            String folder,
            UUID ownerId) {

        if (file == null || file.isEmpty()) {
            throw new S3StorageException(
                    "A non-empty file is required.");
        }

        String key = buildKey(
                folder,
                ownerId,
                file.getOriginalFilename());

        try {
            ObjectMetadata metadata = new ObjectMetadata();
            metadata.setContentLength(file.getSize());
            metadata.setContentType(
                    contentType(file.getContentType()));

            amazonS3.putObject(
                    new PutObjectRequest(
                            properties.bucket(),
                            key,
                            file.getInputStream(),
                            metadata));

            return key;

        } catch (IOException | AmazonClientException exception) {
            throw new S3StorageException(
                    "Unable to upload file to S3.",
                    exception);
        }
    }

    @Override
    public String uploadGenerated(
            byte[] content,
            String fileName,
            String contentType,
            String folder,
            UUID ownerId) {

        if (content == null || content.length == 0) {
            throw new S3StorageException(
                    "Generated file content is required.");
        }

        String key = buildKey(
                folder,
                ownerId,
                fileName);

        try {
            ObjectMetadata metadata = new ObjectMetadata();
            metadata.setContentLength(content.length);
            metadata.setContentType(contentType(contentType));

            amazonS3.putObject(
                    new PutObjectRequest(
                            properties.bucket(),
                            key,
                            new java.io.ByteArrayInputStream(content),
                            metadata));

            return key;

        } catch (AmazonClientException exception) {
            throw new S3StorageException(
                    "Unable to upload generated file to S3.",
                    exception);
        }
    }

    @Override
    public S3PresignedUrl getPresignedDownloadUrl(
            String s3Key) {

        validateKey(s3Key);

        Duration ttl = properties.effectivePresignedUrlTtl();

        if (ttl.isZero()
                || ttl.isNegative()
                || ttl.compareTo(Duration.ofDays(7)) > 0) {
            throw new S3StorageException(
                    "S3 URL TTL must be between one second and seven days.");
        }

        Date expiration = Date.from(
                Instant.now().plus(ttl));

        try {
            GeneratePresignedUrlRequest request =
                    new GeneratePresignedUrlRequest(
                            properties.bucket(),
                            s3Key);

            request.setMethod(HttpMethod.GET);
            request.setExpiration(expiration);

            String url = amazonS3
                    .generatePresignedUrl(request)
                    .toExternalForm();

            return new S3PresignedUrl(
                    url,
                    expiration.toInstant());

        } catch (AmazonClientException exception) {
            throw new S3StorageException(
                    "Unable to generate S3 download URL.",
                    exception);
        }
    }

    @Override
    public void delete(String s3Key) {

        validateKey(s3Key);

        try {
            amazonS3.deleteObject(
                    properties.bucket(),
                    s3Key);

        } catch (AmazonClientException exception) {
            throw new S3StorageException(
                    "Unable to delete file from S3.",
                    exception);
        }
    }

    private String buildKey(
            String folder,
            UUID ownerId,
            String fileName) {

        if (!ALLOWED_FOLDERS.contains(folder)) {
            throw new S3StorageException(
                    "Unsupported S3 folder: " + folder);
        }

        if (ownerId == null) {
            throw new S3StorageException(
                    "File owner is required.");
        }

        String prefix = properties.keyPrefix();

        String normalizedPrefix = prefix == null
                || prefix.isBlank()
                ? ""
                : prefix.replaceAll("^/+|/+$", "") + "/";

        return normalizedPrefix
                + folder
                + "/"
                + ownerId
                + "/"
                + UUID.randomUUID()
                + "-"
                + sanitizeFileName(fileName);
    }

    private String sanitizeFileName(String fileName) {

        String value = fileName == null
                ? "file"
                : fileName.replace('\\', '/');

        value = value.substring(
                value.lastIndexOf('/') + 1);

        value = value.replaceAll(
                "[^A-Za-z0-9._-]",
                "_");

        return value.isBlank() ? "file" : value;
    }

    private String contentType(String value) {
        return value == null || value.isBlank()
                ? "application/octet-stream"
                : value;
    }

    private void validateKey(String s3Key) {

        if (s3Key == null || s3Key.isBlank()) {
            throw new S3StorageException(
                    "S3 key is required.");
        }

        String prefix = properties.keyPrefix();

        if (prefix != null && !prefix.isBlank()) {
            String normalizedPrefix =
                    prefix.replaceAll("^/+|/+$", "") + "/";

            if (!s3Key.startsWith(normalizedPrefix)) {
                throw new S3StorageException(
                        "S3 key is outside the configured prefix.");
            }
        }
    }
}

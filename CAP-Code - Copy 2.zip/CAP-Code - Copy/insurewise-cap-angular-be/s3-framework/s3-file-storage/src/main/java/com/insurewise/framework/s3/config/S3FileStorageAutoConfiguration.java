package com.insurewise.framework.s3.config;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.auth.DefaultAWSCredentialsProviderChain;
import com.amazonaws.auth.AWSCredentialsProvider;
import com.amazonaws.client.builder.AwsClientBuilder;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.insurewise.framework.s3.service.AwsS3FileStorageService;
import com.insurewise.framework.s3.service.S3FileStorageService;
import java.net.URI;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;

@AutoConfiguration
@ConditionalOnClass(AmazonS3.class)
@ConditionalOnProperty(
        prefix = "insurewise.storage",
        name = "enabled",
        havingValue = "true")
@EnableConfigurationProperties(S3FileStorageProperties.class)
public class S3FileStorageAutoConfiguration {

    @Bean(destroyMethod = "shutdown")
    @ConditionalOnMissingBean
    public AmazonS3 amazonS3(
            S3FileStorageProperties properties) {

        AmazonS3ClientBuilder builder =
                AmazonS3ClientBuilder.standard()
                        .withRegion(properties.region())
                        .withCredentials(
                                DefaultAWSCredentialsProviderChain
                                        .getInstance())
                        .withPathStyleAccessEnabled(
                                properties.pathStyleAccessEnabled());

        if (properties.endpoint() != null
                && !properties.endpoint().isBlank()) {
            builder.withEndpointConfiguration(
                    new AwsClientBuilder.EndpointConfiguration(
                            URI.create(properties.endpoint())
                                    .toString(),
                            properties.region()));
        }

        return builder.build();
    }

    @Bean
    @ConditionalOnMissingBean
    public S3FileStorageService s3FileStorageService(
            AmazonS3 amazonS3,
            S3FileStorageProperties properties) {

        return new AwsS3FileStorageService(
                amazonS3,
                properties);
    }
}

package com.insurewise.framework.s3.config;

import java.time.Duration;
import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "insurewise.storage")
public record S3FileStorageProperties(
        boolean enabled,
        String bucket,
        String region,
        String keyPrefix,
        Duration presignedUrlTtl,
        String endpoint,
        boolean pathStyleAccessEnabled
) {
    public Duration effectivePresignedUrlTtl() {
        return presignedUrlTtl == null
                ? Duration.ofMinutes(15)
                : presignedUrlTtl;
    }
}

package com.insurewise.payments.client;

import com.insurewise.policy.entity.ApplicationStatus;
import com.insurewise.policy.entity.PolicyApplication;
import com.insurewise.policy.exception.ApplicationNotFoundException;
import com.insurewise.policy.repository.PolicyApplicationRepository;
import org.springframework.stereotype.Component;

import java.util.UUID;

@Component
public class PaymentPolicyApplicationLookupClient {
    private final PolicyApplicationRepository repository;

    public PaymentPolicyApplicationLookupClient(
            PolicyApplicationRepository repository) {
        this.repository = repository;
    }

    public PaymentPolicyApplicationSnapshot
    getActiveApplicationForCustomer(
            UUID applicationId,
            UUID customerId) {

        PolicyApplication application = repository.findById(applicationId)
                .filter(item -> item.isOwnedBy(customerId))
                .filter(item -> item.getStatus()
                        == ApplicationStatus.ACTIVE)
                .orElseThrow(() -> new ApplicationNotFoundException(
                        applicationId));

        return new PaymentPolicyApplicationSnapshot(
                application.getId(),
                customerId,
                application.getPolicy().getName(),
                true);
    }
}
package com.insurewise.policy.service;

import com.insurewise.common.dto.PresignedUrlResponse;
import com.insurewise.common.security.JwtPrincipal;
import com.insurewise.common.security.JwtRole;
import com.insurewise.common.service.S3StorageService;
import com.insurewise.policy.dto.response.ApplicationDocumentResponse;
import com.insurewise.policy.entity.ApplicationDocument;
import com.insurewise.policy.entity.PolicyApplication;
import com.insurewise.policy.exception.ApplicationNotFoundException;
import com.insurewise.policy.repository.ApplicationDocumentRepository;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;
import com.insurewise.common.exception.InvalidFileException;
import com.insurewise.policy.exception.ApplicationDocumentNotFoundException;

@Service
@Transactional
public class ApplicationDocumentService {
    private static final long MAX_FILE_SIZE = 10L * 1024 * 1024;
    private static final Set<String> ALLOWED_EXTENSIONS =
            Set.of("pdf");

    private final ApplicationDocumentRepository documentRepository;
    private final PolicyApplicationService applicationService;
    private final S3StorageService storageService;

    public ApplicationDocumentService(
            ApplicationDocumentRepository documentRepository,
            PolicyApplicationService applicationService,
            S3StorageService storageService) {
        this.documentRepository = documentRepository;
        this.applicationService = applicationService;
        this.storageService = storageService;
    }

        /**
         * Uploads a PDF document to S3 and records its metadata for a policy application.
         * Customers may upload only to applications they own.
         *
         * @param principal authenticated user requesting the upload
         * @param applicationId policy application that will own the document
         * @param file PDF document to upload
         * @return persisted document metadata with a presigned download URL
         */
    public ApplicationDocumentResponse uploadDocument(
            JwtPrincipal principal,
            UUID applicationId,
            MultipartFile file) {

        try {
            PolicyApplication application =
                    requireApplicationAccess(principal, applicationId);

            validateFile(file);

            String s3Key = storageService.upload(
                    file,
                    "application-documents",
                    principal.userId());

            ApplicationDocument document = documentRepository.save(
                    new ApplicationDocument(
                            application,
                            file.getOriginalFilename() == null
                                    ? "unnamed-file"
                                    : file.getOriginalFilename(),
                            file.getContentType(),
                            s3Key,
                            principal.userId()));

            return toResponse(document);

        } catch (Exception exception) {
            System.err.println(
                    "Error in ApplicationDocumentService.uploadDocument: "
                            + exception.getMessage());
            throw exception;
        }
    }

        /**
         * Lists document metadata for a policy application.
         * Customers may view documents only for applications they own.
         * @param principal authenticated user requesting the documents
         * @param applicationId policy application whose documents are requested
         * @return application documents ordered from newest to oldest
         */
    @Transactional(readOnly = true)
    public List<ApplicationDocumentResponse> listDocuments(
            JwtPrincipal principal,
            UUID applicationId) {

        try {
            requireApplicationAccess(principal, applicationId);

            return documentRepository
                    .findByPolicyApplicationIdOrderByCreatedAtDesc(applicationId)
                    .stream()
                    .map(this::toResponse)
                    .toList();

        } catch (Exception exception) {
            System.err.println(
                    "Error in ApplicationDocumentService.listDocuments: "
                            + exception.getMessage());
            throw exception;
        }
    }

        /**
         * Deletes a policy application document from S3 and the application database.
         * Customers may delete documents only from applications they own.
         * @param principal authenticated user requesting the deletion
         * @param applicationId policy application that owns the document
         * @param documentId document to delete
         */
    public void deleteDocument(
            JwtPrincipal principal,
            UUID applicationId,
            UUID documentId) {

        try {
            requireApplicationAccess(principal, applicationId);

            ApplicationDocument document =
                    documentRepository.findById(documentId)
                            .filter(item -> item
                                    .getPolicyApplication()
                                    .getId()
                                    .equals(applicationId))
                            .orElseThrow(() ->
                                    new ApplicationDocumentNotFoundException(
                                            documentId));

            storageService.delete(document.getS3Key());
            documentRepository.delete(document);

        } catch (Exception exception) {
            System.err.println(
                    "Error in ApplicationDocumentService.deleteDocument: "
                            + exception.getMessage());
            throw exception;
        }
    }

    private void validateFile(MultipartFile file) {
        if (file == null || file.isEmpty()) {
            throw new InvalidFileException("A non-empty document is required");
        }
        if (file.getSize() > MAX_FILE_SIZE) {
            throw new InvalidFileException("Document size cannot exceed 10MB");
        }
        String fileName = file.getOriginalFilename();
        int extensionSeparator = fileName == null ? -1 : fileName.lastIndexOf('.');
        String extension = extensionSeparator < 0
                ? ""
                : fileName.substring(extensionSeparator + 1).toLowerCase(Locale.ROOT);
        if (!ALLOWED_EXTENSIONS.contains(extension)) {
            throw new InvalidFileException(
                                        "Document must be a .pdf file");
        }
    }

    private PolicyApplication requireApplicationAccess(
            JwtPrincipal principal,
            UUID applicationId) {

        PolicyApplication application =
                applicationService.getApplicationEntityForInternalUse(
                        applicationId);

        if (principal.role() == JwtRole.CUSTOMER
                && !application.isOwnedBy(principal.userId())) {
            throw new ApplicationNotFoundException(applicationId);
        }

        return application;
    }

    private ApplicationDocumentResponse toResponse(
            ApplicationDocument document) {

        PresignedUrlResponse download =
                storageService.getPresignedDownloadUrl(document.getS3Key());

        return new ApplicationDocumentResponse(
                document.getId(),
                document.getPolicyApplication().getId(),
                document.getFileName(),
                document.getContentType(),
                download,
                document.getUploadedBy(),
                document.getCreatedAt());
    }
}
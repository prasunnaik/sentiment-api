package com.insurewise.policy.exception;

import java.util.UUID;

public class DependentNotFoundException extends RuntimeException {
    public DependentNotFoundException(UUID dependentId) {
        super("Dependent not found: " + dependentId);
    }
}
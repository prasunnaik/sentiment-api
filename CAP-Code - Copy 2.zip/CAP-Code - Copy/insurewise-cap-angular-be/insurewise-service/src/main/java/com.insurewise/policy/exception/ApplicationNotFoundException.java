package com.insurewise.policy.exception;

import java.util.UUID;

public class ApplicationNotFoundException extends RuntimeException {
    public ApplicationNotFoundException(UUID applicationId) {
        super("Policy application not found: " + applicationId);
    }
}
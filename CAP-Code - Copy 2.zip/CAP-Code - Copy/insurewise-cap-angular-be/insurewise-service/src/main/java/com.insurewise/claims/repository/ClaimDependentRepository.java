package com.insurewise.claims.repository;

import com.insurewise.claims.entity.ClaimDependent;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.UUID;

public interface ClaimDependentRepository
        extends JpaRepository<ClaimDependent, UUID> {

    List<ClaimDependent> findByClaimId(UUID claimId);
}
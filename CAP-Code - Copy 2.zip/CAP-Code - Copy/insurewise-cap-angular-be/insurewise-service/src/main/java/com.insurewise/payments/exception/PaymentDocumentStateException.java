package com.insurewise.payments.exception;

public class PaymentDocumentStateException
        extends RuntimeException {

    public PaymentDocumentStateException(String message) {
        super(message);
    }
}
package com.insurewise.auth.exception;

import java.util.UUID;

public class StaffProfilePictureNotFoundException
        extends RuntimeException {

    public StaffProfilePictureNotFoundException(
            UUID staffUserId) {

        super("Profile picture not found for staff user: "
                + staffUserId);
    }
}

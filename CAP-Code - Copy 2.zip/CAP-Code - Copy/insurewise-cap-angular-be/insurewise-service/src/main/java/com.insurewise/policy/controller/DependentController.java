package com.insurewise.policy.controller;

import com.insurewise.common.security.JwtPrincipal;
import com.insurewise.policy.dto.request.DependentRequest;
import com.insurewise.policy.dto.response.DependentResponse;
import com.insurewise.policy.service.DependentService;
import jakarta.validation.Valid;
import java.util.List;
import java.util.UUID;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/applications/{id}/dependents")
@PreAuthorize("hasRole('CUSTOMER')")
public class DependentController {
    private final DependentService service;

    public DependentController(DependentService service) {
        this.service = service;
    }

    /** Adds a dependent to the authenticated customer's policy application. */
    @PostMapping
    public DependentResponse add(
            @AuthenticationPrincipal JwtPrincipal principal,
            @PathVariable UUID id,
            @Valid @RequestBody DependentRequest request) {
        return service.addDependent(principal, id, request);
    }

    /** Lists dependents on the authenticated customer's policy application. */
    @GetMapping
    public List<DependentResponse> list(
            @AuthenticationPrincipal JwtPrincipal principal,
            @PathVariable UUID id) {
        return service.listDependents(principal, id);
    }

    /** Updates a dependent on the authenticated customer's policy application. */
    @PutMapping("/{dependentId}")
    public DependentResponse update(
            @AuthenticationPrincipal JwtPrincipal principal,
            @PathVariable UUID id,
            @PathVariable UUID dependentId,
            @Valid @RequestBody DependentRequest request) {
        return service.updateDependent(
                principal,
                id,
                dependentId,
                request);
    }

    /** Removes a dependent from the authenticated customer's policy application. */
    @DeleteMapping("/{dependentId}")
    public void delete(
            @AuthenticationPrincipal JwtPrincipal principal,
            @PathVariable UUID id,
            @PathVariable UUID dependentId) {
        service.deleteDependent(principal, id, dependentId);
    }
}
package com.insurewise.auth.dto.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.insurewise.common.dto.PresignedUrlResponse;
import java.util.UUID;

public record ProfilePictureResponse(
        @JsonProperty("customer_id")
        UUID customerId,

        @JsonProperty("s3_key")
        String s3Key,

        PresignedUrlResponse download
) {
}

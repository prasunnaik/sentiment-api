// (Apply for Policy / My Policies). The
// original class also contained staff-only approve/reject methods
// (BR-05: Approve Policy), which have been removed here since they are a
// teammate's requirement. getApplicationEntityForInternalUse() is kept
// because DependentService and ApplicationDocumentService (also BR-02)
// call it to resolve/validate ownership of the parent application.
package com.insurewise.policy.service;

import com.insurewise.common.security.JwtPrincipal;
import com.insurewise.policy.dto.request.PolicyApplicationCreateRequest;
import com.insurewise.policy.dto.response.*;
import com.insurewise.policy.entity.*;
import com.insurewise.policy.exception.*;
import com.insurewise.policy.repository.PolicyApplicationRepository;
import java.time.LocalDate;
import java.util.List;
import java.util.UUID;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


@Service
@Transactional
public class PolicyApplicationService {
    private final PolicyApplicationRepository applicationRepository;
    private final PolicyService policyService;

    public PolicyApplicationService(
            PolicyApplicationRepository applicationRepository,
            PolicyService policyService) {
        this.applicationRepository = applicationRepository;
        this.policyService = policyService;
    }

    /**
     * Creates a pending application for an active catalog policy.
     *
     * @param customerId customer submitting the application
     * @param request policy application details
     * @return the created pending application
     */
    public PolicyApplicationResponse createApplication(
            UUID customerId,
            PolicyApplicationCreateRequest request) {

        try {
            Policy policy = policyService.find(request.policyId());

            if (!policy.isActiveForCustomer()) {
                throw new ApplicationStateException(
                        "Applications can only be created for active policies");
            }

            if (request.preferredStartDate() != null
                    && request.preferredStartDate().isBefore(LocalDate.now())) {
                throw new ApplicationStateException(
                        "Preferred start date cannot be in the past");
            }

            boolean duplicate = applicationRepository
                    .existsByCustomerIdAndPolicyIdAndStatus(
                            customerId,
                            request.policyId(),
                            ApplicationStatus.PENDING);

            if (duplicate) {
                throw new DuplicatePendingApplicationException();
            }

            Long sequence = applicationRepository.nextApplicationCodeSequence();

            PolicyApplication application = new PolicyApplication(
                    "APP-" + sequence,
                    customerId,
                    policy,
                    request.coverageType(),
                    request.dateOfBirth(),
                    request.address(),
                    request.preferredStartDate(),
                    request.nomineeName(),
                    request.nomineeRelationship());

            return toResponse(applicationRepository.save(application));

        } catch (Exception exception) {
            System.err.println(
                    "Error in PolicyApplicationService.createApplication: "
                            + exception.getMessage());
            throw exception;
        }
    }

    /**
     * Lists applications visible to the authenticated user, optionally filtered by status.
     * Customers receive only their own applications; staff receive all applications.
     *
     * @param principal authenticated customer or staff user
     * @param status optional application status filter
     * @return matching applications ordered from newest to oldest
     */
    @Transactional(readOnly = true)
    public List<PolicyApplicationResponse> listApplications(
            JwtPrincipal principal,
            ApplicationStatus status) {

        try {
            List<PolicyApplication> applications;

            if (principal.role().name().equals("STAFF")) {
                applications = status == null
                        ? applicationRepository.findAll()
                        : applicationRepository.findByStatusOrderByCreatedAtDesc(
                        status);
            } else {
                applications = status == null
                        ? applicationRepository
                        .findByCustomerIdOrderByCreatedAtDesc(
                                principal.userId())
                        : applicationRepository
                        .findByCustomerIdAndStatusOrderByCreatedAtDesc(
                                principal.userId(),
                                status);
            }

            return applications.stream()
                    .map(this::toResponse)
                    .toList();

        } catch (Exception exception) {
            System.err.println(
                    "Error in PolicyApplicationService.listApplications: "
                            + exception.getMessage());
            throw exception;
        }
    }

    /**
     * Returns an application if it is visible to the authenticated user.
     *
     * @param principal authenticated customer or staff user
     * @param applicationId application to retrieve
     * @return requested application details
     */
    @Transactional(readOnly = true)
    public PolicyApplicationResponse getApplication(
            JwtPrincipal principal,
            UUID applicationId) {

        try {
            PolicyApplication application =
                    getApplicationEntity(applicationId);

            if (principal.role().name().equals("CUSTOMER")
                    && !application.isOwnedBy(principal.userId())) {
                throw new ApplicationNotFoundException(applicationId);
            }

            return toResponse(application);

        } catch (Exception exception) {
            System.err.println(
                    "Error in PolicyApplicationService.getApplication: "
                            + exception.getMessage());
            throw exception;
        }
    }

    /**
     * Retrieves an application entity for use by policy-module services.
     *
     * @param applicationId application to retrieve
     * @return managed policy application entity
     */
    public PolicyApplication getApplicationEntityForInternalUse(
            UUID applicationId) {
        return getApplicationEntity(applicationId);
    }

    private PolicyApplication getApplicationEntity(UUID applicationId) {
        return applicationRepository.findById(applicationId)
                .orElseThrow(() ->
                        new ApplicationNotFoundException(applicationId));
    }

    private PolicyApplicationResponse toResponse(
            PolicyApplication application) {

        return new PolicyApplicationResponse(
                application.getId(),
                application.getApplicationCode(),
                application.getCustomerId(),
                application.getPolicy().getId(),
                application.getPolicy().getName(),
                application.getCoverageType(),
                application.getCoverageAmount(),
                application.getPremiumAmount(),
                application.getDateOfBirth(),
                application.getAddress(),
                application.getPreferredStartDate(),
                application.getNomineeName(),
                application.getNomineeRelationship(),
                application.getStartDate(),
                application.getEndDate(),
                application.getStatus(),
                application.getDecidedBy(),
                application.getDecidedAt(),
                application.getCreatedAt());
    }
}

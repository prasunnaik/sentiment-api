package com.insurewise.payments.repository;

import com.insurewise.payments.entity.PaymentDocument;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.UUID;

public interface PaymentDocumentRepository
        extends JpaRepository<PaymentDocument, UUID> {

    List<PaymentDocument> findByPaymentIdOrderByCreatedAtDesc(
            UUID paymentId);

    boolean existsByPaymentIdAndSystemGenerated(
            UUID paymentId,
            boolean systemGenerated);
}
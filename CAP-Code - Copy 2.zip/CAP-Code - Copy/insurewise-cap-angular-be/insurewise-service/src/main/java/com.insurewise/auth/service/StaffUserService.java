package com.insurewise.auth.service;

import com.insurewise.auth.dto.request.StaffCreateRequest;
import com.insurewise.auth.dto.request.StaffUpdateRequest;
import com.insurewise.auth.dto.response.StaffProfileResponse;
import com.insurewise.auth.entity.StaffUser;
import com.insurewise.auth.exception.DuplicateEmailException;
import com.insurewise.auth.exception.StaffUserNotFoundException;
import com.insurewise.auth.repository.CustomerRepository;
import com.insurewise.auth.repository.StaffUserRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;

@Service
@Transactional
public class StaffUserService {

    private final StaffUserRepository staffUserRepository;
    private final CustomerRepository customerRepository;
    private final PasswordEncoder passwordEncoder;

    public StaffUserService(
            StaffUserRepository staffUserRepository,
            CustomerRepository customerRepository,
            PasswordEncoder passwordEncoder) {

        this.staffUserRepository = staffUserRepository;
        this.customerRepository = customerRepository;
        this.passwordEncoder = passwordEncoder;
    }

    public StaffProfileResponse create(
            StaffCreateRequest request) {

        try {
            String email = request.email().toLowerCase();

            validateEmailNotUsed(email);

            StaffUser staffUser = new StaffUser(
                    request.fullName(),
                    email,
                    request.address(),
                    passwordEncoder.encode(request.password()));

            return toResponse(
                    staffUserRepository.save(staffUser));

        } catch (Exception exception) {
            System.err.println(
                    "Error in StaffUserService.create: "
                            + exception.getMessage());

            throw exception;
        }
    }

    @Transactional(readOnly = true)
    public List<StaffProfileResponse> list() {

        try {
            return staffUserRepository.findAll()
                    .stream()
                    .map(this::toResponse)
                    .toList();

        } catch (Exception exception) {
            System.err.println(
                    "Error in StaffUserService.list: "
                            + exception.getMessage());

            throw exception;
        }
    }

    @Transactional(readOnly = true)
    public StaffProfileResponse get(UUID id) {

        try {
            return toResponse(find(id));

        } catch (Exception exception) {
            System.err.println(
                    "Error in StaffUserService.get: "
                            + exception.getMessage());

            throw exception;
        }
    }

    public StaffProfileResponse update(
            UUID id,
            StaffUpdateRequest request) {

        try {

            StaffUser staffUser = find(id);

            String email = request.email().toLowerCase();

            boolean emailUsedByAnotherStaff =
                    staffUserRepository
                            .findByEmailIgnoreCase(email)
                            .filter(existing ->
                                    !existing.getId().equals(id))
                            .isPresent();

            boolean emailUsedByCustomer =
                    customerRepository
                            .existsByEmailIgnoreCase(email);

            if (emailUsedByAnotherStaff
                    || emailUsedByCustomer) {
                throw new DuplicateEmailException(email);
            }

            String passwordHash = null;

            if (request.password() != null
                    && !request.password().isBlank()) {

                passwordHash =
                        passwordEncoder.encode(request.password());
            }

            staffUser.update(
                    request.fullName(),
                    email,
                    request.address(),
                    passwordHash);

            return toResponse(staffUser);

        } catch (Exception exception) {
            System.err.println(
                    "Error in StaffUserService.update: "
                            + exception.getMessage());

            throw exception;
        }
    }

    public void delete(UUID id) {

        try {
            StaffUser staffUser = find(id);

            staffUserRepository.delete(staffUser);

        } catch (Exception exception) {
            System.err.println(
                    "Error in StaffUserService.delete: "
                            + exception.getMessage());

            throw exception;
        }
    }

    private StaffUser find(UUID id) {

        return staffUserRepository.findById(id)
                .orElseThrow(() ->
                        new StaffUserNotFoundException(id));
    }

    private void validateEmailNotUsed(String email) {

        if (staffUserRepository.existsByEmailIgnoreCase(email)
                || customerRepository.existsByEmailIgnoreCase(email)) {

            throw new DuplicateEmailException(email);
        }
    }

    private StaffProfileResponse toResponse(
            StaffUser staffUser) {

        return new StaffProfileResponse(
                staffUser.getId(),
                staffUser.getFullName(),
                staffUser.getEmail(),
                staffUser.getAddress());
    }
}

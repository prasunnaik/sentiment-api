package com.insurewise.auth.controller;

import com.insurewise.auth.dto.response.ProfilePictureResponse;
import com.insurewise.auth.service.ProfilePictureService;
import com.insurewise.common.security.JwtPrincipal;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/auth")
@PreAuthorize("hasRole('CUSTOMER')")
public class ProfileController {

    private final ProfilePictureService profilePictureService;

    public ProfileController(
            ProfilePictureService profilePictureService) {
        this.profilePictureService = profilePictureService;
    }

    @PostMapping(
            value = "/profile-picture/upload",
            consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<ProfilePictureResponse> upload(
            @AuthenticationPrincipal JwtPrincipal principal,
            @RequestPart("file") MultipartFile file) {

        ProfilePictureResponse response =
                profilePictureService.upload(
                        principal.userId(),
                        file);

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(response);
    }

    @GetMapping("/profile-picture")
    public ProfilePictureResponse get(
            @AuthenticationPrincipal JwtPrincipal principal) {

        return profilePictureService.get(
                principal.userId());
    }

    @DeleteMapping("/profile-picture")
    public ResponseEntity<Void> delete(
            @AuthenticationPrincipal JwtPrincipal principal) {

        profilePictureService.delete(
                principal.userId());

        return ResponseEntity.noContent().build();
    }
}

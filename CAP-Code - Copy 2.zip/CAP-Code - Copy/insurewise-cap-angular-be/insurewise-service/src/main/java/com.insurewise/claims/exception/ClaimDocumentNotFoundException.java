package com.insurewise.claims.exception;

import java.util.UUID;

public class ClaimDocumentNotFoundException extends RuntimeException {

    public ClaimDocumentNotFoundException(UUID id) {
        super("Claim document not found: " + id);
    }
}
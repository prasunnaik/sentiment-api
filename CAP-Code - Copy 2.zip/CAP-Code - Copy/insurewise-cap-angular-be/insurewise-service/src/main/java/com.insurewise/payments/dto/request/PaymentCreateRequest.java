package com.insurewise.payments.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.insurewise.payments.entity.PaymentMethod;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.math.BigDecimal;
import java.util.UUID;

public record PaymentCreateRequest(
        @JsonProperty("idempotency_key")
        @NotBlank
        @Size(max = 80)
        String idempotencyKey,

        @JsonProperty("policy_application_id")
        @NotNull
        UUID policyApplicationId,

        @NotNull
        @DecimalMin("0.01")
        BigDecimal amount,

        @NotNull
        PaymentMethod method
) {
}
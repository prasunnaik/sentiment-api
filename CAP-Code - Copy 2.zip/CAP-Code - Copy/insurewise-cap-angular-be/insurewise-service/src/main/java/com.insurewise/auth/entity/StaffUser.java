package com.insurewise.auth.entity;

import jakarta.persistence.*;

import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Table(name = "staff_users")
public class StaffUser {

    @Id
    private UUID id;

    @Column(name = "full_name", nullable = false, length = 120)
    private String fullName;

    @Column(nullable = false, unique = true, length = 160)
    private String email;

    @Column(nullable = false, length = 240)
    private String address;

    @Column(name = "password_hash", nullable = false, length = 100)
    private String passwordHash;

    @Column(name = "profile_picture_s3_key", length = 600)
    private String profilePictureS3Key;

    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;

    protected StaffUser() {
    }

    public StaffUser(
            String fullName,
            String email,
            String address,
            String passwordHash) {

        this.id = UUID.randomUUID();
        this.fullName = fullName;
        this.email = email.toLowerCase();
        this.address = address;
        this.passwordHash = passwordHash;
    }

    @PrePersist
    void prePersist() {
        if (createdAt == null) {
            createdAt = LocalDateTime.now();
        }
    }

    public UUID getId() {
        return id;
    }

    public String getFullName() {
        return fullName;
    }

    public String getEmail() {
        return email;
    }

    public String getAddress() {
        return address;
    }

    public String getPasswordHash() {
        return passwordHash;
    }

    public String getProfilePictureS3Key() {
        return profilePictureS3Key;
    }

    public void setProfilePictureS3Key(
            String profilePictureS3Key) {

        this.profilePictureS3Key = profilePictureS3Key;
    }

    public void update(
            String fullName,
            String email,
            String address,
            String passwordHash) {

        this.fullName = fullName;
        this.email = email.toLowerCase();
        this.address = address;

        if (passwordHash != null
                && !passwordHash.isBlank()) {
            this.passwordHash = passwordHash;
        }
    }
}
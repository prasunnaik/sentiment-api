package com.insurewise.policy.exception;

import java.util.UUID;

public class ApplicationDocumentNotFoundException extends RuntimeException {
    public ApplicationDocumentNotFoundException(UUID documentId) {
        super("Application document not found: " + documentId);
    }
}
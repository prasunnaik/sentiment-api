package com.insurewise.auth.service;

import com.insurewise.auth.dto.response.StaffProfilePictureResponse;
import com.insurewise.auth.entity.StaffUser;
import com.insurewise.auth.exception.StaffProfilePictureNotFoundException;
import com.insurewise.auth.exception.StaffUserNotFoundException;
import com.insurewise.auth.repository.StaffUserRepository;
import com.insurewise.common.exception.InvalidFileException;
import com.insurewise.common.service.S3StorageService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.util.Set;
import java.util.UUID;

@Service
@Transactional
public class StaffProfilePictureService {

    private static final Logger log =
            LoggerFactory.getLogger(
                    StaffProfilePictureService.class);

    private static final Set<String> ALLOWED_TYPES = Set.of(
            "image/jpeg",
            "image/png",
            "image/webp");

    private final StaffUserRepository staffUserRepository;
    private final S3StorageService storageService;

    public StaffProfilePictureService(
            StaffUserRepository staffUserRepository,
            S3StorageService storageService) {

        this.staffUserRepository = staffUserRepository;
        this.storageService = storageService;
    }

    public StaffProfilePictureResponse upload(
            UUID staffUserId,
            MultipartFile file) {

        validate(file);

        StaffUser staffUser = findStaffUser(staffUserId);
        String oldKey = staffUser.getProfilePictureS3Key();

        String newKey = storageService.upload(
                file,
                "profile-pictures",
                staffUserId);

        try {
            staffUser.setProfilePictureS3Key(newKey);
            staffUserRepository.save(staffUser);

        } catch (RuntimeException exception) {
            try {
                storageService.delete(newKey);
            } catch (RuntimeException cleanupException) {
                log.warn(
                        "Could not clean up new staff profile picture. key={}",
                        newKey,
                        cleanupException);
            }

            throw exception;
        }

        if (oldKey != null
                && !oldKey.isBlank()
                && !oldKey.equals(newKey)) {

            try {
                storageService.delete(oldKey);
            } catch (RuntimeException exception) {
                log.warn(
                        "New staff profile picture saved, "
                                + "but old object could not be deleted. key={}",
                        oldKey,
                        exception);
            }
        }

        return toResponse(staffUser);
    }

    @Transactional(readOnly = true)
    public StaffProfilePictureResponse get(
            UUID staffUserId) {

        StaffUser staffUser = findStaffUser(staffUserId);
        String s3Key = staffUser.getProfilePictureS3Key();

        if (s3Key == null || s3Key.isBlank()) {
            throw new StaffProfilePictureNotFoundException(
                    staffUserId);
        }

        return toResponse(staffUser);
    }

    public void delete(UUID staffUserId) {

        StaffUser staffUser = findStaffUser(staffUserId);
        String s3Key = staffUser.getProfilePictureS3Key();

        if (s3Key == null || s3Key.isBlank()) {
            throw new StaffProfilePictureNotFoundException(
                    staffUserId);
        }

        storageService.delete(s3Key);

        staffUser.setProfilePictureS3Key(null);
        staffUserRepository.save(staffUser);
    }

    private StaffUser findStaffUser(UUID staffUserId) {
        return staffUserRepository.findById(staffUserId)
                .orElseThrow(() ->
                        new StaffUserNotFoundException(
                                staffUserId));
    }

    private void validate(MultipartFile file) {

        if (file == null || file.isEmpty()) {
            throw new InvalidFileException(
                    "A non-empty profile picture is required.");
        }

        if (file.getContentType() == null
                || !ALLOWED_TYPES.contains(
                file.getContentType())) {

            throw new InvalidFileException(
                    "Only JPEG, PNG, and WebP images are allowed.");
        }
    }

    private StaffProfilePictureResponse toResponse(
            StaffUser staffUser) {

        String s3Key = staffUser.getProfilePictureS3Key();

        return new StaffProfilePictureResponse(
                staffUser.getId(),
                s3Key,
                storageService.getPresignedDownloadUrl(
                        s3Key));
    }
}

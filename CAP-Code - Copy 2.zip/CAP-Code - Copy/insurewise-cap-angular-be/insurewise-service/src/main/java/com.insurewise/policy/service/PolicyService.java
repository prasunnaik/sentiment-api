//(Browse Policies). The original class
// also contained staff-only create/update/delete methods (BR-05: Add
// Policy), which have been removed here since they are a teammate's
// requirement. Removing them also drops the CategoryService dependency,
// which was only used to resolve a policy's category on create/update.
package com.insurewise.policy.service;

import com.insurewise.policy.dto.response.PolicyResponse;
import com.insurewise.policy.entity.Policy;
import com.insurewise.policy.entity.PolicyStatus;
import com.insurewise.policy.repository.PolicyRepository;
import java.util.List;
import java.util.UUID;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.insurewise.policy.exception.PolicyNotFoundException;

@Service
@Transactional
public class PolicyService {
    private final PolicyRepository policyRepository;

    public PolicyService(
            PolicyRepository policyRepository) {
        this.policyRepository = policyRepository;
    }

    /**
     * Lists catalog policies whose policy and category statuses are active.
     *
     * @return customer-visible policies ordered from newest to oldest
     */
    @Transactional(readOnly = true)
    public List<PolicyResponse> listActive() {

        try {
            return policyRepository
                    .findAllByStatusOrderByCreatedAtDesc(PolicyStatus.ACTIVE)
                    .stream()
                    .filter(Policy::isActiveForCustomer)
                    .map(this::toResponse)
                    .toList();
        } catch (Exception exception) {
            System.err.println(
                    "Error in PolicyService.listActive: "
                            + exception.getMessage());
            throw exception;
        }
    }

    /**
     * Returns a policy response by identifier.
     *
     * @param id policy identifier
     * @return requested policy details
     */
    @Transactional(readOnly = true)
    public PolicyResponse get(UUID id) {

        try {
            return toResponse(find(id));

        } catch (Exception exception) {
            System.err.println(
                    "Error in PolicyService.get: "
                            + exception.getMessage());
            throw exception;
        }
    }

    /**
     * Retrieves a policy entity by identifier for internal policy-module operations.
     *
     * @param id policy identifier
     * @return managed policy entity
     */
    public Policy find(UUID id) {
        return policyRepository.findById(id)
                .orElseThrow(() -> new PolicyNotFoundException(id));
    }

    private PolicyResponse toResponse(Policy policy) {
        return new PolicyResponse(
                policy.getId(),
                policy.getName(),
                policy.getCategory().getId(),
                policy.getCategory().getName(),
                policy.getCoverageAmount(),
                policy.getPremiumAmount(),
                policy.getDurationLabel(),
                policy.getStatus());
    }
}

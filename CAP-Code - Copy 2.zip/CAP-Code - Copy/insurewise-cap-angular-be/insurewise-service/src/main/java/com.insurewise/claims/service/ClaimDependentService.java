package com.insurewise.claims.service;

import com.insurewise.claims.dto.request.ClaimDependentRequest;
import com.insurewise.claims.dto.response.ClaimDependentResponse;
import com.insurewise.claims.entity.Claim;
import com.insurewise.claims.entity.ClaimDependent;
import com.insurewise.claims.exception.ClaimNotFoundException;
import com.insurewise.claims.repository.ClaimDependentRepository;
import com.insurewise.claims.repository.ClaimRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;


@Service
@Transactional
public class ClaimDependentService {
    private final ClaimRepository claimRepository;
    private final ClaimDependentRepository dependentRepository;

    public ClaimDependentService(
            ClaimRepository claimRepository,
            ClaimDependentRepository dependentRepository) {
        this.claimRepository = claimRepository;
        this.dependentRepository = dependentRepository;
    }

    public ClaimDependentResponse addDependent(
            UUID customerId,
            UUID claimId,
            ClaimDependentRequest request) {

        try {
            Claim claim = requireOwnedClaim(customerId, claimId);

            ClaimDependent dependent = dependentRepository.save(
                    new ClaimDependent(
                            claim,
                            request.fullName(),
                            request.relationship(),
                            request.dateOfBirth(),
                            request.gender()));

            return toResponse(dependent);

        } catch (Exception exception) {
            System.err.println(
                    "Error in ClaimDependentService.addDependent: "
                            + exception.getMessage());
            throw exception;
        }
    }

    @Transactional(readOnly = true)
    public List<ClaimDependentResponse> listDependents(
            UUID customerId,
            UUID claimId) {

        try {
            requireOwnedClaim(customerId, claimId);

            return dependentRepository.findByClaimId(claimId)
                    .stream()
                    .map(this::toResponse)
                    .toList();

        } catch (Exception exception) {
            System.err.println(
                    "Error in ClaimDependentService.listDependents: "
                            + exception.getMessage());
            throw exception;
        }
    }

    private Claim requireOwnedClaim(UUID customerId, UUID claimId) {
        return claimRepository.findById(claimId)
                .filter(claim -> claim.isOwnedBy(customerId))
                .orElseThrow(ClaimNotFoundException::new);
    }

    private ClaimDependentResponse toResponse(
            ClaimDependent dependent) {
        return new ClaimDependentResponse(
                dependent.getId(),
                dependent.getClaim().getId(),
                dependent.getFullName(),
                dependent.getRelationship(),
                dependent.getDateOfBirth(),
                dependent.getGender());
    }
}

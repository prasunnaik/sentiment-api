package com.insurewise.claims.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.insurewise.policy.entity.Gender;
import com.insurewise.policy.entity.Relationship;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Past;
import jakarta.validation.constraints.Size;

import java.time.LocalDate;

public record ClaimDependentRequest(
        @JsonProperty("full_name")
        @NotBlank
        @Size(max = 120)
        String fullName,

        @NotNull
        Relationship relationship,

        @JsonProperty("date_of_birth")
        @NotNull
        @Past
        LocalDate dateOfBirth,

        @NotNull
        Gender gender
) {
}
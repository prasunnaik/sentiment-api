package com.insurewise.auth.exception;

import java.util.UUID;

public class ProfilePictureNotFoundException
        extends RuntimeException {

    public ProfilePictureNotFoundException(
            UUID customerId) {

        super("Profile picture not found for customer: "
                + customerId);
    }
}

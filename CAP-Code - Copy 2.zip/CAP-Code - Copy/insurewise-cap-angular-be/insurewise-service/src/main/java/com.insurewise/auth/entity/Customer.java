package com.insurewise.auth.entity;

import jakarta.persistence.*;

import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Table(name = "customers")
public class Customer {

    @Id
    private UUID id;

    @Column(name = "full_name", nullable = false, length = 120)
    private String fullName;

    @Column(nullable = false, length = 30)
    private String phone;

    @Column(nullable = false, unique = true, length = 160)
    private String email;

    @Column(name = "password_hash", nullable = false, length = 100)
    private String passwordHash;

    @Column(
            name = "profile_picture_s3_key",
            length = 600)
    private String profilePictureS3Key;

    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;

    protected Customer() {
    }

    public Customer(
            String fullName,
            String phone,
            String email,
            String passwordHash) {

        this.id = UUID.randomUUID();
        this.fullName = fullName;
        this.phone = phone;
        this.email = email.toLowerCase();
        this.passwordHash = passwordHash;
    }

    @PrePersist
    void prePersist() {
        if (createdAt == null) {
            createdAt = LocalDateTime.now();
        }
    }

    public UUID getId() {
        return id;
    }

    public String getFullName() {
        return fullName;
    }

    public String getPhone() {
        return phone;
    }

    public String getEmail() {
        return email;
    }

    public String getPasswordHash() {
        return passwordHash;
    }

    public String getProfilePictureS3Key() {
        return profilePictureS3Key;
    }

    public void setProfilePictureS3Key(
            String profilePictureS3Key) {

        this.profilePictureS3Key = profilePictureS3Key;
    }

    public void update(
            String fullName,
            String phone) {

        this.fullName = fullName;
        this.phone = phone;
    }
}

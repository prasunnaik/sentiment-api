package com.insurewise.payments.exception;

import java.util.UUID;

public class PaymentDocumentNotFoundException
        extends RuntimeException {

    public PaymentDocumentNotFoundException(UUID id) {
        super("Payment document not found: " + id);
    }
}
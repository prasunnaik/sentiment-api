package com.insurewise.claims.controller;

import com.insurewise.claims.dto.request.ClaimDependentRequest;
import com.insurewise.claims.dto.response.ClaimDependentResponse;
import com.insurewise.claims.service.ClaimDependentService;
import com.insurewise.common.security.JwtPrincipal;
import jakarta.validation.Valid;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/claims/{id}/dependents")
@PreAuthorize("hasRole('CUSTOMER')")
public class ClaimDependentController {
    private final ClaimDependentService service;

    public ClaimDependentController(
            ClaimDependentService service) {
        this.service = service;
    }

    @PostMapping
    public ClaimDependentResponse add(
            @AuthenticationPrincipal JwtPrincipal principal,
            @PathVariable UUID id,
            @Valid @RequestBody ClaimDependentRequest request) {

        return service.addDependent(
                principal.userId(),
                id,
                request);
    }

    @GetMapping
    public List<ClaimDependentResponse> list(
            @AuthenticationPrincipal JwtPrincipal principal,
            @PathVariable UUID id) {

        return service.listDependents(
                principal.userId(),
                id);
    }
}

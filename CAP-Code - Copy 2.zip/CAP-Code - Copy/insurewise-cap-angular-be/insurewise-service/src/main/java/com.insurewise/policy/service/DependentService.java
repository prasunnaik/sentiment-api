package com.insurewise.policy.service;

import com.insurewise.common.security.JwtPrincipal;
import com.insurewise.common.security.JwtRole;
import com.insurewise.policy.dto.request.DependentRequest;
import com.insurewise.policy.dto.response.DependentResponse;
import com.insurewise.policy.entity.Dependent;
import com.insurewise.policy.entity.PolicyApplication;
import com.insurewise.policy.exception.ApplicationNotFoundException;
import com.insurewise.policy.repository.DependentRepository;
import java.util.List;
import java.util.UUID;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.insurewise.policy.exception.DependentNotFoundException;

@Service
@Transactional
public class DependentService {
    private final DependentRepository dependentRepository;
    private final PolicyApplicationService applicationService;

    public DependentService(
            DependentRepository dependentRepository,
            PolicyApplicationService applicationService) {
        this.dependentRepository = dependentRepository;
        this.applicationService = applicationService;
    }

        /**
         * Adds a dependent to a policy application after checking customer ownership.
         *
         * @param principal authenticated user requesting the addition
         * @param applicationId policy application that will own the dependent
         * @param request dependent details
         * @return persisted dependent details
         */
    public DependentResponse addDependent(
            JwtPrincipal principal,
            UUID applicationId,
            DependentRequest request) {

        try {
            PolicyApplication application =
                    requireApplicationAccess(principal, applicationId);

            Dependent dependent = dependentRepository.save(new Dependent(
                    application,
                    request.fullName(),
                    request.relationship(),
                    request.dateOfBirth(),
                    request.gender()));

            return toResponse(dependent);

        } catch (Exception exception) {
            System.err.println(
                    "Error in DependentService.addDependent: "
                            + exception.getMessage());
            throw exception;
        }
    }

        /**
         * Lists dependents for a policy application after checking customer ownership.
         *
         * @param principal authenticated user requesting the dependents
         * @param applicationId policy application whose dependents are requested
         * @return dependents ordered by creation time
         */
    @Transactional(readOnly = true)
    public List<DependentResponse> listDependents(
            JwtPrincipal principal,
            UUID applicationId) {

        try {
            requireApplicationAccess(principal, applicationId);

            return dependentRepository
                    .findByPolicyApplicationIdOrderByCreatedAtAsc(applicationId)
                    .stream()
                    .map(this::toResponse)
                    .toList();

        } catch (Exception exception) {
            System.err.println(
                    "Error in DependentService.listDependents: "
                            + exception.getMessage());
            throw exception;
        }
    }

        /**
         * Updates a dependent after checking that it belongs to the customer's application.
         *
         * @param principal authenticated user requesting the update
         * @param applicationId policy application that owns the dependent
         * @param dependentId dependent to update
         * @param request replacement dependent details
         * @return updated dependent details
         */
    public DependentResponse updateDependent(
            JwtPrincipal principal,
            UUID applicationId,
            UUID dependentId,
            DependentRequest request) {

        try {
            requireApplicationAccess(principal, applicationId);

            Dependent dependent =
                    requireDependent(applicationId, dependentId);

            dependent.update(
                    request.fullName(),
                    request.relationship(),
                    request.dateOfBirth(),
                    request.gender());

            return toResponse(dependent);

        } catch (Exception exception) {
            System.err.println(
                    "Error in DependentService.updateDependent: "
                            + exception.getMessage());
            throw exception;
        }
    }

        /**
         * Deletes a dependent after checking that it belongs to the customer's application.
         *
         * @param principal authenticated user requesting the deletion
         * @param applicationId policy application that owns the dependent
         * @param dependentId dependent to delete
         */
    public void deleteDependent(
            JwtPrincipal principal,
            UUID applicationId,
            UUID dependentId) {

        try {
            requireApplicationAccess(principal, applicationId);
            dependentRepository.delete(
                    requireDependent(applicationId, dependentId));

        } catch (Exception exception) {
            System.err.println(
                    "Error in DependentService.deleteDependent: "
                            + exception.getMessage());
            throw exception;
        }
    }

    private PolicyApplication requireApplicationAccess(
            JwtPrincipal principal,
            UUID applicationId) {

        PolicyApplication application =
                applicationService.getApplicationEntityForInternalUse(
                        applicationId);

        if (principal.role() == JwtRole.CUSTOMER
                && !application.isOwnedBy(principal.userId())) {
            throw new ApplicationNotFoundException(applicationId);
        }

        return application;
    }

    private Dependent requireDependent(
            UUID applicationId,
            UUID dependentId) {

        return dependentRepository.findById(dependentId)
                .filter(dependent -> dependent
                        .getPolicyApplication()
                        .getId()
                        .equals(applicationId))
                .orElseThrow(() ->
                        new DependentNotFoundException(dependentId));
    }

    private DependentResponse toResponse(Dependent dependent) {
        return new DependentResponse(
                dependent.getId(),
                dependent.getPolicyApplication().getId(),
                dependent.getFullName(),
                dependent.getRelationship(),
                dependent.getDateOfBirth(),
                dependent.getGender(),
                dependent.getCreatedAt());
    }
}
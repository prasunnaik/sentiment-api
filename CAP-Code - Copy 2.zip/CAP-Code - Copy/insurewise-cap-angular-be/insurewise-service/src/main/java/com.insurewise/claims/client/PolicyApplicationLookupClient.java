package com.insurewise.claims.client;

import com.insurewise.policy.entity.PolicyApplication;
import com.insurewise.policy.exception.ApplicationNotFoundException;
import com.insurewise.policy.repository.PolicyApplicationRepository;
import org.springframework.stereotype.Component;

import java.util.UUID;

@Component
public class PolicyApplicationLookupClient {
    private final PolicyApplicationRepository repository;

    public PolicyApplicationLookupClient(
            PolicyApplicationRepository repository) {
        this.repository = repository;
    }

    public PolicyApplicationSnapshot getActiveApplicationForCustomer(
            UUID applicationId,
            UUID customerId) {

        PolicyApplication application = repository.findById(applicationId)
                .filter(item -> item.isOwnedBy(customerId))
                .filter(item -> item.getStatus()
                        == com.insurewise.policy.entity.ApplicationStatus.ACTIVE)
                .orElseThrow(() -> new ApplicationNotFoundException(
                        applicationId));

        return snapshot(application);
    }

    public PolicyApplicationSnapshot getApplicationSnapshot(
            UUID applicationId) {

        return repository.findById(applicationId)
                .map(this::snapshot)
                .orElseThrow(() -> new ApplicationNotFoundException(
                        applicationId));
    }

    private PolicyApplicationSnapshot snapshot(
            PolicyApplication application) {

        return new PolicyApplicationSnapshot(
                application.getId(),
                application.getCustomerId(),
                application.getPolicy().getName(),
                application.getStatus(),
                application.getStatus()
                        == com.insurewise.policy.entity.ApplicationStatus.ACTIVE);
    }
}
package com.insurewise.payments.exception;

public class PaymentStateException extends RuntimeException {

    public PaymentStateException(String message) {
        super(message);
    }
}
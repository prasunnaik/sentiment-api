package com.insurewise.policy.exception;

public class ApplicationStateException extends RuntimeException {
    public ApplicationStateException(String message) {
        super(message);
    }
}
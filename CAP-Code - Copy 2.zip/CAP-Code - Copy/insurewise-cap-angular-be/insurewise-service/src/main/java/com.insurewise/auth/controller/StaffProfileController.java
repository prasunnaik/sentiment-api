package com.insurewise.auth.controller;

import com.insurewise.auth.dto.response.StaffProfilePictureResponse;
import com.insurewise.auth.service.StaffProfilePictureService;
import com.insurewise.common.security.JwtPrincipal;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/api/staff/profile-picture")
@PreAuthorize("hasRole('STAFF')")
public class StaffProfileController {

    private final StaffProfilePictureService profilePictureService;

    public StaffProfileController(
            StaffProfilePictureService profilePictureService) {

        this.profilePictureService = profilePictureService;
    }

    @PostMapping(
            value = "/upload",
            consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<StaffProfilePictureResponse> upload(
            @AuthenticationPrincipal JwtPrincipal principal,
            @RequestPart("file") MultipartFile file) {

        StaffProfilePictureResponse response =
                profilePictureService.upload(
                        principal.userId(),
                        file);

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(response);
    }

    @GetMapping
    public StaffProfilePictureResponse get(
            @AuthenticationPrincipal JwtPrincipal principal) {

        return profilePictureService.get(
                principal.userId());
    }

    @DeleteMapping
    public ResponseEntity<Void> delete(
            @AuthenticationPrincipal JwtPrincipal principal) {

        profilePictureService.delete(
                principal.userId());

        return ResponseEntity.noContent().build();
    }
}

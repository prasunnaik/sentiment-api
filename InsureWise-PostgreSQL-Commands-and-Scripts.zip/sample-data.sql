-- Optional demo catalog data. Run after the backend has started once (Flyway must have created tables).
INSERT INTO categories(id,name,description,status) VALUES
('30000000-0000-0000-0000-000000000001','Health Insurance','Health coverage for individuals and families.','ACTIVE'),
('30000000-0000-0000-0000-000000000002','Home Insurance','Protection for home and property.','ACTIVE'),
('30000000-0000-0000-0000-000000000003','Travel Insurance','Coverage for eligible travel-related risks.','INACTIVE')
ON CONFLICT DO NOTHING;
INSERT INTO policies(id,name,category_id,coverage_amount,premium_amount,duration_label,status) VALUES
('40000000-0000-0000-0000-000000000001','SecureHealth Gold','30000000-0000-0000-0000-000000000001',500000,25000,'12 months','ACTIVE'),
('40000000-0000-0000-0000-000000000002','Home Safety Plan','30000000-0000-0000-0000-000000000002',400000,18000,'24 months','ACTIVE'),
('40000000-0000-0000-0000-000000000003','Family Life Protector','30000000-0000-0000-0000-000000000001',900000,30000,'36 months','DRAFT')
ON CONFLICT DO NOTHING;

# PostgreSQL commands

The BRD defines Flyway migrations V1 through V8. The application executes those migrations automatically.

## Create database
```sql
CREATE DATABASE insurewise;
```

Connect to `insurewise`, then start the backend. Flyway creates the schema.

## Optional demo data
After the first backend startup, run `sample-data.sql` to add active and inactive categories and policies.

## Reset
Drop/recreate the database, then start the backend again. Or use `backend/insurewise-service/src/main/resources/db/rollback.sql` against the database.

-- InsureWise local PostgreSQL setup. Flyway will create the tables automatically.
CREATE DATABASE insurewise;
-- Then connect to insurewise and run the backend. Flyway V1..V8 creates the schema.
-- Optional clean reset: execute backend/src/main/resources/db/rollback.sql first, then restart.

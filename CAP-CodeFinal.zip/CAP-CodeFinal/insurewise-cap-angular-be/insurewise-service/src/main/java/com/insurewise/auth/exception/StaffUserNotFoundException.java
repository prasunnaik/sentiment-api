package com.insurewise.auth.exception;

import com.insurewise.common.exception.ResourceNotFoundException;
import java.util.UUID;

public class StaffUserNotFoundException extends ResourceNotFoundException {
    /**
     * Staff User Not Found Exception.
     * @param id the value supplied for the id.
     * @return the result of the operation.
     */

    public StaffUserNotFoundException(UUID id) {
        super("STAFF_USER_NOT_FOUND", "Staff user not found: " + id);
    }
}
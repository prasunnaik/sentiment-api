package com.insurewise.auth.service;

import com.insurewise.auth.dto.request.StaffCreateRequest;
import com.insurewise.auth.dto.request.StaffUpdateRequest;
import com.insurewise.auth.dto.response.StaffProfileResponse;
import com.insurewise.auth.entity.StaffUser;
import com.insurewise.auth.exception.DuplicateEmailException;
import com.insurewise.auth.exception.StaffUserNotFoundException;
import com.insurewise.auth.repository.CustomerRepository;
import com.insurewise.auth.repository.StaffUserRepository;
import com.insurewise.common.exception.BusinessException;
import com.insurewise.common.service.S3StorageService;
import java.util.List;
import java.util.UUID;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class StaffUserService {
    private static final Logger log = LoggerFactory.getLogger(StaffUserService.class);

    private final StaffUserRepository staffUserRepository;
    private final CustomerRepository customerRepository;
    private final PasswordEncoder passwordEncoder;
    private final S3StorageService storageService;

    /**
     * Creates the staff management service used for creating, updating, and deleting staff records.
     *
     * @param staffUserRepository repository for staff user records
     * @param customerRepository repository used to reject duplicate customer emails
     * @param passwordEncoder encoder used to hash staff passwords
     * @param storageService storage service used to resolve profile picture presigned URLs
     */
    public StaffUserService(
            StaffUserRepository staffUserRepository,
            CustomerRepository customerRepository,
            PasswordEncoder passwordEncoder,
            S3StorageService storageService) {
        this.staffUserRepository = staffUserRepository;
        this.customerRepository = customerRepository;
        this.passwordEncoder = passwordEncoder;
        this.storageService = storageService;
    }

    /**
     * Creates a new staff account with a normalized email and encoded password.
     *
     * @param request staff creation payload
     * @return persisted staff profile response
     */
    public StaffProfileResponse createStaffUser(StaffCreateRequest request) {
        try {
            String email = request.email().toLowerCase();
            validateEmailNotUsed(email);

            StaffUser staffUser = new StaffUser(
                    request.fullName(),
                    email,
                    request.address(),
                    passwordEncoder.encode(request.password()));

            return toResponse(staffUserRepository.save(staffUser));
        } catch (BusinessException exception) {
            throw exception;
        } catch (RuntimeException exception) {
            log.error("Failed to create staff user fullName={}, email={}", request.fullName(), request.email(), exception);
            throw new BusinessException(
                    "STAFF_USER_CREATE_FAILED",
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unable to create staff user at this time.",
                    exception);
        }
    }

    /**
     * Retrieves the full staff directory sorted by persistence order.
     *
     * @return list of active staff profiles
     */
    @Transactional(readOnly = true)
    public List<StaffProfileResponse> listStaffUsers() {
        try {
            return staffUserRepository.findAll()
                    .stream()
                    .map(this::toResponse)
                    .toList();
        } catch (BusinessException exception) {
            throw exception;
        } catch (RuntimeException exception) {
            log.error("Failed to load staff directory", exception);
            throw new BusinessException(
                    "STAFF_USER_LIST_FAILED",
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unable to load staff directory at this time.",
                    exception);
        }
    }

    /**
     * Loads one staff record by its unique identifier.
     *
     * @param id staff user primary key
     * @return profile response for the requested staff member
     */
    @Transactional(readOnly = true)
    public StaffProfileResponse getStaffUserById(UUID id) {
        try {
            return toResponse(find(id));
        } catch (StaffUserNotFoundException | BusinessException exception) {
            throw exception;
        } catch (RuntimeException exception) {
            log.error("Failed to fetch staff user id={}", id, exception);
            throw new BusinessException(
                    "STAFF_USER_GET_FAILED",
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unable to load staff user at this time.",
                    exception);
        }
    }

    /**
     * Loads the authenticated staff user's own profile.
     *
     * @param principal authenticated staff principal
     * @return profile response for the authenticated staff member
     */
    @Transactional(readOnly = true)
    public StaffProfileResponse getCurrentStaffUserProfile(UUID principalUserId) {
        try {
            return toResponse(find(principalUserId));
        } catch (StaffUserNotFoundException | BusinessException exception) {
            throw exception;
        } catch (RuntimeException exception) {
            log.error("Failed to fetch current staff user id={}", principalUserId, exception);
            throw new BusinessException(
                    "STAFF_USER_GET_FAILED",
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unable to load staff user at this time.",
                    exception);
        }
    }

    /**
     * Updates a staff profile, including optional password rotation and email validation.
     *
     * @param id existing staff user id
     * @param request update payload with new full name, email, address, and optional password
     * @return updated staff profile response
     */
    public StaffProfileResponse updateStaffUser(UUID id, StaffUpdateRequest request) {
        try {
            StaffUser staffUser = find(id);
            String email = request.email().toLowerCase();

            boolean emailUsedByAnotherStaff = staffUserRepository
                    .findByEmailIgnoreCase(email)
                    .filter(existing -> !existing.getId().equals(id))
                    .isPresent();

            boolean emailUsedByCustomer = customerRepository.existsByEmailIgnoreCase(email);

            if (emailUsedByAnotherStaff || emailUsedByCustomer) {
                throw new DuplicateEmailException(email);
            }

            String passwordHash = null;
            if (request.password() != null && !request.password().isBlank()) {
                passwordHash = passwordEncoder.encode(request.password());
            }

            staffUser.update(request.fullName(), email, request.address(), passwordHash);
            return toResponse(staffUser);
        } catch (StaffUserNotFoundException | BusinessException exception) {
            throw exception;
        } catch (RuntimeException exception) {
            log.error("Failed to update staff user id={}, email={}", id, request.email(), exception);
            throw new BusinessException(
                    "STAFF_USER_UPDATE_FAILED",
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unable to update staff user at this time.",
                    exception);
        }
    }

    /**
     * Deletes a staff user record after validating that it exists.
     *
     * @param id id of the staff user to remove
     */
    public void deleteStaffUser(UUID id) {
        try {
            StaffUser staffUser = find(id);
            staffUserRepository.delete(staffUser);
        } catch (StaffUserNotFoundException | BusinessException exception) {
            throw exception;
        } catch (RuntimeException exception) {
            log.error("Failed to delete staff user id={}", id, exception);
            throw new BusinessException(
                    "STAFF_USER_DELETE_FAILED",
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unable to delete staff user at this time.",
                    exception);
        }
    }

    /**
     * Fetches a staff user by id or throws a domain-specific not-found exception.
     *
     * @param id staff user identifier
     * @return persisted staff user entity
     */
    private StaffUser find(UUID id) {
        return staffUserRepository.findById(id)
                .orElseThrow(() -> new StaffUserNotFoundException(id));
    }

    /**
     * Validates that the provided email is not already used by a staff member or customer.
     *
     * @param email normalized email to check for duplicate ownership
     */
    private void validateEmailNotUsed(String email) {
        if (staffUserRepository.existsByEmailIgnoreCase(email)
                || customerRepository.existsByEmailIgnoreCase(email)) {
            throw new DuplicateEmailException(email);
        }
    }

    /**
     * Converts the entity to the public staff profile contract returned by the API.
     *
     * @param staffUser persisted staff user entity
     * @return profile DTO for the API response layer
     */
    private StaffProfileResponse toResponse(StaffUser staffUser) {
        return new StaffProfileResponse(
                staffUser.getId(),
                staffUser.getFullName(),
                staffUser.getEmail(),
                staffUser.getAddress(),
                resolveProfilePictureUrl(staffUser));
    }

    /**
     * Resolves a presigned URL for the staff member's profile picture, tolerating storage failures so a
     * missing/unavailable picture never breaks the staff directory.
     *
     * @param staffUser staff entity whose picture should be resolved
     * @return presigned URL, or null when no picture is set or it cannot be resolved
     */
    private String resolveProfilePictureUrl(StaffUser staffUser) {
        String s3Key = staffUser.getProfilePictureS3Key();
        if (s3Key == null || s3Key.isBlank()) {
            return null;
        }

        try {
            return storageService.getPresignedDownloadUrl(s3Key).url();
        } catch (RuntimeException exception) {
            log.warn("Unable to resolve profile picture URL for staffUserId={}", staffUser.getId(), exception);
            return null;
        }
    }
}

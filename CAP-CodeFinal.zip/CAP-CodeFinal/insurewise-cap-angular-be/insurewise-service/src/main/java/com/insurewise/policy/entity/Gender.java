package com.insurewise.policy.entity;
/**
 * Represents the enum Gender.
 */

public enum Gender {
    MALE,
    FEMALE,
    OTHER
}
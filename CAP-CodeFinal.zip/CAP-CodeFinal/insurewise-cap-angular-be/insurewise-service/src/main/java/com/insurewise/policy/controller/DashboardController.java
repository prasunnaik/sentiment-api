package com.insurewise.policy.controller;

import com.insurewise.policy.dto.response.DashboardMetricsResponse;
import com.insurewise.policy.service.DashboardService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/dashboard")
@PreAuthorize("hasRole('STAFF')")
/**
 * Represents the class Dashboard Controller.
 */
public class DashboardController {
    private final DashboardService service;
    /**
     * Dashboard Controller.
     * @param service the value supplied for the service.
     * @return the result of the operation.
     */

    public DashboardController(DashboardService service) {
        this.service = service;
    }
    /**
     * Metrics.
     * @return the result of the operation.
     */

    @GetMapping("/metrics")
    public DashboardMetricsResponse metrics() {
        return service.getDashboardMetrics();
    }
}
package com.insurewise.policy.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.UUID;
/**
 * Represents the class Application Document.
 */

@Entity
@Table(name = "application_documents")
public class ApplicationDocument {
    @Id
    @GeneratedValue
    private UUID id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "policy_application_id", nullable = false)
    private PolicyApplication policyApplication;

    @Column(name = "file_name", nullable = false, length = 255)
    private String fileName;

    @Column(name = "content_type", length = 100)
    private String contentType;

    @Column(name = "s3_key", nullable = false, length = 600)
    private String s3Key;

    @Column(name = "file_size", nullable = false)
    private long fileSize;

    @Column(name = "uploaded_by", nullable = false)
    private UUID uploadedBy;

    @Column(name = "uploaded_at", nullable = false)
    private LocalDateTime uploadedAt;
    /**
     * Application Document.
     * @return the result of the operation.
     */

    protected ApplicationDocument() {
    }
    /**
     * Application Document.
     * @param policyApplication the value supplied for the policyApplication.
     * @param fileName the value supplied for the fileName.
     * @param contentType the value supplied for the contentType.
     * @param s3Key the value supplied for the s3Key.
     * @param uploadedBy the value supplied for the uploadedBy.
     * @return the result of the operation.
     */

    public ApplicationDocument(
            PolicyApplication policyApplication,
            String fileName,
            String contentType,
            String s3Key,
            long fileSize,
            UUID uploadedBy) {
        this.policyApplication = policyApplication;
        this.fileName = fileName;
        this.contentType = contentType;
        this.s3Key = s3Key;
        this.fileSize = fileSize;
        this.uploadedBy = uploadedBy;
    }

    @PrePersist
    void initialize() {
        if (uploadedAt == null) {
            uploadedAt = LocalDateTime.now();
        }
    }
    /**
     * Get Id.
     * @return the result of the operation.
     */

    public UUID getId() {
        return id;
    }
    /**
     * Get Policy Application.
     * @return the result of the operation.
     */

    public PolicyApplication getPolicyApplication() {
        return policyApplication;
    }
    /**
     * Get File Name.
     * @return the result of the operation.
     */

    public String getFileName() {
        return fileName;
    }
    /**
     * Get Content Type.
     * @return the result of the operation.
     */

    public String getContentType() {
        return contentType;
    }
    /**
     * Get S3 Key.
     * @return the result of the operation.
     */

    public String getS3Key() {
        return s3Key;
    }

    public long getFileSize() {
        return fileSize;
    }
    /**
     * Get Uploaded By.
     * @return the result of the operation.
     */

    public UUID getUploadedBy() {
        return uploadedBy;
    }
    /**
     * Get Created At.
     * @return the result of the operation.
     */

    public LocalDateTime getUploadedAt() {
        return uploadedAt;
    }
}
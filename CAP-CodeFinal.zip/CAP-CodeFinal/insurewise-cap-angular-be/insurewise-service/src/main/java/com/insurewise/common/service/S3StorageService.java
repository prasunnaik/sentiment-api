package com.insurewise.common.service;

import com.insurewise.common.dto.PresignedUrlResponse;
import java.util.UUID;
import org.springframework.web.multipart.MultipartFile;

/**
 * Defines the storage contract for uploading, retrieving, and deleting
 * application files from the configured cloud object store.
 */
public interface S3StorageService {

    /**
     * Uploads a file to the configured storage bucket.
     *
     * @param file the file content to upload
     * @param folder the logical folder or path inside the bucket
     * @param ownerId the identifier of the owner associated with the file
     * @return the storage key assigned to the uploaded file
     */
    String upload(
            MultipartFile file,
            String folder,
            UUID ownerId);

    /**
     * Uploads a file using a caller-provided object key.
     *
     * @param file the file content to upload
     * @param folder the logical folder or path inside the bucket
     * @param ownerId the identifier of the owner associated with the file
     * @param objectKey the explicit object key to persist in storage
     * @return the storage key assigned to the uploaded file
     */
    String upload(
            MultipartFile file,
            String folder,
            UUID ownerId,
            String objectKey);

    /**
     * Uploads generated content as a file object.
     *
     * @param content the raw bytes to save
     * @param fileName the destination file name
     * @param contentType the MIME type of the file
     * @param folder the logical folder or path inside the bucket
     * @param ownerId the identifier of the owner associated with the file
     * @return the storage key assigned to the uploaded file
     */
    String uploadGenerated(
            byte[] content,
            String fileName,
            String contentType,
            String folder,
            UUID ownerId);

    /**
     * Builds a presigned download URL for an object in storage.
     *
     * @param s3Key the storage key of the object to download
     * @return the presigned URL response containing the URL and expiry timestamp
     */
    PresignedUrlResponse getPresignedDownloadUrl(String s3Key);

    /**
     * Builds a presigned preview URL for an object in storage.
     *
     * @param s3Key the storage key of the object to preview
     * @return the presigned URL response containing the URL and expiry timestamp
     */
    PresignedUrlResponse getPresignedPreviewUrl(String s3Key);

    /**
     * Removes an object from storage by key.
     *
     * @param s3Key the storage key of the object to delete
     */
    void delete(String s3Key);
}

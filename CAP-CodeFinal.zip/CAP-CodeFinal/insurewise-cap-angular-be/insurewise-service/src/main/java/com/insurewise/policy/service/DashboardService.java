package com.insurewise.policy.service;

import com.insurewise.auth.repository.CustomerRepository;
import com.insurewise.auth.repository.StaffUserRepository;
import com.insurewise.policy.dto.response.DashboardMetricsResponse;
import com.insurewise.policy.entity.ApplicationStatus;
import com.insurewise.policy.entity.PolicyStatus;
import com.insurewise.policy.repository.CategoryRepository;
import com.insurewise.policy.repository.PolicyApplicationRepository;
import com.insurewise.policy.repository.PolicyRepository;
import jakarta.persistence.EntityManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Aggregates dashboard KPI totals for customers, staff, policies, claims, and payments.
 *
 */
@Service
@Transactional(readOnly = true)
public class DashboardService {
    private static final Logger log = LoggerFactory.getLogger(DashboardService.class);

    private final CustomerRepository customerRepository;
    private final StaffUserRepository staffUserRepository;
    private final CategoryRepository categoryRepository;
    private final PolicyRepository policyRepository;
    private final PolicyApplicationRepository applicationRepository;
    private final EntityManager entityManager;

    /**
     * Creates a dashboard service with the repositories needed for aggregate counters.
     *
     * @param customerRepository repository used to count registered customers
     * @param staffUserRepository repository used to count staff accounts
     * @param categoryRepository repository used to count active policy categories
     * @param policyRepository repository used to count policies and active policy coverage
     * @param applicationRepository repository used to count policy applications and approval status
     * @param entityManager JPA entity manager used for native table-count queries
     */
    public DashboardService(
            CustomerRepository customerRepository,
            StaffUserRepository staffUserRepository,
            CategoryRepository categoryRepository,
            PolicyRepository policyRepository,
            PolicyApplicationRepository applicationRepository,
            EntityManager entityManager) {
        this.customerRepository = customerRepository;
        this.staffUserRepository = staffUserRepository;
        this.categoryRepository = categoryRepository;
        this.policyRepository = policyRepository;
        this.applicationRepository = applicationRepository;
        this.entityManager = entityManager;
    }

    /**
     * Loads the aggregated dashboard metrics across all core business tables.
     *
     * @return the dashboard metrics response containing counts for users, policies, claims, and payments
     */
    public DashboardMetricsResponse getDashboardMetrics() {
        try {
            return new DashboardMetricsResponse(
                    customerRepository.count(),
                    staffUserRepository.count(),
                    categoryRepository.count(),
                    policyRepository.count(),
                    policyRepository.countByStatus(PolicyStatus.ACTIVE),
                    applicationRepository.count(),
                    applicationRepository.countByStatus(ApplicationStatus.PENDING),
                    applicationRepository.countByStatus(ApplicationStatus.APPROVED),
                    countTable("claims"),
                    countByStatus("claims", "PENDING"),
                    countTable("payments"),
                    countByStatus("payments", "SUCCESS"));
        } catch (Exception exception) {
            log.error("Failed to load dashboard metrics while aggregating counts from customers, policies, claims, and payments.", exception);
            throw exception;
        }
    }

    /**
     * Counts all rows in a database table using a native query.
     *
     * @param tableName the table to count
     * @return the total row count for the requested table
     */
    private long countTable(String tableName) {
        Number result = (Number) entityManager
                .createNativeQuery("select count(*) from " + tableName)
                .getSingleResult();

        return result.longValue();
    }

    /**
     * Counts rows in the target table matching the requested status value.
     *
     * @param tableName the table name to query
     * @param status the status value to filter by
     * @return the number of rows matching the given status
     */
    private long countByStatus(String tableName, String status) {
        Number result = (Number) entityManager
                .createNativeQuery(
                        "select count(*) from " + tableName + " where status = :status")
                .setParameter("status", status)
                .getSingleResult();

        return result.longValue();
    }
}
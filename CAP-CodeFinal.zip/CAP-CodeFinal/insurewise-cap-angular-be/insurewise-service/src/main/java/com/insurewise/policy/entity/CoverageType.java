package com.insurewise.policy.entity;
/**
 * Represents the enum Coverage Type.
 */

public enum CoverageType {
    SINGLE,
    GROUP
}

package com.insurewise.common.dto;

import java.time.Instant;
/**
 * Represents the record Presigned Url Response.
 */

public record PresignedUrlResponse(
        String url,
        Instant expiresAt
) {
}

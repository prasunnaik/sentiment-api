package com.insurewise.policy.controller;

import com.insurewise.policy.dto.request.PolicyCreateRequest;
import com.insurewise.policy.dto.request.PolicyUpdateRequest;
import com.insurewise.policy.dto.response.PolicyResponse;
import com.insurewise.policy.service.PolicyService;
import jakarta.validation.Valid;
import java.util.List;
import java.util.UUID;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

/**
 * Provides REST endpoints for browsing and managing policy catalog entries.
 *
 */
@RestController
@RequestMapping("/api/policies")
@Validated
public class PolicyController {
    private final PolicyService service;

    /**
     * Creates a controller with the policy service dependency.
     *
     * @param service the policy service used to manage policy catalog data
     */
    public PolicyController(PolicyService service) {
        this.service = service;
    }

    /**
     * Creates a new policy definition.
     *
     * @param request the policy creation payload
     * @return the created policy response wrapped in an HTTP 201 response
     */
    @PostMapping
    @PreAuthorize("hasRole('STAFF')")
    public ResponseEntity<PolicyResponse> create(@Valid @RequestBody PolicyCreateRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(service.createPolicy(request));
    }

    /**
     * Lists all active policies available to customers and staff.
     *
     * @return the active policy catalog entries
     */
    @GetMapping
    @PreAuthorize("hasAnyRole('CUSTOMER', 'STAFF')")
    public List<PolicyResponse> listActive() {
        return service.listActivePolicies();
    }

    /**
     * Retrieves a single policy by identifier.
     *
     * @param id the policy identifier
     * @return the matching policy response
     */
    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('CUSTOMER', 'STAFF')")
    public PolicyResponse get(@PathVariable UUID id) {
        return service.getPolicyById(id);
    }

    /**
     * Updates an existing policy definition.
     *
     * @param id the policy identifier
     * @param request the policy update payload
     * @return the updated policy response
     */
    @PutMapping("/{id}")
    @PreAuthorize("hasRole('STAFF')")
    public PolicyResponse update(
            @PathVariable UUID id,
            @Valid @RequestBody PolicyUpdateRequest request) {
        return service.updatePolicy(id, request);
    }

    /**
     * Removes a policy definition.
     *
     * @param id the policy identifier
     * @return an empty no-content response
     */
    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('STAFF')")
    public ResponseEntity<Void> delete(@PathVariable UUID id) {
        service.deletePolicy(id);
        return ResponseEntity.noContent().build();
    }
}

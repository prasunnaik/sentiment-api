package com.insurewise.auth.controller;

import com.insurewise.auth.dto.response.ProfilePictureResponse;
import com.insurewise.auth.service.ProfilePictureService;
import com.insurewise.common.security.JwtPrincipal;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/auth")
@PreAuthorize("hasRole('CUSTOMER')")
/**
 * Represents the class Profile Controller.
 */
public class ProfileController {

    private final ProfilePictureService profilePictureService;
    /**
     * Profile Controller.
     * @param profilePictureService the value supplied for the profilePictureService.
     * @return the result of the operation.
     */

    public ProfileController(
            ProfilePictureService profilePictureService) {
        this.profilePictureService = profilePictureService;
    }

    @PostMapping(
            value = "/profile-picture/upload",
            consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<ProfilePictureResponse> upload(
            @AuthenticationPrincipal JwtPrincipal principal,
            @RequestPart("file") MultipartFile file) {

        ProfilePictureResponse response =
                profilePictureService.upload(
                        principal.userId(),
                        file);

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(response);
    }
    /**
     * Get.
     * @param principal the value supplied for the principal.
     * @return the result of the operation.
     */

    @GetMapping("/profile-picture")
    public ResponseEntity<ProfilePictureResponse> get(
            @AuthenticationPrincipal JwtPrincipal principal) {

        ProfilePictureResponse response = profilePictureService.get(
                principal.userId());

        if (response == null) {
            return ResponseEntity.noContent().build();
        }

        return ResponseEntity.ok(response);
    }
    /**
     * Delete.
     * @param principal the value supplied for the principal.
     * @return the result of the operation.
     */

    @DeleteMapping("/profile-picture")
    public ResponseEntity<Void> delete(
            @AuthenticationPrincipal JwtPrincipal principal) {

        profilePictureService.delete(
                principal.userId());

        return ResponseEntity.noContent().build();
    }
}

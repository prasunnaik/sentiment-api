package com.insurewise.policy.entity;
/**
 * Represents the enum Category Status.
 */

public enum CategoryStatus {
    ACTIVE,
    INACTIVE
}
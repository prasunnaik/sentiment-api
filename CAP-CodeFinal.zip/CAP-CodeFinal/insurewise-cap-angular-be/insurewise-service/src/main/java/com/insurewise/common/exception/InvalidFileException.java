package com.insurewise.common.exception;

public class InvalidFileException extends ValidationException {
    /**
     * Invalid File Exception.
     * @param message the value supplied for the message.
     * @return the result of the operation.
     */

    public InvalidFileException(String message) {
        super("INVALID_FILE", message);
    }

    public InvalidFileException(String message, Throwable cause) {
        super("INVALID_FILE", message, cause);
    }
}
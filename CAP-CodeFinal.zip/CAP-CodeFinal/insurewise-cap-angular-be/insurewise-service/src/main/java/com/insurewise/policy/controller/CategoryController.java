package com.insurewise.policy.controller;

import com.insurewise.policy.dto.request.CategoryCreateRequest;
import com.insurewise.policy.dto.request.CategoryUpdateRequest;
import com.insurewise.policy.dto.response.CategoryResponse;
import com.insurewise.policy.service.CategoryService;
import jakarta.validation.Valid;
import java.util.List;
import java.util.UUID;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

/**
 * Provides REST endpoints for managing policy categories.
 *
 */
@RestController
@RequestMapping("/api/categories")
public class CategoryController {
    private final CategoryService service;

    /**
     * Creates a controller with the category service dependency.
     *
     * @param service the category service used to manage categories
     */
    public CategoryController(CategoryService service) {
        this.service = service;
    }

    /**
     * Creates a new category.
     *
     * @param request the category creation payload
     * @return the created category response
     */
    @PostMapping
    @PreAuthorize("hasRole('STAFF')")
    public CategoryResponse create(@Valid @RequestBody CategoryCreateRequest request) {
        return service.create(request);
    }

    /**
     * Lists all available categories.
     *
     * @return the categories available to customers and staff
     */
    @GetMapping
    @PreAuthorize("hasAnyRole('CUSTOMER', 'STAFF')")
    public List<CategoryResponse> list() {
        return service.list();
    }

    /**
     * Updates an existing category.
     *
     * @param id the category identifier
     * @param request the category update payload
     * @return the updated category response
     */
    @PutMapping("/{id}")
    @PreAuthorize("hasRole('STAFF')")
    public CategoryResponse update(
            @PathVariable UUID id,
            @Valid @RequestBody CategoryUpdateRequest request) {
        return service.update(id, request);
    }

    /**
     * Removes a category.
     *
     * @param id the category identifier
     */
    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('STAFF')")
    public void delete(@PathVariable UUID id) {
        service.delete(id);
    }
}

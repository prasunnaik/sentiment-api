package com.insurewise.auth.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import java.time.LocalDateTime;
import java.util.UUID;
/**
 * Represents the class Staff User.
 */

@Entity
@Table(name = "staff_users")
public class StaffUser {

    @Id
    private UUID id;

    @Column(name = "full_name", nullable = false, length = 120)
    private String fullName;

    @Column(nullable = false, unique = true, length = 160)
    private String email;

    @Column(nullable = false, length = 240)
    private String address;

    @Column(name = "password_hash", nullable = false, length = 100)
    private String passwordHash;

    @Column(name = "profile_picture_s3_key", length = 600)
    private String profilePictureS3Key;

    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;
    /**
     * Staff User.
     * @return the result of the operation.
     */

    protected StaffUser() {
    }
    /**
     * Staff User.
     * @param fullName the value supplied for the fullName.
     * @param email the value supplied for the email.
     * @param address the value supplied for the address.
     * @param passwordHash the value supplied for the passwordHash.
     * @return the result of the operation.
     */

    public StaffUser(
            String fullName,
            String email,
            String address,
            String passwordHash) {

        this.id = UUID.randomUUID();
        this.fullName = fullName;
        this.email = email.toLowerCase();
        this.address = address;
        this.passwordHash = passwordHash;
    }

    @PrePersist
    void prePersist() {
        if (createdAt == null) {
            createdAt = LocalDateTime.now();
        }
    }
    /**
     * Get Id.
     * @return the result of the operation.
     */

    public UUID getId() {
        return id;
    }
    /**
     * Get Full Name.
     * @return the result of the operation.
     */

    public String getFullName() {
        return fullName;
    }
    /**
     * Get Email.
     * @return the result of the operation.
     */

    public String getEmail() {
        return email;
    }
    /**
     * Get Address.
     * @return the result of the operation.
     */

    public String getAddress() {
        return address;
    }
    /**
     * Get Password Hash.
     * @return the result of the operation.
     */

    public String getPasswordHash() {
        return passwordHash;
    }
    /**
     * Get Profile Picture S3 Key.
     * @return the result of the operation.
     */

    public String getProfilePictureS3Key() {
        return profilePictureS3Key;
    }
    /**
     * Set Profile Picture S3 Key.
     * @param profilePictureS3Key the value supplied for the profilePictureS3Key.
     */

    public void setProfilePictureS3Key(
            String profilePictureS3Key) {

        this.profilePictureS3Key = profilePictureS3Key;
    }
    /**
     * Update.
     * @param fullName the value supplied for the fullName.
     * @param email the value supplied for the email.
     * @param address the value supplied for the address.
     * @param passwordHash the value supplied for the passwordHash.
     */

    public void update(
            String fullName,
            String email,
            String address,
            String passwordHash) {

        this.fullName = fullName;
        this.email = email.toLowerCase();
        this.address = address;

        if (passwordHash != null
                && !passwordHash.isBlank()) {
            this.passwordHash = passwordHash;
        }
    }
}
package com.insurewise.auth.controller;

import com.insurewise.auth.dto.response.StaffProfilePictureResponse;
import com.insurewise.auth.service.StaffProfilePictureService;
import com.insurewise.common.security.JwtPrincipal;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/api/staff/profile-picture")
@PreAuthorize("hasRole('STAFF')")
/**
 * Represents the class Staff Profile Controller.
 */
public class StaffProfileController {

    private final StaffProfilePictureService profilePictureService;
    /**
     * Staff Profile Controller.
     * @param profilePictureService the value supplied for the profilePictureService.
     * @return the result of the operation.
     */

    public StaffProfileController(
            StaffProfilePictureService profilePictureService) {

        this.profilePictureService = profilePictureService;
    }

    @PostMapping(
            value = "/upload",
            consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<StaffProfilePictureResponse> upload(
            @AuthenticationPrincipal JwtPrincipal principal,
            @RequestPart("file") MultipartFile file) {

        StaffProfilePictureResponse response =
                profilePictureService.upload(
                        principal.userId(),
                        file);

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(response);
    }
    /**
     * Get.
     * @param principal the value supplied for the principal.
     * @return the result of the operation.
     */

    @GetMapping
    public StaffProfilePictureResponse get(
            @AuthenticationPrincipal JwtPrincipal principal) {

        return profilePictureService.get(
                principal.userId());
    }
    /**
     * Delete.
     * @param principal the value supplied for the principal.
     * @return the result of the operation.
     */

    @DeleteMapping
    public ResponseEntity<Void> delete(
            @AuthenticationPrincipal JwtPrincipal principal) {

        profilePictureService.delete(
                principal.userId());

        return ResponseEntity.noContent().build();
    }
}

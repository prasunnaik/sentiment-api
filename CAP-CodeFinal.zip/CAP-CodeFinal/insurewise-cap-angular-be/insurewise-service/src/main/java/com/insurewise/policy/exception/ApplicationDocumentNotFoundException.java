package com.insurewise.policy.exception;

import com.insurewise.common.exception.ResourceNotFoundException;
import java.util.UUID;

public class ApplicationDocumentNotFoundException
        extends ResourceNotFoundException {
    /**
     * Application Document Not Found Exception.
     * @param id the value supplied for the id.
     * @return the result of the operation.
     */

    public ApplicationDocumentNotFoundException(UUID id) {
        super("APPLICATION_DOCUMENT_NOT_FOUND", "Application document not found: " + id);
    }
}
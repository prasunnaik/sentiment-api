package com.insurewise.policy.exception;

import com.insurewise.common.exception.BusinessException;
import org.springframework.http.HttpStatus;

public class PolicyDeletionException extends BusinessException {
    /**
     * Policy Deletion Exception.
     * @param message the value supplied for the message.
     * @return the result of the operation.
     */
    public PolicyDeletionException(String message) {
        super("POLICY_DELETION_ERROR", HttpStatus.CONFLICT, message);
    }
}

package com.insurewise.policy.controller;

import com.insurewise.common.security.JwtPrincipal;
import com.insurewise.policy.dto.request.PolicyApplicationDecisionRequest;
import com.insurewise.policy.dto.request.PolicyApplicationCreateRequest;
import com.insurewise.policy.dto.response.PolicyApplicationResponse;
import com.insurewise.policy.entity.ApplicationStatus;
import com.insurewise.policy.service.PolicyApplicationService;
import jakarta.validation.Valid;
import java.util.List;
import java.util.UUID;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

/**
 * Provides REST endpoints for creating and reviewing policy applications.
 *
 */
@RestController
@RequestMapping("/api/policy-applications")
@Validated
public class PolicyApplicationController {
    private final PolicyApplicationService service;

    /**
     * Creates a controller with the policy application service dependency.
     *
     * @param service the policy application service used to manage applications
     */
    public PolicyApplicationController(PolicyApplicationService service) {
        this.service = service;
    }

    /**
     * Creates a new policy application for the authenticated customer.
     *
     * @param principal the authenticated principal requesting the operation
     * @param request the application creation payload
     * @return the created policy application response
     */
    @PostMapping
    @PreAuthorize("hasRole('CUSTOMER')")
    public PolicyApplicationResponse create(
            @AuthenticationPrincipal JwtPrincipal principal,
            @Valid @RequestBody PolicyApplicationCreateRequest request) {
        return service.createPolicyApplication(principal.userId(), request);
    }

    /**
     * Lists policy applications visible to the authenticated user.
     *
     * @param principal the authenticated principal requesting the operation
     * @param status the optional status filter
     * @return the policy applications matching the filter
     */
    @GetMapping
    @PreAuthorize("hasAnyRole('CUSTOMER', 'STAFF')")
    public List<PolicyApplicationResponse> list(
            @AuthenticationPrincipal JwtPrincipal principal,
            @RequestParam(value = "status", required = false) ApplicationStatus status) {
        return service.listPolicyApplications(principal, status);
    }

    /**
     * Retrieves a single policy application by identifier.
     *
     * @param principal the authenticated principal requesting the operation
     * @param id the policy application identifier
     * @return the matching policy application response
     */
    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('CUSTOMER', 'STAFF')")
    public PolicyApplicationResponse get(
            @AuthenticationPrincipal JwtPrincipal principal,
            @PathVariable UUID id) {
        return service.getPolicyApplication(principal, id);
    }

    /**
     * Updates the status of a policy application.
     *
     * @param principal the authenticated principal requesting the operation
     * @param id the policy application identifier
     * @param request the decision payload
     * @return the updated policy application response
     */
    @PutMapping("/{id}/status")
    @PreAuthorize("hasRole('STAFF')")
    public PolicyApplicationResponse updateStatus(
            @AuthenticationPrincipal JwtPrincipal principal,
            @PathVariable UUID id,
            @Valid @RequestBody PolicyApplicationDecisionRequest request) {
        return service.updatePolicyApplicationStatus(principal, id, request);
    }

    /**
     * Approves a policy application.
     *
     * @param principal the authenticated principal requesting the operation
     * @param id the policy application identifier
     * @return the updated policy application response
     */
    @PutMapping("/{id}/approve")
    @PreAuthorize("hasRole('STAFF')")
    public PolicyApplicationResponse approve(
            @AuthenticationPrincipal JwtPrincipal principal,
            @PathVariable UUID id) {
        return service.updatePolicyApplicationStatus(
                principal,
                id,
                new PolicyApplicationDecisionRequest(ApplicationStatus.APPROVED));
    }

    /**
     * Rejects a policy application.
     *
     * @param principal the authenticated principal requesting the operation
     * @param id the policy application identifier
     * @return the updated policy application response
     */
    @PutMapping("/{id}/reject")
    @PreAuthorize("hasRole('STAFF')")
    public PolicyApplicationResponse reject(
            @AuthenticationPrincipal JwtPrincipal principal,
            @PathVariable UUID id) {
        return service.updatePolicyApplicationStatus(
                principal,
                id,
                new PolicyApplicationDecisionRequest(ApplicationStatus.REJECTED));
    }
}

package com.insurewise.policy.entity;
/**
 * Represents the enum Relationship.
 */

public enum Relationship {
    SPOUSE,
    CHILD,
    PARENT,
    SIBLING
}
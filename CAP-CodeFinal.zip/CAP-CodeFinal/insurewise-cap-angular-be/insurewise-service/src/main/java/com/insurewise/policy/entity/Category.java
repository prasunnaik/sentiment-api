package com.insurewise.policy.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.UUID;
/**
 * Represents the class Category.
 */

@Entity
@Table(name = "categories")
public class Category {
    @Id
    @GeneratedValue
    private UUID id;

    @Column(nullable = false, length = 80)
    private String name;

    @Column(nullable = false, length = 500)
    private String description;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private CategoryStatus status;

    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;
    /**
     * Category.
     * @return the result of the operation.
     */

    protected Category() {
    }
    /**
     * Category.
     * @param name the value supplied for the name.
     * @param description the value supplied for the description.
     * @param status the value supplied for the status.
     * @return the result of the operation.
     */

    public Category(String name, String description, CategoryStatus status) {
        this.name = name;
        this.description = description;
        this.status = status;
    }

    @PrePersist
    void initialize() {
        if (createdAt == null) {
            createdAt = LocalDateTime.now();
        }
    }
    /**
     * Update.
     * @param name the value supplied for the name.
     * @param description the value supplied for the description.
     * @param status the value supplied for the status.
     */

    public void update(
            String name,
            String description,
            CategoryStatus status) {
        this.name = name;
        this.description = description;
        this.status = status;
    }
    /**
     * Get Id.
     * @return the result of the operation.
     */

    public UUID getId() {
        return id;
    }
    /**
     * Get Name.
     * @return the result of the operation.
     */

    public String getName() {
        return name;
    }
    /**
     * Get Description.
     * @return the result of the operation.
     */

    public String getDescription() {
        return description;
    }
    /**
     * Get Status.
     * @return the result of the operation.
     */

    public CategoryStatus getStatus() {
        return status;
    }
}

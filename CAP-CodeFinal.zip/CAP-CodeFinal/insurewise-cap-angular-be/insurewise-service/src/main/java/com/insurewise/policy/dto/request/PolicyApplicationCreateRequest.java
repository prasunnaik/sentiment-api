package com.insurewise.policy.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.insurewise.policy.entity.CoverageType;
import com.insurewise.policy.entity.NomineeRelationship;
import jakarta.validation.constraints.*;
import java.time.LocalDate;
import java.util.UUID;
/**
 * Represents the record Policy Application Create Request.
 */

public record PolicyApplicationCreateRequest(
        @JsonProperty("policy_id")
        @NotNull
        UUID policyId,

        @JsonProperty("coverage_type")
        @NotNull
        CoverageType coverageType,

        @JsonProperty("date_of_birth")
        @NotNull
        @Past
        LocalDate dateOfBirth,

        @NotBlank
        @Size(max = 500)
        String address,

        @JsonProperty("preferred_start_date")
        @FutureOrPresent
        LocalDate preferredStartDate,

        @JsonProperty("nominee_name")
        @Size(max = 120)
        String nomineeName,

        @JsonProperty("nominee_relationship")
        NomineeRelationship nomineeRelationship
) {
        @AssertTrue(message = "nomineeRelationship and nomineeName must either both be provided or both be omitted")
        public boolean hasValidNomineePair() {
                boolean hasRelationship = nomineeRelationship != null;
                boolean hasName = nomineeName != null && !nomineeName.isBlank();
                return hasRelationship == hasName;
        }
}

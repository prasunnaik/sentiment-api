package com.insurewise.policy.entity;
/**
 * Represents the enum Nominee Relationship.
 */

public enum NomineeRelationship {
    SPOUSE,
    PARENT,
    CHILD,
    SIBLING,
    OTHER
}

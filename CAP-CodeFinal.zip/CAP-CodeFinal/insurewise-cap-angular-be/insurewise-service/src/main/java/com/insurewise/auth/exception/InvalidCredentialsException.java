package com.insurewise.auth.exception;

import com.insurewise.common.exception.BusinessException;
import org.springframework.http.HttpStatus;

public class InvalidCredentialsException extends BusinessException {
    /**
     * Invalid Credentials Exception.
     * @return the result of the operation.
     */
    public InvalidCredentialsException() {
        super("INVALID_CREDENTIALS", HttpStatus.BAD_REQUEST, "Invalid email or password");
    }
}

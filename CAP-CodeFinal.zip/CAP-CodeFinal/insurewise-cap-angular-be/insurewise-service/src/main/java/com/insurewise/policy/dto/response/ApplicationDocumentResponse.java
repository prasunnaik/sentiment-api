package com.insurewise.policy.dto.response;

import com.insurewise.common.dto.PresignedUrlResponse;
import java.time.LocalDateTime;
import java.util.UUID;
/**
 * Represents the record Application Document Response.
 */

public record ApplicationDocumentResponse(
        UUID id,
        UUID applicationId,
        String fileName,
        String objectKey,
        String contentType,
        long fileSize,
        PresignedUrlResponse download,
        UUID uploadedBy,
        LocalDateTime uploadedAt
) {
}
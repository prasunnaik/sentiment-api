package com.insurewise.common.security;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import org.springframework.security.web.util.matcher.OrRequestMatcher;
import org.springframework.security.web.util.matcher.RequestMatcher;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

@Component
public class JwtAuthenticationFilter extends OncePerRequestFilter {
    private final JwtService jwtService;

    private final RequestMatcher publicEndpoints =
            new OrRequestMatcher(
                    new AntPathRequestMatcher("/auth/customers"),
                    new AntPathRequestMatcher("/auth/customers/login"),
                    new AntPathRequestMatcher("/auth/staff/login"),
                    new AntPathRequestMatcher("/actuator/health"),
                    new AntPathRequestMatcher("/swagger-ui.html"),
                    new AntPathRequestMatcher("/swagger-ui/**"),
                    new AntPathRequestMatcher("/api-docs"),
                    new AntPathRequestMatcher("/api-docs/**"),
                    new AntPathRequestMatcher("/v3/api-docs"),
                    new AntPathRequestMatcher("/v3/api-docs/**"),
                    new AntPathRequestMatcher("/webjars/**"),
                    new AntPathRequestMatcher("/error")
            );
    /**
     * Jwt Authentication Filter.
     * @param jwtService the value supplied for the jwtService.
     * @return the result of the operation.
     */

    public JwtAuthenticationFilter(JwtService jwtService) {
        this.jwtService = jwtService;
    }
    /**
     * Should Not Filter.
     * @param request the value supplied for the request.
     * @return the result of the operation.
     */

    @Override
    protected boolean shouldNotFilter(HttpServletRequest request) {
        return publicEndpoints.matches(request);
    }
    /**
     * Do Filter Internal.
     * @param request the value supplied for the request.
     * @param response the value supplied for the response.
     * @param chain the value supplied for the chain.
     * @throws ServletException if the operation fails.
     * @throws IOException if the operation fails.
     */

    @Override
    protected void doFilterInternal(
            HttpServletRequest request,
            HttpServletResponse response,
            FilterChain chain)
            throws ServletException, IOException {

        String header = request.getHeader("Authorization");

        if (header == null || !header.startsWith("Bearer ")) {
            chain.doFilter(request, response);
            return;
        }

        String token = header.substring(7).trim();

        if (token.isEmpty()) {
            chain.doFilter(request, response);
            return;
        }

        try {
            JwtPrincipal principal = jwtService.parse(token);

            var authorities = List.of(
                    new SimpleGrantedAuthority(
                            "ROLE_" + principal.role().name()));

            var authentication =
                    new UsernamePasswordAuthenticationToken(
                            principal,
                            null,
                            authorities);

            SecurityContextHolder.getContext()
                    .setAuthentication(authentication);

        } catch (RuntimeException exception) {
            SecurityContextHolder.clearContext();
        }

        chain.doFilter(request, response);
    }
}

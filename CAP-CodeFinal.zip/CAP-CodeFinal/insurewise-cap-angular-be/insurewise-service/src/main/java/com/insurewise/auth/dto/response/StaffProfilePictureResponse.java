package com.insurewise.auth.dto.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.insurewise.common.dto.PresignedUrlResponse;
import java.util.UUID;
/**
 * Represents the record Staff Profile Picture Response.
 */

public record StaffProfilePictureResponse(
        @JsonProperty("staff_user_id")
        UUID staffUserId,

        @JsonProperty("s3_key")
        String s3Key,

        PresignedUrlResponse download
) {
}
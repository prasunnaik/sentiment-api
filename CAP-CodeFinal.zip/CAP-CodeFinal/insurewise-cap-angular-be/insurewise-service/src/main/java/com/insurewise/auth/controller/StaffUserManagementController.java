package com.insurewise.auth.controller;

import com.insurewise.auth.dto.request.StaffCreateRequest;
import com.insurewise.auth.dto.request.StaffUpdateRequest;
import com.insurewise.auth.dto.response.StaffProfileResponse;
import com.insurewise.auth.service.StaffProfilePictureService;
import com.insurewise.auth.service.StaffUserService;
import com.insurewise.common.security.JwtPrincipal;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/staff/users")
@PreAuthorize("hasRole('STAFF')")
/**
 * Represents the class Staff User Management Controller.
 */
public class StaffUserManagementController {

    private final StaffUserService staffUserService;
    private final StaffProfilePictureService profilePictureService;
    /**
     * Staff User Management Controller.
     * @param staffUserService the value supplied for the staffUserService.
     * @param profilePictureService the value supplied for the profilePictureService.
     * @return the result of the operation.
     */

    public StaffUserManagementController(
            StaffUserService staffUserService,
            StaffProfilePictureService profilePictureService) {

        this.staffUserService = staffUserService;
        this.profilePictureService = profilePictureService;
    }
    /**
     * Create.
     * @param request the value supplied for the request.
     * @return the result of the operation.
     */

    @PostMapping
    public ResponseEntity<StaffProfileResponse> create(
            @Valid @RequestBody StaffCreateRequest request) {

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(staffUserService.createStaffUser(request));
    }
    /**
     * List.
     * @return the result of the operation.
     */

    @GetMapping
    public List<StaffProfileResponse> list() {

        return staffUserService.listStaffUsers();
    }
    /**
     * Get.
     * @param id the value supplied for the id.
     * @return the result of the operation.
     */

    @GetMapping("/{id}")
    public StaffProfileResponse get(
            @PathVariable UUID id) {

        return staffUserService.getStaffUserById(id);
    }

    @GetMapping("/me")
    public StaffProfileResponse getCurrentProfile(
            @AuthenticationPrincipal JwtPrincipal principal) {

        return staffUserService.getCurrentStaffUserProfile(principal.userId());
    }
    /**
     * Update.
     * @param id the value supplied for the id.
     * @param request the value supplied for the request.
     * @return the result of the operation.
     */

    @PutMapping("/{id}")
    public StaffProfileResponse update(
            @PathVariable UUID id,
            @Valid @RequestBody StaffUpdateRequest request) {

        return staffUserService.updateStaffUser(id, request);
    }

    /*
     * Admin-facing profile picture management for any staff user (id-scoped, unlike the
     * self-service /api/staff/profile-picture routes).
     */
    @PostMapping(
            value = "/{id}/profile-picture",
            consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public StaffProfileResponse uploadProfilePicture(
            @PathVariable UUID id,
            @RequestPart("file") MultipartFile file) {

        profilePictureService.upload(id, file);
        return staffUserService.getStaffUserById(id);
    }

    @DeleteMapping("/{id}/profile-picture")
    public ResponseEntity<Void> deleteProfilePicture(
            @PathVariable UUID id) {

        profilePictureService.delete(id);
        return ResponseEntity.noContent().build();
    }
    /**
     * Delete.
     * @param id the value supplied for the id.
     * @return the result of the operation.
     */

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(
            @PathVariable UUID id) {

        staffUserService.deleteStaffUser(id);

        return ResponseEntity.noContent().build();
    }
}
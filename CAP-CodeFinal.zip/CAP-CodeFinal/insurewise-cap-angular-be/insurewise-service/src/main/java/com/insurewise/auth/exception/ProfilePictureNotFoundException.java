package com.insurewise.auth.exception;

import java.util.UUID;

public class ProfilePictureNotFoundException
        extends RuntimeException {
    /**
     * Profile Picture Not Found Exception.
     * @param customerId the value supplied for the customerId.
     * @return the result of the operation.
     */

    public ProfilePictureNotFoundException(
            UUID customerId) {

        super("Profile picture not found for customer: "
                + customerId);
    }
}

package com.insurewise.auth.dto.request;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
/**
 * Represents the record Staff Update Request.
 */

public record StaffUpdateRequest(

        @NotBlank
        @Size(max = 120)
        String fullName,

        @NotBlank
        @Email
        @Size(max = 160)
        String email,

        @NotBlank
        @Size(max = 240)
        String address,

        @Size(min = 8, max = 100)
        String password
) {
}
package com.insurewise.auth.exception;

import com.insurewise.common.exception.BusinessException;
import org.springframework.http.HttpStatus;

public class DuplicateEmailException extends BusinessException {
    /**
     * Duplicate Email Exception.
     * @param email the value supplied for the email.
     * @return the result of the operation.
     */
    public DuplicateEmailException(String email) {
        super("DUPLICATE_EMAIL", HttpStatus.CONFLICT, "An account already exists for email: " + email);
    }
}

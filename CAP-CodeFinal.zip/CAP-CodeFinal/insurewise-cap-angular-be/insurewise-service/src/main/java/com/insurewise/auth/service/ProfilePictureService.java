package com.insurewise.auth.service;

import com.insurewise.auth.dto.response.ProfilePictureResponse;
import com.insurewise.auth.entity.Customer;
import com.insurewise.auth.exception.ProfilePictureNotFoundException;
import com.insurewise.auth.repository.CustomerRepository;
import com.insurewise.common.exception.InvalidFileException;
import com.insurewise.common.service.S3StorageService;
import java.util.Set;
import java.util.UUID;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;
/**
 * Represents the class Profile Picture Service.
 */

@Service
@Transactional
public class ProfilePictureService {

    private static final Logger log =
            LoggerFactory.getLogger(ProfilePictureService.class);

    private static final Set<String> ALLOWED_TYPES = Set.of(
            "image/jpeg",
            "image/png",
            "image/webp");

    private final CustomerRepository customerRepository;
    private final S3StorageService storageService;
    /**
     * Profile Picture Service.
     * @param customerRepository the value supplied for the customerRepository.
     * @param storageService the value supplied for the storageService.
     * @return the result of the operation.
     */

    public ProfilePictureService(
            CustomerRepository customerRepository,
            S3StorageService storageService) {

        this.customerRepository = customerRepository;
        this.storageService = storageService;
    }
    /**
     * Upload.
     * @param customerId the value supplied for the customerId.
     * @param file the value supplied for the file.
     * @return the result of the operation.
     */

    public ProfilePictureResponse upload(
            UUID customerId,
            MultipartFile file) {

        validate(file);

        Customer customer = findCustomer(customerId);

        String oldKey = customer.getProfilePictureS3Key();

        String newKey = storageService.upload(
                file,
                "profile-pictures",
                customerId);

        try {
            customer.setProfilePictureS3Key(newKey);
            customerRepository.save(customer);

            if (oldKey != null
                    && !oldKey.isBlank()
                    && !oldKey.equals(newKey)) {

                try {
                    storageService.delete(oldKey);
                } catch (RuntimeException exception) {
                    log.warn(
                            "New profile picture saved, "
                                    + "but old S3 object could not be deleted. key={}",
                            oldKey,
                            exception);
                }
            }

            return toResponse(customer);

        } catch (RuntimeException exception) {
            try {
                storageService.delete(newKey);
            } catch (RuntimeException cleanupException) {
                log.warn(
                        "Could not clean up new S3 object after database failure. key={}",
                        newKey,
                        cleanupException);
            }

            throw exception;
        }
    }
    /**
     * Get.
     * @param customerId the value supplied for the customerId.
     * @return the result of the operation.
     */

    @Transactional(readOnly = true)
    public ProfilePictureResponse get(UUID customerId) {

        Customer customer = findCustomer(customerId);
        String s3Key = customer.getProfilePictureS3Key();

        if (s3Key == null || s3Key.isBlank()) {
            return null;
        }

        return toResponse(customer);
    }
    /**
     * Delete.
     * @param customerId the value supplied for the customerId.
     */

    public void delete(UUID customerId) {

        Customer customer = findCustomer(customerId);
        String s3Key = customer.getProfilePictureS3Key();

        if (s3Key == null || s3Key.isBlank()) {
            throw new ProfilePictureNotFoundException(customerId);
        }

        storageService.delete(s3Key);

        customer.setProfilePictureS3Key(null);
        customerRepository.save(customer);
    }
    /**
     * Find Customer.
     * @param customerId the value supplied for the customerId.
     * @return the result of the operation.
     */

    private Customer findCustomer(UUID customerId) {
        return customerRepository.findById(customerId)
                .orElseThrow(() ->
                        new IllegalArgumentException(
                                "Customer not found: " + customerId));
    }
    /**
     * Validate.
     * @param file the value supplied for the file.
     */

    private void validate(MultipartFile file) {

        if (file == null || file.isEmpty()) {
            throw new InvalidFileException(
                    "A non-empty profile picture is required.");
        }

        if (file.getContentType() == null
                || !ALLOWED_TYPES.contains(file.getContentType())) {

            throw new InvalidFileException(
                    "Only JPEG, PNG, and WebP images are allowed.");
        }
    }
    /**
     * To Response.
     * @param customer the value supplied for the customer.
     * @return the result of the operation.
     */

    private ProfilePictureResponse toResponse(
            Customer customer) {

        String s3Key = customer.getProfilePictureS3Key();

        return new ProfilePictureResponse(
                customer.getId(),
                s3Key,
                storageService.getPresignedDownloadUrl(s3Key));
    }
}

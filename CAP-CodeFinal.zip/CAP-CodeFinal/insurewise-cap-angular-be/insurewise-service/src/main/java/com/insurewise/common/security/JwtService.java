package com.insurewise.common.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.WeakKeyException;
import io.jsonwebtoken.security.Keys;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.Date;
import java.util.Locale;
import java.util.UUID;
import javax.crypto.SecretKey;
import org.springframework.stereotype.Service;
/**
 * Represents the class Jwt Service.
 */

@Service
public class JwtService {
    private final SecurityProperties properties;
    private final SecretKey signingKey;
    /**
     * Jwt Service.
     * @param properties the value supplied for the properties.
     * @return the result of the operation.
     */

    public JwtService(SecurityProperties properties) {
        this.properties = properties;
        byte[] secretBytes = properties.jwtSecret().getBytes(StandardCharsets.UTF_8);
        if (secretBytes.length < 64) {
            throw new WeakKeyException(
                    "JWT secret must be at least 64 bytes for HS512. "
                            + "Update JWT_SECRET to a value with length >= 64 characters.");
        }
        this.signingKey = Keys.hmacShaKeyFor(secretBytes);
    }
    /**
     * Generate.
     * @param userId the value supplied for the userId.
     * @param email the value supplied for the email.
     * @param role the value supplied for the role.
     * @return the result of the operation.
     */

    public String generate(UUID userId, String email, JwtRole role) {
        Instant now = Instant.now();

        return Jwts.builder()
                .issuer(properties.issuer())
                .subject(userId.toString())
                .claim("email", email)
                .claim("role", role.name())
                .issuedAt(Date.from(now))
                .expiration(Date.from(now.plus(properties.tokenTtl())))
                .signWith(signingKey, SignatureAlgorithm.HS512)
                .compact();
    }
    /**
     * Parse.
     * @param token the value supplied for the token.
     * @return the result of the operation.
     */

    public JwtPrincipal parse(String token) {
        Jws<Claims> parsed = Jwts.parser()
                .verifyWith(signingKey)
                .requireIssuer(properties.issuer())
                .build()
                .parseSignedClaims(token);

        Claims claims = parsed.getPayload();

        String roleClaim = claims.get("role", String.class);
        if (roleClaim == null || roleClaim.isBlank()) {
            throw new IllegalArgumentException("JWT role claim is missing or blank");
        }
        String normalizedRole = roleClaim.trim();
        try {
            return new JwtPrincipal(
                    UUID.fromString(claims.getSubject()),
                    JwtRole.valueOf(normalizedRole.toUpperCase(Locale.ROOT)),
                    claims.get("email", String.class));
        } catch (IllegalArgumentException ex) {
            throw new IllegalArgumentException(
                    "Unsupported JWT role claim: " + normalizedRole, ex);
        }
    }
}

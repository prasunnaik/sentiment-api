package com.insurewise.policy.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.UUID;
/**
 * Represents the class Policy.
 */

@Entity
@Table(name = "policies")
public class Policy {
    @Id
    @GeneratedValue
    private UUID id;

    @Column(nullable = false, length = 120)
    private String name;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "category_id", nullable = false)
    private Category category;

    @Column(name = "coverage_amount", nullable = false, precision = 14, scale = 2)
    private BigDecimal coverageAmount;

    @Column(name = "premium_amount", nullable = false, precision = 10, scale = 2)
    private BigDecimal premiumAmount;

    @Column(name = "duration_label", nullable = false, length = 40)
    private String durationLabel;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private PolicyStatus status;

    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;
    /**
     * Policy.
     * @return the result of the operation.
     */

    protected Policy() {
    }
    /**
     * Policy.
     * @param name the value supplied for the name.
     * @param category the value supplied for the category.
     * @param coverageAmount the value supplied for the coverageAmount.
     * @param premiumAmount the value supplied for the premiumAmount.
     * @param durationLabel the value supplied for the durationLabel.
     * @param status the value supplied for the status.
     * @return the result of the operation.
     */

    public Policy(
            String name,
            Category category,
            BigDecimal coverageAmount,
            BigDecimal premiumAmount,
            String durationLabel,
            PolicyStatus status) {
        this.name = name;
        this.category = category;
        this.coverageAmount = coverageAmount;
        this.premiumAmount = premiumAmount;
        this.durationLabel = durationLabel;
        this.status = status;
    }

    @PrePersist
    void initialize() {
        if (createdAt == null) {
            createdAt = LocalDateTime.now();
        }
    }
    /**
     * Update.
     * @param name the value supplied for the name.
     * @param category the value supplied for the category.
     * @param coverageAmount the value supplied for the coverageAmount.
     * @param premiumAmount the value supplied for the premiumAmount.
     * @param durationLabel the value supplied for the durationLabel.
     * @param status the value supplied for the status.
     */

    public void update(
            String name,
            Category category,
            BigDecimal coverageAmount,
            BigDecimal premiumAmount,
            String durationLabel,
            PolicyStatus status) {
        this.name = name;
        this.category = category;
        this.coverageAmount = coverageAmount;
        this.premiumAmount = premiumAmount;
        this.durationLabel = durationLabel;
        this.status = status;
    }
    /**
     * Is Active For Customer.
     * @return the result of the operation.
     */

    public boolean isActiveForCustomer() {
        return status == PolicyStatus.ACTIVE
                && category.getStatus() == CategoryStatus.ACTIVE;
    }
    /**
     * Get Id.
     * @return the result of the operation.
     */

    public UUID getId() {
        return id;
    }
    /**
     * Get Name.
     * @return the result of the operation.
     */

    public String getName() {
        return name;
    }
    /**
     * Get Category.
     * @return the result of the operation.
     */

    public Category getCategory() {
        return category;
    }
    /**
     * Get Coverage Amount.
     * @return the result of the operation.
     */

    public BigDecimal getCoverageAmount() {
        return coverageAmount;
    }
    /**
     * Get Premium Amount.
     * @return the result of the operation.
     */

    public BigDecimal getPremiumAmount() {
        return premiumAmount;
    }
    /**
     * Get Duration Label.
     * @return the result of the operation.
     */

    public String getDurationLabel() {
        return durationLabel;
    }
    /**
     * Get Status.
     * @return the result of the operation.
     */

    public PolicyStatus getStatus() {
        return status;
    }
}

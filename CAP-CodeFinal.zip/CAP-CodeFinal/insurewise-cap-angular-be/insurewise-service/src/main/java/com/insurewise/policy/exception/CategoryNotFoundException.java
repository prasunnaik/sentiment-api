package com.insurewise.policy.exception;

import com.insurewise.common.exception.ResourceNotFoundException;
import java.util.UUID;

public class CategoryNotFoundException extends ResourceNotFoundException {
    /**
     * Category Not Found Exception.
     * @param id the value supplied for the id.
     * @return the result of the operation.
     */

    public CategoryNotFoundException(UUID id) {
        super("CATEGORY_NOT_FOUND", "Category not found: " + id);
    }
}
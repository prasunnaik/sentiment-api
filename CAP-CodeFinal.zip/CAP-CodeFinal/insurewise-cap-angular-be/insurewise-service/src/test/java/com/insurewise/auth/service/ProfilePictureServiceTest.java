package com.insurewise.auth.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.insurewise.auth.dto.response.ProfilePictureResponse;
import com.insurewise.auth.entity.Customer;
import com.insurewise.auth.exception.ProfilePictureNotFoundException;
import com.insurewise.auth.repository.CustomerRepository;
import com.insurewise.common.dto.PresignedUrlResponse;
import com.insurewise.common.exception.InvalidFileException;
import com.insurewise.common.service.S3StorageService;
import java.time.Instant;
import java.util.Optional;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.mock.web.MockMultipartFile;

@ExtendWith(MockitoExtension.class)
class ProfilePictureServiceTest {

    @Mock
    private CustomerRepository customerRepository;

    @Mock
    private S3StorageService storageService;

    @InjectMocks
    private ProfilePictureService service;

    private Customer customer;
    private MockMultipartFile validFile;

    @BeforeEach
    void setUp() {
        customer = new Customer("John Doe", "9999999999", "john@example.com", "password-hash");
        validFile = new MockMultipartFile("file", "avatar.png", "image/png", new byte[] {1, 2, 3});
    }

    @Test
    void uploadShouldStoreNewProfilePicture() {
        UUID customerId = UUID.randomUUID();
        PresignedUrlResponse download = new PresignedUrlResponse("https://example.com/file", Instant.now().plusSeconds(60));
        when(customerRepository.findById(customerId)).thenReturn(Optional.of(customer));
        when(storageService.upload(validFile, "profile-pictures", customerId)).thenReturn("new-key");
        when(customerRepository.save(customer)).thenReturn(customer);
        when(storageService.getPresignedDownloadUrl("new-key")).thenReturn(download);

        ProfilePictureResponse response = service.upload(customerId, validFile);

        assertNotNull(response);
        assertEquals("new-key", response.s3Key());
        assertEquals("https://example.com/file", response.download().url());
    }

    @Test
    void getShouldReturnNullWhenProfilePictureMissing() {
        UUID customerId = UUID.randomUUID();
        when(customerRepository.findById(customerId)).thenReturn(Optional.of(customer));

        ProfilePictureResponse response = service.get(customerId);

        assertNull(response);
    }

    @Test
    void deleteShouldRemoveExistingProfilePicture() {
        UUID customerId = UUID.randomUUID();
        customer.setProfilePictureS3Key("existing-key");
        when(customerRepository.findById(customerId)).thenReturn(Optional.of(customer));
        when(customerRepository.save(customer)).thenReturn(customer);

        service.delete(customerId);

        verify(storageService).delete("existing-key");
        assertNull(customer.getProfilePictureS3Key());
    }

    @Test
    void deleteShouldThrowWhenProfilePictureMissing() {
        UUID customerId = UUID.randomUUID();
        when(customerRepository.findById(customerId)).thenReturn(Optional.of(customer));

        assertThrows(ProfilePictureNotFoundException.class, () -> service.delete(customerId));
    }

    @Test
    void getShouldReturnProfilePictureWhenPresent() {
        UUID customerId = UUID.randomUUID();
        PresignedUrlResponse download = new PresignedUrlResponse("https://example.com/file", Instant.now().plusSeconds(60));
        customer.setProfilePictureS3Key("existing-key");
        when(customerRepository.findById(customerId)).thenReturn(Optional.of(customer));
        when(storageService.getPresignedDownloadUrl("existing-key")).thenReturn(download);

        ProfilePictureResponse response = service.get(customerId);

        assertEquals("existing-key", response.s3Key());
    }

    @Test
    void uploadShouldRejectInvalidContentType() {
        UUID customerId = UUID.randomUUID();
        MockMultipartFile invalidFile = new MockMultipartFile("file", "avatar.gif", "image/gif", new byte[] {1});

        assertThrows(InvalidFileException.class, () -> service.upload(customerId, invalidFile));
    }

    @Test
    void uploadShouldCleanupNewObjectWhenSaveFails() {
        UUID customerId = UUID.randomUUID();
        when(customerRepository.findById(customerId)).thenReturn(Optional.of(customer));
        when(storageService.upload(validFile, "profile-pictures", customerId)).thenReturn("new-key");
        when(customerRepository.save(customer)).thenThrow(new RuntimeException("db error"));

        assertThrows(RuntimeException.class, () -> service.upload(customerId, validFile));

        verify(storageService).delete("new-key");
    }
}

package com.insurewise.auth.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.insurewise.auth.dto.request.StaffCreateRequest;
import com.insurewise.auth.dto.request.StaffUpdateRequest;
import com.insurewise.auth.dto.response.StaffProfileResponse;
import com.insurewise.auth.entity.StaffUser;
import com.insurewise.auth.exception.DuplicateEmailException;
import com.insurewise.auth.exception.StaffUserNotFoundException;
import com.insurewise.auth.repository.CustomerRepository;
import com.insurewise.auth.repository.StaffUserRepository;
import com.insurewise.common.exception.BusinessException;
import com.insurewise.common.service.S3StorageService;
import java.util.Optional;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.crypto.password.PasswordEncoder;

@ExtendWith(MockitoExtension.class)
class StaffUserServiceTest {

    @Mock
    private StaffUserRepository staffUserRepository;

    @Mock
    private CustomerRepository customerRepository;

    @Mock
    private PasswordEncoder passwordEncoder;

    @Mock
    private S3StorageService storageService;

    @InjectMocks
    private StaffUserService service;

    private StaffUser staffUser;

    @BeforeEach
    void setUp() {
        staffUser = new StaffUser("Admin User", "admin@example.com", "HQ Office", "encoded-password");
    }

    @Test
    void createShouldSaveStaffUserAndReturnResponse() {
        StaffCreateRequest request =
                new StaffCreateRequest("Admin User", "Admin@Example.com", "HQ Office", "secret123");
        when(staffUserRepository.existsByEmailIgnoreCase("admin@example.com")).thenReturn(false);
        when(customerRepository.existsByEmailIgnoreCase("admin@example.com")).thenReturn(false);
        when(passwordEncoder.encode("secret123")).thenReturn("encoded-password");
        when(staffUserRepository.save(any(StaffUser.class))).thenReturn(staffUser);

        StaffProfileResponse response = service.createStaffUser(request);

        assertNotNull(response);
        assertEquals("Admin User", response.fullName());
        assertEquals("admin@example.com", response.email());
        assertNull(response.profilePictureUrl());
    }

    @Test
    void createShouldRejectDuplicateEmail() {
        StaffCreateRequest request =
                new StaffCreateRequest("Admin User", "admin@example.com", "HQ Office", "secret123");
        when(staffUserRepository.existsByEmailIgnoreCase("admin@example.com")).thenReturn(true);

        assertThrows(DuplicateEmailException.class, () -> service.createStaffUser(request));
    }

    @Test
    void updateShouldEncodeNewPasswordAndReturnUpdatedResponse() {
        UUID staffId = UUID.randomUUID();
        StaffUpdateRequest request =
                new StaffUpdateRequest("Updated Admin", "updated@example.com", "Branch Office", "new-secret1");
        when(staffUserRepository.findById(staffId)).thenReturn(Optional.of(staffUser));
        when(staffUserRepository.findByEmailIgnoreCase("updated@example.com")).thenReturn(Optional.empty());
        when(customerRepository.existsByEmailIgnoreCase("updated@example.com")).thenReturn(false);
        when(passwordEncoder.encode("new-secret1")).thenReturn("encoded-new-secret");

        StaffProfileResponse response = service.updateStaffUser(staffId, request);

        assertEquals("Updated Admin", response.fullName());
        assertEquals("updated@example.com", response.email());
        assertEquals("Branch Office", response.address());
    }

    @Test
    void getShouldThrowWhenStaffMissing() {
        UUID staffId = UUID.randomUUID();
        when(staffUserRepository.findById(staffId)).thenReturn(Optional.empty());

        assertThrows(StaffUserNotFoundException.class, () -> service.getStaffUserById(staffId));
    }

    @Test
    void getShouldReturnExistingStaffUser() {
        UUID staffId = UUID.randomUUID();
        when(staffUserRepository.findById(staffId)).thenReturn(Optional.of(staffUser));

        StaffProfileResponse response = service.getStaffUserById(staffId);

        assertEquals("Admin User", response.fullName());
    }

    @Test
    void getCurrentStaffProfileShouldReturnAuthenticatedStaffUser() {
        UUID staffId = UUID.randomUUID();
        when(staffUserRepository.findById(staffId)).thenReturn(Optional.of(staffUser));

        StaffProfileResponse response = service.getCurrentStaffUserProfile(staffId);

        assertEquals("admin@example.com", response.email());
    }

    @Test
    void deleteShouldRemoveExistingStaffUser() {
        UUID staffId = UUID.randomUUID();
        when(staffUserRepository.findById(staffId)).thenReturn(Optional.of(staffUser));

        service.deleteStaffUser(staffId);

        verify(staffUserRepository).delete(staffUser);
    }

    @Test
    void listShouldWrapUnexpectedFailure() {
        when(staffUserRepository.findAll()).thenThrow(new RuntimeException("db error"));

        BusinessException exception = assertThrows(BusinessException.class, () -> service.listStaffUsers());

        assertEquals("STAFF_USER_LIST_FAILED", exception.getErrorCode());
    }
}

package com.insurewise.policy.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.insurewise.common.exception.BusinessException;
import com.insurewise.policy.dto.request.CategoryCreateRequest;
import com.insurewise.policy.dto.request.CategoryUpdateRequest;
import com.insurewise.policy.dto.response.CategoryResponse;
import com.insurewise.policy.entity.Category;
import com.insurewise.policy.entity.CategoryStatus;
import com.insurewise.policy.exception.CategoryNotFoundException;
import com.insurewise.policy.repository.CategoryRepository;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class CategoryServiceTest {

    @Mock
    private CategoryRepository repository;

    @InjectMocks
    private CategoryService service;

    private Category category;

    @BeforeEach
    void setUp() {
        category = new Category("Health", "Health insurance plans", CategoryStatus.ACTIVE);
    }

    @Test
    void createShouldReturnSavedCategoryResponse() {
        CategoryCreateRequest request =
                new CategoryCreateRequest("Health", "Health insurance plans", CategoryStatus.ACTIVE);
        when(repository.save(any(Category.class))).thenReturn(category);

        CategoryResponse response = service.create(request);

        assertNotNull(response);
        assertEquals("Health", response.name());
        assertEquals("Health insurance plans", response.description());
        assertEquals(CategoryStatus.ACTIVE, response.status());
        verify(repository).save(any(Category.class));
    }

    @Test
    void listShouldReturnMappedCategoryResponses() {
        when(repository.findAll()).thenReturn(List.of(category));

        List<CategoryResponse> responses = service.list();

        assertEquals(1, responses.size());
        assertEquals("Health", responses.get(0).name());
        assertEquals(CategoryStatus.ACTIVE, responses.get(0).status());
    }

    @Test
    void updateShouldModifyExistingCategory() {
        UUID categoryId = UUID.randomUUID();
        CategoryUpdateRequest request =
                new CategoryUpdateRequest("Life", "Life insurance plans", CategoryStatus.INACTIVE);
        when(repository.findById(categoryId)).thenReturn(Optional.of(category));

        CategoryResponse response = service.update(categoryId, request);

        assertEquals("Life", response.name());
        assertEquals("Life insurance plans", response.description());
        assertEquals(CategoryStatus.INACTIVE, response.status());
    }

    @Test
    void deleteShouldRemoveExistingCategory() {
        UUID categoryId = UUID.randomUUID();
        when(repository.findById(categoryId)).thenReturn(Optional.of(category));

        service.delete(categoryId);

        verify(repository).delete(category);
    }

    @Test
    void findShouldThrowWhenCategoryMissing() {
        UUID categoryId = UUID.randomUUID();
        when(repository.findById(categoryId)).thenReturn(Optional.empty());

        CategoryNotFoundException exception =
                assertThrows(CategoryNotFoundException.class, () -> service.find(categoryId));

        assertTrue(exception.getMessage().contains(categoryId.toString()));
    }

    @Test
    void createShouldWrapUnexpectedRepositoryFailure() {
        CategoryCreateRequest request =
                new CategoryCreateRequest("Health", "Health insurance plans", CategoryStatus.ACTIVE);
        when(repository.save(any(Category.class))).thenThrow(new RuntimeException("db error"));

        BusinessException exception = assertThrows(BusinessException.class, () -> service.create(request));

        assertEquals("CATEGORY_CREATE_FAILED", exception.getErrorCode());
    }
}

package com.insurewise.auth.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.insurewise.auth.dto.response.StaffProfilePictureResponse;
import com.insurewise.auth.entity.StaffUser;
import com.insurewise.auth.exception.StaffProfilePictureNotFoundException;
import com.insurewise.auth.repository.StaffUserRepository;
import com.insurewise.common.dto.PresignedUrlResponse;
import com.insurewise.common.exception.InvalidFileException;
import com.insurewise.common.service.S3StorageService;
import java.time.Instant;
import java.util.Optional;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.mock.web.MockMultipartFile;

@ExtendWith(MockitoExtension.class)
class StaffProfilePictureServiceTest {

    @Mock
    private StaffUserRepository staffUserRepository;

    @Mock
    private S3StorageService storageService;

    @InjectMocks
    private StaffProfilePictureService service;

    private StaffUser staffUser;
    private MockMultipartFile validFile;

    @BeforeEach
    void setUp() {
        staffUser = new StaffUser("Admin User", "admin@example.com", "HQ Office", "password-hash");
        validFile = new MockMultipartFile("file", "avatar.png", "image/png", new byte[] {1, 2, 3});
    }

    @Test
    void uploadShouldStoreNewStaffProfilePicture() {
        UUID staffId = UUID.randomUUID();
        PresignedUrlResponse download = new PresignedUrlResponse("https://example.com/staff", Instant.now().plusSeconds(60));
        when(staffUserRepository.findById(staffId)).thenReturn(Optional.of(staffUser));
        when(storageService.upload(validFile, "profile-pictures", staffId)).thenReturn("staff-key");
        when(staffUserRepository.save(staffUser)).thenReturn(staffUser);
        when(storageService.getPresignedDownloadUrl("staff-key")).thenReturn(download);

        StaffProfilePictureResponse response = service.upload(staffId, validFile);

        assertNotNull(response);
        assertEquals("staff-key", response.s3Key());
        assertEquals("https://example.com/staff", response.download().url());
    }

    @Test
    void getShouldThrowWhenStaffProfilePictureMissing() {
        UUID staffId = UUID.randomUUID();
        when(staffUserRepository.findById(staffId)).thenReturn(Optional.of(staffUser));

        assertThrows(StaffProfilePictureNotFoundException.class, () -> service.get(staffId));
    }

    @Test
    void getShouldReturnExistingStaffProfilePicture() {
        UUID staffId = UUID.randomUUID();
        PresignedUrlResponse download = new PresignedUrlResponse("https://example.com/staff", Instant.now().plusSeconds(60));
        staffUser.setProfilePictureS3Key("staff-key");
        when(staffUserRepository.findById(staffId)).thenReturn(Optional.of(staffUser));
        when(storageService.getPresignedDownloadUrl("staff-key")).thenReturn(download);

        StaffProfilePictureResponse response = service.get(staffId);

        assertEquals("staff-key", response.s3Key());
    }

    @Test
    void deleteShouldRemoveExistingStaffProfilePicture() {
        UUID staffId = UUID.randomUUID();
        staffUser.setProfilePictureS3Key("staff-key");
        when(staffUserRepository.findById(staffId)).thenReturn(Optional.of(staffUser));
        when(staffUserRepository.save(staffUser)).thenReturn(staffUser);

        service.delete(staffId);

        verify(storageService).delete("staff-key");
        assertNull(staffUser.getProfilePictureS3Key());
    }

    @Test
    void uploadShouldRejectInvalidImageType() {
        UUID staffId = UUID.randomUUID();
        MockMultipartFile invalidFile = new MockMultipartFile("file", "avatar.gif", "image/gif", new byte[] {1});

        assertThrows(InvalidFileException.class, () -> service.upload(staffId, invalidFile));
    }
}

package com.insurewise.policy.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import com.insurewise.common.security.JwtPrincipal;
import com.insurewise.common.security.JwtRole;
import com.insurewise.policy.dto.request.PolicyApplicationCreateRequest;
import com.insurewise.policy.dto.request.PolicyApplicationDecisionRequest;
import com.insurewise.policy.dto.response.PolicyApplicationResponse;
import com.insurewise.policy.entity.ApplicationStatus;
import com.insurewise.policy.entity.Category;
import com.insurewise.policy.entity.CategoryStatus;
import com.insurewise.policy.entity.CoverageType;
import com.insurewise.policy.entity.NomineeRelationship;
import com.insurewise.policy.entity.Policy;
import com.insurewise.policy.entity.PolicyApplication;
import com.insurewise.policy.entity.PolicyStatus;
import com.insurewise.policy.exception.ApplicationNotFoundException;
import com.insurewise.policy.exception.ApplicationStateException;
import com.insurewise.policy.exception.DuplicatePendingApplicationException;
import com.insurewise.policy.repository.PolicyApplicationRepository;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class PolicyApplicationServiceTest {

    @Mock
    private PolicyApplicationRepository applicationRepository;

    @Mock
    private PolicyService policyService;

    @InjectMocks
    private PolicyApplicationService service;

    private Policy policy;

    @BeforeEach
    void setUp() {
        Category category = new Category("Health", "Health plans", CategoryStatus.ACTIVE);
        policy = new Policy(
                "Standard Plan",
                category,
                BigDecimal.valueOf(250000),
                BigDecimal.valueOf(4999),
                "1 Year",
                PolicyStatus.ACTIVE);
    }

    @Test
    void createApplicationShouldPersistPendingApplication() {
        UUID customerId = UUID.randomUUID();
        UUID policyId = UUID.randomUUID();
        PolicyApplicationCreateRequest request = new PolicyApplicationCreateRequest(
                policyId,
                CoverageType.SINGLE,
                LocalDate.now().minusYears(25),
                "123 Main Street",
                LocalDate.now().plusDays(5),
                "Jane Doe",
                NomineeRelationship.SPOUSE);
        when(policyService.findPolicyEntity(policyId)).thenReturn(policy);
        when(applicationRepository.existsByCustomerIdAndPolicyIdAndStatus(customerId, policyId, ApplicationStatus.PENDING))
                .thenReturn(false);
        when(applicationRepository.nextApplicationCodeSequence()).thenReturn(101L);
        when(applicationRepository.saveAndFlush(any(PolicyApplication.class)))
                .thenAnswer(invocation -> invocation.getArgument(0));

        PolicyApplicationResponse response = service.createPolicyApplication(customerId, request);

        assertNotNull(response);
        assertEquals("APP-101", response.applicationCode());
        assertEquals(ApplicationStatus.PENDING, response.status());
        assertEquals("Jane Doe", response.nomineeName());
    }

    @Test
    void createApplicationShouldRejectPastPreferredStartDate() {
        UUID customerId = UUID.randomUUID();
        UUID policyId = UUID.randomUUID();
        PolicyApplicationCreateRequest request = new PolicyApplicationCreateRequest(
                policyId,
                CoverageType.SINGLE,
                LocalDate.now().minusYears(25),
                "123 Main Street",
                LocalDate.now().minusDays(1),
                null,
                null);
        when(policyService.findPolicyEntity(policyId)).thenReturn(policy);

        assertThrows(ApplicationStateException.class, () -> service.createPolicyApplication(customerId, request));
    }

    @Test
    void createApplicationShouldRejectDuplicatePendingApplication() {
        UUID customerId = UUID.randomUUID();
        UUID policyId = UUID.randomUUID();
        PolicyApplicationCreateRequest request = new PolicyApplicationCreateRequest(
                policyId,
                CoverageType.SINGLE,
                LocalDate.now().minusYears(25),
                "123 Main Street",
                LocalDate.now().plusDays(5),
                null,
                null);
        when(policyService.findPolicyEntity(policyId)).thenReturn(policy);
        when(applicationRepository.existsByCustomerIdAndPolicyIdAndStatus(customerId, policyId, ApplicationStatus.PENDING))
                .thenReturn(true);

        assertThrows(DuplicatePendingApplicationException.class, () -> service.createPolicyApplication(customerId, request));
    }

    @Test
    void listApplicationsShouldUseCustomerScopedQuery() {
        UUID customerId = UUID.randomUUID();
        JwtPrincipal principal = new JwtPrincipal(customerId, JwtRole.CUSTOMER, "john@example.com");
        PolicyApplication application = new PolicyApplication(
                "APP-100",
                customerId,
                policy,
                CoverageType.SINGLE,
                LocalDate.now().minusYears(25),
                "123 Main Street",
                LocalDate.now().plusDays(5),
                null,
                null);
        when(applicationRepository.findByCustomerIdOrderByCreatedAtDesc(customerId)).thenReturn(List.of(application));

        List<PolicyApplicationResponse> responses = service.listPolicyApplications(principal, null);

        assertEquals(1, responses.size());
        assertEquals("APP-100", responses.get(0).applicationCode());
    }

    @Test
    void getApplicationShouldRejectAccessToAnotherCustomersRecord() {
        UUID ownerId = UUID.randomUUID();
        UUID callerId = UUID.randomUUID();
        UUID applicationId = UUID.randomUUID();
        JwtPrincipal principal = new JwtPrincipal(callerId, JwtRole.CUSTOMER, "john@example.com");
        PolicyApplication application = new PolicyApplication(
                "APP-100",
                ownerId,
                policy,
                CoverageType.SINGLE,
                LocalDate.now().minusYears(25),
                "123 Main Street",
                LocalDate.now().plusDays(5),
                null,
                null);
        when(applicationRepository.findById(applicationId)).thenReturn(Optional.of(application));

        assertThrows(ApplicationNotFoundException.class, () -> service.getPolicyApplication(principal, applicationId));
    }

    @Test
    void updateApplicationStatusShouldApproveForStaff() {
        UUID staffId = UUID.randomUUID();
        UUID applicationId = UUID.randomUUID();
        JwtPrincipal principal = new JwtPrincipal(staffId, JwtRole.STAFF, "admin@example.com");
        PolicyApplication application = new PolicyApplication(
                "APP-100",
                UUID.randomUUID(),
                policy,
                CoverageType.SINGLE,
                LocalDate.now().minusYears(25),
                "123 Main Street",
                LocalDate.now().plusDays(5),
                null,
                null);
        when(applicationRepository.findById(applicationId)).thenReturn(Optional.of(application));
        when(applicationRepository.save(application)).thenReturn(application);

        PolicyApplicationResponse response = service.updatePolicyApplicationStatus(
                principal,
                applicationId,
                new PolicyApplicationDecisionRequest(ApplicationStatus.APPROVED));

        assertEquals(ApplicationStatus.APPROVED, response.status());
    }

    @Test
    void updateApplicationStatusShouldRejectApplicationForStaff() {
        UUID staffId = UUID.randomUUID();
        UUID applicationId = UUID.randomUUID();
        JwtPrincipal principal = new JwtPrincipal(staffId, JwtRole.STAFF, "admin@example.com");
        PolicyApplication application = new PolicyApplication(
                "APP-100",
                UUID.randomUUID(),
                policy,
                CoverageType.SINGLE,
                LocalDate.now().minusYears(25),
                "123 Main Street",
                LocalDate.now().plusDays(5),
                null,
                null);
        when(applicationRepository.findById(applicationId)).thenReturn(Optional.of(application));
        when(applicationRepository.save(application)).thenReturn(application);

        PolicyApplicationResponse response = service.updatePolicyApplicationStatus(
                principal,
                applicationId,
                new PolicyApplicationDecisionRequest(ApplicationStatus.REJECTED));

        assertEquals(ApplicationStatus.REJECTED, response.status());
    }

    @Test
    void getApplicationEntityForInternalUseShouldReturnEntity() {
        UUID applicationId = UUID.randomUUID();
        PolicyApplication application = new PolicyApplication(
                "APP-100",
                UUID.randomUUID(),
                policy,
                CoverageType.SINGLE,
                LocalDate.now().minusYears(25),
                "123 Main Street",
                LocalDate.now().plusDays(5),
                null,
                null);
        when(applicationRepository.findById(applicationId)).thenReturn(Optional.of(application));

        PolicyApplication response = service.getPolicyApplicationEntityForInternalUse(applicationId);

        assertNotNull(response);
        assertEquals("APP-100", response.getApplicationCode());
    }

    @Test
    void updateApplicationStatusShouldRejectNonStaffUser() {
        JwtPrincipal principal = new JwtPrincipal(UUID.randomUUID(), JwtRole.CUSTOMER, "john@example.com");

        assertThrows(
                ApplicationStateException.class,
                () -> service.updatePolicyApplicationStatus(
                        principal,
                        UUID.randomUUID(),
                        new PolicyApplicationDecisionRequest(ApplicationStatus.APPROVED)));
    }
}

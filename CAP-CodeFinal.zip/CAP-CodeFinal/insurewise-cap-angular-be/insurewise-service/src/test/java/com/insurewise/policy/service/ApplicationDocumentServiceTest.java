package com.insurewise.policy.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.insurewise.common.dto.PresignedUrlResponse;
import com.insurewise.common.exception.InvalidFileException;
import com.insurewise.common.security.JwtPrincipal;
import com.insurewise.common.security.JwtRole;
import com.insurewise.common.service.S3StorageService;
import com.insurewise.policy.dto.response.ApplicationDocumentContentResponse;
import com.insurewise.policy.dto.response.ApplicationDocumentResponse;
import com.insurewise.policy.entity.ApplicationDocument;
import com.insurewise.policy.entity.Category;
import com.insurewise.policy.entity.CategoryStatus;
import com.insurewise.policy.entity.CoverageType;
import com.insurewise.policy.entity.Policy;
import com.insurewise.policy.entity.PolicyApplication;
import com.insurewise.policy.entity.PolicyStatus;
import com.insurewise.policy.repository.ApplicationDocumentRepository;
import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.mock.web.MockMultipartFile;

@ExtendWith(MockitoExtension.class)
class ApplicationDocumentServiceTest {

    @Mock
    private ApplicationDocumentRepository documentRepository;

    @Mock
    private PolicyApplicationService applicationService;

    @Mock
    private S3StorageService storageService;

    @InjectMocks
    private ApplicationDocumentService service;

    private UUID customerId;
    private UUID applicationId;
    private PolicyApplication application;
    private MockMultipartFile validFile;

    @BeforeEach
    void setUp() {
        customerId = UUID.randomUUID();
        applicationId = UUID.randomUUID();
        Category category = new Category("Health", "Health plans", CategoryStatus.ACTIVE);
        Policy policy = new Policy(
                "Standard Plan",
                category,
                BigDecimal.valueOf(250000),
                BigDecimal.valueOf(4999),
                "1 Year",
                PolicyStatus.ACTIVE);
        application = new PolicyApplication(
                "APP-100",
                customerId,
                policy,
                CoverageType.SINGLE,
                LocalDate.now().minusYears(25),
                "123 Main Street",
                LocalDate.now().plusDays(5),
                null,
                null);
        validFile = new MockMultipartFile("file", "document.pdf", "application/pdf", new byte[] {1, 2, 3});
    }

    @Test
    void uploadDocumentShouldStorePdfAndReturnResponse() {
        JwtPrincipal principal = new JwtPrincipal(customerId, JwtRole.CUSTOMER, "john@example.com");
        PresignedUrlResponse download = new PresignedUrlResponse("https://example.com/document", Instant.now().plusSeconds(60));
        when(applicationService.getPolicyApplicationEntityForInternalUse(applicationId)).thenReturn(application);
        when(storageService.upload(any(), anyString(), eq(customerId), anyString())).thenAnswer(invocation -> invocation.getArgument(3));
        when(documentRepository.saveAndFlush(any(ApplicationDocument.class))).thenAnswer(invocation -> invocation.getArgument(0));
        when(storageService.getPresignedDownloadUrl(anyString())).thenReturn(download);

        ApplicationDocumentResponse response = service.uploadPolicyApplicationDocument(principal, applicationId, validFile);

        assertNotNull(response);
        assertEquals("document.pdf", response.fileName());
        assertNotNull(response.objectKey());
    }

    @Test
    void uploadDocumentShouldRejectNonPdfFile() {
        JwtPrincipal principal = new JwtPrincipal(customerId, JwtRole.CUSTOMER, "john@example.com");
        MockMultipartFile invalidFile = new MockMultipartFile("file", "image.png", "image/png", new byte[] {1});
        when(applicationService.getPolicyApplicationEntityForInternalUse(applicationId)).thenReturn(application);

        assertThrows(InvalidFileException.class, () -> service.uploadPolicyApplicationDocument(principal, applicationId, invalidFile));
    }

    @Test
    void listDocumentsShouldReturnMappedDocuments() {
        JwtPrincipal principal = new JwtPrincipal(customerId, JwtRole.CUSTOMER, "john@example.com");
        ApplicationDocument document = new ApplicationDocument(
                application,
                "document.pdf",
                "application/pdf",
                "doc-key",
                123L,
                customerId);
        PresignedUrlResponse download = new PresignedUrlResponse("https://example.com/document", Instant.now().plusSeconds(60));
        when(applicationService.getPolicyApplicationEntityForInternalUse(applicationId)).thenReturn(application);
        when(documentRepository.findByPolicyApplicationIdOrderByUploadedAtDesc(applicationId)).thenReturn(List.of(document));
        when(storageService.getPresignedDownloadUrl(anyString())).thenReturn(download);

        List<ApplicationDocumentResponse> responses = service.listApplicationDocuments(principal, applicationId);

        assertEquals(1, responses.size());
        assertEquals("document.pdf", responses.get(0).fileName());
    }

    @Test
    void getDocumentShouldReturnDocumentWithDownloadLink() {
        JwtPrincipal principal = new JwtPrincipal(customerId, JwtRole.CUSTOMER, "john@example.com");
        UUID documentId = UUID.randomUUID();
        ApplicationDocument document = new ApplicationDocument(
                application,
                "document.pdf",
                "application/pdf",
                "doc-key",
                123L,
                customerId);
        PresignedUrlResponse download = new PresignedUrlResponse("https://example.com/document", Instant.now().plusSeconds(60));
        when(applicationService.getPolicyApplicationEntityForInternalUse(applicationId)).thenReturn(application);
        when(documentRepository.findByIdAndPolicyApplicationId(documentId, applicationId)).thenReturn(Optional.of(document));
        when(storageService.getPresignedDownloadUrl(anyString())).thenReturn(download);

        ApplicationDocumentContentResponse response = service.getApplicationDocument(principal, applicationId, documentId);

        assertEquals("document.pdf", response.fileName());
        assertEquals("https://example.com/document", response.download().url());
    }

    @Test
    void previewDocumentShouldReturnDownloadLink() {
        JwtPrincipal principal = new JwtPrincipal(customerId, JwtRole.CUSTOMER, "john@example.com");
        UUID documentId = UUID.randomUUID();
        ApplicationDocument document = new ApplicationDocument(
                application,
                "document.pdf",
                "application/pdf",
                "doc-key",
                123L,
                customerId);
        PresignedUrlResponse download = new PresignedUrlResponse("https://example.com/document", Instant.now().plusSeconds(60));
        when(applicationService.getPolicyApplicationEntityForInternalUse(applicationId)).thenReturn(application);
        when(documentRepository.findByIdAndPolicyApplicationId(documentId, applicationId)).thenReturn(Optional.of(document));
        when(storageService.getPresignedPreviewUrl(anyString())).thenReturn(download);

        PresignedUrlResponse response = service.previewApplicationDocument(principal, applicationId, documentId);

        assertEquals("https://example.com/document", response.url());
    }

    @Test
    void downloadDocumentShouldReturnDownloadLink() {
        JwtPrincipal principal = new JwtPrincipal(customerId, JwtRole.CUSTOMER, "john@example.com");
        UUID documentId = UUID.randomUUID();
        ApplicationDocument document = new ApplicationDocument(
                application,
                "document.pdf",
                "application/pdf",
                "doc-key",
                123L,
                customerId);
        PresignedUrlResponse download = new PresignedUrlResponse("https://example.com/document", Instant.now().plusSeconds(60));
        when(applicationService.getPolicyApplicationEntityForInternalUse(applicationId)).thenReturn(application);
        when(documentRepository.findByIdAndPolicyApplicationId(documentId, applicationId)).thenReturn(Optional.of(document));
        when(storageService.getPresignedDownloadUrl(anyString())).thenReturn(download);

        PresignedUrlResponse response = service.downloadApplicationDocument(principal, applicationId, documentId);

        assertEquals("https://example.com/document", response.url());
    }

    @Test
    void deleteDocumentShouldDeleteStorageObjectAndEntity() {
        JwtPrincipal principal = new JwtPrincipal(customerId, JwtRole.CUSTOMER, "john@example.com");
        UUID documentId = UUID.randomUUID();
        ApplicationDocument document = new ApplicationDocument(
                application,
                "document.pdf",
                "application/pdf",
                "doc-key",
                123L,
                customerId);
        when(applicationService.getPolicyApplicationEntityForInternalUse(applicationId)).thenReturn(application);
        when(documentRepository.findByIdAndPolicyApplicationId(documentId, applicationId)).thenReturn(Optional.of(document));

        service.deleteApplicationDocument(principal, applicationId, documentId);

        verify(storageService).delete("doc-key");
        verify(documentRepository).delete(document);
    }

    @Test
    void uploadDocumentShouldCleanupStorageWhenSaveFails() {
        JwtPrincipal principal = new JwtPrincipal(customerId, JwtRole.CUSTOMER, "john@example.com");
        when(applicationService.getPolicyApplicationEntityForInternalUse(applicationId)).thenReturn(application);
        when(storageService.upload(any(), anyString(), eq(customerId), anyString())).thenAnswer(invocation -> invocation.getArgument(3));
        when(documentRepository.saveAndFlush(any(ApplicationDocument.class))).thenThrow(new RuntimeException("db error"));

        assertThrows(RuntimeException.class, () -> service.uploadPolicyApplicationDocument(principal, applicationId, validFile));

        verify(storageService).delete(anyString());
    }
}

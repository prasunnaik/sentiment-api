package com.insurewise.auth.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.insurewise.auth.dto.request.CustomerLoginRequest;
import com.insurewise.auth.dto.request.CustomerRegistrationRequest;
import com.insurewise.auth.dto.request.StaffLoginRequest;
import com.insurewise.auth.dto.response.AuthResponse;
import com.insurewise.auth.entity.Customer;
import com.insurewise.auth.entity.StaffUser;
import com.insurewise.auth.exception.DuplicateEmailException;
import com.insurewise.auth.exception.InvalidCredentialsException;
import com.insurewise.auth.repository.CustomerRepository;
import com.insurewise.auth.repository.StaffUserRepository;
import com.insurewise.common.exception.BusinessException;
import com.insurewise.common.security.JwtRole;
import com.insurewise.common.security.JwtService;
import java.util.Optional;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.crypto.password.PasswordEncoder;

@ExtendWith(MockitoExtension.class)
class AuthServiceTest {

    @Mock
    private CustomerRepository customerRepository;

    @Mock
    private StaffUserRepository staffUserRepository;

    @Mock
    private PasswordEncoder passwordEncoder;

    @Mock
    private JwtService jwtService;

    @InjectMocks
    private AuthService service;

    private Customer customer;
    private StaffUser staffUser;

    @BeforeEach
    void setUp() {
        customer = new Customer("John Doe", "9999999999", "john@example.com", "encoded-password");
        staffUser = new StaffUser("Admin User", "admin@example.com", "HQ Office", "encoded-password");
    }

    @Test
    void registerCustomerShouldSaveCustomerAndReturnToken() {
        CustomerRegistrationRequest request =
                new CustomerRegistrationRequest("John Doe", "9999999999", "John@Example.com", "secret123");
        when(customerRepository.existsByEmailIgnoreCase("john@example.com")).thenReturn(false);
        when(staffUserRepository.existsByEmailIgnoreCase("john@example.com")).thenReturn(false);
        when(passwordEncoder.encode("secret123")).thenReturn("encoded-password");
        when(customerRepository.save(any(Customer.class))).thenReturn(customer);
        when(jwtService.generate(any(UUID.class), eq("john@example.com"), eq(JwtRole.CUSTOMER))).thenReturn("jwt-token");

        AuthResponse response = service.registerCustomerAccount(request);

        assertNotNull(response);
        assertEquals("jwt-token", response.accessToken());
        assertEquals("john@example.com", response.email());
        assertEquals("CUSTOMER", response.role());
        verify(customerRepository).save(any(Customer.class));
    }

    @Test
    void registerCustomerShouldRejectDuplicateEmail() {
        CustomerRegistrationRequest request =
                new CustomerRegistrationRequest("John Doe", "9999999999", "john@example.com", "secret123");
        when(customerRepository.existsByEmailIgnoreCase("john@example.com")).thenReturn(true);

        assertThrows(DuplicateEmailException.class, () -> service.registerCustomerAccount(request));
    }

    @Test
    void loginCustomerShouldReturnTokenForValidCredentials() {
        CustomerLoginRequest request = new CustomerLoginRequest("john@example.com", "secret123");
        when(customerRepository.findByEmailIgnoreCase("john@example.com")).thenReturn(Optional.of(customer));
        when(passwordEncoder.matches("secret123", customer.getPasswordHash())).thenReturn(true);
        when(jwtService.generate(any(UUID.class), eq("john@example.com"), eq(JwtRole.CUSTOMER))).thenReturn("jwt-token");

        AuthResponse response = service.loginCustomerAccount(request);

        assertEquals("jwt-token", response.accessToken());
        assertEquals(customer.getId(), response.userId());
    }

    @Test
    void loginCustomerShouldRejectInvalidPassword() {
        CustomerLoginRequest request = new CustomerLoginRequest("john@example.com", "wrong-password");
        when(customerRepository.findByEmailIgnoreCase("john@example.com")).thenReturn(Optional.of(customer));
        when(passwordEncoder.matches("wrong-password", customer.getPasswordHash())).thenReturn(false);

        assertThrows(InvalidCredentialsException.class, () -> service.loginCustomerAccount(request));
    }

    @Test
    void loginStaffShouldReturnStaffTokenForValidCredentials() {
        StaffLoginRequest request = new StaffLoginRequest("admin@example.com", "secret123");
        when(staffUserRepository.findByEmailIgnoreCase("admin@example.com")).thenReturn(Optional.of(staffUser));
        when(passwordEncoder.matches("secret123", staffUser.getPasswordHash())).thenReturn(true);
        when(jwtService.generate(any(UUID.class), eq("admin@example.com"), eq(JwtRole.STAFF))).thenReturn("staff-token");

        AuthResponse response = service.loginStaffAccount(request);

        assertEquals("staff-token", response.accessToken());
        assertEquals("STAFF", response.role());
        assertEquals(staffUser.getEmail(), response.email());
    }

    @Test
    void loginStaffShouldRejectInvalidPassword() {
        StaffLoginRequest request = new StaffLoginRequest("admin@example.com", "wrong-password");
        when(staffUserRepository.findByEmailIgnoreCase("admin@example.com")).thenReturn(Optional.of(staffUser));
        when(passwordEncoder.matches("wrong-password", staffUser.getPasswordHash())).thenReturn(false);

        assertThrows(InvalidCredentialsException.class, () -> service.loginStaffAccount(request));
    }

    @Test
    void registerCustomerShouldWrapUnexpectedFailure() {
        CustomerRegistrationRequest request =
                new CustomerRegistrationRequest("John Doe", "9999999999", "john@example.com", "secret123");
        when(customerRepository.existsByEmailIgnoreCase("john@example.com")).thenReturn(false);
        when(staffUserRepository.existsByEmailIgnoreCase("john@example.com")).thenReturn(false);
        when(passwordEncoder.encode("secret123")).thenReturn("encoded-password");
        when(customerRepository.save(any(Customer.class))).thenThrow(new RuntimeException("db error"));

        BusinessException exception = assertThrows(BusinessException.class, () -> service.registerCustomerAccount(request));

        assertEquals("CUSTOMER_REGISTRATION_FAILED", exception.getErrorCode());
        assertTrue(exception.getMessage().contains("Unable to register customer"));
    }
}

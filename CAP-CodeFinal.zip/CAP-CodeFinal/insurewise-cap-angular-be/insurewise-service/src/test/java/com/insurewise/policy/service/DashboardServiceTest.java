package com.insurewise.policy.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import com.insurewise.auth.repository.CustomerRepository;
import com.insurewise.auth.repository.StaffUserRepository;
import com.insurewise.policy.dto.response.DashboardMetricsResponse;
import com.insurewise.policy.entity.ApplicationStatus;
import com.insurewise.policy.entity.PolicyStatus;
import com.insurewise.policy.repository.CategoryRepository;
import com.insurewise.policy.repository.PolicyApplicationRepository;
import com.insurewise.policy.repository.PolicyRepository;
import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class DashboardServiceTest {

    @Mock
    private CustomerRepository customerRepository;

    @Mock
    private StaffUserRepository staffUserRepository;

    @Mock
    private CategoryRepository categoryRepository;

    @Mock
    private PolicyRepository policyRepository;

    @Mock
    private PolicyApplicationRepository applicationRepository;

    @Mock
    private EntityManager entityManager;

    @Mock
    private Query claimsCountQuery;

    @Mock
    private Query claimsPendingQuery;

    @Mock
    private Query paymentsCountQuery;

    @Mock
    private Query paymentsSuccessQuery;

    @InjectMocks
    private DashboardService service;

    @Test
    void getMetricsShouldAggregateAllCounts() {
        when(customerRepository.count()).thenReturn(10L);
        when(staffUserRepository.count()).thenReturn(4L);
        when(categoryRepository.count()).thenReturn(6L);
        when(policyRepository.count()).thenReturn(8L);
        when(policyRepository.countByStatus(PolicyStatus.ACTIVE)).thenReturn(5L);
        when(applicationRepository.count()).thenReturn(7L);
        when(applicationRepository.countByStatus(ApplicationStatus.PENDING)).thenReturn(3L);
        when(applicationRepository.countByStatus(ApplicationStatus.APPROVED)).thenReturn(2L);

        when(entityManager.createNativeQuery("select count(*) from claims")).thenReturn(claimsCountQuery);
        when(claimsCountQuery.getSingleResult()).thenReturn(9L);

        when(entityManager.createNativeQuery("select count(*) from claims where status = :status"))
                .thenReturn(claimsPendingQuery);
        when(claimsPendingQuery.setParameter("status", "PENDING")).thenReturn(claimsPendingQuery);
        when(claimsPendingQuery.getSingleResult()).thenReturn(1L);

        when(entityManager.createNativeQuery("select count(*) from payments")).thenReturn(paymentsCountQuery);
        when(paymentsCountQuery.getSingleResult()).thenReturn(11L);

        when(entityManager.createNativeQuery("select count(*) from payments where status = :status"))
                .thenReturn(paymentsSuccessQuery);
        when(paymentsSuccessQuery.setParameter("status", "SUCCESS")).thenReturn(paymentsSuccessQuery);
        when(paymentsSuccessQuery.getSingleResult()).thenReturn(10L);

        DashboardMetricsResponse response = service.getDashboardMetrics();

        assertEquals(10L, response.totalCustomers());
        assertEquals(4L, response.totalStaff());
        assertEquals(6L, response.totalCategories());
        assertEquals(8L, response.totalPolicies());
        assertEquals(5L, response.activePolicies());
        assertEquals(7L, response.totalApplications());
        assertEquals(3L, response.pendingApplications());
        assertEquals(2L, response.activeApplications());
        assertEquals(9L, response.totalClaims());
        assertEquals(1L, response.pendingClaims());
        assertEquals(11L, response.totalPayments());
        assertEquals(10L, response.successfulPayments());
    }

    @Test
    void getMetricsShouldPropagateUnexpectedFailure() {
        when(customerRepository.count()).thenThrow(new RuntimeException("db error"));

        assertThrows(RuntimeException.class, () -> service.getDashboardMetrics());
    }
}

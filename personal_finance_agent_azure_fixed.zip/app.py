import os
import streamlit as st
from dotenv import load_dotenv

from src.agent import build_agent, run_agent

load_dotenv()

st.set_page_config(
    page_title="Personal Finance AI Agent",
    page_icon="💰",
    layout="centered",
)

st.title("💰 Personal Finance AI Agent")
st.caption("LangChain + Azure OpenAI • Web Search • Calculator")

required = [
    "AZURE_OPENAI_API_KEY",
    "AZURE_OPENAI_ENDPOINT",
    "AZURE_OPENAI_CHAT_DEPLOYMENT",
    "AZURE_OPENAI_CHAT_MODEL",
    "AZURE_OPENAI_API_VERSION",
]
missing = [name for name in required if not os.getenv(name)]

if missing:
    st.error("Missing environment variables: " + ", ".join(missing))
    st.info("Copy .env.example to .env and add your Azure OpenAI values.")
    st.stop()

@st.cache_resource
def get_agent():
    return build_agent()

agent = get_agent()

if "messages" not in st.session_state:
    st.session_state.messages = []

for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])

question = st.chat_input(
    "Ask about stocks, currency rates, percentages, returns, or other finance questions..."
)

if question:
    st.session_state.messages.append({"role": "user", "content": question})
    with st.chat_message("user"):
        st.markdown(question)

    with st.chat_message("assistant"):
        with st.spinner("Thinking..."):
            try:
                answer, tool_events = run_agent(agent, question)
                st.markdown(answer)

                if tool_events:
                    with st.expander("Tools used"):
                        for event in tool_events:
                            st.write(event)

                st.session_state.messages.append(
                    {"role": "assistant", "content": answer}
                )
            except Exception as exc:
                error = f"Agent error: {exc}"
                st.error(error)
                st.session_state.messages.append(
                    {"role": "assistant", "content": error}
                )

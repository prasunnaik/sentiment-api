from langchain.agents import create_agent
from langchain_openai import AzureChatOpenAI

from .tools import calculator, web_search


SYSTEM_PROMPT = """
You are a helpful personal finance assistant.

Your job is to answer personal-finance questions accurately and clearly.
You have two tools:
1. calculator: use it for arithmetic, percentages, conversions, interest,
   investment-return calculations, and any numerical calculation where
   precision matters.
2. web_search: use it whenever the answer depends on current or changing
   information, such as stock prices, exchange rates, market news, current
   financial facts, or recent events.

Rules:
- Do not invent current market data.
- If a question asks for current information, search the web first.
- For calculations, use the calculator rather than doing non-trivial
  arithmetic mentally.
- Explain assumptions when a financial calculation is ambiguous.
- Do not present financial education as personalized regulated advice.
- Keep answers concise but include the key calculation/result.
- If a user asks for a simple factual question that does not require a tool,
  answer directly.
"""


def build_agent():
    import os

    model = AzureChatOpenAI(
        azure_endpoint=os.environ["AZURE_OPENAI_ENDPOINT"],
        api_key=os.environ["AZURE_OPENAI_API_KEY"],
        api_version=os.environ["AZURE_OPENAI_API_VERSION"],
        azure_deployment=os.environ["AZURE_OPENAI_CHAT_DEPLOYMENT"],
        model=os.getenv("AZURE_OPENAI_CHAT_MODEL"),
        temperature=0,
    )
    return create_agent(
        model=model,
        tools=[web_search, calculator],
        system_prompt=SYSTEM_PROMPT,
    )


def _message_text(content):
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts = []
        for item in content:
            if isinstance(item, dict) and item.get("type") == "text":
                parts.append(item.get("text", ""))
            elif isinstance(item, str):
                parts.append(item)
        return "\n".join(p for p in parts if p)
    return str(content)


def run_agent(agent, question: str):
    result = agent.invoke(
        {"messages": [{"role": "user", "content": question}]}
    )

    messages = result.get("messages", [])
    tool_events = []

    for message in messages:
        if getattr(message, "type", None) == "tool":
            tool_name = getattr(message, "name", "tool")
            tool_events.append(f"{tool_name}: completed")

    answer = ""
    if messages:
        answer = _message_text(getattr(messages[-1], "content", messages[-1]))

    return answer, tool_events

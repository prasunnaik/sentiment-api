package com.insurewise.framework.s3.aspect;

import com.insurewise.framework.s3.annotation.EnableS3Upload;
import com.insurewise.framework.s3.annotation.S3FileField;
import com.insurewise.framework.s3.service.S3FileService;
import java.lang.reflect.Field;
import java.util.UUID;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

@Aspect
@Component
public class S3UploadAspect {

    private final S3FileService fileService;

    public S3UploadAspect(S3FileService fileService) {
        this.fileService = fileService;
    }

    @Around("@annotation(enableS3Upload)")
    public Object upload(
            ProceedingJoinPoint joinPoint,
            EnableS3Upload enableS3Upload) throws Throwable {

        MultipartFile file = null;
        UUID ownerId = null;
        Object targetFieldObject = null;

        for (Object argument : joinPoint.getArgs()) {
            if (argument instanceof MultipartFile multipartFile) {
                file = multipartFile;
            } else if (argument instanceof UUID uuid) {
                ownerId = uuid;
            } else if (argument != null) {
                targetFieldObject = argument;
            }
        }

        if (file != null && !file.isEmpty()) {
            String key = fileService.upload(
                    file,
                    enableS3Upload.folder(),
                    ownerId);

            if (targetFieldObject != null) {
                setS3FileField(targetFieldObject, key);
            }
        }

        return joinPoint.proceed();
    }

    private void setS3FileField(
            Object target,
            String key) throws IllegalAccessException {

        for (Field field : target.getClass().getDeclaredFields()) {
            if (!field.isAnnotationPresent(S3FileField.class)
                    || field.getType() != String.class) {
                continue;
            }

            field.setAccessible(true);
            field.set(target, key);
            return;
        }
    }
}

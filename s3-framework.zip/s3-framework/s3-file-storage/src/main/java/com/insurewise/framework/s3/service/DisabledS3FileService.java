package com.insurewise.framework.s3.service;

import com.insurewise.framework.s3.exception.S3FileStorageException;
import java.util.UUID;
import org.springframework.web.multipart.MultipartFile;

public class DisabledS3FileService implements S3FileService {

    private S3FileStorageException disabled() {
        return new S3FileStorageException(
                "S3 storage is disabled. Set S3_ENABLED=true and configure S3.");
    }

    @Override
    public String upload(MultipartFile file, String folder, UUID ownerId) {
        throw disabled();
    }

    @Override
    public String uploadGenerated(
            byte[] content,
            String fileName,
            String contentType,
            String folder,
            UUID ownerId) {
        throw disabled();
    }

    @Override
    public S3PresignedUrl getPresignedDownloadUrl(String s3Key) {
        throw disabled();
    }

    @Override
    public void delete(String s3Key) {
        // S3 is disabled; there is no remote object to delete.
    }
}

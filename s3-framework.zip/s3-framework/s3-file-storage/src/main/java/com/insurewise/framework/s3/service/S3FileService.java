package com.insurewise.framework.s3.service;

import java.util.UUID;
import org.springframework.web.multipart.MultipartFile;

public interface S3FileService {
    String upload(MultipartFile file, String folder, UUID ownerId);

    String uploadGenerated(
            byte[] content,
            String fileName,
            String contentType,
            String folder,
            UUID ownerId);

    S3PresignedUrl getPresignedDownloadUrl(String s3Key);

    void delete(String s3Key);
}

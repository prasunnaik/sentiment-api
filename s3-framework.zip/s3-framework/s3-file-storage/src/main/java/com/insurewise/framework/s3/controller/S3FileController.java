package com.insurewise.framework.s3.controller;

import com.insurewise.framework.s3.service.S3FileService;
import com.insurewise.framework.s3.service.S3PresignedUrl;
import java.util.Map;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/storage")
@ConditionalOnProperty(
        prefix = "ng.file-upload.s3.download",
        name = "enabled",
        havingValue = "true")
public class S3FileController {

    private final S3FileService fileService;

    public S3FileController(S3FileService fileService) {
        this.fileService = fileService;
    }

    @GetMapping("/download-url")
    @PreAuthorize("hasRole('STAFF')")
    public ResponseEntity<Map<String, Object>> downloadUrl(
            @RequestParam String key) {

        S3PresignedUrl response =
                fileService.getPresignedDownloadUrl(key);

        return ResponseEntity.ok(Map.of(
                "url", response.url(),
                "expiresAt", response.expiresAt()));
    }
}

package com.insurewise.framework.s3.service;

import java.time.Instant;

public record S3PresignedUrl(String url, Instant expiresAt) {
}

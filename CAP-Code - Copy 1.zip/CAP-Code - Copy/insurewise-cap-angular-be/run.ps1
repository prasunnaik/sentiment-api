<#
    Builds the s3-framework dependency, installs it to the local Maven repo,
    builds insurewise-service against it, then runs the jar with .env loaded.

    Usage:
      .\run.ps1                # build both modules, then run
      .\run.ps1 -SkipBuild     # reuse previously built jars, just run
#>
param(
    [switch]$SkipBuild
)

$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot

# --- Locate a JDK 17 install (mvn/java on PATH may resolve to an older JDK) ---
function Find-Jdk17 {
    if ($env:JAVA_HOME -and (Test-Path "$env:JAVA_HOME\bin\java.exe")) {
        # java -version writes to stderr; relax ErrorActionPreference so 2>&1 isn't treated as terminating
        $prevEap = $ErrorActionPreference
        $ErrorActionPreference = 'Continue'
        $ver = & "$env:JAVA_HOME\bin\java.exe" -version 2>&1 | Select-String 'version "17'
        $ErrorActionPreference = $prevEap
        if ($ver) { return $env:JAVA_HOME }
    }
    $candidates = @(
        'C:\Program Files\Eclipse Adoptium\jdk-17*',
        'C:\Program Files\Amazon Corretto\jdk17*',
        'C:\Program Files\Java\jdk-17*'
    )
    foreach ($pattern in $candidates) {
        $found = Get-ChildItem -Path $pattern -Directory -ErrorAction SilentlyContinue |
            Sort-Object Name -Descending | Select-Object -First 1
        if ($found) { return $found.FullName }
    }
    return $null
}

$jdk17 = Find-Jdk17
if (-not $jdk17) {
    throw "JDK 17 not found. Install one (e.g. Eclipse Adoptium Temurin 17) or set JAVA_HOME to a JDK 17 path."
}
$env:JAVA_HOME = $jdk17
$env:Path = "$jdk17\bin;$env:Path"
Write-Host "Using JAVA_HOME: $jdk17"

$s3FrameworkPom = Join-Path $root 's3-framework\pom.xml'
$servicePom = Join-Path $root 'insurewise-service\pom.xml'
$serviceDir = Join-Path $root 'insurewise-service'

if (-not $SkipBuild) {
    Write-Host "`nBuilding and installing s3-framework..."
    mvn -f $s3FrameworkPom clean install -DskipTests
    if ($LASTEXITCODE -ne 0) { throw "s3-framework build failed." }

    Write-Host "`nBuilding insurewise-service..."
    mvn -f $servicePom clean package -DskipTests
    if ($LASTEXITCODE -ne 0) { throw "insurewise-service build failed." }
}

$jar = Get-ChildItem -Path (Join-Path $serviceDir 'target') -Filter '*.jar' -ErrorAction SilentlyContinue |
    Where-Object { $_.Name -notmatch '\.original$' } | Select-Object -First 1
if (-not $jar) {
    throw "No jar found under insurewise-service\target. Run without -SkipBuild first."
}

# --- Load insurewise-service\.env into the process environment (falls back to .env.example) ---
$envFile = Join-Path $serviceDir '.env'
if (-not (Test-Path $envFile)) {
    Write-Warning ".env not found; copying .env.example. Fill in real values before relying on S3/DB features."
    Copy-Item (Join-Path $serviceDir '.env.example') $envFile
}

Get-Content $envFile | ForEach-Object {
    $line = $_.Trim()
    if ($line -and -not $line.StartsWith('#') -and $line.Contains('=')) {
        $parts = $line.Split('=', 2)
        [System.Environment]::SetEnvironmentVariable($parts[0].Trim(), $parts[1].Trim(), 'Process')
    }
}

Write-Host "`nStarting insurewise-service..."
& "$jdk17\bin\java.exe" -jar $jar.FullName

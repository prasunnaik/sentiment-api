CREATE EXTENSION IF NOT EXISTS "pgcrypto";

CREATE SEQUENCE claim_code_seq START WITH 1000 INCREMENT BY 1;

CREATE TABLE claims (
    id                     UUID           PRIMARY KEY DEFAULT gen_random_uuid(),
    claim_code             VARCHAR(20)    NOT NULL,
    idempotency_key        VARCHAR(80)    NOT NULL,
    customer_id            UUID           NOT NULL,
    policy_application_id  UUID           NOT NULL,
    policy_name_snapshot   VARCHAR(120)   NOT NULL,
    incident_type          VARCHAR(40)    NOT NULL,
    incident_date          DATE           NOT NULL,
    amount                 NUMERIC(14,2)  NOT NULL,
    description            VARCHAR(1000)  NOT NULL,
    document_ref           VARCHAR(300),
    status                 VARCHAR(20)    NOT NULL,
    processed_by           UUID,
    processed_at           TIMESTAMP,
    created_at             TIMESTAMP      NOT NULL DEFAULT now(),
    CONSTRAINT uq_claims_claim_code      UNIQUE (claim_code),
    CONSTRAINT uq_claims_idempotency_key UNIQUE (idempotency_key),
    CONSTRAINT ck_claims_amount_positive CHECK (amount > 0),
    CONSTRAINT ck_claims_incident_type CHECK (incident_type IN ('ACCIDENT','HOSPITALIZATION','THEFT','NATURAL_DISASTER','FIRE','DEATH','DISABILITY','PROPERTY_DAMAGE','OTHER')),
    CONSTRAINT ck_claims_status CHECK (status IN ('PENDING','UNDER_REVIEW','APPROVED','REJECTED'))
);

CREATE INDEX idx_claims_customer ON claims (customer_id);
CREATE INDEX idx_claims_status ON claims (status);
CREATE INDEX idx_claims_policy_app ON claims (policy_application_id);

ALTER TABLE customers
    ADD COLUMN profile_picture TEXT;

ALTER TABLE staff_users
    ADD COLUMN profile_picture TEXT;
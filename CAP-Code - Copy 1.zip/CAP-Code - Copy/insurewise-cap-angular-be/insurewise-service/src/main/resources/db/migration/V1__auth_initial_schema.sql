CREATE EXTENSION IF NOT EXISTS "pgcrypto";

CREATE TABLE customers (
    id            UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    full_name     VARCHAR(120)  NOT NULL,
    phone         VARCHAR(30)   NOT NULL,
    email         VARCHAR(160)  NOT NULL,
    password_hash VARCHAR(100)  NOT NULL,
    created_at    TIMESTAMP     NOT NULL DEFAULT now(),
    CONSTRAINT uq_customers_email UNIQUE (email)
);

CREATE TABLE staff_users (
    id            UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    full_name     VARCHAR(120)  NOT NULL,
    email         VARCHAR(160)  NOT NULL,
    address       VARCHAR(240)  NOT NULL,
    password_hash VARCHAR(100)  NOT NULL,
    created_at    TIMESTAMP     NOT NULL DEFAULT now(),
    CONSTRAINT uq_staff_users_email UNIQUE (email)
);

INSERT INTO staff_users (id, full_name, email, address, password_hash)
VALUES (
    'a0000000-0000-0000-0000-000000000001',
    'System Admin',
    'admin@insurewise.com',
    'InsureWise HQ',
    '$2a$10$5HJZwqvGZgJRII/fkr8HsedsvESUF8khDwpUOBDgc7EMI578NV2qK'
);

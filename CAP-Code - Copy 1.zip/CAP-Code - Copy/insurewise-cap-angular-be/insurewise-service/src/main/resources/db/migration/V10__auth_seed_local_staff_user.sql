INSERT INTO staff_users (id, full_name, email, address, password_hash)
VALUES (
    '2a3ef9df-1c18-429e-ab38-2f1e6f8fa6c7',
    'Local Staff Admin',
    'staff.local@insurewise.com',
    'InsureWise HQ',
    '$2a$10$hUGRG47rHX4zg8Ccj1lT.eQn3Tkni9zu2HU9.Og5TMjOBNR6i3GfG'
)
ON CONFLICT (email) DO UPDATE SET
    full_name = EXCLUDED.full_name,
    address = EXCLUDED.address,
    password_hash = EXCLUDED.password_hash;
UPDATE customers
SET profile_picture = NULL
WHERE profile_picture IS NOT NULL
  AND profile_picture LIKE 'data:%';

UPDATE staff_users
SET profile_picture = NULL
WHERE profile_picture IS NOT NULL
  AND profile_picture LIKE 'data:%';

ALTER TABLE customers
    RENAME COLUMN profile_picture TO profile_picture_s3_key;

ALTER TABLE staff_users
    RENAME COLUMN profile_picture TO profile_picture_s3_key;

ALTER TABLE customers
    ALTER COLUMN profile_picture_s3_key TYPE VARCHAR(600);

ALTER TABLE staff_users
    ALTER COLUMN profile_picture_s3_key TYPE VARCHAR(600);
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

CREATE TABLE categories (
    id          UUID          PRIMARY KEY DEFAULT gen_random_uuid(),
    name        VARCHAR(80)   NOT NULL,
    description VARCHAR(500)  NOT NULL,
    status      VARCHAR(20)   NOT NULL,
    created_at  TIMESTAMP     NOT NULL DEFAULT now(),
    CONSTRAINT ck_categories_status CHECK (status IN ('ACTIVE', 'INACTIVE'))
);

CREATE TABLE policies (
    id              UUID          PRIMARY KEY DEFAULT gen_random_uuid(),
    name            VARCHAR(120)  NOT NULL,
    category_id     UUID          NOT NULL,
    coverage_amount NUMERIC(14,2) NOT NULL,
    premium_amount  NUMERIC(10,2) NOT NULL,
    duration_label  VARCHAR(40)   NOT NULL,
    status          VARCHAR(20)   NOT NULL,
    created_at      TIMESTAMP     NOT NULL DEFAULT now(),
    CONSTRAINT ck_policies_coverage_positive CHECK (coverage_amount > 0),
    CONSTRAINT ck_policies_premium_positive  CHECK (premium_amount > 0),
    CONSTRAINT ck_policies_status CHECK (status IN ('DRAFT', 'ACTIVE', 'INACTIVE')),
    CONSTRAINT fk_policies_category FOREIGN KEY (category_id) REFERENCES categories (id) ON DELETE RESTRICT
);

CREATE INDEX idx_policies_category_id ON policies (category_id);
CREATE INDEX idx_policies_status ON policies (status);

CREATE SEQUENCE application_code_seq START WITH 1000 INCREMENT BY 1;

CREATE TABLE policy_applications (
    id                   UUID          PRIMARY KEY DEFAULT gen_random_uuid(),
    application_code     VARCHAR(20)   NOT NULL,
    customer_id          UUID          NOT NULL,
    policy_id            UUID          NOT NULL,
    coverage_type        VARCHAR(20)   NOT NULL,
    coverage_amount      NUMERIC(14,2) NOT NULL,
    premium_amount       NUMERIC(10,2) NOT NULL,
    date_of_birth        DATE          NOT NULL,
    address              VARCHAR(500)  NOT NULL,
    preferred_start_date DATE,
    nominee_name         VARCHAR(120),
    nominee_relationship VARCHAR(20),
    start_date           DATE,
    end_date             DATE,
    status               VARCHAR(20)   NOT NULL,
    decided_by           UUID,
    decided_at           TIMESTAMP,
    created_at           TIMESTAMP     NOT NULL DEFAULT now(),
    CONSTRAINT uq_application_code UNIQUE (application_code),
    CONSTRAINT ck_applications_coverage_type CHECK (coverage_type IN ('SINGLE', 'GROUP')),
    CONSTRAINT ck_applications_status CHECK (status IN ('PENDING', 'ACTIVE', 'REJECTED', 'EXPIRED')),
    CONSTRAINT ck_applications_nominee_rel CHECK (nominee_relationship IS NULL OR nominee_relationship IN ('SPOUSE', 'PARENT', 'CHILD', 'SIBLING', 'OTHER')),
    CONSTRAINT fk_applications_policy FOREIGN KEY (policy_id) REFERENCES policies (id) ON DELETE RESTRICT
);

CREATE UNIQUE INDEX uq_pending_application ON policy_applications (customer_id, policy_id) WHERE status = 'PENDING';
CREATE INDEX idx_applications_customer ON policy_applications (customer_id);
CREATE INDEX idx_applications_status ON policy_applications (status);
CREATE INDEX idx_applications_policy ON policy_applications (policy_id);

CREATE TABLE dependents (
    id                     UUID         PRIMARY KEY DEFAULT gen_random_uuid(),
    policy_application_id  UUID         NOT NULL,
    full_name              VARCHAR(120) NOT NULL,
    relationship           VARCHAR(20)  NOT NULL,
    date_of_birth          DATE         NOT NULL,
    gender                 VARCHAR(10)  NOT NULL,
    created_at             TIMESTAMP    NOT NULL DEFAULT now(),
    CONSTRAINT ck_dependents_relationship CHECK (relationship IN ('SPOUSE', 'CHILD', 'PARENT', 'SIBLING')),
    CONSTRAINT ck_dependents_gender CHECK (gender IN ('MALE', 'FEMALE', 'OTHER')),
    CONSTRAINT fk_dependents_application FOREIGN KEY (policy_application_id) REFERENCES policy_applications (id) ON DELETE CASCADE
);

CREATE INDEX idx_dependents_application ON dependents (policy_application_id);

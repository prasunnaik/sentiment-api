CREATE EXTENSION IF NOT EXISTS "pgcrypto";

CREATE TABLE payments (
    id                     UUID          PRIMARY KEY DEFAULT gen_random_uuid(),
    idempotency_key        VARCHAR(80)   NOT NULL,
    customer_id            UUID          NOT NULL,
    policy_application_id  UUID          NOT NULL,
    policy_name_snapshot   VARCHAR(120)  NOT NULL,
    amount                 NUMERIC(10,2) NOT NULL,
    method                 VARCHAR(20)   NOT NULL,
    status                 VARCHAR(20)   NOT NULL,
    transaction_ref        VARCHAR(40)   NOT NULL,
    paid_at                TIMESTAMP     NOT NULL,
    created_at             TIMESTAMP     NOT NULL DEFAULT now(),
    CONSTRAINT uq_payments_idempotency_key UNIQUE (idempotency_key),
    CONSTRAINT uq_payments_transaction_ref UNIQUE (transaction_ref),
    CONSTRAINT ck_payments_amount_positive CHECK (amount > 0),
    CONSTRAINT ck_payments_method CHECK (method IN ('CREDIT_CARD','DEBIT_CARD','UPI','NET_BANKING')),
    CONSTRAINT ck_payments_status CHECK (status IN ('SUCCESS','FAILED','PENDING'))
);

CREATE INDEX idx_payments_customer ON payments (customer_id);
CREATE INDEX idx_payments_status ON payments (status);
CREATE INDEX idx_payments_policy_app ON payments (policy_application_id);

CREATE TABLE claim_dependents (
    id              UUID           PRIMARY KEY DEFAULT gen_random_uuid(),
    claim_id        UUID           NOT NULL,
    full_name       VARCHAR(120)   NOT NULL,
    relationship    VARCHAR(20)    NOT NULL,
    date_of_birth   DATE           NOT NULL,
    gender          VARCHAR(10)    NOT NULL,
    CONSTRAINT ck_claim_dependents_relationship CHECK (relationship IN ('SPOUSE', 'CHILD', 'PARENT', 'SIBLING')),
    CONSTRAINT ck_claim_dependents_gender CHECK (gender IN ('MALE', 'FEMALE', 'OTHER')),
    CONSTRAINT fk_claim_dependents_claim FOREIGN KEY (claim_id) REFERENCES claims (id) ON DELETE CASCADE
);

CREATE INDEX idx_claim_dependents_claim ON claim_dependents (claim_id);

package com.insurewise.payments.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Table(name = "payment_documents")
public class PaymentDocument {
    @Id
    @GeneratedValue
    private UUID id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "payment_id", nullable = false)
    private Payment payment;

    @Column(name = "file_name", nullable = false, length = 255)
    private String fileName;

    @Column(name = "content_type", length = 100)
    private String contentType;

    @Column(name = "s3_key", nullable = false, length = 600)
    private String s3Key;

    @Column(name = "uploaded_by", nullable = false)
    private UUID uploadedBy;

    @Column(name = "system_generated", nullable = false)
    private boolean systemGenerated;

    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;

    protected PaymentDocument() {
    }

    public PaymentDocument(
            Payment payment,
            String fileName,
            String contentType,
            String s3Key,
            UUID uploadedBy,
            boolean systemGenerated) {
        this.payment = payment;
        this.fileName = fileName;
        this.contentType = contentType;
        this.s3Key = s3Key;
        this.uploadedBy = uploadedBy;
        this.systemGenerated = systemGenerated;
    }

    @PrePersist
    void initialize() {
        if (createdAt == null) {
            createdAt = LocalDateTime.now();
        }
    }

    public UUID getId() {
        return id;
    }

    public Payment getPayment() {
        return payment;
    }

    public String getFileName() {
        return fileName;
    }

    public String getContentType() {
        return contentType;
    }

    public String getS3Key() {
        return s3Key;
    }

    public UUID getUploadedBy() {
        return uploadedBy;
    }

    public boolean isSystemGenerated() {
        return systemGenerated;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }
}
package com.insurewise.common.dto;

import java.time.Instant;

public record PresignedUrlResponse(
        String url,
        Instant expiresAt
) {
}
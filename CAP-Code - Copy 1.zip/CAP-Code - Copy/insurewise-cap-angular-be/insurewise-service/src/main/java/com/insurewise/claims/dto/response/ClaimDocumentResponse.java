package com.insurewise.claims.dto.response;

import com.insurewise.common.dto.PresignedUrlResponse;
import java.time.LocalDateTime;
import java.util.UUID;

public record ClaimDocumentResponse(
        UUID id,
        UUID claimId,
        String fileName,
        String contentType,
        PresignedUrlResponse download,
        UUID uploadedBy,
        LocalDateTime createdAt
) {
}
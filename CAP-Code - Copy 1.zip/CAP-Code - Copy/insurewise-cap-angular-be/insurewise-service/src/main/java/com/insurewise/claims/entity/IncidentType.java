package com.insurewise.claims.entity;

public enum IncidentType {
    ACCIDENT,
    HOSPITALIZATION,
    THEFT,
    NATURAL_DISASTER,
    FIRE,
    DEATH,
    DISABILITY,
    PROPERTY_DAMAGE,
    OTHER
}
package com.insurewise.claims.dto.response;

import com.insurewise.claims.entity.ClaimStatus;
import com.insurewise.claims.entity.IncidentType;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.UUID;

public record ClaimResponse(
        UUID id,
        String claimCode,
        UUID customerId,
        UUID policyApplicationId,
        String policyName,
        IncidentType incidentType,
        LocalDate incidentDate,
        BigDecimal amount,
        String description,
        String documentRef,
        ClaimStatus status,
        UUID processedBy,
        LocalDateTime processedAt,
        LocalDateTime createdAt
) {
}
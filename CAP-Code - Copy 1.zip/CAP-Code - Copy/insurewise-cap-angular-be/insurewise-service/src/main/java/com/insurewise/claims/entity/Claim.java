package com.insurewise.claims.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Table(
        name = "claims",
        uniqueConstraints = {
                @UniqueConstraint(
                        name = "uq_claims_idempotency_key",
                        columnNames = "idempotency_key"),
                @UniqueConstraint(
                        name = "uq_claims_claim_code",
                        columnNames = "claim_code")
        })
public class Claim {
    @Id
    @GeneratedValue
    private UUID id;

    @Column(name = "claim_code", nullable = false, length = 20)
    private String claimCode;

    @Column(name = "idempotency_key", nullable = false, length = 80)
    private String idempotencyKey;

    @Column(name = "customer_id", nullable = false)
    private UUID customerId;

    @Column(name = "policy_application_id", nullable = false)
    private UUID policyApplicationId;

    @Column(name = "policy_name_snapshot", nullable = false, length = 120)
    private String policyNameSnapshot;

    @Enumerated(EnumType.STRING)
    @Column(name = "incident_type", nullable = false, length = 40)
    private IncidentType incidentType;

    @Column(name = "incident_date", nullable = false)
    private LocalDate incidentDate;

    @Column(nullable = false, precision = 14, scale = 2)
    private BigDecimal amount;

    @Column(nullable = false, length = 1000)
    private String description;

    @Column(name = "document_ref", length = 300)
    private String documentRef;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private ClaimStatus status;

    @Column(name = "processed_by")
    private UUID processedBy;

    @Column(name = "processed_at")
    private LocalDateTime processedAt;

    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;

    protected Claim() {
    }

    public Claim(
            String claimCode,
            String idempotencyKey,
            UUID customerId,
            UUID policyApplicationId,
            String policyNameSnapshot,
            IncidentType incidentType,
            LocalDate incidentDate,
            BigDecimal amount,
            String description,
            String documentRef) {
        this.claimCode = claimCode;
        this.idempotencyKey = idempotencyKey;
        this.customerId = customerId;
        this.policyApplicationId = policyApplicationId;
        this.policyNameSnapshot = policyNameSnapshot;
        this.incidentType = incidentType;
        this.incidentDate = incidentDate;
        this.amount = amount;
        this.description = description;
        this.documentRef = documentRef;
        this.status = ClaimStatus.PENDING;
    }

    @PrePersist
    void initialize() {
        if (createdAt == null) {
            createdAt = LocalDateTime.now();
        }
    }

    public void markUnderReview(UUID staffUserId) {
        requirePending();
        status = ClaimStatus.UNDER_REVIEW;
        processedBy = staffUserId;
        processedAt = LocalDateTime.now();
    }

    public void approve(UUID staffUserId) {
        if (status != ClaimStatus.PENDING
                && status != ClaimStatus.UNDER_REVIEW) {
            throw new IllegalStateException(
                    "Only pending or under-review claims can be approved");
        }

        status = ClaimStatus.APPROVED;
        processedBy = staffUserId;
        processedAt = LocalDateTime.now();
    }

    public void reject(UUID staffUserId) {
        if (status != ClaimStatus.PENDING
                && status != ClaimStatus.UNDER_REVIEW) {
            throw new IllegalStateException(
                    "Only pending or under-review claims can be rejected");
        }

        status = ClaimStatus.REJECTED;
        processedBy = staffUserId;
        processedAt = LocalDateTime.now();
    }

    private void requirePending() {
        if (status != ClaimStatus.PENDING) {
            throw new IllegalStateException(
                    "Only pending claims can enter review");
        }
    }

    public boolean isOwnedBy(UUID customerId) {
        return this.customerId.equals(customerId);
    }

    public UUID getId() {
        return id;
    }

    public String getClaimCode() {
        return claimCode;
    }

    public String getIdempotencyKey() {
        return idempotencyKey;
    }

    public UUID getCustomerId() {
        return customerId;
    }

    public UUID getPolicyApplicationId() {
        return policyApplicationId;
    }

    public String getPolicyNameSnapshot() {
        return policyNameSnapshot;
    }

    public IncidentType getIncidentType() {
        return incidentType;
    }

    public LocalDate getIncidentDate() {
        return incidentDate;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public String getDescription() {
        return description;
    }

    public String getDocumentRef() {
        return documentRef;
    }

    public ClaimStatus getStatus() {
        return status;
    }

    public UUID getProcessedBy() {
        return processedBy;
    }

    public LocalDateTime getProcessedAt() {
        return processedAt;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }
}
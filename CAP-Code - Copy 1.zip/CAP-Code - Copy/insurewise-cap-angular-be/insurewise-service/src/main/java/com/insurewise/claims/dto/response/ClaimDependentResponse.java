package com.insurewise.claims.dto.response;

import com.insurewise.policy.entity.Gender;
import com.insurewise.policy.entity.Relationship;
import java.time.LocalDate;
import java.util.UUID;

public record ClaimDependentResponse(
        UUID id,
        UUID claimId,
        String fullName,
        Relationship relationship,
        LocalDate dateOfBirth,
        Gender gender
) {
}
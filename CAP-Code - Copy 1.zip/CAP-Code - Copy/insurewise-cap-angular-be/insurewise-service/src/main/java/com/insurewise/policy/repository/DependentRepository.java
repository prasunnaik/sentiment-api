package com.insurewise.policy.repository;

import com.insurewise.policy.entity.Dependent;
import java.util.List;
import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DependentRepository
        extends JpaRepository<Dependent, UUID> {

    List<Dependent> findByPolicyApplicationIdOrderByCreatedAtAsc(
            UUID policyApplicationId);
}
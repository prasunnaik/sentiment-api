package com.insurewise.claims.entity;

public enum ClaimStatus {
    PENDING,
    UNDER_REVIEW,
    APPROVED,
    REJECTED
}
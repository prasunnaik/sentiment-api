package com.insurewise.payments.service;

import com.insurewise.common.dto.PresignedUrlResponse;
import com.insurewise.common.security.JwtPrincipal;
import com.insurewise.common.security.JwtRole;
import com.insurewise.common.service.S3StorageService;
import com.insurewise.payments.dto.response.PaymentDocumentResponse;
import com.insurewise.payments.entity.Payment;
import com.insurewise.payments.entity.PaymentDocument;
import com.insurewise.payments.entity.PaymentStatus;
import com.insurewise.payments.repository.PaymentDocumentRepository;
import com.insurewise.payments.repository.PaymentRepository;
import java.nio.charset.StandardCharsets;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.UUID;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

@Service
@Transactional
public class PaymentDocumentService {
    private static final DateTimeFormatter RECEIPT_DATE_FORMAT =
            DateTimeFormatter.ISO_LOCAL_DATE_TIME;

    private final PaymentRepository paymentRepository;
    private final PaymentDocumentRepository documentRepository;
    private final S3StorageService storageService;

    public PaymentDocumentService(
            PaymentRepository paymentRepository,
            PaymentDocumentRepository documentRepository,
            S3StorageService storageService) {
        this.paymentRepository = paymentRepository;
        this.documentRepository = documentRepository;
        this.storageService = storageService;
    }

    public PaymentDocumentResponse uploadDocument(
            JwtPrincipal principal,
            UUID paymentId,
            MultipartFile file) {

        Payment payment = requirePaymentAccess(
                principal,
                paymentId);

        if (file == null || file.isEmpty()) {
            throw new IllegalArgumentException(
                    "A non-empty file is required");
        }

        String fileName = file.getOriginalFilename() == null
                ? "payment-document"
                : file.getOriginalFilename();

        String s3Key = storageService.upload(
                file,
                "payment-documents",
                principal.userId());

        PaymentDocument document = documentRepository.save(
                new PaymentDocument(
                        payment,
                        fileName,
                        file.getContentType(),
                        s3Key,
                        principal.userId(),
                        false));

        return toResponse(document);
    }

    @Transactional(readOnly = true)
    public List<PaymentDocumentResponse> listDocuments(
            JwtPrincipal principal,
            UUID paymentId) {

        requirePaymentAccess(principal, paymentId);

        return documentRepository
                .findByPaymentIdOrderByCreatedAtDesc(paymentId)
                .stream()
                .map(this::toResponse)
                .toList();
    }

    public void deleteDocument(
            JwtPrincipal principal,
            UUID paymentId,
            UUID documentId) {

        requirePaymentAccess(principal, paymentId);

        PaymentDocument document =
                documentRepository.findById(documentId)
                        .filter(item -> item.getPayment().getId()
                                .equals(paymentId))
                        .orElseThrow(() -> new IllegalArgumentException(
                                "Payment document not found"));

        if (document.isSystemGenerated()) {
            throw new IllegalStateException(
                    "System-generated receipts cannot be deleted");
        }

        storageService.delete(document.getS3Key());
        documentRepository.delete(document);
    }

    public PaymentDocumentResponse createSystemReceipt(
            UUID paymentId) {

        Payment payment = paymentRepository.findById(paymentId)
                .orElseThrow(() -> new IllegalArgumentException(
                        "Payment not found: " + paymentId));

        if (payment.getStatus() != PaymentStatus.SUCCESS) {
            throw new IllegalStateException(
                    "Receipt requires a successful payment");
        }

        if (documentRepository.existsByPaymentIdAndSystemGenerated(
                paymentId,
                true)) {
            return documentRepository
                    .findByPaymentIdOrderByCreatedAtDesc(paymentId)
                    .stream()
                    .filter(PaymentDocument::isSystemGenerated)
                    .findFirst()
                    .map(this::toResponse)
                    .orElseThrow();
        }

        String receipt = """
                InsureWise Payment Receipt
                --------------------------
                Transaction: %s
                Payment ID: %s
                Customer ID: %s
                Policy: %s
                Amount: %s
                Method: %s
                Status: %s
                Paid At: %s
                """.formatted(
                payment.getTransactionRef(),
                payment.getId(),
                payment.getCustomerId(),
                payment.getPolicyNameSnapshot(),
                payment.getAmount(),
                payment.getMethod(),
                payment.getStatus(),
                payment.getPaidAt()
                        .format(RECEIPT_DATE_FORMAT));

        String fileName = "receipt-"
                + payment.getTransactionRef()
                + ".txt";

        String s3Key = storageService.uploadGenerated(
                receipt.getBytes(StandardCharsets.UTF_8),
                fileName,
                "text/plain",
                "payment-receipts",
                payment.getCustomerId());

        PaymentDocument document = documentRepository.save(
                new PaymentDocument(
                        payment,
                        fileName,
                        "text/plain",
                        s3Key,
                        payment.getCustomerId(),
                        true));

        return toResponse(document);
    }

    private Payment requirePaymentAccess(
            JwtPrincipal principal,
            UUID paymentId) {

        Payment payment = paymentRepository.findById(paymentId)
                .orElseThrow(() -> new IllegalArgumentException(
                        "Payment not found: " + paymentId));

        if (principal.role() == JwtRole.CUSTOMER
                && !payment.isOwnedBy(principal.userId())) {
            throw new IllegalArgumentException(
                    "Payment not found");
        }

        return payment;
    }

    private PaymentDocumentResponse toResponse(
            PaymentDocument document) {

        PresignedUrlResponse download =
                storageService.getPresignedDownloadUrl(
                        document.getS3Key());

        return new PaymentDocumentResponse(
                document.getId(),
                document.getPayment().getId(),
                document.getFileName(),
                document.getContentType(),
                download,
                document.getUploadedBy(),
                document.isSystemGenerated(),
                document.getCreatedAt());
    }
}
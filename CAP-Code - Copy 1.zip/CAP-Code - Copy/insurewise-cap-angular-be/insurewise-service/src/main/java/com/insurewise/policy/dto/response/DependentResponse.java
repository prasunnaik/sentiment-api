package com.insurewise.policy.dto.response;

import com.insurewise.policy.entity.Gender;
import com.insurewise.policy.entity.Relationship;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.UUID;

public record DependentResponse(
        UUID id,
        UUID applicationId,
        String fullName,
        Relationship relationship,
        LocalDate dateOfBirth,
        Gender gender,
        LocalDateTime createdAt
) {
}
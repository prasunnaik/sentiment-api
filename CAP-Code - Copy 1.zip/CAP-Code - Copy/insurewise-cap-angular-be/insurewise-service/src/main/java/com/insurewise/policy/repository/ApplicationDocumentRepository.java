package com.insurewise.policy.repository;

import com.insurewise.policy.entity.ApplicationDocument;
import java.util.List;
import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ApplicationDocumentRepository
        extends JpaRepository<ApplicationDocument, UUID> {

    List<ApplicationDocument> findByPolicyApplicationIdOrderByCreatedAtDesc(
            UUID policyApplicationId);
}
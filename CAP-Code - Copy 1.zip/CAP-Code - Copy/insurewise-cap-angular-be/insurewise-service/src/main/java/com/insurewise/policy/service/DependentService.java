package com.insurewise.policy.service;

import com.insurewise.common.security.JwtPrincipal;
import com.insurewise.common.security.JwtRole;
import com.insurewise.policy.dto.request.DependentRequest;
import com.insurewise.policy.dto.response.DependentResponse;
import com.insurewise.policy.entity.Dependent;
import com.insurewise.policy.entity.PolicyApplication;
import com.insurewise.policy.exception.ApplicationNotFoundException;
import com.insurewise.policy.repository.DependentRepository;
import java.util.List;
import java.util.UUID;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class DependentService {
    private final DependentRepository dependentRepository;
    private final PolicyApplicationService applicationService;

    public DependentService(
            DependentRepository dependentRepository,
            PolicyApplicationService applicationService) {
        this.dependentRepository = dependentRepository;
        this.applicationService = applicationService;
    }

    public DependentResponse addDependent(
            JwtPrincipal principal,
            UUID applicationId,
            DependentRequest request) {

        PolicyApplication application =
                requireApplicationAccess(principal, applicationId);

        Dependent dependent = dependentRepository.save(new Dependent(
                application,
                request.fullName(),
                request.relationship(),
                request.dateOfBirth(),
                request.gender()));

        return toResponse(dependent);
    }

    @Transactional(readOnly = true)
    public List<DependentResponse> listDependents(
            JwtPrincipal principal,
            UUID applicationId) {

        requireApplicationAccess(principal, applicationId);

        return dependentRepository
                .findByPolicyApplicationIdOrderByCreatedAtAsc(applicationId)
                .stream()
                .map(this::toResponse)
                .toList();
    }

    public DependentResponse updateDependent(
            JwtPrincipal principal,
            UUID applicationId,
            UUID dependentId,
            DependentRequest request) {

        requireApplicationAccess(principal, applicationId);

        Dependent dependent = requireDependent(applicationId, dependentId);
        dependent.update(
                request.fullName(),
                request.relationship(),
                request.dateOfBirth(),
                request.gender());

        return toResponse(dependent);
    }

    public void deleteDependent(
            JwtPrincipal principal,
            UUID applicationId,
            UUID dependentId) {

        requireApplicationAccess(principal, applicationId);
        dependentRepository.delete(requireDependent(applicationId, dependentId));
    }

    private PolicyApplication requireApplicationAccess(
            JwtPrincipal principal,
            UUID applicationId) {

        PolicyApplication application =
                applicationService.getApplicationEntityForInternalUse(
                        applicationId);

        if (principal.role() == JwtRole.CUSTOMER
                && !application.isOwnedBy(principal.userId())) {
            throw new ApplicationNotFoundException(applicationId);
        }

        return application;
    }

    private Dependent requireDependent(
            UUID applicationId,
            UUID dependentId) {

        return dependentRepository.findById(dependentId)
                .filter(dependent -> dependent
                        .getPolicyApplication()
                        .getId()
                        .equals(applicationId))
                .orElseThrow(() -> new IllegalArgumentException(
                        "Dependent not found: " + dependentId));
    }

    private DependentResponse toResponse(Dependent dependent) {
        return new DependentResponse(
                dependent.getId(),
                dependent.getPolicyApplication().getId(),
                dependent.getFullName(),
                dependent.getRelationship(),
                dependent.getDateOfBirth(),
                dependent.getGender(),
                dependent.getCreatedAt());
    }
}

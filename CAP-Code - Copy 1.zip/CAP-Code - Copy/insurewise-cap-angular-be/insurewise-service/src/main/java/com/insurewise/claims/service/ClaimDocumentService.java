package com.insurewise.claims.service;

import com.insurewise.claims.dto.response.ClaimDocumentResponse;
import com.insurewise.claims.entity.Claim;
import com.insurewise.claims.entity.ClaimDocument;
import com.insurewise.claims.repository.ClaimDocumentRepository;
import com.insurewise.claims.repository.ClaimRepository;
import com.insurewise.common.dto.PresignedUrlResponse;
import com.insurewise.common.service.S3StorageService;
import java.util.List;
import java.util.UUID;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

@Service
@Transactional
public class ClaimDocumentService {
    private final ClaimRepository claimRepository;
    private final ClaimDocumentRepository documentRepository;
    private final S3StorageService storageService;

    public ClaimDocumentService(
            ClaimRepository claimRepository,
            ClaimDocumentRepository documentRepository,
            S3StorageService storageService) {
        this.claimRepository = claimRepository;
        this.documentRepository = documentRepository;
        this.storageService = storageService;
    }

    public ClaimDocumentResponse uploadDocument(
            UUID customerId,
            UUID claimId,
            MultipartFile file) {

        Claim claim = requireOwnedClaim(customerId, claimId);

        if (file == null || file.isEmpty()) {
            throw new IllegalArgumentException(
                    "A non-empty file is required");
        }

        String s3Key = storageService.upload(
                file,
                "claim-documents",
                customerId);

        String fileName = file.getOriginalFilename() == null
                ? "unnamed-file"
                : file.getOriginalFilename();

        ClaimDocument document = documentRepository.save(
                new ClaimDocument(
                        claim,
                        fileName,
                        file.getContentType(),
                        s3Key,
                        customerId));

        return toResponse(document);
    }

    @Transactional(readOnly = true)
    public List<ClaimDocumentResponse> listDocuments(
            UUID customerId,
            UUID claimId) {

        requireOwnedClaim(customerId, claimId);

        return documentRepository.findByClaimId(claimId)
                .stream()
                .map(this::toResponse)
                .toList();
    }

    public void deleteDocument(
            UUID customerId,
            UUID claimId,
            UUID documentId) {

        requireOwnedClaim(customerId, claimId);

        ClaimDocument document =
                documentRepository.findById(documentId)
                        .filter(item -> item.getClaim().getId()
                                .equals(claimId))
                        .orElseThrow(() -> new IllegalArgumentException(
                                "Document not found"));

        storageService.delete(document.getS3Key());
        documentRepository.delete(document);
    }

    private Claim requireOwnedClaim(
            UUID customerId,
            UUID claimId) {

        return claimRepository.findById(claimId)
                .filter(claim -> claim.isOwnedBy(customerId))
                .orElseThrow(() -> new IllegalArgumentException(
                        "Claim not found"));
    }

    private ClaimDocumentResponse toResponse(
            ClaimDocument document) {

        PresignedUrlResponse download =
                storageService.getPresignedDownloadUrl(
                        document.getS3Key());

        return new ClaimDocumentResponse(
                document.getId(),
                document.getClaim().getId(),
                document.getFileName(),
                document.getContentType(),
                download,
                document.getUploadedBy(),
                document.getCreatedAt());
    }
}
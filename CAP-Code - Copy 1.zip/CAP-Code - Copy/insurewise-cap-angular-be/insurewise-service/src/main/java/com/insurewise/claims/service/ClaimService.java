package com.insurewise.claims.service;

import com.insurewise.claims.client.PolicyApplicationLookupClient;
import com.insurewise.claims.client.PolicyApplicationSnapshot;
import com.insurewise.claims.dto.request.ClaimCreateRequest;
import com.insurewise.claims.dto.response.ClaimResponse;
import com.insurewise.claims.entity.Claim;
import com.insurewise.claims.repository.ClaimRepository;
import java.util.UUID;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class ClaimService {
    private final ClaimRepository claimRepository;
    private final PolicyApplicationLookupClient applicationClient;

    public ClaimService(
            ClaimRepository claimRepository,
            PolicyApplicationLookupClient applicationClient) {
        this.claimRepository = claimRepository;
        this.applicationClient = applicationClient;
    }

    public ClaimResponse fileClaim(
            UUID customerId,
            ClaimCreateRequest request) {

        var existing = claimRepository.findByIdempotencyKey(
                request.idempotencyKey());

        if (existing.isPresent()) {
            Claim claim = existing.get();

            if (!claim.isOwnedBy(customerId)) {
                throw new IllegalStateException(
                        "Idempotency key belongs to another customer");
            }

            return toResponse(claim);
        }

        PolicyApplicationSnapshot application =
                applicationClient.getActiveApplicationForCustomer(
                        request.policyApplicationId(),
                        customerId);

        Long sequence = claimRepository.nextClaimCodeSequence();
        String claimCode = "CLM-" + sequence;

        Claim claim = new Claim(
                claimCode,
                request.idempotencyKey(),
                customerId,
                application.applicationId(),
                application.policyName(),
                request.incidentType(),
                request.incidentDate(),
                request.amount(),
                request.description(),
                request.documentRef());

        return toResponse(claimRepository.save(claim));
    }

    public ClaimResponse approveClaim(
            UUID staffUserId,
            UUID claimId) {

        Claim claim = getClaimEntity(claimId);
        claim.approve(staffUserId);
        return toResponse(claim);
    }

    public ClaimResponse rejectClaim(
            UUID staffUserId,
            UUID claimId) {

        Claim claim = getClaimEntity(claimId);
        claim.reject(staffUserId);
        return toResponse(claim);
    }

    @Transactional(readOnly = true)
    public ClaimResponse getClaimForCustomer(
            UUID customerId,
            UUID claimId) {

        Claim claim = getClaimEntity(claimId);

        if (!claim.isOwnedBy(customerId)) {
            throw new IllegalArgumentException("Claim not found");
        }

        return toResponse(claim);
    }

    @Transactional(readOnly = true)
    public ClaimResponse getClaimForStaff(UUID claimId) {
        return toResponse(getClaimEntity(claimId));
    }

    private Claim getClaimEntity(UUID claimId) {
        return claimRepository.findById(claimId)
                .orElseThrow(() -> new IllegalArgumentException(
                        "Claim not found: " + claimId));
    }

    private ClaimResponse toResponse(Claim claim) {
        return new ClaimResponse(
                claim.getId(),
                claim.getClaimCode(),
                claim.getCustomerId(),
                claim.getPolicyApplicationId(),
                claim.getPolicyNameSnapshot(),
                claim.getIncidentType(),
                claim.getIncidentDate(),
                claim.getAmount(),
                claim.getDescription(),
                claim.getDocumentRef(),
                claim.getStatus(),
                claim.getProcessedBy(),
                claim.getProcessedAt(),
                claim.getCreatedAt());
    }
}
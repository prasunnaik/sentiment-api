package com.insurewise.payments.client;

import java.util.UUID;

public record PaymentPolicyApplicationSnapshot(
        UUID applicationId,
        UUID customerId,
        String policyName,
        boolean active
) {
}

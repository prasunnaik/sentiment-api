package com.insurewise.claims.repository;

import com.insurewise.claims.entity.Claim;
import com.insurewise.claims.entity.ClaimStatus;
import java.util.Optional;
import java.util.UUID;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;

public interface ClaimRepository extends JpaRepository<Claim, UUID> {
    Optional<Claim> findByIdempotencyKey(String idempotencyKey);

    Page<Claim> findByCustomerId(UUID customerId, Pageable pageable);

    Page<Claim> findByStatus(ClaimStatus status, Pageable pageable);

    Page<Claim> findByCustomerIdAndStatus(
            UUID customerId,
            ClaimStatus status,
            Pageable pageable);

    long countByStatus(ClaimStatus status);

    @Query(
            value = "select nextval('claim_code_seq')",
            nativeQuery = true)
    Long nextClaimCodeSequence();
}
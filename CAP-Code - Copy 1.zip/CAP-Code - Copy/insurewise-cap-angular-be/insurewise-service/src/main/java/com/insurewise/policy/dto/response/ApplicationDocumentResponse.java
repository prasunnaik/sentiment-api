package com.insurewise.policy.dto.response;

import com.insurewise.common.dto.PresignedUrlResponse;
import java.time.LocalDateTime;
import java.util.UUID;

public record ApplicationDocumentResponse(
        UUID id,
        UUID applicationId,
        String fileName,
        String contentType,
        PresignedUrlResponse download,
        UUID uploadedBy,
        LocalDateTime createdAt
) {
}
package com.insurewise.payments.entity;

public enum PaymentStatus {
    SUCCESS,
    FAILED,
    PENDING
}
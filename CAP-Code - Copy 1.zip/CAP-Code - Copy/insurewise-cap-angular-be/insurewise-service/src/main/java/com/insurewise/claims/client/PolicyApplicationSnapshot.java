package com.insurewise.claims.client;

import com.insurewise.policy.entity.ApplicationStatus;
import java.util.UUID;

public record PolicyApplicationSnapshot(
        UUID applicationId,
        UUID customerId,
        String policyName,
        ApplicationStatus status,
        boolean active
) {
}
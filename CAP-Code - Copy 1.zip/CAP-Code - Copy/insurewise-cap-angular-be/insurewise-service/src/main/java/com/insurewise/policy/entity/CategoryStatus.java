package com.insurewise.policy.entity;

public enum CategoryStatus {
    ACTIVE,
    INACTIVE
}
package com.insurewise.payments.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.UUID;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Entity
@Table(
        name = "payments",
        uniqueConstraints = {
                @UniqueConstraint(name = "uq_payments_idempotency_key",
                        columnNames = "idempotency_key"),
                @UniqueConstraint(name = "uq_payments_transaction_ref",
                        columnNames = "transaction_ref")
        })
@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
public class Payment {
    @Id
    @GeneratedValue
    private UUID id;

    @Column(name = "idempotency_key", nullable = false, length = 80)
    private String idempotencyKey;

    @Column(name = "customer_id", nullable = false)
    private UUID customerId;

    @Column(name = "policy_application_id", nullable = false)
    private UUID policyApplicationId;

    @Column(name = "policy_name_snapshot", nullable = false, length = 120)
    private String policyNameSnapshot;

    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal amount;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private PaymentMethod method;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private PaymentStatus status;

    @Column(name = "transaction_ref", nullable = false, length = 40)
    private String transactionRef;

    @Column(name = "paid_at", nullable = false)
    private LocalDateTime paidAt;

    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;

    public Payment(
            String idempotencyKey,
            UUID customerId,
            UUID policyApplicationId,
            String policyNameSnapshot,
            BigDecimal amount,
            PaymentMethod method) {
        this.idempotencyKey = idempotencyKey;
        this.customerId = customerId;
        this.policyApplicationId = policyApplicationId;
        this.policyNameSnapshot = policyNameSnapshot;
        this.amount = amount;
        this.method = method;
        this.status = PaymentStatus.PENDING;
    }

    @PrePersist
    void initialize() {
        if (createdAt == null) {
            createdAt = LocalDateTime.now();
        }
    }

    public void markSuccess(String transactionRef) {
        if (status != PaymentStatus.PENDING) {
            throw new IllegalStateException("Payment is already processed");
        }
        this.status = PaymentStatus.SUCCESS;
        this.transactionRef = transactionRef;
        this.paidAt = LocalDateTime.now();
    }

    public void markFailed(String transactionRef) {
        if (status != PaymentStatus.PENDING) {
            throw new IllegalStateException("Payment is already processed");
        }
        this.status = PaymentStatus.FAILED;
        this.transactionRef = transactionRef;
        this.paidAt = LocalDateTime.now();
    }

    public boolean isOwnedBy(UUID customerId) {
        return this.customerId.equals(customerId);
    }
}
package com.insurewise.policy.service;

import com.insurewise.common.dto.PresignedUrlResponse;
import com.insurewise.common.security.JwtPrincipal;
import com.insurewise.common.security.JwtRole;
import com.insurewise.common.service.S3StorageService;
import com.insurewise.policy.dto.response.ApplicationDocumentResponse;
import com.insurewise.policy.entity.ApplicationDocument;
import com.insurewise.policy.entity.PolicyApplication;
import com.insurewise.policy.exception.ApplicationNotFoundException;
import com.insurewise.policy.repository.ApplicationDocumentRepository;
import java.util.List;
import java.util.UUID;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

@Service
@Transactional
public class ApplicationDocumentService {
    private final ApplicationDocumentRepository documentRepository;
    private final PolicyApplicationService applicationService;
    private final S3StorageService storageService;

    public ApplicationDocumentService(
            ApplicationDocumentRepository documentRepository,
            PolicyApplicationService applicationService,
            S3StorageService storageService) {
        this.documentRepository = documentRepository;
        this.applicationService = applicationService;
        this.storageService = storageService;
    }

    public ApplicationDocumentResponse uploadDocument(
            JwtPrincipal principal,
            UUID applicationId,
            MultipartFile file) {

        PolicyApplication application =
                requireApplicationAccess(principal, applicationId);

        if (file == null || file.isEmpty()) {
            throw new IllegalArgumentException("A non-empty file is required");
        }

        String s3Key = storageService.upload(
                file,
                "application-documents",
                principal.userId());

        ApplicationDocument document = documentRepository.save(
                new ApplicationDocument(
                        application,
                        file.getOriginalFilename() == null
                                ? "unnamed-file"
                                : file.getOriginalFilename(),
                        file.getContentType(),
                        s3Key,
                        principal.userId()));

        return toResponse(document);
    }

    @Transactional(readOnly = true)
    public List<ApplicationDocumentResponse> listDocuments(
            JwtPrincipal principal,
            UUID applicationId) {

        requireApplicationAccess(principal, applicationId);

        return documentRepository
                .findByPolicyApplicationIdOrderByCreatedAtDesc(applicationId)
                .stream()
                .map(this::toResponse)
                .toList();
    }

    public void deleteDocument(
            JwtPrincipal principal,
            UUID applicationId,
            UUID documentId) {

        requireApplicationAccess(principal, applicationId);

        ApplicationDocument document =
                documentRepository.findById(documentId)
                        .filter(item -> item
                                .getPolicyApplication()
                                .getId()
                                .equals(applicationId))
                        .orElseThrow(() -> new IllegalArgumentException(
                                "Document not found: " + documentId));

        storageService.delete(document.getS3Key());
        documentRepository.delete(document);
    }

    private PolicyApplication requireApplicationAccess(
            JwtPrincipal principal,
            UUID applicationId) {

        PolicyApplication application =
                applicationService.getApplicationEntityForInternalUse(
                        applicationId);

        if (principal.role() == JwtRole.CUSTOMER
                && !application.isOwnedBy(principal.userId())) {
            throw new ApplicationNotFoundException(applicationId);
        }

        return application;
    }

    private ApplicationDocumentResponse toResponse(
            ApplicationDocument document) {

        PresignedUrlResponse download =
                storageService.getPresignedDownloadUrl(
                        document.getS3Key());

        return new ApplicationDocumentResponse(
                document.getId(),
                document.getPolicyApplication().getId(),
                document.getFileName(),
                document.getContentType(),
                download,
                document.getUploadedBy(),
                document.getCreatedAt());
    }
}
package com.insurewise.claims.service;

import com.insurewise.claims.dto.request.ClaimDependentRequest;
import com.insurewise.claims.dto.response.ClaimDependentResponse;
import com.insurewise.claims.entity.Claim;
import com.insurewise.claims.entity.ClaimDependent;
import com.insurewise.claims.repository.ClaimDependentRepository;
import com.insurewise.claims.repository.ClaimRepository;
import java.util.List;
import java.util.UUID;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class ClaimDependentService {
    private final ClaimRepository claimRepository;
    private final ClaimDependentRepository dependentRepository;

    public ClaimDependentService(
            ClaimRepository claimRepository,
            ClaimDependentRepository dependentRepository) {
        this.claimRepository = claimRepository;
        this.dependentRepository = dependentRepository;
    }

    public ClaimDependentResponse addDependent(
            UUID customerId,
            UUID claimId,
            ClaimDependentRequest request) {

        Claim claim = requireOwnedClaim(customerId, claimId);

        ClaimDependent dependent = dependentRepository.save(
                new ClaimDependent(
                        claim,
                        request.fullName(),
                        request.relationship(),
                        request.dateOfBirth(),
                        request.gender()));

        return toResponse(dependent);
    }

    @Transactional(readOnly = true)
    public List<ClaimDependentResponse> listDependents(
            UUID customerId,
            UUID claimId) {

        requireOwnedClaim(customerId, claimId);

        return dependentRepository.findByClaimId(claimId)
                .stream()
                .map(this::toResponse)
                .toList();
    }

    private Claim requireOwnedClaim(UUID customerId, UUID claimId) {
        return claimRepository.findById(claimId)
                .filter(claim -> claim.isOwnedBy(customerId))
                .orElseThrow(() -> new IllegalArgumentException(
                        "Claim not found"));
    }

    private ClaimDependentResponse toResponse(
            ClaimDependent dependent) {
        return new ClaimDependentResponse(
                dependent.getId(),
                dependent.getClaim().getId(),
                dependent.getFullName(),
                dependent.getRelationship(),
                dependent.getDateOfBirth(),
                dependent.getGender());
    }
}
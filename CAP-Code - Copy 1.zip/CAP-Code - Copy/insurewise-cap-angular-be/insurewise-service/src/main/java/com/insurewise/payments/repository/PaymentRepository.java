package com.insurewise.payments.repository;

import com.insurewise.payments.entity.*;
import java.math.BigDecimal;
import java.util.*;
import org.springframework.data.domain.*;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;

public interface PaymentRepository
        extends JpaRepository<Payment, UUID> {

    Optional<Payment> findByIdempotencyKey(String idempotencyKey);

    Page<Payment> findByCustomerId(UUID customerId, Pageable pageable);

    Page<Payment> findByStatus(
            PaymentStatus status,
            Pageable pageable);

    Page<Payment> findByCustomerIdAndStatus(
            UUID customerId,
            PaymentStatus status,
            Pageable pageable);

    long countByStatus(PaymentStatus status);

    @Query("""
        select coalesce(sum(p.amount), 0)
        from Payment p
        where p.status = com.insurewise.payments.entity.PaymentStatus.SUCCESS
        """)
    BigDecimal sumSuccessfulPayments();
}
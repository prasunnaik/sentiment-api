package com.insurewise.policy.entity;

public enum Relationship {
    SPOUSE,
    CHILD,
    PARENT,
    SIBLING
}
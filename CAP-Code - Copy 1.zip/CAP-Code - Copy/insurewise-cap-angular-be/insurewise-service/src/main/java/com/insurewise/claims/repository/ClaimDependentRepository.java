package com.insurewise.claims.repository;

import com.insurewise.claims.entity.ClaimDependent;
import java.util.List;
import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ClaimDependentRepository
        extends JpaRepository<ClaimDependent, UUID> {

    List<ClaimDependent> findByClaimId(UUID claimId);
}
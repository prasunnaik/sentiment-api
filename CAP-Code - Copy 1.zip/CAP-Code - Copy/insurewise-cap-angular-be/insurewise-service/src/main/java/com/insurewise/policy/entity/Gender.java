package com.insurewise.policy.entity;

public enum Gender {
    MALE,
    FEMALE,
    OTHER
}
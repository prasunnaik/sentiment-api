# Insurewise Scaffold

Empty project scaffolding for the Insurewise backend. It has the same Maven module layout,
package structure, and build order as the real application, but **no business logic** —
only `pom.xml` files, a bare Spring Boot entry point, and empty package folders for
controllers, services, entities, etc. Use it to start a new implementation from scratch
without copying the real app's code.

## Folder structure

```
insurewise-scaffold/
├── run.ps1                      # builds s3-framework, builds insurewise-service, runs it
├── s3-framework/                # shared S3 upload/download library (own Maven reactor)
│   ├── pom.xml                  # aggregator (packaging=pom)
│   ├── s3-file-storage/
│   │   ├── pom.xml
│   │   └── src/main/
│   │       ├── java/com/insurewise/framework/s3/
│   │       │   ├── annotation/   # e.g. @EnableS3Upload, @S3FileField
│   │       │   ├── aspect/       # AOP interceptors driving annotation-based upload/delete
│   │       │   ├── config/       # S3Properties, auto-configuration
│   │       │   ├── controller/   # generic download/presigned-URL endpoints
│   │       │   ├── exception/    # framework-specific exceptions
│   │       │   └── service/      # S3FileService interface + implementation
│   │       └── resources/META-INF/spring/
│   │           └── org.springframework.boot.autoconfigure.AutoConfiguration.imports
│   └── s3-spring-boot-starter/
│       └── pom.xml               # thin starter that depends on s3-file-storage
└── insurewise-service/            # the Spring Boot application
    ├── pom.xml
    ├── .env.example                # template - copy to .env and fill in real values
    └── src/main/
        ├── java/com/insurewise/
        │   ├── InsurewiseApplication.java   # @SpringBootApplication entry point
        │   ├── auth/       {config, controller, dto/request, dto/response, entity, exception, repository, service}
        │   ├── claims/     {client, config, controller, dto/request, dto/response, entity, exception, repository, service}
        │   ├── common/     {config, controller, security}
        │   ├── payments/   {client, config, controller, dto/request, dto/response, entity, exception, repository, service}
        │   └── policy/     {config, controller, dto/request, dto/response, entity, exception, repository, service}
        └── resources/
            ├── application.yml   # env-var driven config, no secrets
            └── db/migration/     # empty - add Flyway V1__*.sql scripts here
```

Each domain package (`auth`, `claims`, `payments`, `policy`) follows the same convention:

| Folder         | Purpose                                                      |
|----------------|---------------------------------------------------------------|
| `controller/`  | `@RestController` classes, one per resource, mapped under `/api/...` |
| `dto/request/` | Request payload classes (`@Valid` annotated where needed)     |
| `dto/response/`| Response payload classes returned by controllers               |
| `entity/`      | `@Entity` JPA classes                                          |
| `repository/`  | `JpaRepository` interfaces                                     |
| `service/`     | Business logic, transactional boundaries                       |
| `exception/`   | Domain-specific exceptions + a `@RestControllerAdvice` handler  |
| `config/`      | Domain-scoped `@Configuration` classes (if needed)              |
| `client/`      | Feign/REST clients for cross-domain calls (claims, payments only) |

`common/` holds cross-cutting pieces: shared `@Configuration`, a `DashboardController`-style
aggregate endpoint, and `security/` for JWT filters and Spring Security wiring.

## Prerequisites

- JDK 17 (script auto-detects Eclipse Adoptium / Amazon Corretto / Oracle installs)
- Maven (`mvn` on PATH)
- A running PostgreSQL instance and a database for this app

## Running it

1. Copy the env template and fill in your local database (and, optionally, S3 credentials):

   ```powershell
   cd insurewise-service
   Copy-Item .env.example .env
   notepad .env
   ```

2. From `insurewise-scaffold/`, run:

   ```powershell
   .\run.ps1
   ```

   This builds and installs `s3-framework` to the local Maven repo, builds
   `insurewise-service` against it, loads `.env` into the process, and starts the jar.

   Use `.\run.ps1 -SkipBuild` to skip the Maven steps and just relaunch the last built jar.

3. Verify it's up:

   ```powershell
   Invoke-RestMethod http://localhost:8080/actuator/health
   ```

   With no entities/migrations yet, this returns `{"status":"UP"}` — Flyway just creates an
   empty `flyway_schema_history` table and Hibernate has nothing to validate.

## Developing a feature end-to-end

1. **Migration**: add `src/main/resources/db/migration/V1__<description>.sql` (Flyway
   naming: `V<version>__<description>.sql`) to create your tables.
2. **Entity**: add a `@Entity` class under `<domain>/entity/` matching the table.
3. **Repository**: add a `JpaRepository<Entity, IdType>` under `<domain>/repository/`.
4. **DTOs**: add request/response classes under `<domain>/dto/request` and `dto/response`.
5. **Service**: implement business logic under `<domain>/service/`, injecting the repository.
6. **Controller**: expose endpoints under `<domain>/controller/`, mapped at `/api/<resource>`.
7. **Exceptions**: add domain exceptions + a `@RestControllerAdvice` in `<domain>/exception/`
   if you need custom error responses.
8. Rebuild and rerun with `.\run.ps1`.

## Using the S3 framework

`s3-framework` is a separate Maven reactor (own `pom.xml`), matching how the real app
consumes it — `insurewise-service`'s `pom.xml` depends on
`com.insurewise.framework:s3-file-storage:1.0.0-SNAPSHOT`, resolved from the local `.m2`
repo after `run.ps1` installs it.

To implement it:

- Add `@interface EnableS3Upload` / `@EnableS3Delete` under `s3-file-storage/.../annotation/`.
- Add `@S3FileField` for marking DTO fields that carry file payloads.
- Implement `S3UploadAspect` / `S3DeleteAspect` under `.../aspect/` to intercept annotated
  controller methods.
- Implement `S3FileService` under `.../service/` (upload/download/delete against AWS S3
  using `aws-java-sdk-s3`, already on the classpath).
- Register your auto-configuration class in
  `src/main/resources/META-INF/spring/org.springframework.boot.autoconfigure.AutoConfiguration.imports`.
- Consume it in `insurewise-service` the same way: annotate controller methods with
  `@EnableS3Upload`/`@EnableS3Delete`, and `@S3FileField` on the relevant DTO string field.

Enable/disable S3 at runtime via `.env`:

```
S3_ENABLED=true
S3_BUCKET_NAME=<bucket>
AWS_REGION=<region>
AWS_ACCESS_KEY_ID=<key>
AWS_SECRET_ACCESS_KEY=<secret>
```

## Notes

- `insurewise-service` and `s3-framework` are **separate Maven reactors** — always build
  `s3-framework` first (`run.ps1` does this automatically) so the dependency resolves from
  `~/.m2/repository`.
- `.gitkeep` files mark otherwise-empty package folders; delete them once you add real
  source files to that folder.
- Never commit a filled-in `.env` — only `.env.example` (with blank/placeholder values)
  should be tracked in source control.

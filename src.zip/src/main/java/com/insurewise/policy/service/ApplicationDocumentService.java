package com.insurewise.policy.service;

import com.insurewise.common.dto.PresignedUrlResponse;
import com.insurewise.common.security.JwtPrincipal;
import com.insurewise.common.security.JwtRole;
import com.insurewise.common.service.S3StorageService;
import com.insurewise.policy.dto.response.ApplicationDocumentResponse;
import com.insurewise.policy.entity.ApplicationDocument;
import com.insurewise.policy.entity.PolicyApplication;
import com.insurewise.policy.exception.ApplicationNotFoundException;
import com.insurewise.policy.repository.ApplicationDocumentRepository;
import java.util.List;
import java.util.UUID;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;
import com.insurewise.common.exception.InvalidFileException;
import com.insurewise.policy.exception.ApplicationDocumentNotFoundException;

@Service
@Transactional
public class ApplicationDocumentService {
    private final ApplicationDocumentRepository documentRepository;
    private final PolicyApplicationService applicationService;
    private final S3StorageService storageService;

    public ApplicationDocumentService(
            ApplicationDocumentRepository documentRepository,
            PolicyApplicationService applicationService,
            S3StorageService storageService) {
        this.documentRepository = documentRepository;
        this.applicationService = applicationService;
        this.storageService = storageService;
    }

    public ApplicationDocumentResponse uploadDocument(
            JwtPrincipal principal,
            UUID applicationId,
            MultipartFile file) {

        try {
            PolicyApplication application =
                    requireApplicationAccess(principal, applicationId);

            if (file == null || file.isEmpty()) {
                throw new InvalidFileException("A non-empty file is required");
            }

            String s3Key = storageService.upload(
                    file,
                    "application-documents",
                    principal.userId());

            ApplicationDocument document = documentRepository.save(
                    new ApplicationDocument(
                            application,
                            file.getOriginalFilename() == null
                                    ? "unnamed-file"
                                    : file.getOriginalFilename(),
                            file.getContentType(),
                            s3Key,
                            principal.userId()));

            return toResponse(document);

        } catch (Exception exception) {
            System.err.println(
                    "Error in ApplicationDocumentService.uploadDocument: "
                            + exception.getMessage());
            throw exception;
        }
    }

    @Transactional(readOnly = true)
    public List<ApplicationDocumentResponse> listDocuments(
            JwtPrincipal principal,
            UUID applicationId) {

        try {
            requireApplicationAccess(principal, applicationId);

            return documentRepository
                    .findByPolicyApplicationIdOrderByCreatedAtDesc(applicationId)
                    .stream()
                    .map(this::toResponse)
                    .toList();

        } catch (Exception exception) {
            System.err.println(
                    "Error in ApplicationDocumentService.listDocuments: "
                            + exception.getMessage());
            throw exception;
        }
    }

    public void deleteDocument(
            JwtPrincipal principal,
            UUID applicationId,
            UUID documentId) {

        try {
            requireApplicationAccess(principal, applicationId);

            ApplicationDocument document =
                    documentRepository.findById(documentId)
                            .filter(item -> item
                                    .getPolicyApplication()
                                    .getId()
                                    .equals(applicationId))
                            .orElseThrow(() ->
                                    new ApplicationDocumentNotFoundException(
                                            documentId));

            storageService.delete(document.getS3Key());
            documentRepository.delete(document);

        } catch (Exception exception) {
            System.err.println(
                    "Error in ApplicationDocumentService.deleteDocument: "
                            + exception.getMessage());
            throw exception;
        }
    }

    private PolicyApplication requireApplicationAccess(
            JwtPrincipal principal,
            UUID applicationId) {

        PolicyApplication application =
                applicationService.getApplicationEntityForInternalUse(
                        applicationId);

        if (principal.role() == JwtRole.CUSTOMER
                && !application.isOwnedBy(principal.userId())) {
            throw new ApplicationNotFoundException(applicationId);
        }

        return application;
    }

    private ApplicationDocumentResponse toResponse(
            ApplicationDocument document) {

        PresignedUrlResponse download =
                storageService.getPresignedDownloadUrl(
                        document.getS3Key());

        return new ApplicationDocumentResponse(
                document.getId(),
                document.getPolicyApplication().getId(),
                document.getFileName(),
                document.getContentType(),
                download,
                document.getUploadedBy(),
                document.getCreatedAt());
    }
}
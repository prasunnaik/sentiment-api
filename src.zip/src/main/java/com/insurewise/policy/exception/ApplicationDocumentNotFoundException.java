package com.insurewise.policy.exception;

import java.util.UUID;

public class ApplicationDocumentNotFoundException
        extends RuntimeException {

    public ApplicationDocumentNotFoundException(UUID id) {
        super("Application document not found: " + id);
    }
}
export interface DashboardMetrics {
  customers: number;
  staff: number;
  categories: number;
  policies: number;
  activePolicies: number;
  applications: number;
  claims: number;
  payments: number;
}


/* =========================
   STAFF USER
   ========================= */

export interface StaffUser {
  id: string;
  fullName: string;
  email: string;
  address: string;
  profilePictureUrl?: string | null;
}

export interface StaffCreateRequest {
  fullName: string;
  email: string;
  address: string;
  password: string;
}

export interface StaffUpdateRequest {
  fullName: string;
  email: string;
  address: string;
}


/* =========================
   CATEGORY
   ========================= */

export interface Category {
  id: string;
  name: string;
  description: string;
  status: 'ACTIVE' | 'INACTIVE';
}

export interface CategoryCreateRequest {
  name: string;
  description: string;
  status: 'ACTIVE' | 'INACTIVE';
}


/* =========================
   POLICY
   ========================= */

export interface Policy {
  id: string;
  name: string;
  categoryId: string;
  categoryName?: string;
  coverageAmount: number;
  premiumAmount: number;
  durationLabel: string;
  status: string;
}

export interface PolicyCreateRequest {
  name: string;
  categoryId: string;
  coverageAmount: number;
  premiumAmount: number;
  durationLabel: string;
  status: string;
}


/* =========================
   POLICY APPLICATION
   ========================= */

export interface PolicyApplication {
  id: string;
  applicationCode?: string;
  customerId?: string;
  policyId?: string;
  policyName?: string;
  coverageType?: string;
  coverageAmount?: number;
  premiumAmount?: number;
  dateOfBirth?: string;
  address?: string;
  preferredStartDate?: string;
  nomineeName?: string;
  nomineeRelationship?: string;
  startDate?: string;
  endDate?: string;
  status: string;
  decidedBy?: string;
  decidedAt?: string;
  createdAt?: string;
}

export interface PolicyApplicationCreateRequest {
  policy_id: string;
  coverage_type: string;
  date_of_birth: string;
  address: string;
  preferred_start_date: string | null;
  nominee_name: string | null;
  nominee_relationship: string | null;
}


/* =========================
   DEPENDENT
   ========================= */

export type Relationship = 'SPOUSE' | 'CHILD' | 'PARENT' | 'SIBLING';
export type Gender = 'MALE' | 'FEMALE' | 'OTHER';

export interface Dependent {
  id: string;
  applicationId?: string;
  fullName: string;
  relationship: Relationship;
  dateOfBirth: string;
  gender: Gender;
  createdAt?: string;
}

export interface DependentRequest {
  full_name: string;
  relationship: Relationship;
  date_of_birth: string;
  gender: Gender;
}

/* =========================
   DOCUMENTS (shared shape)
   ========================= */

export interface PresignedUrl {
  url: string;
  expiresAt?: string;
}

export interface ApplicationDocument {
  id: string;
  applicationId?: string;
  fileName: string;
  objectKey?: string;
  contentType: string;
  fileSize?: number;
  download?: PresignedUrl;
  uploadedBy?: string;
  uploadedAt?: string;
  createdAt?: string;
}

export interface PageResponse<T> {
  items: T[];
  total: number;
  limit: number;
  offset: number;
}

/* =========================
   CLAIMS
   ========================= */

export type IncidentType =
  | 'ACCIDENT' | 'HOSPITALIZATION' | 'THEFT' | 'NATURAL_DISASTER'
  | 'FIRE' | 'DEATH' | 'DISABILITY' | 'PROPERTY_DAMAGE' | 'OTHER';

export type ClaimStatus = 'PENDING' | 'UNDER_REVIEW' | 'APPROVED' | 'REJECTED';

export interface Claim {
  id: string;
  claimCode?: string;
  customerId?: string;
  policyApplicationId: string;
  policyName?: string;
  incidentType: IncidentType;
  incidentDate: string;
  amount: number;
  description: string;
  documentRef?: string;
  status: ClaimStatus;
  processedBy?: string;
  processedByName?: string;
  processedAt?: string;
  createdAt?: string;
  remarks?: string;
}

export interface ClaimCreateRequest {
  idempotencyKey: string;
  policyApplicationId: string;
  incidentType: IncidentType;
  incidentDate: string;
  amount: number;
  description: string;
  documentRef?: string;
}

export interface ClaimDetail {
  id: string;
  claimCode: string;
  status: ClaimStatus;
  incidentType: IncidentType;
  incidentDate: string;
  amount: number;
  description: string;
  remarks?: string;
  applicantName?: string;
  applicantEmail?: string;
  applicantPhone?: string;
  applicationCode?: string;
  policyName?: string;
  coverageAmount?: number;
  premiumAmount?: number;
  processedBy?: string;
  processedByName?: string;
  processedAt?: string;
  createdAt?: string;
}

export interface ClaimDocument {
  id: string;
  claimId: string;
  fileName: string;
  contentType: string;
  preview?: PresignedUrl;
  download?: PresignedUrl;
  uploadedBy?: string;
  uploadedByName?: string;
  createdAt?: string;
}

export interface ClaimSubmission {
  claim: Claim;
  document: ClaimDocument;
}

export interface ClaimDependent {
  id: string;
  claimId?: string;
  fullName: string;
  relationship: Relationship;
  dateOfBirth: string;
  gender: Gender;
}

/* =========================
   PAYMENTS
   ========================= */

export type PaymentMethod = 'CREDIT_CARD' | 'DEBIT_CARD' | 'UPI' | 'NET_BANKING';
export type PaymentStatus = 'SUCCESS' | 'FAILED' | 'PENDING';

export interface Payment {
  id: string;
  idempotencyKey?: string;
  customerId?: string;
  policyApplicationId: string;
  policyName?: string;
  amount: number;
  method: PaymentMethod;
  status: PaymentStatus;
  transactionRef?: string;
  paidAt?: string;
  createdAt?: string;
}

export interface PaymentCreateRequest {
  idempotency_key: string;
  policy_application_id: string;
  amount: number;
  method: PaymentMethod;
}

export interface PaymentSummary {
  totalRevenue: number;
  successfulPayments: number;
  failedPayments: number;
  pendingPayments: number;
}

export interface PaymentDocument {
  id: string;
  paymentId: string;
  fileName: string;
  contentType: string;
  download?: PresignedUrl;
  uploadedBy?: string;
  systemGenerated: boolean;
  createdAt?: string;
}
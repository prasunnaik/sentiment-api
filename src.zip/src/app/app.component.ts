import { Location } from '@angular/common';
import { Component } from '@angular/core';
import { Router, RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { AuthService } from './core/auth/auth.service';
import { ToastComponent } from './components/common/toast/toast.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, RouterLink, RouterLinkActive, ToastComponent],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  constructor(
    private readonly router: Router,
    private readonly auth: AuthService,
    private readonly location: Location
  ) {}

  isLoginRoute(): boolean {
    return this.router.url.startsWith('/auth/');
  }

  isStaffRoute(): boolean { return this.router.url.startsWith('/staff/'); }
  isCustomerRoute(): boolean { return this.router.url.startsWith('/customer/'); }
  goBack(): void { this.location.back(); }
  logout(): void { this.auth.logout(); this.router.navigate(['/auth/customer-login']); }
}
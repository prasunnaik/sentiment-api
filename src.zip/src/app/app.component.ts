import { Location } from '@angular/common';
import { Component } from '@angular/core';
import { Router, RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { AuthService } from './core/auth/auth.service';
import { ToastComponent } from './components/common/toast/toast.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, RouterLink, RouterLinkActive, ToastComponent],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  constructor(
    private readonly router: Router,
    private readonly auth: AuthService,
    private readonly location: Location
  ) {}

  /**
   * Checks if the current route is a login route
   * @returns {boolean} true if the current URL starts with '/auth/', false otherwise
   */
  isLoginRoute(): boolean {
    return this.router.url.startsWith('/auth/');
  }

  /**
   * Checks if the current route is a staff route
   * @returns {boolean} true if the current URL starts with '/staff/', false otherwise
   */
  isStaffRoute(): boolean { return this.router.url.startsWith('/staff/'); }

  /**
   * Checks if the current route is a customer route
   * @returns {boolean} true if the current URL starts with '/customer/', false otherwise
   */
  isCustomerRoute(): boolean { return this.router.url.startsWith('/customer/'); }

  /**
   * Navigates back to the previous page
   * @returns {void}
   */
  goBack(): void { this.location.back(); }

  /**
   * Logs out the user and redirects to customer login page
   * @returns {void}
   */
  logout(): void { this.auth.logout(); this.router.navigate(['/auth/customer-login']); }
}
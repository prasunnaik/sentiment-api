import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { ToastService } from './toast.service';

@Component({
  selector: 'app-toast',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './toast.component.html',
  styleUrls: ['./toast.component.css']
})
export class ToastComponent {
  readonly toasts$;

  constructor(private readonly toastService: ToastService) {
    this.toasts$ = this.toastService.toasts$;
  }

  /**
   * Removes a toast message by its ID
   * @param {number} id - The ID of the toast to dismiss
   * @returns {void}
   */
  dismiss(id: number): void {
    this.toastService.dismiss(id);
  }

  /**
   * Returns the CSS class name for the toast variant
   * @param {string} variant - The toast variant ('success', 'error', 'info')
   * @returns {string} Bootstrap toast CSS class
   */
  variantClass(variant: string): string {
    switch (variant) {
      case 'success': return 'text-bg-success';
      case 'error': return 'text-bg-danger';
      default: return 'text-bg-dark';
    }
  }
}

import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

export type ToastVariant = 'success' | 'error' | 'info';

export interface ToastMessage {
  id: number;
  variant: ToastVariant;
  message: string;
  correlationId?: string;
}

const DEFAULT_DURATION_MS = 6000;

@Injectable({ providedIn: 'root' })
export class ToastService {
  private readonly toastsSubject = new BehaviorSubject<ToastMessage[]>([]);
  readonly toasts$ = this.toastsSubject.asObservable();
  private nextId = 1;

  /**
   * Displays a success toast message
   * @param {string} message - The success message to display
   * @returns {void}
   */
  success(message: string): void {
    this.show('success', message);
  }

  /**
   * Displays an error toast message
   * @param {string} message - The error message to display
   * @param {string} [correlationId] - Optional correlation ID for error tracking
   * @returns {void}
   */
  error(message: string, correlationId?: string): void {
    this.show('error', message, correlationId);
  }

  /**
   * Displays an info toast message
   * @param {string} message - The info message to display
   * @returns {void}
   */
  info(message: string): void {
    this.show('info', message);
  }

  /**
   * Removes a toast message by its ID
   * @param {number} id - The ID of the toast to remove
   * @returns {void}
   */
  dismiss(id: number): void {
    this.toastsSubject.next(this.toastsSubject.value.filter(toast => toast.id !== id));
  }

  /**
   * Shows a toast message with the specified variant
   * @private
   * @param {ToastVariant} variant - The type of toast ('success' | 'error' | 'info')
   * @param {string} message - The message content
   * @param {string} [correlationId] - Optional correlation ID for error tracking
   * @returns {void}
   */
  private show(variant: ToastVariant, message: string, correlationId?: string): void {
    const toast: ToastMessage = { id: this.nextId++, variant, message, correlationId };
    this.toastsSubject.next([...this.toastsSubject.value, toast]);
    setTimeout(() => this.dismiss(toast.id), DEFAULT_DURATION_MS);
  }
}

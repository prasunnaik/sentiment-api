export const PROFILE_PICTURE_MAX_SIZE = 5 * 1024 * 1024;
export const SUPPORTING_DOCUMENT_MAX_SIZE = 10 * 1024 * 1024;

export const PROFILE_PICTURE_TYPES = ['image/jpeg', 'image/png', 'image/webp'];
export const SUPPORTING_DOCUMENT_TYPES = ['application/pdf', 'image/jpeg', 'image/png'];

export function validateFile(
  file: File | null,
  allowedTypes: readonly string[],
  maxSize: number,
  requiredMessage: string,
  typeMessage: string,
  sizeMessage: string
): string | null {
  if (!file) {
    return requiredMessage;
  }

  if (!allowedTypes.includes(file.type)) {
    return typeMessage;
  }

  if (file.size > maxSize) {
    return sizeMessage;
  }

  return null;
}
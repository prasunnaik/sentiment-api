﻿import { Routes } from '@angular/router';
import { staffGuard } from '../core/rbac/staff.guard';

export const routes: Routes = [
  {
    path: '',
    redirectTo: 'auth/staff-login',
    pathMatch: 'full'
  },
  {
    path: 'auth/staff-login',
    loadComponent: () =>
      import('../pages/auth/staff-login/staff-login.component')
        .then(m => m.StaffLoginComponent)
  },
  {
    path: 'login',
    redirectTo: 'auth/staff-login',
    pathMatch: 'full'
  },
  {
    path: 'staff',
    canActivate: [staffGuard],
    children: [
      {
        path: '',
        redirectTo: 'dashboard',
        pathMatch: 'full'
      },
      {
        path: 'dashboard',
        loadComponent: () =>
          import('../pages/staff/dashboard/dashboard.component')
            .then(m => m.DashboardComponent)
      },
      {
        path: 'manage-users',
        loadComponent: () =>
          import('../pages/staff/manage-users-list/manage-users-list.component')
            .then(m => m.ManageUsersListComponent)
      },
      {
        path: 'manage-users/new',
        loadComponent: () =>
          import('../pages/staff/manage-users-new/manage-users-new.component')
            .then(m => m.ManageUsersNewComponent)
      },
      {
        path: 'manage-users/:id/edit',
        loadComponent: () =>
          import('../pages/staff/manage-users-new/manage-users-new.component')
            .then(m => m.ManageUsersNewComponent)
      },
      {
        path: 'categories',
        loadComponent: () =>
          import('../pages/staff/categories-list/categories-list.component')
            .then(m => m.CategoriesListComponent)
      },
      {
        path: 'categories/new',
        loadComponent: () =>
          import('../pages/staff/categories-new/categories-new.component')
            .then(m => m.CategoriesNewComponent)
      },
      {
        path: 'categories/:id/edit',
        loadComponent: () =>
          import('../pages/staff/categories-new/categories-new.component')
            .then(m => m.CategoriesNewComponent)
      },
      {
        path: 'policies',
        loadComponent: () =>
          import('../pages/staff/policies-list/policies-list.component')
            .then(m => m.PoliciesListComponent)
      },
      {
        path: 'policies/new',
        loadComponent: () =>
          import('../pages/staff/policies-new/policies-new.component')
            .then(m => m.PoliciesNewComponent)
      },
      {
        path: 'policies/:id/edit',
        loadComponent: () =>
          import('../pages/staff/policies-new/policies-new.component')
            .then(m => m.PoliciesNewComponent)
      },
      {
        path: 'approve-policies',
        loadComponent: () =>
          import('../pages/staff/approve-policies-list/approve-policies-list.component')
            .then(m => m.ApprovePoliciesListComponent)
      },
      {
        path: 'approve-policies/:id',
        loadComponent: () =>
          import('../pages/staff/approve-policies-review/approve-policies-review.component')
            .then(m => m.ApprovePoliciesReviewComponent)
      },
      {
        path: 'process-claims',
        loadComponent: () =>
          import('../pages/staff/process-claims-list/process-claims-list.component')
            .then(m => m.ProcessClaimsListComponent)
      },
      {
        path: 'process-claims/:id',
        loadComponent: () =>
          import('../pages/staff/process-claims-review/process-claims-review.component')
            .then(m => m.ProcessClaimsReviewComponent)
      },
      {
        path: 'view-payments',
        loadComponent: () =>
          import('../pages/staff/view-payments/view-payments.component')
            .then(m => m.ViewPaymentsComponent)
      },
      {
        path: 'view-payments/:id/documents',
        loadComponent: () =>
          import('../pages/shared/payment-documents/payment-documents.component')
            .then(m => m.PaymentDocumentsComponent)
      }
    ]
  },
  {
    path: '**',
    redirectTo: 'auth/staff-login'
  }
];

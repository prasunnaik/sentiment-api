import { Routes } from '@angular/router';
import { staffGuard } from '../core/rbac/staff.guard';
import { customerGuard } from '../core/rbac/customer.guard';

export const routes: Routes = [

  // Default route
  {
    path: '',
    redirectTo: 'auth/customer-login',
    pathMatch: 'full'
  },

  // Staff Login
  {
    path: 'auth/staff-login',
    loadComponent: () =>
      import('../pages/auth/staff-login/staff-login.component')
        .then(m => m.StaffLoginComponent)
  },

  {
    path: 'auth/customer-login',
    loadComponent: () => import('../pages/auth/customer-auth/customer-auth.component').then(m => m.CustomerAuthComponent)
  },
  {
    path: 'login',
    loadComponent: () => import('../pages/auth/customer-auth/customer-auth.component').then(m => m.CustomerAuthComponent)
  },
  {
    path: 'auth/register',
    loadComponent: () => import('../pages/auth/customer-auth/customer-auth.component').then(m => m.CustomerAuthComponent)
  },

  // Customer Area
  {
    path: 'customer',
    canActivate: [customerGuard],
    children: [

      { path: '', redirectTo: 'browse-policies', pathMatch: 'full' },

      // Browse & Apply
      {
        path: 'browse-policies',
        loadComponent: () => import('../pages/customer/browse-policies/browse-policies.component').then(m => m.BrowsePoliciesComponent)
      },
      {
        path: 'policies/:id',
        loadComponent: () => import('../pages/customer/policy-details/policy-details.component').then(m => m.PolicyDetailsComponent)
      },
      {
        path: 'policies/:id/pay',
        loadComponent: () => import('../pages/customer/make-policy-payment/make-policy-payment.component').then(m => m.MakePolicyPaymentComponent)
      },
      {
        path: 'policies/:id/documents',
        loadComponent: () => import('../pages/customer/policy-documents/policy-documents.component').then(m => m.PolicyDocumentsComponent)
      },

      // My Policies
      {
        path: 'my-policies',
        loadComponent: () => import('../pages/customer/my-policies/my-policies.component').then(m => m.MyPoliciesComponent)
      },

      // Claims
      {
        path: 'claims',
        loadComponent: () => import('../pages/customer/my-claims/my-claims.component').then(m => m.MyClaimsComponent)
      },
      {
        path: 'claims/new',
        loadComponent: () => import('../pages/customer/file-claim/file-claim.component').then(m => m.FileClaimComponent)
      },
      {
        path: 'claims/file-new',
        loadComponent: () => import('../pages/customer/my-claims-file-new/my-claims-file-new.component').then(m => m.MyClaimsFileNewComponent)
      },
      {
        path: 'claims/:id/documents',
        loadComponent: () => import('../pages/customer/claim-documents/claim-documents.component').then(m => m.ClaimDocumentsComponent)
      },

      // Payments
      {
        path: 'payments',
        loadComponent: () => import('../pages/customer/my-payments/my-payments.component').then(m => m.MyPaymentsComponent)
      },
      {
        path: 'payments/new',
        loadComponent: () => import('../pages/customer/make-new-payment/make-new-payment.component').then(m => m.MakeNewPaymentComponent)
      },
      {
        path: 'payments/:id/documents',
        loadComponent: () => import('../pages/shared/payment-documents/payment-documents.component').then(m => m.PaymentDocumentsComponent)
      },

      // Documents & Profile
      {
        path: 'documents',
        loadComponent: () => import('../pages/customer/customer-documents/customer-documents.component').then(m => m.CustomerDocumentsComponent)
      },
      {
        path: 'profile',
        loadComponent: () => import('../pages/customer/customer-profile/customer-profile.component').then(m => m.CustomerProfileComponent)
      }
    ]
  },

  // Staff Area
  {
    path: 'staff',
    canActivate: [staffGuard],
    children: [

      // Dashboard
      {
        path: 'dashboard',
        loadComponent: () =>
          import('../pages/staff/dashboard/dashboard.component')
            .then(m => m.DashboardComponent)
      },

      // -------------------------
      // Staff User Management
      // -------------------------

      {
        path: 'manage-users',
        loadComponent: () =>
          import('../pages/staff/manage-users-list/manage-users-list.component')
            .then(m => m.ManageUsersListComponent)
      },

      {
        path: 'manage-users/new',
        loadComponent: () =>
          import('../pages/staff/manage-users-new/manage-users-new.component')
            .then(m => m.ManageUsersNewComponent)
      },

      {
        path: 'manage-users/:id/edit',
        loadComponent: () =>
          import('../pages/staff/manage-users-new/manage-users-new.component')
            .then(m => m.ManageUsersNewComponent)
      },

      // -------------------------
      // Category Management
      // -------------------------

      {
        path: 'categories',
        loadComponent: () =>
          import('../pages/staff/categories-list/categories-list.component')
            .then(m => m.CategoriesListComponent)
      },

      {
        path: 'categories/new',
        loadComponent: () =>
          import('../pages/staff/categories-new/categories-new.component')
            .then(m => m.CategoriesNewComponent)
      },

      {
        path: 'categories/:id/edit',
        loadComponent: () =>
          import('../pages/staff/categories-new/categories-new.component')
            .then(m => m.CategoriesNewComponent)
      },

      // -------------------------
      // Policy Management
      // -------------------------

      {
        path: 'policies',
        loadComponent: () =>
          import('../pages/staff/policies-list/policies-list.component')
            .then(m => m.PoliciesListComponent)
      },

      {
        path: 'policies/new',
        loadComponent: () =>
          import('../pages/staff/policies-new/policies-new.component')
            .then(m => m.PoliciesNewComponent)
      },

      {
        path: 'policies/:id/edit',
        loadComponent: () =>
          import('../pages/staff/policies-new/policies-new.component')
            .then(m => m.PoliciesNewComponent)
      },

      // -------------------------
      // Policy Application Approval
      // -------------------------

      {
        path: 'approve-policies',
        loadComponent: () =>
          import('../pages/staff/approve-policies-list/approve-policies-list.component')
            .then(m => m.ApprovePoliciesListComponent)
      },

      {
        path: 'approve-policies/:id',
        loadComponent: () =>
          import('../pages/staff/approve-policies-review/approve-policies-review.component')
            .then(m => m.ApprovePoliciesReviewComponent)
      },

      // -------------------------
      // Claims Processing
      // -------------------------

      {
        path: 'process-claims',
        loadComponent: () =>
          import('../pages/staff/process-claims-list/process-claims-list.component')
            .then(m => m.ProcessClaimsListComponent)
      },

      {
        path: 'process-claims/:id',
        loadComponent: () =>
          import('../pages/staff/process-claims-review/process-claims-review.component')
            .then(m => m.ProcessClaimsReviewComponent)
      },

      // -------------------------
      // Payments
      // -------------------------

      {
        path: 'view-payments',
        loadComponent: () =>
          import('../pages/staff/view-payments/view-payments.component')
            .then(m => m.ViewPaymentsComponent)
      },

      {
        path: 'view-payments/:id/documents',
        loadComponent: () =>
          import('../pages/shared/payment-documents/payment-documents.component')
            .then(m => m.PaymentDocumentsComponent)
      }
    ]
  },

  // Unknown route
  {
    path: '**',
    redirectTo: 'auth/customer-login'
  }
];
import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';

import {
  StaffUser
} from '../../../types/br04-05.types';

import {
  StaffUserApiService
} from '../../../services/api/staff-user-api.service';

@Component({
  selector: 'app-manage-users-list',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './manage-users-list.component.html',
  styleUrls: ['./manage-users-list.component.css']
})
export class ManageUsersListComponent implements OnInit {

  users: StaffUser[] = [];

  loading = true;
  error = '';

  constructor(
    private readonly staffUserApi: StaffUserApiService,
    private readonly router: Router
  ) {}

  ngOnInit(): void {
    this.loadUsers();
  }

  loadUsers(): void {

    this.loading = true;
    this.error = '';

    this.staffUserApi.getAll().subscribe({

      next: (users) => {

        this.users = users;
        this.loading = false;
      },

      error: (error: unknown) => {

        console.error(
          'Unable to load staff users.',
          error
        );

        this.error =
          'Unable to load staff users.';

        this.loading = false;
      }
    });
  }

  addUser(): void {

    this.router.navigate([
      '/staff/manage-users/new'
    ]);
  }

  editUser(id: string): void {

    this.router.navigate([
      '/staff/manage-users',
      id,
      'edit'
    ]);
  }

  deleteUser(user: StaffUser): void {

    const confirmed =
      window.confirm(
        `Delete staff user "${user.fullName}"?`
      );

    if (!confirmed) {
      return;
    }

    this.error = '';

    this.staffUserApi
      .delete(user.id)
      .subscribe({

        next: () => {

          this.loadUsers();
        },

        error: (error: unknown) => {

          console.error(
            'Unable to delete staff user.',
            error
          );

          this.error =
            'Unable to delete staff user.';
        }
      });
  }
}
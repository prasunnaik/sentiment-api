import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';

import { Category } from '../../../types/brd.types';
import { CategoryApiService } from '../../../services/api/category-api.service';

@Component({
  selector: 'app-categories-list',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './categories-list.component.html',
  styleUrls: ['./categories-list.component.css']
})
export class CategoriesListComponent implements OnInit {

  categories: Category[] = [];
  loading = true;
  error = '';

  constructor(
    private readonly categoryApi: CategoryApiService,
    private readonly router: Router
  ) {}

  ngOnInit(): void {
    this.loadCategories();
  }

  loadCategories(): void {
    this.loading = true;
    this.error = '';

    this.categoryApi.getAll().subscribe({
      next: categories => {
        this.categories = categories;
        this.loading = false;
      },
      error: () => {
        this.error = 'Unable to load categories.';
        this.loading = false;
      }
    });
  }

  addCategory(): void {
    this.router.navigate(['/staff/categories/new']);
  }

  editCategory(id: string): void {
    this.router.navigate(['/staff/categories', id, 'edit']);
  }

  deleteCategory(category: Category): void {
    if (category.status === 'ACTIVE') {
      this.error = `"${category.name}" is active and cannot be deleted. Set it to Inactive first.`;
      return;
    }

    if (!window.confirm(`Delete category "${category.name}"?`)) {
      return;
    }

    this.error = '';

    this.categoryApi.delete(category.id).subscribe({
      next: () => this.loadCategories(),
      error: (error: unknown) => {
        const message = (error as { error?: { message?: string } })?.error?.message;
        this.error = message ?? 'Unable to delete category.';
      }
    });
  }
}

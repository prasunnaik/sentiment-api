import { of } from 'rxjs';

import { ClaimDocument } from '../../../types/br04-05.types';
import { ProcessClaimsReviewComponent } from './process-claims-review.component';

describe('ProcessClaimsReviewComponent', () => {
  const document: ClaimDocument = {
    id: 'document-1',
    claimId: 'claim-1',
    fileName: 'evidence.pdf',
    contentType: 'application/pdf',
    uploadedBy: 'customer-1',
    createdAt: '2026-09-17T10:00:00',
    download: { url: 'https://signed.example/evidence' }
  };

  function createComponent() {
    const claimApi = { listDocuments: vi.fn(() => of([document])) };
    const component = new ProcessClaimsReviewComponent(
      {} as never,
      {} as never,
      claimApi as never
    );
    return { component, claimApi };
  }

  it('loads staff-visible supporting documents', () => {
    const { component, claimApi } = createComponent();

    component.loadDocuments('claim-1');

    expect(claimApi.listDocuments).toHaveBeenCalledWith('claim-1');
    expect(component.documents).toEqual([document]);
    expect(component.documentsLoading).toBe(false);
    expect(component.documentsError).toBe('');
  });

  it('opens the short-lived document URL securely', () => {
    const { component } = createComponent();
    const open = vi.spyOn(window, 'open').mockReturnValue(null);

    component.openDocument(document);

    expect(open).toHaveBeenCalledWith(
      'https://signed.example/evidence',
      '_blank',
      'noopener,noreferrer'
    );
  });

  it('downloads using the short-lived document URL', () => {
    const { component } = createComponent();
    const anchor = { href: '', download: '', rel: '', click: vi.fn() };
    vi.spyOn(window.document, 'createElement').mockReturnValue(anchor as unknown as HTMLAnchorElement);

    component.downloadDocument(document);

    expect(anchor.href).toBe('https://signed.example/evidence');
    expect(anchor.download).toBe('evidence.pdf');
    expect(anchor.rel).toBe('noopener noreferrer');
    expect(anchor.click).toHaveBeenCalled();
  });
});
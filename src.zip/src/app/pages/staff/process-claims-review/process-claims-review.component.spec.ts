import { of, throwError } from 'rxjs';

import { ClaimDocument } from '../../../types/br04-05.types';
import { ProcessClaimsReviewComponent } from './process-claims-review.component';

describe('ProcessClaimsReviewComponent', () => {
  const document: ClaimDocument = {
    id: 'document-1',
    claimId: 'claim-1',
    fileName: 'evidence.pdf',
    contentType: 'application/pdf',
    uploadedBy: 'customer-1',
    createdAt: '2026-09-17T10:00:00',
    preview: { url: 'https://signed.example/preview' },
    download: { url: 'https://signed.example/evidence' }
  };

  function createComponent() {
    const claimApi = {
      listDocuments: vi.fn(() => of([document])),
      downloadDocumentContent: vi.fn(() => of(new Blob(['document content'])))
    };
    const component = new ProcessClaimsReviewComponent(
      {} as never,
      {} as never,
      claimApi as never
    );
    return { component, claimApi };
  }

  it('loads staff-visible supporting documents', () => {
    const { component, claimApi } = createComponent();

    component.loadDocuments('claim-1');

    expect(claimApi.listDocuments).toHaveBeenCalledWith('claim-1');
    expect(component.documents).toEqual([document]);
    expect(component.documentsLoading).toBe(false);
    expect(component.documentsError).toBe('');
  });

  it('opens the preview URL in a new tab so the document is shown, not downloaded', () => {
    const { component } = createComponent();
    const open = vi.spyOn(window, 'open').mockReturnValue(null);

    component.openDocument(document);

    expect(open).toHaveBeenCalledWith(
      'https://signed.example/preview',
      '_blank',
      'noopener,noreferrer'
    );
  });

  it('falls back to the download URL when no preview URL is available', () => {
    const { component } = createComponent();
    const open = vi.spyOn(window, 'open').mockReturnValue(null);
    const documentWithoutPreview: ClaimDocument = { ...document, preview: undefined };

    component.openDocument(documentWithoutPreview);

    expect(open).toHaveBeenCalledWith(
      'https://signed.example/evidence',
      '_blank',
      'noopener,noreferrer'
    );
  });

  it('downloads the document content as a blob from the backend', () => {
    const { component, claimApi } = createComponent();
    component.claimId = 'claim-1';
    const anchor = { href: '', download: '', setAttribute: vi.fn(), click: vi.fn(), remove: vi.fn() };
    vi.spyOn(window.document, 'createElement').mockReturnValue(anchor as unknown as HTMLAnchorElement);
    const appendChild = vi.spyOn(window.document.body, 'appendChild')
      .mockImplementation(node => node);
    Object.defineProperty(URL, 'createObjectURL', {
      configurable: true,
      value: vi.fn(() => 'blob:download')
    });
    Object.defineProperty(URL, 'revokeObjectURL', {
      configurable: true,
      value: vi.fn()
    });

    component.downloadDocument(document);

    expect(claimApi.downloadDocumentContent).toHaveBeenCalledWith('claim-1', 'document-1');
    expect(anchor.href).toBe('blob:download');
    expect(anchor.download).toBe('evidence.pdf');
    expect(anchor.setAttribute).toHaveBeenCalledWith('download', 'evidence.pdf');
    expect(appendChild).toHaveBeenCalledWith(anchor);
    expect(anchor.click).toHaveBeenCalled();
    expect(anchor.remove).toHaveBeenCalled();
    expect(URL.revokeObjectURL).toHaveBeenCalledWith('blob:download');
  });

  it('shows an error when the document content request fails', () => {
    const claimApi = {
      listDocuments: vi.fn(() => of([document])),
      downloadDocumentContent: vi.fn(() => throwError(() => new Error('not found')))
    };
    const component = new ProcessClaimsReviewComponent(
      {} as never,
      {} as never,
      claimApi as never
    );
    component.claimId = 'claim-1';

    component.downloadDocument(document);

    expect(component.documentsError).toBe('The document could not be downloaded.');
  });
});
import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormControl, ReactiveFormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';

import { ClaimDetail, ClaimDocument } from '../../../types/br04-05.types';
import { ClaimApiService } from '../../../services/api/claim-api.service';
import {
  SUPPORTING_DOCUMENT_MAX_SIZE,
  SUPPORTING_DOCUMENT_TYPES,
  validateFile
} from '../../../components/common/file-upload/file-upload.validation';

@Component({
  selector: 'app-process-claims-review',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './process-claims-review.component.html',
  styleUrls: ['./process-claims-review.component.css']
})
export class ProcessClaimsReviewComponent implements OnInit {

  claim: ClaimDetail | null = null;
  documents: ClaimDocument[] = [];

  loading = true;
  documentsLoading = true;
  processing = false;

  error = '';
  documentsError = '';
  success = '';
  selectedDecisionDocument: File | null = null;

  claimId = '';

  readonly remarksControl: FormControl<string> = new FormControl('', { nonNullable: true });

  constructor(
    private readonly route: ActivatedRoute,
    private readonly router: Router,
    private readonly claimApi: ClaimApiService
  ) {}

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id');

    if (!id) {
      this.error = 'Claim ID is missing.';
      this.loading = false;
      return;
    }

    this.claimId = id;
    this.loadClaim(id);
    this.loadDocuments(id);
  }

  loadClaim(id: string): void {
    this.claimApi.getDetail(id).subscribe({
      next: claim => {
        this.claim = claim;
        this.loading = false;
      },
      error: () => {
        this.error = 'Unable to load claim.';
        this.loading = false;
      }
    });
  }

  loadDocuments(id: string): void {
    this.documentsLoading = true;
    this.documentsError = '';
    this.claimApi.listDocuments(id).subscribe({
      next: documents => {
        this.documents = documents;
        this.documentsLoading = false;
      },
      error: () => {
        this.documentsError = 'Unable to load supporting documents.';
        this.documentsLoading = false;
      }
    });
  }

  selectDecisionDocument(event: Event): void {
    const input = event.target as HTMLInputElement;
    const file = input.files?.[0] ?? null;
    const validationError = validateFile(
      file,
      SUPPORTING_DOCUMENT_TYPES,
      SUPPORTING_DOCUMENT_MAX_SIZE,
      '',
      'Upload a PDF, JPG, JPEG, or PNG document.',
      'Supporting document must be 10 MB or smaller.'
    );

    if (validationError) {
      this.selectedDecisionDocument = null;
      this.error = validationError;
      input.value = '';
      return;
    }

    this.error = '';
    this.selectedDecisionDocument = file;
  }

  approve(): void {
    if (!this.claim || !window.confirm('Approve and settle this claim?')) {
      return;
    }

    this.processing = true;

    this.claimApi.approve(this.claimId, this.selectedDecisionDocument ?? undefined).subscribe({
      next: () => {
        if (this.claim) { this.claim = { ...this.claim, status: 'APPROVED' }; }
        this.processing = false;
        this.success = 'Claim approved successfully.';
      },
      error: (error: unknown) => {
        this.processing = false;
        this.error = (error as { error?: { message?: string } })?.error?.message ?? 'Unable to approve claim.';
      }
    });
  }

  reject(): void {
    if (!this.claim) {
      return;
    }

    if (!this.remarksControl.value.trim()) {
      this.error = 'Remarks are required when rejecting a claim.';
      this.remarksControl.markAsTouched();
      return;
    }

    if (!window.confirm('Reject this claim?')) {
      return;
    }

    this.processing = true;
    this.error = '';

    this.claimApi.reject(this.claimId, this.remarksControl.value.trim(), this.selectedDecisionDocument ?? undefined).subscribe({
      next: () => {
        if (this.claim) { this.claim = { ...this.claim, status: 'REJECTED', remarks: this.remarksControl.value.trim() }; }
        this.processing = false;
        this.success = 'Claim rejected.';
      },
      error: (error: unknown) => {
        this.processing = false;
        this.error = (error as { error?: { message?: string } })?.error?.message ?? 'Unable to reject claim.';
      }
    });
  }

  openDocument(document: ClaimDocument): void {
    if (document.download?.url) {
      window.open(document.download.url, '_blank', 'noopener,noreferrer');
      return;
    }

    this.documentsError = 'The document link has expired or is unavailable.';
  }

  downloadDocument(document: ClaimDocument): void {
    const url = document.download?.url;
    if (!url) {
      this.documentsError = 'The document link has expired or is unavailable.';
      return;
    }

    const link = window.document.createElement('a');
    link.href = url;
    link.download = document.fileName;
    link.rel = 'noopener noreferrer';
    link.click();
  }

  back(): void {
    this.router.navigate(['/staff/process-claims']);
  }
}

import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';

import {
  Policy
} from '../../../types/brd.types';

import {
  PolicyApiService
} from '../../../services/api/policy-api.service';

@Component({
  selector: 'app-policies-list',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './policies-list.component.html',
  styleUrls: ['./policies-list.component.css']
})
export class PoliciesListComponent implements OnInit {

  policies: Policy[] = [];
  loading = true;
  error = '';

  constructor(
    private policyApi: PolicyApiService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.loadPolicies();
  }

  loadPolicies(): void {

    this.loading = true;

    this.policyApi.getAllForStaff().subscribe({
      next: policies => {
        this.policies = policies;
        this.loading = false;
      },

      error: () => {
        this.error = 'Unable to load policies.';
        this.loading = false;
      }
    });
  }

  addPolicy(): void {
    this.router.navigate([
      '/staff/policies/new'
    ]);
  }

  editPolicy(id: string): void {
    this.router.navigate([
      '/staff/policies',
      id,
      'edit'
    ]);
  }

  deletePolicy(policy: Policy): void {

    if (!window.confirm(
      `Delete policy "${policy.name}"?`
    )) {
      return;
    }

    this.policyApi.delete(policy.id).subscribe({
      next: () => this.loadPolicies(),
      error: () => {
        this.error = 'Unable to delete policy.';
      }
    });
  }
}
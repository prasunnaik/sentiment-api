import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  ReactiveFormsModule,
  Validators
} from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';

import { CategoryApiService } from '../../../services/api/category-api.service';
import { CategoryCreateRequest } from '../../../types/br04-05.types';

@Component({
  selector: 'app-categories-new',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './categories-new.component.html',
  styleUrls: ['./categories-new.component.css']
})
export class CategoriesNewComponent implements OnInit {

  categoryId: string | null = null;
  isEdit = false;

  loading = false;
  saving = false;

  error = '';
  success = '';

  form: FormGroup<{
    name: FormControl<string>;
    description: FormControl<string>;
    status: FormControl<'ACTIVE' | 'INACTIVE'>;
  }>;

  constructor(
    private readonly fb: FormBuilder,
    private readonly categoryApi: CategoryApiService,
    private readonly route: ActivatedRoute,
    private readonly router: Router
  ) {
    this.form = this.fb.nonNullable.group({
      name: ['', [Validators.required, Validators.maxLength(80)]],
      description: ['', [Validators.required, Validators.maxLength(500)]],
      status: ['ACTIVE' as 'ACTIVE' | 'INACTIVE', Validators.required]
    });
  }

  ngOnInit(): void {
    this.categoryId = this.route.snapshot.paramMap.get('id');
    this.isEdit = !!this.categoryId;

    if (this.categoryId) {
      this.loadCategory(this.categoryId);
    }
  }

  loadCategory(id: string): void {
    this.loading = true;
    this.error = '';

    this.categoryApi.getAll().subscribe({
      next: categories => {
        const category = categories.find(item => item.id === id);

        if (!category) {
          this.error = 'Category not found.';
          this.loading = false;
          return;
        }

        this.form.patchValue({
          name: category.name,
          description: category.description,
          status: category.status
        });

        this.loading = false;
      },
      error: () => {
        this.error = 'Unable to load category.';
        this.loading = false;
      }
    });
  }

  save(): void {
    this.error = '';
    this.success = '';

    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }

    this.saving = true;

    const request: CategoryCreateRequest = this.form.getRawValue();

    const operation = this.isEdit && this.categoryId
      ? this.categoryApi.update(this.categoryId, request)
      : this.categoryApi.create(request);

    operation.subscribe({
      next: () => {
        this.saving = false;
        this.success = this.isEdit ? 'Category updated successfully.' : 'Category created successfully.';
        setTimeout(() => this.router.navigate(['/staff/categories']), 700);
      },
      error: (error: unknown) => {
        this.saving = false;
        const message = (error as { error?: { message?: string } })?.error?.message;
        this.error = message ?? 'Unable to save category.';
      }
    });
  }

  cancel(): void {
    this.router.navigate(['/staff/categories']);
  }
}

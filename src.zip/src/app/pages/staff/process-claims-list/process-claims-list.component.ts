import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';

import { Claim } from '../../../types/br04-05.types';
import { ClaimApiService } from '../../../services/api/claim-api.service';

@Component({
  selector: 'app-process-claims-list',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './process-claims-list.component.html',
  styleUrls: ['./process-claims-list.component.css']
})
export class ProcessClaimsListComponent implements OnInit {

  claims: Claim[] = [];
  loading = true;
  error = '';

  constructor(
    private readonly claimApi: ClaimApiService,
    private readonly router: Router
  ) {}

  ngOnInit(): void {
    this.loadClaims();
  }

  loadClaims(): void {
    this.loading = true;
    this.error = '';

    this.claimApi.list().subscribe({
      next: response => {
        this.claims = response.items ?? [];
        this.loading = false;
      },
      error: () => {
        this.error = 'Unable to load claims.';
        this.loading = false;
      }
    });
  }

  review(id: string): void {
    this.router.navigate(['/staff/process-claims', id]);
  }
}

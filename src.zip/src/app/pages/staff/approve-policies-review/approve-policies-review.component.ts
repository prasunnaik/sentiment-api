import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';

import {
  PolicyApplication,
  ApplicationDocument
} from '../../../types/brd.types';

import {
  PolicyApplicationApiService
} from '../../../services/api/policy-application-api.service';

import {
  ApplicationDocumentApiService
} from '../../../services/api/application-document-api.service';

@Component({
  selector: 'app-approve-policies-review',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './approve-policies-review.component.html',
  styleUrls: ['./approve-policies-review.component.css']
})
export class ApprovePoliciesReviewComponent implements OnInit {

  application: PolicyApplication | null = null;

  documents: ApplicationDocument[] = [];

  loading = true;
  processing = false;
  documentActionId = '';

  error = '';
  success = '';

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private applicationApi: PolicyApplicationApiService,
    private documentApi: ApplicationDocumentApiService
  ) {}

  ngOnInit(): void {

    const id =
      this.route.snapshot.paramMap.get('id');

    if (!id) {
      this.error = 'Application ID is missing.';
      this.loading = false;
      return;
    }

    this.loadApplication(id);
    this.loadDocuments(id);
  }

  loadApplication(id: string): void {

    this.applicationApi
      .getById(id)
      .subscribe({

        next: application => {
          this.application = application;
          this.loading = false;
        },

        error: () => {
          this.error =
            'Unable to load application.';
          this.loading = false;
        }

      });
  }

  loadDocuments(id: string): void {

    this.documentApi
      .getByApplicationId(id)
      .subscribe({

        next: documents => {
          this.documents = documents;
        },

        error: () => {
          this.error =
            'Unable to load supporting documents.';
        }

      });
  }

  approve(): void {

    if (!this.application) {
      return;
    }

    if (!window.confirm(
      'Approve this policy application?'
    )) {
      return;
    }

    this.processing = true;

    this.applicationApi
      .approve(this.application.id)
      .subscribe({

        next: application => {

          this.application = application;
          this.processing = false;

          this.success =
            'Policy application approved successfully.';
        },

        error: error => {

          this.processing = false;

          this.error =
            error?.error?.message ??
            'Unable to approve application.';
        }

      });
  }

  reject(): void {

    if (!this.application) {
      return;
    }

    if (!window.confirm(
      'Reject this policy application?'
    )) {
      return;
    }

    this.processing = true;

    this.applicationApi
      .reject(this.application.id)
      .subscribe({

        next: application => {

          this.application = application;
          this.processing = false;

          this.success =
            'Policy application rejected.';
        },

        error: error => {

          this.processing = false;

          this.error =
            error?.error?.message ??
            'Unable to reject application.';
        }

      });
  }

  openDocument(document: ApplicationDocument): void {
    const applicationId = document.applicationId ?? this.application?.id;

    if (!applicationId) {
      this.error = 'Application ID is missing for this document.';
      return;
    }

    if (!this.canPreview(document)) {
      this.downloadDocument(document);
      return;
    }

    this.documentActionId = document.id;
    this.error = '';
    this.documentApi.preview(applicationId, document.id).subscribe({
      next: response => {
        this.documentActionId = '';
        this.openSecureUrl(response.url);
      },
      error: error => {
        this.documentActionId = '';
        this.error = this.documentApi.errorMessage(error, 'preview');
      }
    });
  }

  downloadDocument(document: ApplicationDocument): void {
    const applicationId = document.applicationId ?? this.application?.id;
    if (!applicationId) {
      this.error = 'Application ID is missing for this document.';
      return;
    }

    this.documentActionId = document.id;
    this.error = '';
    this.documentApi.download(applicationId, document.id).subscribe({
      next: response => {
        this.documentActionId = '';
        const link = window.document.createElement('a');
        link.href = response.url;
        link.download = document.fileName;
        link.rel = 'noopener noreferrer';
        link.click();
      },
      error: error => {
        this.documentActionId = '';
        this.error = this.documentApi.errorMessage(error, 'download');
      }
    });
  }

  canPreview(document: ApplicationDocument): boolean {
    return document.contentType === 'application/pdf' || document.contentType.startsWith('image/');
  }

  formatFileSize(size?: number): string {
    if (size === undefined) { return 'Unknown'; }
    if (size < 1024) { return `${size} B`; }
    if (size < 1024 * 1024) { return `${(size / 1024).toFixed(1)} KB`; }
    return `${(size / (1024 * 1024)).toFixed(1)} MB`;
  }

  private openSecureUrl(url?: string): void {
    if (!url) {
      this.error = 'A preview link is not available for this document.';
      return;
    }

    window.open(url, '_blank', 'noopener,noreferrer');
  }

  back(): void {
    this.router.navigate([
      '/staff/approve-policies'
    ]);
  }
}

import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';

import { Payment, PaymentDocument, PaymentSummary } from '../../../types/br04-05.types';
import { PaymentApiService } from '../../../services/api/payment-api.service';

@Component({
  selector: 'app-view-payments',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './view-payments.component.html',
  styleUrls: ['./view-payments.component.css']
})
export class ViewPaymentsComponent implements OnInit {

  payments: Payment[] = [];
  summary: PaymentSummary = { totalRevenue: 0, successfulPayments: 0, failedPayments: 0, pendingPayments: 0 };

  loading = true;
  error = '';
  receiptsPayment: Payment | null = null;
  receiptDocuments: PaymentDocument[] = [];
  selectedReceipt: PaymentDocument | null = null;
  selectedReceiptUrl: SafeResourceUrl | null = null;
  receiptsLoading = false;
  receiptsError = '';

  constructor(
    private readonly paymentApi: PaymentApiService,
    private readonly sanitizer: DomSanitizer
  ) {}

  ngOnInit(): void {
    this.loadSummary();
    this.loadPayments();
  }

  loadSummary(): void {
    this.paymentApi.getSummary().subscribe({
      next: summary => this.summary = summary,
      error: () => undefined
    });
  }

  loadPayments(): void {
    this.loading = true;
    this.error = '';

    this.paymentApi.list(undefined, 100, 0).subscribe({
      next: response => {
        this.payments = response.items ?? [];
        this.loading = false;
      },
      error: () => {
        this.error = 'Unable to load payments.';
        this.loading = false;
      }
    });
  }

  viewReceipts(id: string): void {
    this.receiptsPayment = this.payments.find(payment => payment.id === id) ?? null;
    this.receiptDocuments = [];
    this.receiptsError = '';
    this.receiptsLoading = true;

    this.paymentApi.listDocuments(id).subscribe({
      next: documents => {
        this.receiptDocuments = documents;
        this.receiptsLoading = false;
      },
      error: error => {
        this.receiptsError = this.paymentApi.errorMessage(error, 'receipt');
        this.receiptsLoading = false;
      }
    });
  }

  closeReceipts(): void {
    this.receiptsPayment = null;
    this.receiptDocuments = [];
    this.selectedReceipt = null;
    this.selectedReceiptUrl = null;
    this.receiptsError = '';
  }

  openReceipt(document: PaymentDocument): void {
    if (document.preview?.url) {
      this.selectedReceipt = document;
      this.selectedReceiptUrl =
        this.sanitizer.bypassSecurityTrustResourceUrl(document.preview.url);
      return;
    }

    this.receiptsError = 'A receipt link is not available.';
  }
}

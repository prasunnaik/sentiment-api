import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';

import { Payment, PaymentSummary } from '../../../types/br04-05.types';
import { PaymentApiService } from '../../../services/api/payment-api.service';

@Component({
  selector: 'app-view-payments',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './view-payments.component.html',
  styleUrls: ['./view-payments.component.css']
})
export class ViewPaymentsComponent implements OnInit {

  payments: Payment[] = [];
  summary: PaymentSummary = { totalRevenue: 0, successfulPayments: 0, failedPayments: 0, pendingPayments: 0 };

  loading = true;
  error = '';

  constructor(
    private readonly paymentApi: PaymentApiService,
    private readonly router: Router
  ) {}

  ngOnInit(): void {
    this.loadSummary();
    this.loadPayments();
  }

  loadSummary(): void {
    this.paymentApi.getSummary().subscribe({
      next: summary => this.summary = summary,
      error: () => undefined
    });
  }

  loadPayments(): void {
    this.loading = true;
    this.error = '';

    this.paymentApi.list(undefined, 100, 0).subscribe({
      next: response => {
        this.payments = response.items ?? [];
        this.loading = false;
      },
      error: () => {
        this.error = 'Unable to load payments.';
        this.loading = false;
      }
    });
  }

  viewReceipts(id: string): void {
    this.router.navigate(['/staff/view-payments', id, 'documents']);
  }
}

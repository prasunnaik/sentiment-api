import { HttpErrorResponse } from '@angular/common/http';
import { of, throwError } from 'rxjs';

import { CustomerProfileComponent } from './customer-profile.component';

describe('CustomerProfileComponent', () => {
  it('loads a successful profile image', () => {
    const api = {
      getProfilePicture: vi.fn(() => of({ download: { url: 'https://signed.example/avatar' } }))
    };
    const component = new CustomerProfileComponent(api as never);

    component.ngOnInit();

    expect(component.pictureUrl).toBe('https://signed.example/avatar');
    expect(component.error).toBe('');
  });

  it('keeps the default avatar without an error when the image is missing', () => {
    const api = { getProfilePicture: vi.fn(() => of(null)) };
    const component = new CustomerProfileComponent(api as never);

    component.ngOnInit();

    expect(component.pictureUrl).toBeNull();
    expect(component.error).toBe('');
  });

  it('shows a session message for an unauthorized response', () => {
    const api = {
      getProfilePicture: vi.fn(() => throwError(() => new HttpErrorResponse({ status: 401 })))
    };
    const component = new CustomerProfileComponent(api as never);

    component.ngOnInit();

    expect(component.pictureUrl).toBeNull();
    expect(component.error).toContain('session has expired');
  });

  it('shows a local fallback message for a server error', () => {
    const api = {
      getProfilePicture: vi.fn(() => throwError(() => new HttpErrorResponse({ status: 500 })))
    };
    const component = new CustomerProfileComponent(api as never);

    component.ngOnInit();

    expect(component.pictureUrl).toBeNull();
    expect(component.error).toContain('continue using your account');
  });
});
import { CommonModule } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';

import { CustomerApiService } from '../../../services/api/customer-api.service';

@Component({
  selector: 'app-customer-profile',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './customer-profile.component.html',
  styleUrls: ['./customer-profile.component.css']
})
export class CustomerProfileComponent implements OnInit {
  pictureUrl: string | null = null;
  uploading = false;
  error = '';
  message = '';

  constructor(private readonly api: CustomerApiService) {}

  ngOnInit(): void {
    this.api.getProfilePicture().subscribe({
      next: response => this.pictureUrl = response?.download?.url ?? null,
      error: (error: HttpErrorResponse) => {
        this.pictureUrl = null;
        this.error = error.status === 401
          ? 'Your session has expired. Sign in again.'
          : 'Profile picture could not be loaded. You can continue using your account.';
      }
    });
  }

  upload(event: Event): void {
    const file = (event.target as HTMLInputElement).files?.[0];
    if (!file) {
      return;
    }

    this.uploading = true;
    this.api.uploadProfilePicture(file).subscribe({
      next: response => {
        this.pictureUrl = response.download?.url || this.pictureUrl;
        this.message = 'Profile picture updated.';
        this.uploading = false;
      },
      error: () => {
        this.error = 'Profile picture upload failed.';
        this.uploading = false;
      }
    });
  }
}

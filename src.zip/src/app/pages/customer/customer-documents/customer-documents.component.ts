import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { CustomerApiService } from '../../../services/api/customer-api.service';
import { ApplicationDocumentApiService } from '../../../services/api/application-document-api.service';
import { ApplicationDocument, PolicyApplication } from '../../../types/br04-05.types';
import { getApiError } from '../../../core/errors/api-error.util';

@Component({
  selector: 'app-customer-documents',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './customer-documents.component.html',
  styleUrls: ['./customer-documents.component.css']
})
export class CustomerDocumentsComponent implements OnInit {
  applications: PolicyApplication[] = [];
  documents: ApplicationDocument[] = [];
  applicationId = '';
  loading = false;
  uploading = false;
  openingDocumentId = '';
  error = '';
  message = '';

  constructor(
    private readonly api: CustomerApiService,
    private readonly documentApi: ApplicationDocumentApiService
  ) {}

  ngOnInit(): void {
    this.api.getApplications().subscribe({
      next: data => this.applications = data,
      error: error => this.error = getApiError(error)?.message ?? 'Applications could not be loaded.'
    });
  }

  loadDocuments(): void {
    if (!this.applicationId) {
      this.documents = [];
      return;
    }

    this.loading = true;
    this.api.getApplicationDocuments(this.applicationId).subscribe({
      next: data => {
        this.documents = data;
        this.loading = false;
      },
      error: error => {
        this.error = getApiError(error)?.message ?? 'Documents could not be loaded.';
        this.loading = false;
      }
    });
  }

  upload(event: Event): void {
    const file = (event.target as HTMLInputElement).files?.[0];
    if (!file || !this.applicationId) {
      return;
    }

    this.uploading = true;
    this.message = '';
    this.api.uploadApplicationDocument(this.applicationId, file).subscribe({
      next: document => {
        this.documents = [...this.documents, document];
        this.message = 'Document uploaded successfully.';
        this.uploading = false;
      },
      error: error => {
        this.error = getApiError(error)?.message ?? 'Document upload failed.';
        this.uploading = false;
      }
    });
  }

  openDocument(document: ApplicationDocument): void {
    if (!this.applicationId) {
      this.error = 'Application ID is missing for this document.';
      return;
    }

    const previewWindow = window.open('about:blank', '_blank');
    if (previewWindow) {
      previewWindow.opener = null;
    }

    this.openingDocumentId = document.id;
    this.error = '';

    this.documentApi.preview(this.applicationId, document.id).subscribe({
      next: response => {
        this.openingDocumentId = '';
        const url = response.url;

        if (!url) {
          previewWindow?.close();
          this.error = 'A preview link is not available for this document.';
          return;
        }

        if (previewWindow) {
          previewWindow.location.href = url;
          return;
        }

        this.error = 'The preview window was blocked. Allow pop-ups and try again.';
      },
      error: error => {
        previewWindow?.close();
        this.openingDocumentId = '';
        this.error = this.documentApi.errorMessage(error, 'preview');
      }
    });
  }

  downloadDocument(document: ApplicationDocument): void {
    if (!this.applicationId) {
      this.error = 'Application ID is missing for this document.';
      return;
    }

    this.openingDocumentId = document.id;
    this.error = '';

    this.documentApi.download(this.applicationId, document.id).subscribe({
      next: response => {
        this.openingDocumentId = '';
        if (!response.url) {
          this.error = 'A download link is not available for this document.';
          return;
        }

        const link = window.document.createElement('a');
        link.href = response.url;
        link.download = document.fileName;
        link.rel = 'noopener noreferrer';
        link.click();
      },
      error: error => {
        this.openingDocumentId = '';
        this.error = this.documentApi.errorMessage(error, 'download');
      }
    });
  }
}

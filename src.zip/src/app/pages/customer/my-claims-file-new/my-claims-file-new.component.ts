import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

/**
 * Legacy alias route — redirects to the canonical file-claim flow.
 */
@Component({
  selector: 'app-my-claims-file-new',
  standalone: true,
  templateUrl: './my-claims-file-new.component.html',
  styleUrls: ['./my-claims-file-new.component.css']
})
export class MyClaimsFileNewComponent implements OnInit {
  constructor(private readonly router: Router) {}

  ngOnInit(): void {
    this.router.navigate(['/customer/claims/new']);
  }
}

import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpEventType } from '@angular/common/http';
import { ActivatedRoute, Router } from '@angular/router';

import { ApplicationDocument } from '../../../types/br04-05.types';
import {
  APPLICATION_DOCUMENT_ACCEPT,
  ApplicationDocumentApiService
} from '../../../services/api/application-document-api.service';

@Component({
  selector: 'app-policy-documents',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './policy-documents.component.html',
  styleUrls: ['./policy-documents.component.css']
})
export class PolicyDocumentsComponent implements OnInit {

  @ViewChild('fileInput') fileInput?: ElementRef<HTMLInputElement>;

  applicationId = '';
  documents: ApplicationDocument[] = [];
  selectedFile: File | null = null;
  readonly acceptedFileTypes = APPLICATION_DOCUMENT_ACCEPT;

  loading = true;
  uploading = false;
  openingDocumentId = '';
  uploadProgress = 0;
  error = '';
  message = '';

  constructor(
    private readonly route: ActivatedRoute,
    private readonly router: Router,
    private readonly documentApi: ApplicationDocumentApiService
  ) {}

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id');

    if (!id) {
      this.error = 'Application ID is missing.';
      this.loading = false;
      return;
    }

    this.applicationId = id;
    this.loadDocuments();
  }

  loadDocuments(): void {
    this.loading = true;

    this.documentApi.list(this.applicationId).subscribe({
      next: documents => {
        this.documents = documents;
        this.loading = false;
      },
      error: error => {
        this.error = this.documentApi.errorMessage(error, 'list');
        this.loading = false;
      }
    });
  }

  selectFile(event: Event): void {
    const input = event.target as HTMLInputElement;
    const file = input.files?.[0] ?? null;
    const validationError = this.documentApi.validateFile(file);

    this.error = validationError ?? '';
    this.message = '';
    this.selectedFile = validationError ? null : file;

    if (validationError) {
      input.value = '';
    }
  }

  upload(): void {
    const validationError = this.documentApi.validateFile(this.selectedFile);
    if (validationError || !this.selectedFile) {
      this.error = validationError ?? 'Select a PDF document to upload.';
      return;
    }

    this.uploading = true;
    this.uploadProgress = 0;
    this.error = '';
    this.message = '';

    this.documentApi.upload(this.applicationId, this.selectedFile).subscribe({
      next: event => {
        if (event.type === HttpEventType.UploadProgress) {
          this.uploadProgress = event.total
            ? Math.round((event.loaded / event.total) * 100)
            : 0;
        }

        if (event.type === HttpEventType.Response) {
          this.uploadProgress = 100;
          this.uploading = false;
          this.selectedFile = null;
          if (this.fileInput) {
            this.fileInput.nativeElement.value = '';
          }
          this.message = 'Document uploaded successfully.';
          this.loadDocuments();
        }
      },
      error: error => {
        this.error = this.documentApi.errorMessage(error, 'upload');
        this.uploading = false;
        this.uploadProgress = 0;
      }
    });
  }

  openDocument(document: ApplicationDocument): void {
    const previewWindow = window.open('about:blank', '_blank');
    if (previewWindow) {
      previewWindow.opener = null;
    }

    this.openingDocumentId = document.id;
    this.error = '';
    this.documentApi.preview(this.applicationId, document.id).subscribe({
      next: response => {
        this.openingDocumentId = '';
        const url = response.url;

        if (!url) {
          previewWindow?.close();
          this.error = 'A preview link is not available for this document.';
          return;
        }

        if (previewWindow) {
          previewWindow.location.href = url;
          return;
        }

        this.error = 'The preview window was blocked. Allow pop-ups and try again.';
      },
      error: error => {
        previewWindow?.close();
        this.openingDocumentId = '';
        this.error = this.documentApi.errorMessage(error, 'preview');
      }
    });
  }

  removeDocument(document: ApplicationDocument): void {
    if (!window.confirm(`Remove "${document.fileName}"?`)) {
      return;
    }

    this.documentApi.delete(this.applicationId, document.id).subscribe({
      next: () => this.documents = this.documents.filter(item => item.id !== document.id),
      error: error => this.error = this.documentApi.errorMessage(error, 'delete')
    });
  }

  back(): void {
    this.router.navigate(['/customer/my-policies']);
  }
}

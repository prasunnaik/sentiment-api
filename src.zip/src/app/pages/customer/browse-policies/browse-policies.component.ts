import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

import { Policy } from '../../../types/br04-05.types';
import { CustomerApiService } from '../../../services/api/customer-api.service';

@Component({
  selector: 'app-browse-policies',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './browse-policies.component.html',
  styleUrls: ['./browse-policies.component.css']
})
export class BrowsePoliciesComponent implements OnInit {

  policies: Policy[] = [];
  filtered: Policy[] = [];

  search = '';
  selectedCategory = '';
  categories: string[] = [];

  loading = true;
  error = '';

  constructor(
    private readonly customerApi: CustomerApiService,
    private readonly router: Router
  ) {}

  ngOnInit(): void {
    this.loading = true;

    this.customerApi.getPolicies().subscribe({
      next: policies => {
        this.policies = policies;
        this.categories = [...new Set(policies.map(policy => policy.categoryName || 'General'))];
        this.applyFilters();
        this.loading = false;
      },
      error: () => {
        this.error = 'Unable to load policies.';
        this.loading = false;
      }
    });
  }

  applyFilters(): void {
    const term = this.search.trim().toLowerCase();

    this.filtered = this.policies.filter(policy => {
      const matchesSearch = !term || policy.name.toLowerCase().includes(term);
      const matchesCategory = !this.selectedCategory || (policy.categoryName || 'General') === this.selectedCategory;
      return matchesSearch && matchesCategory;
    });
  }

  viewDetails(policy: Policy): void {
    this.router.navigate(['/customer/policies', policy.id]);
  }

  applyNow(policy: Policy): void {
    this.router.navigate(['/customer/policies', policy.id], { queryParams: { apply: '1' } });
  }
}

import { of } from 'rxjs';

import { MakePolicyPaymentComponent } from './make-policy-payment.component';

describe('MakePolicyPaymentComponent', () => {
  function createComponent() {
    const customerApi = {
      getApplication: vi.fn(() => of({
        id: 'application-1',
        policyName: 'Health Policy',
        premiumAmount: 5000,
        status: 'APPROVED'
      }))
    };
    const paymentApi = {
      makePayment: vi.fn(),
      listDocuments: vi.fn()
    };
    const router = { navigate: vi.fn() };
    const component = new MakePolicyPaymentComponent(
      { snapshot: { paramMap: { get: () => 'application-1' } } } as never,
      router as never,
      customerApi as never,
      paymentApi as never
    );
    component.ngOnInit();

    return { component, paymentApi };
  }

  it('does not submit a card payment when required details are empty', () => {
    const { component, paymentApi } = createComponent();

    component.pay();

    expect(component.form.invalid).toBe(true);
    expect(component.error).toContain('required payment details');
    expect(paymentApi.makePayment).not.toHaveBeenCalled();
  });

  it('requires a UPI ID when UPI is selected', () => {
    const { component, paymentApi } = createComponent();
    component.form.controls.method.setValue('UPI');

    component.pay();

    expect(component.form.controls.upiId.hasError('required')).toBe(true);
    expect(paymentApi.makePayment).not.toHaveBeenCalled();
  });

  it('opens the generated receipt directly', () => {
    const { component, paymentApi } = createComponent();
    const popup = {
      opener: window,
      location: { href: 'about:blank' },
      close: vi.fn()
    };
    vi.spyOn(window, 'open').mockReturnValue(popup as unknown as Window);
    paymentApi.listDocuments.mockReturnValue(of([{
      id: 'receipt-1',
      paymentId: 'payment-1',
      fileName: 'receipt.txt',
      contentType: 'text/plain',
      systemGenerated: true,
      download: { url: 'https://signed.example/receipt' }
    }]));
    component.payment = {
      id: 'payment-1',
      policyApplicationId: 'application-1',
      amount: 5000,
      method: 'CREDIT_CARD',
      status: 'SUCCESS'
    };

    component.viewReceipt();

    expect(paymentApi.listDocuments).toHaveBeenCalledWith('payment-1');
    expect(popup.opener).toBeNull();
    expect(popup.location.href).toBe('https://signed.example/receipt');
  });
});
import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';

import { Payment, PaymentMethod, PolicyApplication } from '../../../types/br04-05.types';
import { CustomerApiService } from '../../../services/api/customer-api.service';
import { PaymentApiService } from '../../../services/api/payment-api.service';

@Component({
  selector: 'app-make-policy-payment',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './make-policy-payment.component.html',
  styleUrls: ['./make-policy-payment.component.css']
})
export class MakePolicyPaymentComponent implements OnInit {

  application: PolicyApplication | null = null;
  payment: Payment | null = null;

  loading = true;
  submitting = false;
  loadingReceipt = false;
  error = '';

  private readonly fb = new FormBuilder();

  readonly form = this.fb.group({
    method: ['CREDIT_CARD', Validators.required],
    cardholderName: [''],
    cardNumber: [''],
    expiry: [''],
    cvv: [''],
    upiId: [''],
    bankName: ['']
  });

  constructor(
    private readonly route: ActivatedRoute,
    private readonly router: Router,
    private readonly customerApi: CustomerApiService,
    private readonly paymentApi: PaymentApiService
  ) {}

  ngOnInit(): void {
    this.form.controls.method.valueChanges.subscribe(method => {
      this.updatePaymentValidators(method as PaymentMethod);
    });
    this.updatePaymentValidators('CREDIT_CARD');

    const id = this.route.snapshot.paramMap.get('id');

    if (!id) {
      this.error = 'Policy application is missing.';
      this.loading = false;
      return;
    }

    this.customerApi.getApplication(id).subscribe({
      next: application => {
        if (application.status !== 'APPROVED') {
          this.error = 'Payments can only be made for approved policies.';
        }
        this.application = application;
        this.loading = false;
      },
      error: () => {
        this.error = 'Unable to load this policy application.';
        this.loading = false;
      }
    });
  }

  pay(): void {
    if (!this.application) {
      return;
    }

    if (this.form.invalid) {
      this.form.markAllAsTouched();
      this.error = 'Complete all required payment details.';
      return;
    }

    if (this.requiresCardDetails && !this.isExpiryValid(this.form.controls.expiry.value ?? '')) {
      this.form.controls.expiry.setErrors({ expired: true });
      this.error = 'Enter a valid future card expiry date.';
      return;
    }

    this.submitting = true;
    this.error = '';

    this.paymentApi.makePayment({
      idempotency_key: crypto.randomUUID(),
      policy_application_id: this.application.id,
      amount: this.application.premiumAmount ?? 0,
      method: this.form.controls.method.value as never
    }).subscribe({
      next: payment => {
        this.payment = payment;
        this.submitting = false;
      },
      error: (error: unknown) => {
        this.submitting = false;
        this.error = (error as { error?: { message?: string } })?.error?.message ?? 'Payment could not be processed.';
      }
    });
  }

  viewReceipt(): void {
    if (!this.payment || this.loadingReceipt) {
      return;
    }

    const receiptWindow = window.open('about:blank', '_blank');
    if (receiptWindow) {
      receiptWindow.opener = null;
    }

    this.loadingReceipt = true;
    this.error = '';
    this.paymentApi.listDocuments(this.payment.id).subscribe({
      next: documents => {
        this.loadingReceipt = false;
        const receipt = documents.find(document => document.systemGenerated) ?? documents[0];
        const url = receipt?.download?.url;

        if (!url) {
          receiptWindow?.close();
          this.error = 'The payment receipt is not available yet.';
          return;
        }

        if (receiptWindow) {
          receiptWindow.location.href = url;
        } else {
          this.error = 'The receipt window was blocked. Allow pop-ups and try again.';
        }
      },
      error: error => {
        receiptWindow?.close();
        this.loadingReceipt = false;
        this.error = this.paymentApi.errorMessage(error, 'receipt');
      }
    });
  }

  goToPayments(): void {
    this.router.navigate(['/customer/payments']);
  }

  get requiresCardDetails(): boolean {
    const method = this.form.controls.method.value;
    return method === 'CREDIT_CARD' || method === 'DEBIT_CARD';
  }

  private updatePaymentValidators(method: PaymentMethod): void {
    const cardControls = [
      this.form.controls.cardholderName,
      this.form.controls.cardNumber,
      this.form.controls.expiry,
      this.form.controls.cvv
    ];

    cardControls.forEach(control => control.clearValidators());
    this.form.controls.upiId.clearValidators();
    this.form.controls.bankName.clearValidators();

    if (method === 'CREDIT_CARD' || method === 'DEBIT_CARD') {
      this.form.controls.cardholderName.setValidators([Validators.required, Validators.minLength(2)]);
      this.form.controls.cardNumber.setValidators([Validators.required, Validators.pattern(/^(?:\d[ -]?){15}\d$/)]);
      this.form.controls.expiry.setValidators([Validators.required, Validators.pattern(/^(0[1-9]|1[0-2])\/\d{2}$/)]);
      this.form.controls.cvv.setValidators([Validators.required, Validators.pattern(/^\d{3,4}$/)]);
    } else if (method === 'UPI') {
      this.form.controls.upiId.setValidators([Validators.required, Validators.pattern(/^[\w.-]+@[\w.-]+$/)]);
    } else if (method === 'NET_BANKING') {
      this.form.controls.bankName.setValidators(Validators.required);
    }

    [...cardControls, this.form.controls.upiId, this.form.controls.bankName]
      .forEach(control => control.updateValueAndValidity({ emitEvent: false }));
  }

  private isExpiryValid(expiry: string): boolean {
    const match = /^(0[1-9]|1[0-2])\/(\d{2})$/.exec(expiry);
    if (!match) {
      return false;
    }

    const month = Number(match[1]);
    const year = 2000 + Number(match[2]);
    const expiryDate = new Date(year, month, 0, 23, 59, 59);
    return expiryDate >= new Date();
  }
}

import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';

import { PolicyApplication } from '../../../types/br04-05.types';
import { CustomerApiService } from '../../../services/api/customer-api.service';
import { ClaimApiService } from '../../../services/api/claim-api.service';
import { ApiFieldError } from '../../../core/errors/api-error.model';
import { getApiError } from '../../../core/errors/api-error.util';

@Component({
  selector: 'app-file-claim',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './file-claim.component.html',
  styleUrls: ['./file-claim.component.css']
})
export class FileClaimComponent implements OnInit {

  applications: PolicyApplication[] = [];
  loading = true;
  submitting = false;
  uploading = false;
  submissionComplete = false;
  error = '';
  message = '';
  fieldErrors: ApiFieldError[] = [];
  correlationId?: string;
  today = new Date().toISOString().slice(0, 10);
  selectedDocument: File | null = null;
  private submissionKey = '';

  private readonly fb = new FormBuilder();

  readonly form = this.fb.group({
    policyApplicationId: ['', Validators.required],
    incidentType: ['ACCIDENT', Validators.required],
    otherIncident: [''],
    incidentDate: ['', Validators.required],
    amount: ['', [Validators.required, Validators.min(0.01)]],
    description: ['', [Validators.required, Validators.maxLength(850)]]
  });

  constructor(
    private readonly route: ActivatedRoute,
    private readonly router: Router,
    private readonly customerApi: CustomerApiService,
    private readonly claimApi: ClaimApiService
  ) {}

  get selectedApplication(): PolicyApplication | undefined {
    return this.applications.find(item => item.id === this.form.controls.policyApplicationId.value);
  }

  get isOtherIncident(): boolean {
    return this.form.controls.incidentType.value === 'OTHER';
  }

  ngOnInit(): void {
    this.form.controls.incidentType.valueChanges.subscribe(incidentType => {
      const otherIncident = this.form.controls.otherIncident;
      if (incidentType === 'OTHER') {
        otherIncident.setValidators([Validators.required, Validators.maxLength(120)]);
      } else {
        otherIncident.clearValidators();
        otherIncident.setValue('');
      }
      otherIncident.updateValueAndValidity();
    });

    this.customerApi.getApplications('APPROVED').subscribe({
      next: applications => {
        this.applications = applications;
        this.loading = false;

        const preselected = this.route.snapshot.queryParamMap.get('applicationId');
        if (preselected) {
          this.form.controls.policyApplicationId.setValue(preselected);
        }
      },
      error: () => {
        this.error = 'Unable to load your approved policies.';
        this.loading = false;
      }
    });
  }

  submit(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }

    const documentError = this.validateDocument(this.selectedDocument);
    if (documentError || !this.selectedDocument) {
      this.error = documentError ?? 'Select a supporting document.';
      return;
    }

    const value = this.form.getRawValue();
    const amount = Number(value.amount);
    const coverage = this.selectedApplication?.coverageAmount ?? Number.MAX_SAFE_INTEGER;

    if (amount <= 0 || amount >= coverage) {
      this.error = 'Claim amount must be greater than zero and less than the coverage amount.';
      return;
    }

    this.submitting = true;
    this.error = '';
    this.fieldErrors = [];
    this.correlationId = undefined;
    const description = this.isOtherIncident
      ? `Other incident: ${value.otherIncident?.trim()}\n\n${value.description?.trim()}`
      : value.description?.trim() ?? '';

    this.submissionKey ||= crypto.randomUUID();
    this.claimApi.fileWithDocument({
      idempotencyKey: this.submissionKey,
      policyApplicationId: value.policyApplicationId as string,
      incidentType: value.incidentType as never,
      incidentDate: value.incidentDate as string,
      amount,
      description
    }, this.selectedDocument).subscribe({
      next: () => {
        this.message = 'Claim and supporting document submitted successfully.';
        this.submissionComplete = true;
        this.submitting = false;
      },
      error: error => {
        this.submitting = false;
        const apiError = getApiError(error);
        this.error = apiError?.message ?? this.claimApi.errorMessage(error, 'submit');
        this.fieldErrors = apiError?.fieldErrors ?? [];
        this.correlationId = apiError?.correlationId;
      }
    });
  }

  fieldError(controlName: string): string | undefined {
    return this.fieldErrors.find(fieldError => fieldError.field === controlName)?.message;
  }

  selectDocument(event: Event): void {
    const input = event.target as HTMLInputElement;
    const file = input.files?.[0] ?? null;
    const validationError = this.validateDocument(file);

    this.selectedDocument = validationError ? null : file;
    this.error = validationError ?? '';

    if (validationError) {
      input.value = '';
    }
  }

  private validateDocument(file: File | null): string | null {
    if (!file) {
      return 'Select a supporting document before submitting the claim.';
    }

    const allowedTypes = ['application/pdf', 'image/jpeg', 'image/png'];
    if (!allowedTypes.includes(file.type)) {
      return 'Upload a PDF, JPG, JPEG, or PNG document.';
    }

    if (file.size > 10 * 1024 * 1024) {
      return 'The document must be 10 MB or smaller.';
    }

    return null;
  }

  done(): void {
    this.router.navigate(['/customer/claims']);
  }
}

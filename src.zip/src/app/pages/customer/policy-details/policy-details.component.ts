import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormArray, FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';

import { Policy, PolicyApplicationCreateRequest, DependentRequest, Relationship, Gender } from '../../../types/br04-05.types';
import { CustomerApiService } from '../../../services/api/customer-api.service';
import { DependentApiService } from '../../../services/api/dependent-api.service';

@Component({
  selector: 'app-policy-details',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './policy-details.component.html',
  styleUrls: ['./policy-details.component.css']
})
export class PolicyDetailsComponent implements OnInit {

  policy: Policy | null = null;
  loading = true;
  submitting = false;
  error = '';
  message = '';
  showApplyForm = false;
  today = new Date().toISOString().slice(0, 10);

  private readonly fb = new FormBuilder();

  readonly applicationForm = this.fb.group({
    coverage_type: ['SINGLE', Validators.required],
    date_of_birth: ['', Validators.required],
    address: ['', Validators.required],
    preferred_start_date: [''],
    nominee_name: [''],
    nominee_relationship: [''],
    dependents: this.fb.array<ReturnType<FormBuilder['group']>>([])
  });

  constructor(
    private readonly route: ActivatedRoute,
    private readonly router: Router,
    private readonly customerApi: CustomerApiService,
    private readonly dependentApi: DependentApiService
  ) {}

  get dependents(): FormArray {
    return this.applicationForm.get('dependents') as FormArray;
  }

  get isGroup(): boolean {
    return this.applicationForm.controls.coverage_type.value === 'GROUP';
  }

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id');

    if (!id) {
      this.error = 'Policy not found.';
      this.loading = false;
      return;
    }

    this.showApplyForm = this.route.snapshot.queryParamMap.get('apply') === '1';

    this.customerApi.getPolicy(id).subscribe({
      next: policy => {
        this.policy = policy;
        this.loading = false;
      },
      error: () => {
        this.error = 'Unable to load this policy.';
        this.loading = false;
      }
    });

    this.applicationForm.controls.coverage_type.valueChanges.subscribe(value => {
      if (value === 'GROUP' && this.dependents.length === 0) {
        this.addDependent();
      }
      if (value !== 'GROUP') {
        this.dependents.clear();
      }
    });
  }

  toggleApplyForm(): void {
    this.showApplyForm = !this.showApplyForm;
  }

  addDependent(): void {
    if (this.dependents.length >= 4) {
      return;
    }

    this.dependents.push(this.fb.group({
      full_name: ['', Validators.required],
      relationship: ['SPOUSE', Validators.required],
      date_of_birth: ['', Validators.required],
      gender: ['MALE', Validators.required]
    }));
  }

  removeDependent(index: number): void {
    this.dependents.removeAt(index);
  }

  submitApplication(): void {
    if (!this.policy) {
      return;
    }

    if (this.applicationForm.controls.preferred_start_date.value) {
      const preferred = this.applicationForm.controls.preferred_start_date.value as string;
      if (preferred < this.today) {
        this.error = 'Preferred start date cannot be in the past.';
        return;
      }
    }

    if (this.isGroup && this.dependents.length === 0) {
      this.error = 'At least one dependent is required for group coverage.';
      return;
    }

    if (this.applicationForm.invalid) {
      this.applicationForm.markAllAsTouched();
      return;
    }

    this.submitting = true;
    this.error = '';

    const value = this.applicationForm.getRawValue();
    const dependents = value.dependents;

    const request: PolicyApplicationCreateRequest = {
      policy_id: this.policy.id,
      coverage_type: value.coverage_type ?? '',
      date_of_birth: value.date_of_birth ?? '',
      address: value.address ?? '',
      preferred_start_date: value.preferred_start_date || null,
      nominee_name: value.nominee_name || null,
      nominee_relationship: value.nominee_relationship || null
    };

    this.customerApi.createApplication(request).subscribe({
      next: application => {
        this.submitting = false;

        if (dependents.length === 0) {
          this.message = 'Your application has been submitted for review.';
          setTimeout(() => this.router.navigate(['/customer/my-policies']), 900);
          return;
        }

        this.saveDependents(application.id, dependents);
      },
      error: (error: unknown) => {
        this.submitting = false;
        this.error = (error as { error?: { message?: string } })?.error?.message ?? 'We could not submit this application.';
      }
    });
  }

  private saveDependents(applicationId: string, dependents: Array<Record<string, string>>): void {
    const requests: DependentRequest[] = dependents.map(dependent => ({
      full_name: dependent['full_name'],
      relationship: dependent['relationship'] as Relationship,
      date_of_birth: dependent['date_of_birth'],
      gender: dependent['gender'] as Gender
    }));

    let index = 0;
    const finish = (): void => {
      this.message = 'Your application and dependents were submitted for review.';
      setTimeout(() => this.router.navigate(['/customer/my-policies']), 900);
    };

    const next = (): void => {
      if (index >= requests.length) {
        finish();
        return;
      }

      const request = requests[index];
      index += 1;

      this.dependentApi.add(applicationId, request).subscribe({
        next: () => next(),
        error: () => next()
      });
    };

    next();
  }
}

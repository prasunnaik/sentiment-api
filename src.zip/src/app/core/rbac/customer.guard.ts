import { inject } from '@angular/core';
import {
  CanActivateFn,
  Router
} from '@angular/router';

import { AuthService } from '../auth/auth.service';

export const customerGuard: CanActivateFn = () => {

  const authService = inject(AuthService);
  const router = inject(Router);

  if (
    authService.isLoggedIn() &&
    authService.isCustomer()
  ) {
    return true;
  }

  authService.logout();

  return router.createUrlTree(['/auth/customer-login']);
};

import { inject } from '@angular/core';
import {
  CanActivateFn,
  Router
} from '@angular/router';

import { AuthService } from '../auth/auth.service';

/**
 * Route guard that ensures only authenticated staff users can access protected routes.
 * If the user is not logged in or is not a staff member, they are logged out and redirected to the staff login page.
 * @returns {boolean | UrlTree} true if the user is an authenticated staff member, or a UrlTree redirecting to login
 */
export const staffGuard: CanActivateFn = () => {

  const authService = inject(AuthService);
  const router = inject(Router);

  if (
    authService.isLoggedIn() &&
    authService.isStaff()
  ) {
    return true;
  }

  authService.logout();

  return router.createUrlTree(['/auth/staff-login']);
};
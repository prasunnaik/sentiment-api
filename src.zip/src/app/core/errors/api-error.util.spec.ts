import { formatErrorMessage, hasFieldErrors, formatFieldErrors, getErrorCategory } from './api-error.util';
import { ApiError } from './api-error.model';

describe('Error Utilities', () => {
  describe('formatErrorMessage()', () => {
    it('should return the message as-is when it is user-friendly', () => {
      const error: ApiError = {
        timestamp: '2025-09-22T00:00:00Z',
        status: 400,
        errorCode: 'VALIDATION_ERROR',
        message: 'Email is already registered'
      };

      expect(formatErrorMessage(error)).toBe('Email is already registered');
    });

    it('should return generic message when error message is empty', () => {
      const error: ApiError = {
        timestamp: '2025-09-22T00:00:00Z',
        status: 500,
        errorCode: 'UNKNOWN_ERROR',
        message: ''
      };

      expect(formatErrorMessage(error)).toBe('An unexpected error occurred. Please try again.');
    });

    it('should return generic message when error message is null', () => {
      const error: ApiError = {
        timestamp: '2025-09-22T00:00:00Z',
        status: 500,
        errorCode: 'UNKNOWN_ERROR',
        message: null as any
      };

      expect(formatErrorMessage(error)).toBe('An unexpected error occurred. Please try again.');
    });
  });

  describe('hasFieldErrors()', () => {
    it('should return true when fieldErrors array exists and has items', () => {
      const error: ApiError = {
        timestamp: '2025-09-22T00:00:00Z',
        status: 400,
        errorCode: 'VALIDATION_ERROR',
        message: 'Validation failed',
        fieldErrors: [
          { field: 'email', message: 'Invalid email' }
        ]
      };

      expect(hasFieldErrors(error)).toBe(true);
    });

    it('should return false when fieldErrors is undefined', () => {
      const error: ApiError = {
        timestamp: '2025-09-22T00:00:00Z',
        status: 400,
        errorCode: 'VALIDATION_ERROR',
        message: 'Validation failed'
      };

      expect(hasFieldErrors(error)).toBe(false);
    });

    it('should return false when fieldErrors is empty array', () => {
      const error: ApiError = {
        timestamp: '2025-09-22T00:00:00Z',
        status: 400,
        errorCode: 'VALIDATION_ERROR',
        message: 'Validation failed',
        fieldErrors: []
      };

      expect(hasFieldErrors(error)).toBe(false);
    });
  });

  describe('formatFieldErrors()', () => {
    it('should return map of field names to error messages', () => {
      const error: ApiError = {
        timestamp: '2025-09-22T00:00:00Z',
        status: 400,
        errorCode: 'VALIDATION_ERROR',
        message: 'Validation failed',
        fieldErrors: [
          { field: 'email', message: 'Invalid email format' },
          { field: 'password', message: 'Password too short' },
          { field: 'phone', message: 'Invalid phone number' }
        ]
      };

      const fieldErrors = formatFieldErrors(error);

      expect(fieldErrors.get('email')).toBe('Invalid email format');
      expect(fieldErrors.get('password')).toBe('Password too short');
      expect(fieldErrors.get('phone')).toBe('Invalid phone number');
      expect(fieldErrors.size).toBe(3);
    });

    it('should return empty map when fieldErrors is undefined', () => {
      const error: ApiError = {
        timestamp: '2025-09-22T00:00:00Z',
        status: 400,
        errorCode: 'VALIDATION_ERROR',
        message: 'Validation failed'
      };

      const fieldErrors = formatFieldErrors(error);

      expect(fieldErrors.size).toBe(0);
    });

    it('should return empty map when fieldErrors is empty array', () => {
      const error: ApiError = {
        timestamp: '2025-09-22T00:00:00Z',
        status: 400,
        errorCode: 'VALIDATION_ERROR',
        message: 'Validation failed',
        fieldErrors: []
      };

      const fieldErrors = formatFieldErrors(error);

      expect(fieldErrors.size).toBe(0);
    });
  });

  describe('getErrorCategory()', () => {
    it('should return category for VALIDATION_ERROR', () => {
      expect(getErrorCategory('VALIDATION_ERROR')).toBe('Validation Error');
    });

    it('should return category for AUTHENTICATION_ERROR', () => {
      expect(getErrorCategory('AUTHENTICATION_ERROR')).toBe('Login Failed');
    });

    it('should return category for AUTHORIZATION_ERROR', () => {
      expect(getErrorCategory('AUTHORIZATION_ERROR')).toBe('Access Denied');
    });

    it('should return category for NOT_FOUND_ERROR', () => {
      expect(getErrorCategory('NOT_FOUND_ERROR')).toBe('Not Found');
    });

    it('should return category for CONFLICT_ERROR', () => {
      expect(getErrorCategory('CONFLICT_ERROR')).toBe('Resource Conflict');
    });

    it('should return category for NETWORK_ERROR', () => {
      expect(getErrorCategory('NETWORK_ERROR')).toBe('Connection Error');
    });

    it('should return category for UNKNOWN_ERROR', () => {
      expect(getErrorCategory('UNKNOWN_ERROR')).toBe('Error');
    });

    it('should return generic Error category for unknown error code', () => {
      expect(getErrorCategory('SOME_UNKNOWN_CODE')).toBe('Error');
    });
  });
});

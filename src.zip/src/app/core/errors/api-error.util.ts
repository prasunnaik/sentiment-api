import { HttpErrorResponse } from '@angular/common/http';
import { ApiError } from './api-error.model';

/**
 * Extracts the normalized `ApiError` from an error thrown by an HTTP call.
 * Returns null when the error does not carry the standardized shape
 * (for example when the error interceptor is not present, such as in unit tests).
 */
export function getApiError(error: unknown): ApiError | null {
  if (!(error instanceof HttpErrorResponse)) {
    return null;
  }

  const body = error.error;
  if (body && typeof body === 'object' && typeof (body as ApiError).message === 'string') {
    return body as ApiError;
  }

  return null;
}

/**
 * Formats an ApiError into a human-readable message for UI display
 * Removes technical error codes and stack traces, shows user-friendly text
 * @param {ApiError} error - The API error to format
 * @returns {string} Human-readable error message
 */
export function formatErrorMessage(error: ApiError): string {
  // Return the message as-is since backend should already provide user-friendly text
  return error.message || 'An unexpected error occurred. Please try again.';
}

/**
 * Checks if an error contains field-level validation errors
 * @param {ApiError} error - The API error to check
 * @returns {boolean} true if the error has field-level errors
 */
export function hasFieldErrors(error: ApiError): boolean {
  return !!error.fieldErrors && error.fieldErrors.length > 0;
}

/**
 * Formats field errors for display in forms
 * @param {ApiError} error - The API error containing field errors
 * @returns {Map<string, string>} Map of field name to error message
 */
export function formatFieldErrors(error: ApiError): Map<string, string> {
  const fieldErrorMap = new Map<string, string>();

  if (error.fieldErrors) {
    error.fieldErrors.forEach(fieldError => {
      fieldErrorMap.set(fieldError.field, fieldError.message);
    });
  }

  return fieldErrorMap;
}

/**
 * Gets a friendly error category name for display purposes
 * @param {string} errorCode - The backend error code
 * @returns {string} User-friendly error category
 */
export function getErrorCategory(errorCode: string): string {
  const categoryMap: { [key: string]: string } = {
    'VALIDATION_ERROR': 'Validation Error',
    'AUTHENTICATION_ERROR': 'Login Failed',
    'AUTHORIZATION_ERROR': 'Access Denied',
    'NOT_FOUND_ERROR': 'Not Found',
    'CONFLICT_ERROR': 'Resource Conflict',
    'NETWORK_ERROR': 'Connection Error',
    'UNKNOWN_ERROR': 'Error'
  };

  return categoryMap[errorCode] || 'Error';
}


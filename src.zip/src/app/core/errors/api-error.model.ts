/** Field-level validation error, mirrors backend `ApiFieldError`. */
export interface ApiFieldError {
  field: string;
  message: string;
}

/** Normalized shape of every backend error response (`ApiErrorResponse`) and client-side failures. */
export interface ApiError {
  timestamp: string;
  status: number;
  errorCode: string;
  message: string;
  path?: string;
  correlationId?: string;
  fieldErrors?: ApiFieldError[];
}

import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { HttpClient, HttpErrorResponse, HTTP_INTERCEPTORS } from '@angular/common/http';
import { ErrorInterceptor } from './error.interceptor';
import { ToastService } from '../../components/common/toast/toast.service';

describe('ErrorInterceptor', () => {
  let httpClient: HttpClient;
  let httpMock: HttpTestingController;
  let toastService: ToastService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [
        ToastService,
        { provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true }
      ]
    });

    httpClient = TestBed.inject(HttpClient);
    httpMock = TestBed.inject(HttpTestingController);
    toastService = TestBed.inject(ToastService);
  });

  afterEach(() => {
    httpMock.verify();
  });

  it('should pass through successful requests', () => {
    const mockData = { message: 'success' };

    httpClient.get('/api/test').subscribe((data) => {
      expect(data).toEqual(mockData);
    });

    const req = httpMock.expectOne('/api/test');
    expect(req.request.method).toBe('GET');
    req.flush(mockData);
  });

  it('should handle network errors (status 0)', () => {
    let errorCaught = false;
    httpClient.get('/api/test').subscribe(
      () => fail('should have failed'),
      (error: HttpErrorResponse) => {
        errorCaught = true;
        expect((error.error as any).errorCode).toBe('NETWORK_ERROR');
        expect((error.error as any).message).toContain('Unable to reach the server');
      }
    );

    const req = httpMock.expectOne('/api/test');
    req.error(new ErrorEvent('Network error'));
  });

  it('should normalize backend API error responses', () => {
    const backendError = {
      status: 400,
      errorCode: 'INVALID_INPUT',
      message: 'Validation failed',
      timestamp: '2025-09-22T00:00:00Z',
      correlationId: 'corr-123',
      fieldErrors: { email: 'Invalid email' }
    };

    let errorCaught = false;
    httpClient.get('/api/test').subscribe(
      () => fail('should have failed'),
      (error: HttpErrorResponse) => {
        errorCaught = true;
        const apiError = error.error;
        expect(apiError.errorCode).toBe('INVALID_INPUT');
        expect(apiError.message).toBe('Validation failed');
        expect(apiError.correlationId).toBe('corr-123');
      }
    );

    const req = httpMock.expectOne('/api/test');
    req.flush(backendError, { status: 400, statusText: 'Bad Request' });
  });

  it('should extract correlation ID from response headers', () => {
    const errorResponse = {
      status: 500,
      errorCode: 'INTERNAL_ERROR',
      message: 'Server error'
    };

    httpClient.get('/api/test').subscribe(
      () => fail('should have failed'),
      (error: HttpErrorResponse) => {
        expect((error.error as any).correlationId).toBe('header-corr-456');
      }
    );

    const req = httpMock.expectOne('/api/test');
    req.flush(errorResponse, {
      status: 500,
      statusText: 'Internal Server Error',
      headers: { 'X-Correlation-Id': 'header-corr-456' }
    });
  });

  it('should show toast for unexpected errors (5xx)', (done) => {
    const toastSpy = spyOn(toastService, 'error');

    httpClient.get('/api/test').subscribe(
      () => fail('should have failed'),
      () => {
        expect(toastSpy).toHaveBeenCalledWith(
          'Something went wrong. Please try again.',
          undefined
        );
        done();
      }
    );

    const req = httpMock.expectOne('/api/test');
    req.error(
      new ErrorEvent('Server error'),
      { status: 500, statusText: 'Internal Server Error' }
    );
  });

  it('should not show toast for expected errors (4xx validation)', () => {
    const toastSpy = spyOn(toastService, 'error');

    httpClient.get('/api/test').subscribe(
      () => fail('should have failed'),
      () => {
        expect(toastSpy).not.toHaveBeenCalled();
      }
    );

    const req = httpMock.expectOne('/api/test');
    req.flush(
      {
        status: 400,
        errorCode: 'VALIDATION_ERROR',
        message: 'Invalid input'
      },
      { status: 400, statusText: 'Bad Request' }
    );
  });

  it('should handle non-JSON error responses', () => {
    httpClient.get('/api/test').subscribe(
      () => fail('should have failed'),
      (error: HttpErrorResponse) => {
        expect((error.error as any).errorCode).toBe('UNKNOWN_ERROR');
        expect((error.error as any).message).toBe('Something went wrong. Please try again.');
      }
    );

    const req = httpMock.expectOne('/api/test');
    req.flush('Plain text error', { status: 500, statusText: 'Internal Server Error' });
  });

  describe('Message Sanitization', () => {
    it('should sanitize stack trace from error message', () => {
      const toastSpy = spyOn(toastService, 'error');

      httpClient.get('/api/test').subscribe(
        () => fail('should have failed'),
        () => {
          expect(toastSpy).toHaveBeenCalled();
          const calledMessage = toastSpy.calls.mostRecent().args[0];
          expect(calledMessage).not.toContain('at java');
          expect(calledMessage).not.toContain('.java:');
        }
      );

      const req = httpMock.expectOne('/api/test');
      req.flush(
        {
          status: 500,
          errorCode: 'INTERNAL_ERROR',
          message: 'NullPointerException at UserService.java:45'
        },
        { status: 500, statusText: 'Internal Server Error' }
      );
    });

    it('should remove Exception keyword from error message', () => {
      const toastSpy = spyOn(toastService, 'error');

      httpClient.get('/api/test').subscribe(
        () => fail('should have failed'),
        () => {
          const calledMessage = toastSpy.calls.mostRecent().args[0];
          expect(calledMessage).not.toContain('Exception');
        }
      );

      const req = httpMock.expectOne('/api/test');
      req.flush(
        {
          status: 500,
          errorCode: 'INTERNAL_ERROR',
          message: 'SQLException: constraint violation'
        },
        { status: 500, statusText: 'Internal Server Error' }
      );
    });

    it('should show generic message for technical errors', () => {
      const toastSpy = spyOn(toastService, 'error');

      httpClient.get('/api/test').subscribe(
        () => fail('should have failed'),
        () => {
          const calledMessage = toastSpy.calls.mostRecent().args[0];
          expect(calledMessage).toBe('Something went wrong. Please try again.');
        }
      );

      const req = httpMock.expectOne('/api/test');
      req.flush(
        {
          status: 500,
          errorCode: 'INTERNAL_ERROR',
          message: 'Error: undefined is not a function'
        },
        { status: 500, statusText: 'Internal Server Error' }
      );
    });

    it('should preserve user-friendly messages', () => {
      const toastSpy = spyOn(toastService, 'error');

      httpClient.get('/api/test').subscribe(
        () => fail('should have failed'),
        () => {
          const calledMessage = toastSpy.calls.mostRecent().args[0];
          expect(calledMessage).toBe('Email is already registered');
        }
      );

      const req = httpMock.expectOne('/api/test');
      req.flush(
        {
          status: 400,
          errorCode: 'CONFLICT_ERROR',
          message: 'Email is already registered'
        },
        { status: 400, statusText: 'Bad Request' }
      );
    });
  });
});

/**
 * Mock class for ErrorEvent as it's not directly constructible
 */
class ErrorResponse {
  constructor(private options: { status: number; statusText: string }) {}
}


import { Injectable } from '@angular/core';
import {
  HttpErrorResponse,
  HttpEvent,
  HttpHandler,
  HttpInterceptor,
  HttpRequest
} from '@angular/common/http';
import { Observable, catchError, throwError } from 'rxjs';

import { ApiError } from '../errors/api-error.model';
import { ToastService } from '../../components/common/toast/toast.service';

const CORRELATION_HEADER = 'X-Correlation-Id';

/**
 * Normalizes every backend/network failure into the standardized `ApiError` shape,
 * logs diagnostics (with correlation id) without exposing stack traces to the UI,
 * and surfaces unexpected failures (network/5xx) as a toast. Expected, request-specific
 * failures (validation, conflicts, not-found, etc.) are left for the calling component
 * to render inline via its existing banner/form-error pattern.
 */
@Injectable()
export class ErrorInterceptor implements HttpInterceptor {

  constructor(private readonly toast: ToastService) {}

  /**
   * Intercepts HTTP errors and normalizes them to ApiError format
   * @param {HttpRequest<unknown>} req - The HTTP request
   * @param {HttpHandler} next - The next HTTP handler
   * @returns {Observable<HttpEvent<unknown>>} Observable of the HTTP event or error
   */
  intercept(req: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>> {
    return next.handle(req).pipe(
      catchError((error: HttpErrorResponse) => {
        const apiError = this.normalize(error);

        console.error(
          `[HTTP ${apiError.status}] ${req.method} ${req.urlWithParams} errorCode=${apiError.errorCode} correlationId=${apiError.correlationId ?? 'unknown'}`
        );

        if (this.isUnexpected(apiError)) {
          const userMessage = this.getUserFriendlyMessage(apiError);
          this.toast.error(userMessage, apiError.correlationId);
        }

        const normalized = new HttpErrorResponse({
          error: apiError,
          headers: error.headers,
          status: error.status,
          statusText: error.statusText,
          url: error.url ?? undefined
        });

        return throwError(() => normalized);
      })
    );
  }

  /**
   * Normalizes HTTP error response to standardized ApiError format
   * @private
   * @param {HttpErrorResponse} error - The HTTP error response
   * @returns {ApiError} Normalized API error object
   */
  private normalize(error: HttpErrorResponse): ApiError {
    const correlationId = error.headers?.get(CORRELATION_HEADER) ?? this.bodyCorrelationId(error);

    if (error.status === 0) {
      return {
        timestamp: new Date().toISOString(),
        status: 0,
        errorCode: 'NETWORK_ERROR',
        message: 'Unable to reach the server. Check your connection and try again.',
        correlationId
      };
    }

    const body = error.error;
    if (body && typeof body === 'object' && typeof (body as ApiError).message === 'string') {
      const backendError = body as ApiError;
      return {
        timestamp: backendError.timestamp ?? new Date().toISOString(),
        status: backendError.status ?? error.status,
        errorCode: backendError.errorCode ?? 'UNKNOWN_ERROR',
        message: backendError.message,
        path: backendError.path,
        correlationId: backendError.correlationId ?? correlationId,
        fieldErrors: backendError.fieldErrors
      };
    }

    // Non-JSON or unrecognized error body: never surface the raw payload/stack trace.
    return {
      timestamp: new Date().toISOString(),
      status: error.status,
      errorCode: 'UNKNOWN_ERROR',
      message: 'Something went wrong. Please try again.',
      correlationId
    };
  }

  /**
   * Extracts correlation ID from the error response body
   * @private
   * @param {HttpErrorResponse} error - The HTTP error response
   * @returns {string | undefined} Correlation ID from the error body or undefined
   */
  private bodyCorrelationId(error: HttpErrorResponse): string | undefined {
    const body = error.error;
    return body && typeof body === 'object' ? (body as ApiError).correlationId : undefined;
  }

  /**
   * Checks if an error is unexpected (network, unknown, or server error)
   * @private
   * @param {ApiError} apiError - The normalized API error
   * @returns {boolean} true if the error is unexpected and should be toasted
   */
  private isUnexpected(apiError: ApiError): boolean {
    return apiError.errorCode === 'NETWORK_ERROR'
      || apiError.errorCode === 'UNKNOWN_ERROR'
      || apiError.status >= 500;
  }

  /**
   * Sanitizes error messages to remove technical details and stack traces
   * Ensures only user-friendly text is displayed
   * @private
   * @param {string} message - The raw error message
   * @returns {string} Sanitized, user-friendly error message
   */
  private sanitizeMessage(message: string): string {
    if (!message) {
      return 'Something went wrong. Please try again.';
    }

    // Remove stack traces (anything after the first line if it contains "at ")
    const firstLine = message.split('\n')[0];
    if (firstLine.includes('at ') || firstLine.includes('Error:')) {
      return 'Something went wrong. Please try again.';
    }

    // Remove common technical patterns
    const sanitized = message
      .replace(/\[ERROR\]/gi, '')
      .replace(/Exception|Error|error:/gi, '')
      .replace(/\.java:\d+\)/g, '')
      .replace(/null|undefined/gi, 'system')
      .trim();

    // If message is empty or too technical, return generic message
    if (!sanitized || sanitized.length === 0 || /^[a-z_]+\.?$/.test(sanitized)) {
      return 'Something went wrong. Please try again.';
    }

    return sanitized;
  }

  /**
   * Gets a user-friendly message for display in toast notifications
   * @private
   * @param {ApiError} error - The API error
   * @returns {string} User-friendly error message for toast
   */
  private getUserFriendlyMessage(error: ApiError): string {
    // Sanitize the message to ensure it doesn't contain technical details
    const sanitized = this.sanitizeMessage(error.message);
    return sanitized || 'An error occurred. Please try again.';
  }
}

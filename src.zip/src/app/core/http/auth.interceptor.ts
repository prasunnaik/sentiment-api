
import { Injectable } from '@angular/core';
import {
  HttpInterceptor,
  HttpRequest,
  HttpHandler
} from '@angular/common/http';

@Injectable()
export class AuthInterceptor implements HttpInterceptor {

  /**
   * Adds Bearer token to outgoing HTTP requests if a token is available
   * @param {HttpRequest<any>} req - The HTTP request
   * @param {HttpHandler} next - The next HTTP handler
   * @returns {Observable} The next handler observable
   */
  intercept(req: HttpRequest<any>, next: HttpHandler) {

    const token =
      localStorage.getItem('insurewise_token');

    if (token && !req.headers.has('Authorization')) {

      req = req.clone({
        setHeaders: {
          Authorization: `Bearer ${token}`
        }
      });
    }

    return next.handle(req);
  }
}



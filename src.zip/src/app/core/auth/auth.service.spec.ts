import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { provideHttpClient } from '@angular/common/http';
import { TestBed } from '@angular/core/testing';

import { API_CONFIG } from '../environment/api.config';
import { AuthService, LoginResponse } from './auth.service';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';

describe('AuthService', () => {
  let service: AuthService;
  let http: HttpTestingController;

  const mockLoginResponse: LoginResponse = {
    access_token: 'test-token-123',
    token_type: 'Bearer',
    user_id: 'user-123',
    email: 'test@example.com',
    role: 'STAFF'
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [provideHttpClient(), provideHttpClientTesting()]
    });
    service = TestBed.inject(AuthService);
    http = TestBed.inject(HttpTestingController);
    localStorage.clear();
  });

  afterEach(() => {
    http.verify();
    localStorage.clear();
  });

  describe('login()', () => {
    it('should send POST request to staff login endpoint', () => {
      const credentials = { email: 'staff@test.com', password: 'password123' };
      service.login(credentials).subscribe();

      const request = http.expectOne(`${API_CONFIG.baseUrl}/auth/staff/login`);
      expect(request.request.method).toBe('POST');
      expect(request.request.body).toEqual(credentials);
    });

    it('should store token and role in localStorage on successful staff login', () => {
      service.login({ email: 'staff@test.com', password: 'password123' }).subscribe();

      const request = http.expectOne(`${API_CONFIG.baseUrl}/auth/staff/login`);
      request.flush(mockLoginResponse);

      expect(localStorage.getItem('insurewise_token')).toBe('test-token-123');
      expect(localStorage.getItem('insurewise_role')).toBe('STAFF');
    });
  });

  describe('loginCustomer()', () => {
    it('should send POST request to customer login endpoint', () => {
      const credentials = { email: 'customer@test.com', password: 'password123' };
      service.loginCustomer(credentials).subscribe();

      const request = http.expectOne(`${API_CONFIG.baseUrl}/auth/customers/login`);
      expect(request.request.method).toBe('POST');
      expect(request.request.body).toEqual(credentials);
    });

    it('should store token and role in localStorage on customer login', () => {
      const customerResponse: LoginResponse = { ...mockLoginResponse, role: 'CUSTOMER' };
      service.loginCustomer({ email: 'customer@test.com', password: 'password123' }).subscribe();

      const request = http.expectOne(`${API_CONFIG.baseUrl}/auth/customers/login`);
      request.flush(customerResponse);

      expect(localStorage.getItem('insurewise_token')).toBe('test-token-123');
      expect(localStorage.getItem('insurewise_role')).toBe('CUSTOMER');
    });
  });

  describe('registerCustomer()', () => {
    it('registers a customer with the JSON signup contract', () => {
      service.registerCustomer({
        fullName: 'Jane Customer',
        phone: '1234567890',
        email: 'jane@example.com',
        password: 'password123'
      }).subscribe();

      const request = http.expectOne(`${API_CONFIG.baseUrl}/auth/customers`);
      expect(request.request.method).toBe('POST');
      expect(request.request.body).toEqual({
        fullName: 'Jane Customer',
        phone: '1234567890',
        email: 'jane@example.com',
        password: 'password123'
      });
      request.flush({
        access_token: 'registration-token',
        token_type: 'Bearer',
        user_id: 'customer-1',
        email: 'jane@example.com',
        role: 'CUSTOMER'
      });
    });
  });

  describe('uploadCustomerProfilePicture()', () => {
    it('uploads a customer profile picture with the registration token', () => {
      const picture = new File(['image'], 'profile.png', { type: 'image/png' });

      service.uploadCustomerProfilePicture('registration-token', picture).subscribe();

      const request = http.expectOne(`${API_CONFIG.baseUrl}/auth/profile-picture/upload`);
      expect(request.request.method).toBe('POST');
      expect(request.request.headers.get('Authorization')).toBe('Bearer registration-token');
      expect(request.request.headers.has('Content-Type')).toBe(false);
      const uploadedFile = (request.request.body as FormData).get('file') as File;
      expect(uploadedFile).toBeInstanceOf(File);
      expect(uploadedFile.name).toBe('profile.png');
      expect(uploadedFile.type).toBe('image/png');
      request.flush({});
    });
  });

  describe('getToken()', () => {
    it('should return stored token from localStorage', () => {
      localStorage.setItem('insurewise_token', 'test-token-123');
      expect(service.getToken()).toBe('test-token-123');
    });

    it('should return null when no token is stored', () => {
      expect(service.getToken()).toBeNull();
    });
  });

  describe('getRole()', () => {
    it('should return stored role from localStorage', () => {
      localStorage.setItem('insurewise_role', 'STAFF');
      expect(service.getRole()).toBe('STAFF');
    });

    it('should return null when no role is stored', () => {
      expect(service.getRole()).toBeNull();
    });
  });

  describe('isLoggedIn()', () => {
    it('should return true when token exists', () => {
      localStorage.setItem('insurewise_token', 'test-token-123');
      expect(service.isLoggedIn()).toBe(true);
    });

    it('should return false when no token exists', () => {
      expect(service.isLoggedIn()).toBe(false);
    });
  });

  describe('isStaff()', () => {
    it('should return true when role is STAFF', () => {
      localStorage.setItem('insurewise_role', 'STAFF');
      expect(service.isStaff()).toBe(true);
    });

    it('should return false when role is not STAFF', () => {
      localStorage.setItem('insurewise_role', 'CUSTOMER');
      expect(service.isStaff()).toBe(false);
    });

    it('should return false when no role is stored', () => {
      expect(service.isStaff()).toBe(false);
    });
  });

  describe('isCustomer()', () => {
    it('should return true when role is CUSTOMER', () => {
      localStorage.setItem('insurewise_role', 'CUSTOMER');
      expect(service.isCustomer()).toBe(true);
    });

    it('should return false when role is not CUSTOMER', () => {
      localStorage.setItem('insurewise_role', 'STAFF');
      expect(service.isCustomer()).toBe(false);
    });

    it('should return false when no role is stored', () => {
      expect(service.isCustomer()).toBe(false);
    });
  });

  describe('logout()', () => {
    it('should remove token and role from localStorage', () => {
      localStorage.setItem('insurewise_token', 'test-token-123');
      localStorage.setItem('insurewise_role', 'STAFF');

      service.logout();

      expect(localStorage.getItem('insurewise_token')).toBeNull();
      expect(localStorage.getItem('insurewise_role')).toBeNull();
    });

    it('should set isLoggedIn to false after logout', () => {
      localStorage.setItem('insurewise_token', 'test-token-123');
      service.logout();
      expect(service.isLoggedIn()).toBe(false);
    });
  });
});


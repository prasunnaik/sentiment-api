import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { provideHttpClient } from '@angular/common/http';
import { TestBed } from '@angular/core/testing';

import { API_CONFIG } from '../environment/api.config';
import { AuthService } from './auth.service';

describe('AuthService', () => {
  let service: AuthService;
  let http: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [provideHttpClient(), provideHttpClientTesting()]
    });
    service = TestBed.inject(AuthService);
    http = TestBed.inject(HttpTestingController);
  });

  afterEach(() => http.verify());

  it('registers a customer with the JSON signup contract', () => {
    service.registerCustomer({
      fullName: 'Jane Customer',
      phone: '1234567890',
      email: 'jane@example.com',
      password: 'password123'
    }).subscribe();

    const request = http.expectOne(`${API_CONFIG.baseUrl}/auth/customers`);
    expect(request.request.method).toBe('POST');
    expect(request.request.body).toEqual({
      fullName: 'Jane Customer',
      phone: '1234567890',
      email: 'jane@example.com',
      password: 'password123'
    });
    request.flush({
      access_token: 'registration-token',
      token_type: 'Bearer',
      user_id: 'customer-1',
      email: 'jane@example.com',
      role: 'CUSTOMER'
    });
  });

  it('uploads a customer profile picture with the registration token', () => {
    const picture = new File(['image'], 'profile.png', { type: 'image/png' });

    service.uploadCustomerProfilePicture('registration-token', picture).subscribe();

    const request = http.expectOne(`${API_CONFIG.baseUrl}/auth/profile-picture/upload`);
    expect(request.request.method).toBe('POST');
    expect(request.request.headers.get('Authorization')).toBe('Bearer registration-token');
    expect(request.request.headers.has('Content-Type')).toBe(false);
    const uploadedFile = (request.request.body as FormData).get('file') as File;
    expect(uploadedFile).toBeInstanceOf(File);
    expect(uploadedFile.name).toBe('profile.png');
    expect(uploadedFile.type).toBe('image/png');
    request.flush({});
  });
});

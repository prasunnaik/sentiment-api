import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, tap } from 'rxjs';

import { API_CONFIG } from '../environment/api.config';

export interface StaffLoginRequest {
  email: string;
  password: string;
}

export interface CustomerRegistrationRequest {
  fullName: string;
  phone: string;
  email: string;
  password: string;
}

export interface LoginResponse {
  access_token: string;
  token_type: string;
  user_id: string;
  email: string;
  role: string;
}

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private readonly TOKEN_KEY = 'insurewise_token';
  private readonly ROLE_KEY = 'insurewise_role';

  private readonly loginUrl =
    `${API_CONFIG.baseUrl}/auth/staff/login`;

  constructor(
    private readonly http: HttpClient
  ) {}

  /**
   * Authenticates a staff user with email and password
   * @param {StaffLoginRequest} request - The staff login request containing email and password
   * @returns {Observable<LoginResponse>} Observable that emits the login response with access token and user info
   */
  login(
    request: StaffLoginRequest
  ): Observable<LoginResponse> {

    return this.http
      .post<LoginResponse>(
        this.loginUrl,
        request
      )
      .pipe(
        tap((response: LoginResponse) => {

          /*
           * Backend returns:
           *
           * {
           *   "access_token": "...",
           *   "token_type": "Bearer",
           *   "user_id": "...",
           *   "email": "...",
           *   "role": "STAFF"
           * }
           */

          if (response?.access_token) {

            localStorage.setItem(
              this.TOKEN_KEY,
              response.access_token
            );

            localStorage.setItem(
              this.ROLE_KEY,
              response.role ?? ''
            );
          }
        })
      );
  }

  /**
   * Authenticates a customer user with email and password
   * @param {StaffLoginRequest} request - The customer login request containing email and password
   * @returns {Observable<LoginResponse>} Observable that emits the login response with access token and user info
   */
  loginCustomer(request: StaffLoginRequest): Observable<LoginResponse> {
    return this.authenticate(`${API_CONFIG.baseUrl}/auth/customers/login`, request);
  }

  /**
   * Registers a new customer user
   * @param {CustomerRegistrationRequest} request - The customer registration request containing user details
   * @returns {Observable<LoginResponse>} Observable that emits the login response with access token
   */
  registerCustomer(request: CustomerRegistrationRequest): Observable<LoginResponse> {
    return this.http.post<LoginResponse>(`${API_CONFIG.baseUrl}/auth/customers`, request);
  }

  /**
   * Uploads a profile picture for a customer
   * @param {string} accessToken - The authentication token for the request
   * @param {File} profilePicture - The profile picture file to upload
   * @returns {Observable<void>} Observable that completes when the upload is successful
   */
  uploadCustomerProfilePicture(accessToken: string, profilePicture: File): Observable<void> {
    const data = new FormData();
    data.append('file', profilePicture, profilePicture.name);
    return this.http.post<void>(
      `${API_CONFIG.baseUrl}/auth/profile-picture/upload`,
      data,
      { headers: new HttpHeaders({ Authorization: `Bearer ${accessToken}` }) }
    );
  }

  /**
   * Authenticates a user via the provided URL and request
   * @private
   * @param {string} url - The authentication endpoint URL
   * @param {unknown} request - The authentication request object
   * @returns {Observable<LoginResponse>} Observable that emits the login response with access token and user info
   */
  private authenticate(url: string, request: unknown): Observable<LoginResponse> {
    return this.http.post<LoginResponse>(url, request).pipe(
      tap((response) => this.storeSession(response))
    );
  }

  /**
   * Stores the session information in localStorage
   * @private
   * @param {LoginResponse} response - The login response containing authentication details
   * @returns {void}
   */
  private storeSession(response: LoginResponse): void {
    if (response?.access_token) {
      localStorage.setItem(this.TOKEN_KEY, response.access_token);
      localStorage.setItem(this.ROLE_KEY, response.role ?? '');
    }
  }

  /**
   * Retrieves the stored authentication token from localStorage
   * @returns {string | null} The authentication token or null if not found
   */
  getToken(): string | null {
    return localStorage.getItem(
      this.TOKEN_KEY
    );
  }

  /**
   * Retrieves the stored user role from localStorage
   * @returns {string | null} The user role or null if not found
   */
  getRole(): string | null {
    return localStorage.getItem(
      this.ROLE_KEY
    );
  }

  /**
   * Checks if a user is currently logged in
   * @returns {boolean} true if a valid token exists, false otherwise
   */
  isLoggedIn(): boolean {
    return !!this.getToken();
  }

  /**
   * Checks if the logged-in user is a staff member
   * @returns {boolean} true if the user role is 'STAFF', false otherwise
   */
  isStaff(): boolean {
    return this.getRole() === 'STAFF';
  }

  /**
   * Checks if the logged-in user is a customer
   * @returns {boolean} true if the user role is 'CUSTOMER', false otherwise
   */
  isCustomer(): boolean {
    return this.getRole() === 'CUSTOMER';
  }

  /**
   * Logs out the current user by removing stored credentials from localStorage
   * @returns {void}
   */
  logout(): void {
    localStorage.removeItem(
      this.TOKEN_KEY
    );

    localStorage.removeItem(
      this.ROLE_KEY
    );
  }
}

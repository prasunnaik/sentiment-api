import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, tap } from 'rxjs';

import { API_CONFIG } from '../environment/api.config';

export interface StaffLoginRequest {
  email: string;
  password: string;
}

export interface CustomerRegistrationRequest {
  fullName: string;
  phone: string;
  email: string;
  password: string;
}

export interface LoginResponse {
  access_token: string;
  token_type: string;
  user_id: string;
  email: string;
  role: string;
}

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private readonly TOKEN_KEY = 'insurewise_token';
  private readonly ROLE_KEY = 'insurewise_role';

  private readonly loginUrl =
    `${API_CONFIG.baseUrl}/auth/staff/login`;

  constructor(
    private readonly http: HttpClient
  ) {}

  login(
    request: StaffLoginRequest
  ): Observable<LoginResponse> {

    return this.http
      .post<LoginResponse>(
        this.loginUrl,
        request
      )
      .pipe(
        tap((response: LoginResponse) => {

          /*
           * Backend returns:
           *
           * {
           *   "access_token": "...",
           *   "token_type": "Bearer",
           *   "user_id": "...",
           *   "email": "...",
           *   "role": "STAFF"
           * }
           */

          if (response?.access_token) {

            localStorage.setItem(
              this.TOKEN_KEY,
              response.access_token
            );

            localStorage.setItem(
              this.ROLE_KEY,
              response.role ?? ''
            );
          }
        })
      );
  }

  loginCustomer(request: StaffLoginRequest): Observable<LoginResponse> {
    return this.authenticate(`${API_CONFIG.baseUrl}/auth/customers/login`, request);
  }

  registerCustomer(request: CustomerRegistrationRequest): Observable<LoginResponse> {
    return this.http.post<LoginResponse>(`${API_CONFIG.baseUrl}/auth/customers`, request);
  }

  uploadCustomerProfilePicture(accessToken: string, profilePicture: File): Observable<void> {
    const data = new FormData();
    data.append('file', profilePicture, profilePicture.name);
    return this.http.post<void>(
      `${API_CONFIG.baseUrl}/auth/profile-picture/upload`,
      data,
      { headers: new HttpHeaders({ Authorization: `Bearer ${accessToken}` }) }
    );
  }

  private authenticate(url: string, request: unknown): Observable<LoginResponse> {
    return this.http.post<LoginResponse>(url, request).pipe(
      tap((response) => this.storeSession(response))
    );
  }

  private storeSession(response: LoginResponse): void {
    if (response?.access_token) {
      localStorage.setItem(this.TOKEN_KEY, response.access_token);
      localStorage.setItem(this.ROLE_KEY, response.role ?? '');
    }
  }

  getToken(): string | null {
    return localStorage.getItem(
      this.TOKEN_KEY
    );
  }

  getRole(): string | null {
    return localStorage.getItem(
      this.ROLE_KEY
    );
  }

  isLoggedIn(): boolean {
    return !!this.getToken();
  }

  isStaff(): boolean {
    return this.getRole() === 'STAFF';
  }

  isCustomer(): boolean {
    return this.getRole() === 'CUSTOMER';
  }

  logout(): void {
    localStorage.removeItem(
      this.TOKEN_KEY
    );

    localStorage.removeItem(
      this.ROLE_KEY
    );
  }
}

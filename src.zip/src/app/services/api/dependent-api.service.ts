import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

import { API_CONFIG } from '../../core/environment/api.config';
import { Dependent, DependentRequest } from '../../types/br04-05.types';

@Injectable({ providedIn: 'root' })
export class DependentApiService {

  private readonly url = `${API_CONFIG.baseUrl}/api/applications`;

  constructor(private readonly http: HttpClient) {}

  list(applicationId: string): Observable<Dependent[]> {
    return this.http.get<Dependent[]>(`${this.url}/${applicationId}/dependents`);
  }

  add(applicationId: string, request: DependentRequest): Observable<Dependent> {
    return this.http.post<Dependent>(`${this.url}/${applicationId}/dependents`, request);
  }

  update(applicationId: string, dependentId: string, request: DependentRequest): Observable<Dependent> {
    return this.http.put<Dependent>(`${this.url}/${applicationId}/dependents/${dependentId}`, request);
  }

  delete(applicationId: string, dependentId: string): Observable<void> {
    return this.http.delete<void>(`${this.url}/${applicationId}/dependents/${dependentId}`);
  }
}

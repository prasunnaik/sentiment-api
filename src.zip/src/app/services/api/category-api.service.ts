import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

import { API_CONFIG } from '../../core/environment/api.config';
import { Category, CategoryCreateRequest } from '../../types/brd.types';

@Injectable({ providedIn: 'root' })
export class CategoryApiService {

  private readonly url = `${API_CONFIG.baseUrl}/api/categories`;

  constructor(private readonly http: HttpClient) {}

  getAll(): Observable<Category[]> {
    return this.http.get<Category[]>(this.url);
  }

  create(request: CategoryCreateRequest): Observable<Category> {
    return this.http.post<Category>(this.url, request);
  }

  update(id: string, request: CategoryCreateRequest): Observable<Category> {
    return this.http.put<Category>(`${this.url}/${id}`, request);
  }

  delete(id: string): Observable<void> {
    return this.http.delete<void>(`${this.url}/${id}`);
  }
}

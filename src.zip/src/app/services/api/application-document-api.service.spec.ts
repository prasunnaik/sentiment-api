import { TestBed } from '@angular/core/testing';
import {
  HttpErrorResponse,
  HttpEventType,
  HttpUploadProgressEvent,
  provideHttpClient
} from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';

import { API_CONFIG } from '../../core/environment/api.config';
import { ApplicationDocumentApiService, APPLICATION_DOCUMENT_MAX_SIZE } from './application-document-api.service';

describe('ApplicationDocumentApiService', () => {
  let service: ApplicationDocumentApiService;
  let http: HttpTestingController;
  const applicationId = 'application-1';
  const documentId = 'document-1';
  const baseUrl = `${API_CONFIG.baseUrl}/api/applications/${applicationId}/documents`;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [provideHttpClient(), provideHttpClientTesting()]
    });
    service = TestBed.inject(ApplicationDocumentApiService);
    http = TestBed.inject(HttpTestingController);
  });

  afterEach(() => http.verify());

  it('uploads using the exact file field and reports progress without setting Content-Type', () => {
    const file = new File(['pdf'], 'policy.pdf', { type: 'application/pdf' });
    let progress = 0;

    service.upload(applicationId, file).subscribe(event => {
      if (event.type === HttpEventType.UploadProgress && event.total) {
        progress = Math.round((event.loaded / event.total) * 100);
      }
    });

    const request = http.expectOne(baseUrl);
    expect(request.request.method).toBe('POST');
    expect(request.request.body).toBeInstanceOf(FormData);
    const uploadedFile = (request.request.body as FormData).get('file') as File;
    expect(uploadedFile.name).toBe(file.name);
    expect(uploadedFile.type).toBe(file.type);
    expect(uploadedFile.size).toBe(file.size);
    expect(request.request.headers.has('Content-Type')).toBe(false);

    request.event({ type: HttpEventType.UploadProgress, loaded: 5, total: 10 } as HttpUploadProgressEvent);
    expect(progress).toBe(50);
    request.flush({ id: documentId, fileName: file.name, contentType: file.type });
  });

  it('validates required file, PDF type, and maximum size', () => {
    expect(service.validateFile(null)).toContain('Select');
    expect(service.validateFile(new File(['text'], 'notes.txt', { type: 'text/plain' }))).toContain('Only PDF');
    expect(service.validateFile(new File([new Uint8Array(APPLICATION_DOCUMENT_MAX_SIZE + 1)], 'large.pdf', { type: 'application/pdf' }))).toContain('10 MB');
    expect(service.validateFile(new File(['pdf'], 'policy.pdf', { type: 'application/pdf' }))).toBeNull();
  });

  it('lists application documents', () => {
    service.list(applicationId).subscribe(documents => expect(documents[0].id).toBe(documentId));
    const request = http.expectOne(baseUrl);
    expect(request.request.method).toBe('GET');
    request.flush([{ id: documentId, fileName: 'policy.pdf', contentType: 'application/pdf' }]);
  });

  it('requests staff preview and download URLs', () => {
    service.preview(applicationId, documentId).subscribe(response => expect(response.url).toContain('preview'));
    const preview = http.expectOne(`${baseUrl}/${documentId}/preview`);
    expect(preview.request.method).toBe('GET');
    preview.flush({ url: 'https://signed.example/preview' });

    service.download(applicationId, documentId).subscribe(response => expect(response.url).toContain('download'));
    const download = http.expectOne(`${baseUrl}/${documentId}/download`);
    expect(download.request.method).toBe('GET');
    download.flush({ url: 'https://signed.example/download' });
  });

  it('maps authentication and authorization errors to user-friendly messages', () => {
    const unauthorized = new HttpErrorResponse({ status: 401 });
    const forbidden = new HttpErrorResponse({ status: 403 });

    expect(service.errorMessage(unauthorized, 'list')).toContain('session has expired');
    expect(service.errorMessage(forbidden, 'preview')).toContain('not authorized');
  });
});
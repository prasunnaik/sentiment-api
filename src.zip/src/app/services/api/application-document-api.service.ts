import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

import { API_CONFIG } from '../../core/environment/api.config';

import {
  ApplicationDocument
} from '../../types/brd.types';

@Injectable({
  providedIn: 'root'
})
export class ApplicationDocumentApiService {

  private readonly url =
    `${API_CONFIG.baseUrl}/api/applications`;

  constructor(private readonly http: HttpClient) {}

  /**
   * GET /api/applications/{id}/documents
   */
  getByApplicationId(
    applicationId: string
  ): Observable<ApplicationDocument[]> {
    return this.http.get<ApplicationDocument[]>(
      `${this.url}/${applicationId}/documents`
    );
  }

  /**
   * POST /api/applications/{id}/documents (multipart/form-data)
   */
  upload(
    applicationId: string,
    file: File
  ): Observable<ApplicationDocument> {

    const formData = new FormData();
    formData.append('file', file);

    return this.http.post<ApplicationDocument>(
      `${this.url}/${applicationId}/documents`,
      formData
    );
  }

  /**
   * DELETE /api/applications/{id}/documents/{documentId}
   */
  delete(
    applicationId: string,
    documentId: string
  ): Observable<void> {
    return this.http.delete<void>(
      `${this.url}/${applicationId}/documents/${documentId}`
    );
  }
}
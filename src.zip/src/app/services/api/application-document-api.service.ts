import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';

import { API_CONFIG } from '../../core/environment/api.config';

import {
  ApplicationDocument,
  PresignedUrl
} from '../../types/br04-05.types';

export const APPLICATION_DOCUMENT_MAX_SIZE = 10 * 1024 * 1024;
export const APPLICATION_DOCUMENT_ACCEPT = '.pdf,application/pdf';

@Injectable({
  providedIn: 'root'
})
export class ApplicationDocumentApiService {

  constructor(private http: HttpClient) {}

  upload(
    applicationId: string,
    file: File
  ): Observable<HttpEvent<ApplicationDocument>> {
    const data = new FormData();
    data.append('file', file, file.name);

    return this.http.post<ApplicationDocument>(
      this.documentsUrl(applicationId),
      data,
      { observe: 'events', reportProgress: true }
    );
  }

  list(
    applicationId: string
  ): Observable<ApplicationDocument[]> {
    return this.http.get<ApplicationDocument[]>(
      this.documentsUrl(applicationId)
    );
  }

  getByApplicationId(applicationId: string): Observable<ApplicationDocument[]> {
    return this.list(applicationId);
  }

  getById(
    applicationId: string,
    documentId: string
  ): Observable<ApplicationDocument> {
    return this.http.get<ApplicationDocument>(
      `${this.documentsUrl(applicationId)}/${documentId}`
    );
  }

  preview(applicationId: string, documentId: string): Observable<PresignedUrl> {
    return this.http.get<PresignedUrl>(
      `${this.documentsUrl(applicationId)}/${documentId}/preview`
    );
  }

  download(applicationId: string, documentId: string): Observable<PresignedUrl> {
    return this.http.get<PresignedUrl>(
      `${this.documentsUrl(applicationId)}/${documentId}/download`
    );
  }

  delete(applicationId: string, documentId: string): Observable<void> {
    return this.http.delete<void>(
      `${this.documentsUrl(applicationId)}/${documentId}`
    );
  }

  validateFile(file: File | null | undefined): string | null {
    if (!file) {
      return 'Select a PDF document to upload.';
    }

    const extension = file.name.split('.').pop()?.toLowerCase();
    if (extension !== 'pdf' || file.type !== 'application/pdf') {
      return 'Only PDF documents are supported.';
    }

    if (file.size > APPLICATION_DOCUMENT_MAX_SIZE) {
      return 'The document must be 10 MB or smaller.';
    }

    return null;
  }

  errorMessage(error: unknown, action: 'upload' | 'list' | 'preview' | 'download' | 'delete'): string {
    if (!(error instanceof HttpErrorResponse)) {
      return `Unable to ${action} the document. Try again.`;
    }

    const backendMessage = this.backendMessage(error);
    switch (error.status) {
      case 401:
        return 'Your session has expired. Sign in again.';
      case 403:
        return 'You are not authorized to access this document.';
      case 404:
        return 'The application or document could not be found.';
      case 413:
        return 'The document is too large. The maximum size is 10 MB.';
      case 500:
        return 'The document service is temporarily unavailable. Try again later.';
      default:
        return backendMessage ?? `Unable to ${action} the document. Try again.`;
    }
  }

  private documentsUrl(applicationId: string): string {
    return `${API_CONFIG.baseUrl}/api/applications/${applicationId}/documents`;
  }

  private backendMessage(error: HttpErrorResponse): string | null {
    if (typeof error.error === 'string' && error.error.trim()) {
      return error.error;
    }

    const body = error.error as { message?: unknown } | null;
    return typeof body?.message === 'string' && body.message.trim()
      ? body.message
      : null;
  }
}
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

import { API_CONFIG } from '../../core/environment/api.config';
import { DashboardMetrics } from '../../types/br04-05.types';

@Injectable({
  providedIn: 'root'
})
export class DashboardApiService {

  private readonly url =
    `${API_CONFIG.baseUrl}/api/dashboard/metrics`;

  constructor(private http: HttpClient) {}

  getMetrics(): Observable<DashboardMetrics> {
    return this.http.get<DashboardMetrics>(this.url);
  }
}
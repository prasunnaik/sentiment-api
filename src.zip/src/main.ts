import { bootstrapApplication } from '@angular/platform-browser';
import 'bootstrap';

import {
  provideHttpClient,
  withInterceptorsFromDi
} from '@angular/common/http';

import { HTTP_INTERCEPTORS } from '@angular/common/http';

import { provideRouter } from '@angular/router';

import { AppComponent } from './app/app.component';

import { AuthInterceptor } from './app/core/http/auth.interceptor';
import { ErrorInterceptor } from './app/core/http/error.interceptor';

import { routes } from './app/routing/app.routes';


bootstrapApplication(AppComponent, {

  providers: [

    provideRouter(routes),

    provideHttpClient(
      withInterceptorsFromDi()
    ),

    {
      provide: HTTP_INTERCEPTORS,
      useClass: AuthInterceptor,
      multi: true
    },

    {
      provide: HTTP_INTERCEPTORS,
      useClass: ErrorInterceptor,
      multi: true
    }

  ]

}).catch(error => console.error(error));
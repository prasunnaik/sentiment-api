package com.insurewise.policy.service;

import com.insurewise.common.dto.PresignedUrlResponse;
import com.insurewise.common.exception.FileStorageException;
import com.insurewise.common.exception.InvalidFileException;
import com.insurewise.common.security.JwtPrincipal;
import com.insurewise.common.security.JwtRole;
import com.insurewise.common.service.S3StorageService;
import com.insurewise.policy.entity.CoverageType;
import com.insurewise.policy.entity.NomineeRelationship;
import com.insurewise.policy.entity.Policy;
import com.insurewise.policy.entity.PolicyApplication;
import com.insurewise.policy.entity.Category;
import com.insurewise.policy.entity.CategoryStatus;
import com.insurewise.policy.entity.PolicyStatus;
import com.insurewise.policy.exception.ApplicationNotFoundException;
import com.insurewise.policy.repository.ApplicationDocumentRepository;
import java.math.BigDecimal;
import java.lang.reflect.Field;
import java.time.LocalDate;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.security.access.AccessDeniedException;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ApplicationDocumentServiceTest {

    @Mock
    private ApplicationDocumentRepository documentRepository;

    @Mock
    private PolicyApplicationService applicationService;

    @Mock
    private S3StorageService storageService;

    @InjectMocks
    private ApplicationDocumentService service;

    private JwtPrincipal customerPrincipal;
    private PolicyApplication application;

    @BeforeEach
    void setUp() {
        UUID customerId = UUID.randomUUID();
        customerPrincipal = new JwtPrincipal(customerId, JwtRole.CUSTOMER, "customer@example.com");
        UUID applicationId = UUID.randomUUID();

        Category category = new Category("Health", "Health coverage", CategoryStatus.ACTIVE);
        Policy policy = new Policy(
                "Silver Plan",
                category,
                new BigDecimal("500000.00"),
                new BigDecimal("1200.00"),
                "1 Year",
                PolicyStatus.ACTIVE);

        application = new PolicyApplication(
                "APP-2000",
                customerId,
                policy,
                CoverageType.SINGLE,
                LocalDate.now().minusYears(30),
                "123 Main Street",
                LocalDate.now().plusDays(10),
                "Nominee Name",
                NomineeRelationship.SPOUSE);
        setField(application, "id", applicationId);
    }

    @Test
    void uploadPersistsMetadataAfterS3UploadSucceeds() {
        MockMultipartFile file = new MockMultipartFile(
                "file",
                "policy.pdf",
                MediaType.APPLICATION_PDF_VALUE,
                "dummy-pdf".getBytes());

        when(applicationService.getApplicationEntityForInternalUse(application.getId())).thenReturn(application);
        when(documentRepository.saveAndFlush(any()))
                .thenAnswer(invocation -> invocation.getArgument(0));

        var saved = service.uploadApplicationDocument(customerPrincipal, application.getId(), file);

        ArgumentCaptor<String> keyCaptor = ArgumentCaptor.forClass(String.class);
        verify(storageService).upload(eq(file), eq("application-documents"), eq(customerPrincipal.userId()), keyCaptor.capture());
        String key = keyCaptor.getValue();
        assertThat(key).contains(application.getId().toString());
        assertThat(key).endsWith(".pdf");
        assertThat(saved.objectKey()).isEqualTo(key);
        assertThat(saved.fileName()).isEqualTo("policy.pdf");
        assertThat(saved.fileSize()).isEqualTo(9);
    }

    @Test
    void uploadDeletesS3ObjectWhenDatabasePersistenceFails() {
        MockMultipartFile file = new MockMultipartFile(
                "file",
                "policy.pdf",
                MediaType.APPLICATION_PDF_VALUE,
                "dummy-pdf".getBytes());

        when(applicationService.getApplicationEntityForInternalUse(application.getId())).thenReturn(application);
        when(documentRepository.saveAndFlush(any()))
                .thenThrow(new IllegalStateException("db failure"));

        assertThatThrownBy(() -> service.uploadApplicationDocument(customerPrincipal, application.getId(), file))
                .isInstanceOf(IllegalStateException.class)
                .hasMessage("db failure");

        ArgumentCaptor<String> keyCaptor = ArgumentCaptor.forClass(String.class);
        verify(storageService).upload(eq(file), eq("application-documents"), eq(customerPrincipal.userId()), keyCaptor.capture());
        verify(storageService).delete(keyCaptor.getValue());
    }

    @Test
    void uploadRejectsMissingBucketFailureFromStorage() {
        MockMultipartFile file = new MockMultipartFile(
                "file",
                "policy.pdf",
                MediaType.APPLICATION_PDF_VALUE,
                "dummy-pdf".getBytes());

        when(applicationService.getApplicationEntityForInternalUse(application.getId())).thenReturn(application);
        doThrow(new FileStorageException("Unable to store the file."))
                .when(storageService)
                .upload(eq(file), eq("application-documents"), eq(customerPrincipal.userId()), any());

        assertThatThrownBy(() -> service.uploadApplicationDocument(customerPrincipal, application.getId(), file))
                .isInstanceOf(FileStorageException.class);

        verify(documentRepository, never()).saveAndFlush(any());
    }

    @Test
    void uploadRejectsInvalidFile() {
        MockMultipartFile file = new MockMultipartFile(
                "file",
                "policy.txt",
                MediaType.TEXT_PLAIN_VALUE,
                "dummy".getBytes());

        when(applicationService.getApplicationEntityForInternalUse(application.getId())).thenReturn(application);

        assertThatThrownBy(() -> service.uploadApplicationDocument(customerPrincipal, application.getId(), file))
                .isInstanceOf(InvalidFileException.class)
                .hasMessage("Document must be a .pdf file");
    }

    @Test
    void uploadRejectsOversizedFile() {
        byte[] oversized = new byte[(int) (10L * 1024 * 1024 + 1)];
        MockMultipartFile file = new MockMultipartFile(
                "file",
                "policy.pdf",
                MediaType.APPLICATION_PDF_VALUE,
                oversized);

        when(applicationService.getApplicationEntityForInternalUse(application.getId())).thenReturn(application);

        assertThatThrownBy(() -> service.uploadApplicationDocument(customerPrincipal, application.getId(), file))
                .isInstanceOf(InvalidFileException.class)
                .hasMessage("Document size cannot exceed 10MB");
    }

    @Test
    void uploadRejectsMissingApplication() {
        MockMultipartFile file = new MockMultipartFile(
                "file",
                "policy.pdf",
                MediaType.APPLICATION_PDF_VALUE,
                "dummy-pdf".getBytes());

        when(applicationService.getApplicationEntityForInternalUse(application.getId()))
                .thenThrow(new ApplicationNotFoundException(application.getId()));

        assertThatThrownBy(() -> service.uploadApplicationDocument(customerPrincipal, application.getId(), file))
                .isInstanceOf(AccessDeniedException.class)
                .hasCauseInstanceOf(ApplicationNotFoundException.class);
    }

    private void setField(Object target, String fieldName, Object value) {
        try {
            Field field = target.getClass().getDeclaredField(fieldName);
            field.setAccessible(true);
            field.set(target, value);
        } catch (ReflectiveOperationException exception) {
            throw new IllegalStateException(exception);
        }
    }
}

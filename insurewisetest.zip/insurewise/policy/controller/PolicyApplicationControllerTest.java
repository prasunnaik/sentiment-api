package com.insurewise.policy.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.insurewise.common.security.JwtRole;
import com.insurewise.common.security.JwtService;
import com.insurewise.policy.dto.request.PolicyApplicationCreateRequest;
import com.insurewise.policy.dto.request.PolicyApplicationDecisionRequest;
import com.insurewise.policy.entity.ApplicationStatus;
import com.insurewise.policy.entity.Category;
import com.insurewise.policy.entity.CategoryStatus;
import com.insurewise.policy.entity.CoverageType;
import com.insurewise.policy.entity.NomineeRelationship;
import com.insurewise.policy.entity.Policy;
import com.insurewise.policy.entity.PolicyStatus;
import com.insurewise.policy.repository.CategoryRepository;
import com.insurewise.policy.repository.PolicyApplicationRepository;
import com.insurewise.policy.repository.PolicyRepository;
import jakarta.persistence.EntityManager;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@Transactional
@TestPropertySource(properties = {
        "spring.datasource.url=jdbc:h2:mem:policy-application-controller-test;MODE=PostgreSQL;DB_CLOSE_DELAY=-1;DATABASE_TO_UPPER=false",
        "spring.datasource.driver-class-name=org.h2.Driver",
        "spring.datasource.username=sa",
        "spring.datasource.password=",
        "spring.jpa.hibernate.ddl-auto=create-drop",
        "spring.jpa.properties.hibernate.dialect=org.hibernate.dialect.H2Dialect",
        "spring.flyway.enabled=false"
})
class PolicyApplicationControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private JwtService jwtService;

    @Autowired
    private CategoryRepository categoryRepository;

    @Autowired
    private PolicyRepository policyRepository;

    @Autowired
    private PolicyApplicationRepository policyApplicationRepository;

    @Autowired
    private EntityManager entityManager;

    private String staffToken;
    private String customerToken;
    private UUID customerId;
    private Policy policy;

    @BeforeEach
    void setUp() {
        entityManager.createNativeQuery("CREATE SEQUENCE IF NOT EXISTS application_code_seq START WITH 1000 INCREMENT BY 1")
                .executeUpdate();
        policyApplicationRepository.deleteAll();
        policyRepository.deleteAll();
        categoryRepository.deleteAll();

        Category category = categoryRepository.save(new Category(
                "Health",
                "Health coverage",
                CategoryStatus.ACTIVE));
        policy = policyRepository.save(new Policy(
                "Silver Plan",
                category,
                new BigDecimal("500000.00"),
                new BigDecimal("1200.00"),
                "1 Year",
                PolicyStatus.ACTIVE));
        customerId = UUID.randomUUID();
        customerToken = bearerToken(customerId, JwtRole.CUSTOMER);
        staffToken = bearerToken(UUID.randomUUID(), JwtRole.STAFF);
    }

    @Test
    void approveApplicationPersistsApprovedStatus() throws Exception {
        UUID applicationId = createApplication();

        mockMvc.perform(put("/api/policy-applications/{id}/approve", applicationId)
                        .header("Authorization", staffToken)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(decisionRemarks("Approved")))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("APPROVED"))
                .andExpect(jsonPath("$.decidedBy").isNotEmpty())
                .andExpect(jsonPath("$.decidedAt").isNotEmpty());
    }

    @Test
    void rejectApplicationPersistsRejectedStatus() throws Exception {
        UUID applicationId = createApplication();

        mockMvc.perform(put("/api/policy-applications/{id}/reject", applicationId)
                        .header("Authorization", staffToken)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(decisionRemarks("Rejected")))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("REJECTED"))
                .andExpect(jsonPath("$.decidedBy").isNotEmpty())
                .andExpect(jsonPath("$.decidedAt").isNotEmpty());
    }

    @Test
    void statusEndpointRejectsInvalidStatus() throws Exception {
        UUID applicationId = createApplication();

        mockMvc.perform(put("/api/policy-applications/{id}/status", applicationId)
                        .header("Authorization", staffToken)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(
                                new PolicyApplicationDecisionRequest(ApplicationStatus.PENDING, "Invalid status test"))))
                .andExpect(status().isConflict())
                .andExpect(jsonPath("$.message").value("Application status must be APPROVED or REJECTED"));
    }

    @Test
    void approveRequiresStaffAuthorization() throws Exception {
        UUID applicationId = createApplication();

        mockMvc.perform(put("/api/policy-applications/{id}/approve", applicationId)
                        .header("Authorization", customerToken)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(decisionRemarks("Approved")))
                .andExpect(status().isForbidden());
    }

    @Test
    void rejectReturnsNotFoundForMissingId() throws Exception {
        mockMvc.perform(put("/api/policy-applications/{id}/reject", UUID.randomUUID())
                        .header("Authorization", staffToken)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(decisionRemarks("Rejected")))
                .andExpect(status().isNotFound());
    }

    @Test
    void statusEndpointRejectsUnsupportedEnumValue() throws Exception {
        UUID applicationId = createApplication();

        mockMvc.perform(put("/api/policy-applications/{id}/status", applicationId)
                        .header("Authorization", staffToken)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"status\":\"INVALID\"}"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message").value("status: must be one of [PENDING, APPROVED, REJECTED]"));
    }

    @Test
    void createApplicationStartsInPendingStatus() throws Exception {
        mockMvc.perform(post("/api/policy-applications")
                        .header("Authorization", customerToken)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(validCreateRequest())))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("PENDING"));
    }

    @Test
    void createApplicationRejectsNomineeRelationshipWithoutName() throws Exception {
        mockMvc.perform(post("/api/policy-applications")
                        .header("Authorization", customerToken)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {
                                  "policy_id":"%s",
                                  "coverage_type":"SINGLE",
                                  "date_of_birth":"%s",
                                  "address":"123 Main Street",
                                  "preferred_start_date":"%s",
                                  "nominee_relationship":"SPOUSE"
                                }
                                """.formatted(
                                policy.getId(),
                                LocalDate.now().minusYears(30),
                                LocalDate.now().plusDays(10))))
                .andExpect(status().isBadRequest())
                                .andExpect(jsonPath("$.message").value("Request validation failed."));
    }

    @Test
    void createApplicationRejectsNomineeNameWithoutRelationship() throws Exception {
        mockMvc.perform(post("/api/policy-applications")
                        .header("Authorization", customerToken)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {
                                  "policy_id":"%s",
                                  "coverage_type":"SINGLE",
                                  "date_of_birth":"%s",
                                  "address":"123 Main Street",
                                  "preferred_start_date":"%s",
                                  "nominee_name":"Nominee Name"
                                }
                                """.formatted(
                                policy.getId(),
                                LocalDate.now().minusYears(30),
                                LocalDate.now().plusDays(10))))
                .andExpect(status().isBadRequest())
                                .andExpect(jsonPath("$.message").value("Request validation failed."));
    }

    private String decisionRemarks(String remarks) {
        return """
                                {
                                  "remarks": "%s"
                                }
                                """.formatted(remarks);
    }

    private UUID createApplication() throws Exception {
        String response = mockMvc.perform(post("/api/policy-applications")
                        .header("Authorization", customerToken)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(validCreateRequest())))
                .andExpect(status().isOk())
                .andReturn()
                .getResponse()
                .getContentAsString();

        return UUID.fromString(objectMapper.readTree(response).path("id").asText());
    }

    private String bearerToken(UUID userId, JwtRole role) {
        return "Bearer " + jwtService.generate(
                userId,
                role.name().toLowerCase() + "@example.com",
                role);
    }

    private PolicyApplicationCreateRequest validCreateRequest() {
        return new PolicyApplicationCreateRequest(
                policy.getId(),
                CoverageType.SINGLE,
                LocalDate.now().minusYears(30),
                "123 Main Street",
                LocalDate.now().plusDays(10),
                "Nominee Name",
                NomineeRelationship.SPOUSE);
    }
}

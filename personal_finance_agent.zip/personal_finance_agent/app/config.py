from __future__ import annotations

import os
from dataclasses import dataclass

from dotenv import load_dotenv

load_dotenv()


@dataclass(frozen=True)
class Settings:
    model_provider: str = os.getenv("MODEL_PROVIDER", "openai").lower()
    openai_api_key: str | None = os.getenv("OPENAI_API_KEY")
    openai_model: str = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
    anthropic_api_key: str | None = os.getenv("ANTHROPIC_API_KEY")
    anthropic_model: str = os.getenv("ANTHROPIC_MODEL", "claude-3-5-sonnet-latest")
    tavily_api_key: str | None = os.getenv("TAVILY_API_KEY")


settings = Settings()


def validate_settings() -> list[str]:
    errors: list[str] = []

    if settings.model_provider not in {"openai", "anthropic"}:
        errors.append("MODEL_PROVIDER must be 'openai' or 'anthropic'.")

    if settings.model_provider == "openai" and not settings.openai_api_key:
        errors.append("OPENAI_API_KEY is missing.")

    if settings.model_provider == "anthropic" and not settings.anthropic_api_key:
        errors.append("ANTHROPIC_API_KEY is missing.")

    if not settings.tavily_api_key:
        errors.append("TAVILY_API_KEY is missing. Live web search will not work without it.")

    return errors

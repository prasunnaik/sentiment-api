from __future__ import annotations

import ast
import math
import operator
import re
from typing import Any

from langchain_core.tools import tool
from langchain_tavily import TavilySearch

from .config import settings


# -----------------------------
# Safe calculator implementation
# -----------------------------
_ALLOWED_BINOPS = {
    ast.Add: operator.add,
    ast.Sub: operator.sub,
    ast.Mult: operator.mul,
    ast.Div: operator.truediv,
    ast.Pow: operator.pow,
    ast.Mod: operator.mod,
    ast.FloorDiv: operator.floordiv,
}
_ALLOWED_UNARYOPS = {
    ast.UAdd: operator.pos,
    ast.USub: operator.neg,
}
_ALLOWED_FUNCS = {
    "sqrt": math.sqrt,
    "abs": abs,
    "round": round,
    "floor": math.floor,
    "ceil": math.ceil,
    "log": math.log,
    "log10": math.log10,
    "exp": math.exp,
}
_ALLOWED_CONSTS = {"pi": math.pi, "e": math.e}


def _eval_node(node: ast.AST) -> float | int:
    if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)):
        return node.value

    if isinstance(node, ast.BinOp) and type(node.op) in _ALLOWED_BINOPS:
        left = _eval_node(node.left)
        right = _eval_node(node.right)
        # Prevent absurd exponentiation/resource use.
        if isinstance(node.op, ast.Pow) and abs(float(right)) > 100:
            raise ValueError("Exponent is too large.")
        return _ALLOWED_BINOPS[type(node.op)](left, right)

    if isinstance(node, ast.UnaryOp) and type(node.op) in _ALLOWED_UNARYOPS:
        return _ALLOWED_UNARYOPS[type(node.op)](_eval_node(node.operand))

    if isinstance(node, ast.Name) and node.id in _ALLOWED_CONSTS:
        return _ALLOWED_CONSTS[node.id]

    if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id in _ALLOWED_FUNCS:
        if node.keywords:
            raise ValueError("Keyword arguments are not supported.")
        args = [_eval_node(arg) for arg in node.args]
        return _ALLOWED_FUNCS[node.func.id](*args)

    raise ValueError("Unsupported expression.")


def safe_calculate(expression: str) -> float | int:
    expression = expression.strip()
    if not expression:
        raise ValueError("Expression is empty.")
    if len(expression) > 250:
        raise ValueError("Expression is too long.")

    # Convert common percentage notation: 15% -> 15/100.
    expression = re.sub(r"(?<![A-Za-z0-9_.])([0-9]+(?:\.[0-9]+)?)%", r"(\1/100)", expression)
    tree = ast.parse(expression, mode="eval")
    result = _eval_node(tree.body)

    if not math.isfinite(float(result)):
        raise ValueError("Result is not finite.")
    return result


@tool
def calculator(expression: str) -> str:
    """Calculate a mathematical expression safely.

    Supports +, -, *, /, //, %, **, parentheses, percentages such as 15%,
    constants pi/e, and functions sqrt, abs, round, floor, ceil, log, log10, exp.
    """
    try:
        result = safe_calculate(expression)
        if isinstance(result, float):
            return f"{result:.12g}"
        return str(result)
    except Exception as exc:
        return f"Calculator error: {exc}"


def build_web_search_tool():
    if not settings.tavily_api_key:
        return None
    return TavilySearch(
        max_results=5,
        topic="general",
    )


def build_tools() -> list[Any]:
    tools: list[Any] = [calculator]
    web_search = build_web_search_tool()
    if web_search is not None:
        tools.insert(0, web_search)
    return tools

"""Personal Finance AI Agent package."""

from __future__ import annotations

from functools import lru_cache

from langchain.agents import create_agent
from langchain_core.messages import AIMessage, HumanMessage, ToolMessage

from .config import settings
from .prompts import SYSTEM_PROMPT
from .tools import build_tools


def _build_model():
    if settings.model_provider == "anthropic":
        from langchain_anthropic import ChatAnthropic

        return ChatAnthropic(
            model=settings.anthropic_model,
            api_key=settings.anthropic_api_key,
            temperature=0,
        )

    from langchain_openai import ChatOpenAI

    return ChatOpenAI(
        model=settings.openai_model,
        api_key=settings.openai_api_key,
        temperature=0,
    )


@lru_cache(maxsize=1)
def get_agent():
    model = _build_model()
    tools = build_tools()
    return create_agent(
        model=model,
        tools=tools,
        system_prompt=SYSTEM_PROMPT,
    )


def _content_to_text(content) -> str:
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        chunks = []
        for item in content:
            if isinstance(item, dict) and item.get("type") == "text":
                chunks.append(item.get("text", ""))
        return "".join(chunks)
    return str(content)


def run_agent(question: str, history: list[dict[str, str]] | None = None) -> tuple[str, list[str]]:
    agent = get_agent()
    messages = []

    for item in history or []:
        role = item.get("role")
        content = item.get("content", "")
        if role == "user":
            messages.append(HumanMessage(content=content))
        elif role == "assistant":
            messages.append(AIMessage(content=content))

    messages.append(HumanMessage(content=question))
    result = agent.invoke({"messages": messages})

    tool_names: list[str] = []
    for message in result.get("messages", []):
        if isinstance(message, ToolMessage):
            name = getattr(message, "name", None)
            if name and name not in tool_names:
                tool_names.append(name)

    final_text = ""
    for message in reversed(result.get("messages", [])):
        if isinstance(message, AIMessage):
            text = _content_to_text(message.content).strip()
            if text:
                final_text = text
                break

    return final_text or "I couldn't produce an answer.", tool_names

# Personal Finance AI Agent

A complete single-agent personal-finance assistant built with **LangChain**, **Streamlit**, a **web-search tool**, and a **safe calculator tool**.

It follows the architecture from the supplied design:

`User -> LangChain AI Agent -> (Web Search / Calculator when needed) -> LLM -> Answer`

## What it can do

- Answer finance questions from the model's knowledge when tools are not needed.
- Search the web for current stock prices, market news, currency rates, and other time-sensitive information.
- Perform accurate arithmetic such as percentages, conversions, compound interest, and returns.
- Decide autonomously whether to use the web-search or calculator tool.
- Show the conversation in a simple Streamlit UI.
- Display which tools were used for each answer.

## Example questions

- `What is Apple's current stock price?`
- `Convert 250 USD to INR.`
- `What is 15% of 7,849.60?`
- `How much will $30,000 grow in 5 years at 8% annual interest compounded yearly?`
- `Who won the F1 race in Monaco in 2024?`
- `What is the population of Tokyo?`

## Requirements

- Python 3.10+
- An OpenAI API key (default provider) OR Anthropic API key
- A Tavily API key for live web search

## Setup

### 1. Create a virtual environment

Windows PowerShell:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
```

macOS/Linux:

```bash
python3 -m venv .venv
source .venv/bin/activate
```

### 2. Install dependencies

```bash
pip install -r requirements.txt
```

### 3. Configure environment variables

Copy `.env.example` to `.env` and fill in your keys.

For OpenAI:

```env
MODEL_PROVIDER=openai
OPENAI_API_KEY=your_key
OPENAI_MODEL=gpt-4o-mini
TAVILY_API_KEY=your_tavily_key
```

For Anthropic:

```env
MODEL_PROVIDER=anthropic
ANTHROPIC_API_KEY=your_key
ANTHROPIC_MODEL=claude-3-5-sonnet-latest
TAVILY_API_KEY=your_tavily_key
```

### 4. Run

```bash
streamlit run app.py
```

The browser UI will open automatically.

## Project structure

```text
personal_finance_agent/
├── app.py                 # Streamlit frontend
├── requirements.txt
├── .env.example
├── .gitignore
├── README.md
├── app/
│   ├── __init__.py
│   ├── agent.py           # LangChain agent + model selection
│   ├── config.py          # Environment/configuration
│   ├── prompts.py         # Agent system prompt
│   └── tools.py           # Web search + safe calculator tools
└── tests/
    └── test_calculator.py
```

## Notes on tool behavior

The agent is explicitly instructed to use web search for information that can change over time, such as current prices, exchange rates, market news, and current events. It is instructed to use the calculator for arithmetic instead of doing important calculations mentally.

The calculator accepts only numbers, arithmetic operators, parentheses, decimal points, percentages, and a small set of mathematical functions. It does **not** execute arbitrary Python code.

## Important

This is an educational/demo personal-finance assistant, not a registered financial adviser. Current financial information should be independently verified before making investment or other financial decisions.

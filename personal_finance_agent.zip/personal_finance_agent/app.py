from __future__ import annotations

import streamlit as st

from app.agent import run_agent
from app.config import settings, validate_settings

st.set_page_config(
    page_title="Personal Finance AI Agent",
    page_icon="💰",
    layout="centered",
)

st.title("💰 Personal Finance AI Agent")
st.caption("LangChain single-agent architecture • Web Search + Calculator")

with st.sidebar:
    st.header("Agent")
    st.write(f"Provider: `{settings.model_provider}`")
    model_name = settings.openai_model if settings.model_provider == "openai" else settings.anthropic_model
    st.write(f"Model: `{model_name}`")
    st.divider()
    st.subheader("Examples")
    examples = [
        "What is Apple's current stock price?",
        "Convert 250 USD to INR.",
        "What is 15% of 7,849.60?",
        "How much will $30,000 grow in 5 years at 8% annual interest compounded yearly?",
        "Who won the F1 race in Monaco in 2024?",
        "What is the population of Tokyo?",
    ]
    for example in examples:
        st.write(f"• {example}")
    if st.button("Clear chat", use_container_width=True):
        st.session_state.messages = []
        st.rerun()

errors = validate_settings()
if errors:
    st.warning("Configuration needs attention:\n\n" + "\n".join(f"- {e}" for e in errors))
    st.info("Copy `.env.example` to `.env`, add your API keys, then restart Streamlit.")

if "messages" not in st.session_state:
    st.session_state.messages = []

for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])
        if message.get("tools"):
            st.caption("Tools used: " + ", ".join(message["tools"]))

question = st.chat_input("Ask a finance question...")

if question:
    st.session_state.messages.append({"role": "user", "content": question})
    with st.chat_message("user"):
        st.markdown(question)

    with st.chat_message("assistant"):
        with st.spinner("Thinking and choosing tools..."):
            try:
                history = [
                    {"role": m["role"], "content": m["content"]}
                    for m in st.session_state.messages[:-1]
                    if m["role"] in {"user", "assistant"}
                ]
                answer, tools_used = run_agent(question, history=history)
                st.markdown(answer)
                if tools_used:
                    st.caption("Tools used: " + ", ".join(tools_used))
                st.session_state.messages.append(
                    {"role": "assistant", "content": answer, "tools": tools_used}
                )
            except Exception as exc:
                error_text = f"I couldn't complete that request. Error: `{exc}`"
                st.error(error_text)
                st.session_state.messages.append(
                    {"role": "assistant", "content": error_text, "tools": []}
                )

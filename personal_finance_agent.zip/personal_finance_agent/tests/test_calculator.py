import pytest

from app.tools import safe_calculate


def test_percentage():
    assert safe_calculate("15% * 7849.60") == pytest.approx(1177.44)


def test_compound_interest():
    assert safe_calculate("30000 * (1 + 0.08) ** 5") == pytest.approx(44079.846912)


def test_parentheses():
    assert safe_calculate("(250 * 83.5) / 100") == pytest.approx(208.75)


def test_blocks_code_execution():
    with pytest.raises(ValueError):
        safe_calculate("__import__('os').system('echo unsafe')")

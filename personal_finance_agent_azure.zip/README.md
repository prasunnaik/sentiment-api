# Personal Finance AI Agent — Azure OpenAI

A complete single-agent personal finance assistant built with **LangChain** and **Azure OpenAI**.

The agent automatically decides whether it needs:
- **Web Search** — for current stock prices, exchange rates, market news, and other changing information.
- **Calculator** — for percentages, conversions, investment returns, compound interest, and arithmetic.

## Architecture

```text
User
  |
  v
Streamlit UI
  |
  v
LangChain AI Agent
  |
  +------> Azure OpenAI
  |
  +------> Web Search Tool (DuckDuckGo)
  |
  +------> Calculator Tool (safe AST evaluator)
  |
  v
Answer
```

## Azure environment variables

This project uses the same variable names shown in the supplied `.env` screenshot:

```env
AZURE_OPENAI_API_KEY=...
AZURE_OPENAI_ENDPOINT=...
AZURE_OPENAI_DEPLOYMENT=...
AZURE_OPENAI_CHAT_MODEL=...
AZURE_OPENAI_API_VERSION=...
```

**Important:** `.env` is intentionally not included in this ZIP. Put your real Azure values in a local `.env` file. Never commit the key to GitHub.

The project does not require a Tavily/SerpAPI key because web search is implemented with DuckDuckGo.

## Setup

### 1. Create a virtual environment

Windows:

```powershell
python -m venv .venv
.venv\Scripts\activate
```

macOS/Linux:

```bash
python3 -m venv .venv
source .venv/bin/activate
```

### 2. Install dependencies

```bash
pip install -r requirements.txt
```

### 3. Create `.env`

Copy `.env.example` to `.env` and replace the placeholders with your Azure OpenAI values.

### 4. Run the application

```bash
streamlit run app.py
```

Open the Streamlit URL shown in the terminal.

## Example questions

### Calculator
- What is 15% of 7,849.60?
- How much will 50,000 grow to in 5 years at 8% annual compound interest?
- Convert 250 USD to INR.  
  The agent should search for the current exchange rate and then calculate the result.

### Web search
- What is Apple's current stock price?
- What is the latest USD to INR exchange rate?
- What are the latest major market headlines?

### Mixed tool usage
- If 250 USD is converted to INR using today's rate, what is the result?

The agent can search first and then use the calculator.

## Testing

Run:

```bash
pytest -q
```

The tests cover arithmetic, percentage calculations, compound interest, and rejection of arbitrary Python code.

## Security notes

- Do not place your Azure API key directly in Python source code.
- `.env` is ignored by Git.
- The calculator does not call `eval()`; it parses only approved arithmetic AST nodes.
- Current financial data should be retrieved using the web-search tool rather than guessed.

## Project structure

```text
personal_finance_agent_azure/
├── app.py
├── .env.example
├── .gitignore
├── README.md
├── requirements.txt
├── src/
│   ├── __init__.py
│   ├── agent.py
│   └── tools.py
└── tests/
    └── test_calculator.py
```

from src.tools import calculator


def test_percentage():
    assert calculator.invoke("15 / 100 * 7849.60") == "1177.44"


def test_compound_interest():
    result = float(calculator.invoke("50000 * (1 + 0.08) ** 5"))
    assert round(result, 2) == 73466.4


def test_basic_arithmetic():
    assert calculator.invoke("250 * 83.5") == "20875"


def test_rejects_code():
    result = calculator.invoke("__import__('os').system('whoami')")
    assert result.startswith("Calculation error:")

"""Configuration reference for the Azure OpenAI project.

AzureChatOpenAI reads these standard environment variables:
AZURE_OPENAI_API_KEY
AZURE_OPENAI_ENDPOINT
AZURE_OPENAI_API_VERSION

The project also keeps:
AZURE_OPENAI_DEPLOYMENT
AZURE_OPENAI_CHAT_MODEL

in the .env file so the configuration matches the supplied setup.
"""

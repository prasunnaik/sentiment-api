import ast
import math
import operator as op

from langchain_core.tools import tool
from langchain_community.tools import DuckDuckGoSearchRun


_search = DuckDuckGoSearchRun()

_ALLOWED_BINOPS = {
    ast.Add: op.add,
    ast.Sub: op.sub,
    ast.Mult: op.mul,
    ast.Div: op.truediv,
    ast.Pow: op.pow,
    ast.Mod: op.mod,
    ast.FloorDiv: op.floordiv,
}

_ALLOWED_UNARYOPS = {
    ast.UAdd: op.pos,
    ast.USub: op.neg,
}


def _safe_eval(node):
    if isinstance(node, ast.Expression):
        return _safe_eval(node.body)

    if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)):
        if not math.isfinite(node.value):
            raise ValueError("Non-finite number is not allowed.")
        return node.value

    if isinstance(node, ast.UnaryOp) and type(node.op) in _ALLOWED_UNARYOPS:
        return _ALLOWED_UNARYOPS[type(node.op)](_safe_eval(node.operand))

    if isinstance(node, ast.BinOp) and type(node.op) in _ALLOWED_BINOPS:
        left = _safe_eval(node.left)
        right = _safe_eval(node.right)
        if isinstance(node.op, ast.Pow) and abs(right) > 100:
            raise ValueError("Exponent is too large.")
        value = _ALLOWED_BINOPS[type(node.op)](left, right)
        if not math.isfinite(value):
            raise ValueError("Result is not finite.")
        return value

    raise ValueError(
        "Only numeric arithmetic is allowed: +, -, *, /, //, %, and **."
    )


@tool
def calculator(expression: str) -> str:
    """
    Safely calculate a numeric arithmetic expression.

    Examples:
    - 15 / 100 * 7849.60
    - 50000 * (1 + 0.08) ** 5
    - (250 * 83.5)
    """
    try:
        tree = ast.parse(expression.strip(), mode="eval")
        result = _safe_eval(tree)
        return f"{result:.10g}"
    except Exception as exc:
        return f"Calculation error: {exc}"


@tool
def web_search(query: str) -> str:
    """
    Search the web for current or factual information, especially finance,
    markets, stock prices, exchange rates, and recent news.
    """
    try:
        result = _search.invoke(query)
        return str(result)
    except Exception as exc:
        return f"Web search error: {exc}"

# InsureWise BR04/BR05 S3 implementation

This version keeps the existing BR04/BR05 business logic and adds the S3 integration with the smallest necessary backend changes.

## Existing pieces intentionally kept

- `S3StorageService` in `insurewise-service/common/service` is retained as the application's compatibility abstraction.
- `DisabledS3StorageService` is retained as source code, but is no longer registered as a Spring bean. The framework now supplies the enabled/disabled `S3FileService` implementation.
- Existing Flyway migrations `V9`, `V11`, and `V3` were not changed because the uploaded project already contains the required profile-picture S3-key and application-document tables.
- Existing authentication, JWT, policy, category, application, approval/rejection, and dashboard logic is otherwise unchanged.

## S3 framework added

Under `s3-framework/s3-file-storage/src/main/java/com/insurewise/framework/s3/`:

- `annotation/EnableS3Upload.java`
- `annotation/EnableS3Delete.java`
- `annotation/S3FileField.java`
- `aspect/S3UploadAspect.java`
- `aspect/S3DeleteAspect.java`
- `config/S3Properties.java`
- `config/S3AutoConfiguration.java`
- `controller/S3FileController.java`
- `exception/S3FileStorageException.java`
- `exception/S3FileValidationException.java`
- `service/S3FileService.java`
- `service/AwsS3FileService.java`
- `service/DisabledS3FileService.java`
- `service/S3PresignedUrl.java`

The implementation uses the AWS Java SDK v1 already declared by the scaffold (`aws-java-sdk-s3:1.12.400`).

## BR04 changes

1. `StaffUser` now maps the existing `staff_users.profile_picture_s3_key` column.
2. `StaffProfileResponse` now contains `profilePictureUrl`.
3. `StaffUserService` now uploads profile pictures to `staff/profile-pictures/<staff-id>/...`.
4. Updating a picture uploads the new object, stores its key, and removes the previous S3 object.
5. A dedicated `POST /api/staff/users/{id}/profile-picture` endpoint is provided.
6. `DELETE /api/staff/users/{id}/profile-picture` removes the S3 object and clears the DB key.
7. Existing JSON create/update endpoints remain available. Multipart create/update endpoints were added alongside them, so existing clients are not forced to change immediately.
8. Staff list/get responses return a temporary presigned URL when a profile picture exists.

## BR05 changes

The existing `application_documents` table is now wired to Java code:

- `PolicyApplicationDocument` entity
- `PolicyApplicationDocumentRepository`
- `PolicyApplicationDocumentResponse`
- `PolicyApplicationDocumentService`
- `PolicyApplicationDocumentController`
- `ApplicationDocumentNotFoundException`

Endpoints:

- `POST /api/applications/{applicationId}/documents` - STAFF, multipart field `file`
- `GET /api/applications/{applicationId}/documents` - STAFF, returns metadata and temporary download URLs
- `DELETE /api/applications/{applicationId}/documents/{documentId}` - STAFF

Document records store file name, content type, S3 key, uploading staff user, and creation timestamp, matching the existing database migration.

## Compatibility adapter

`FrameworkS3StorageService` was added under `common/service` to adapt the existing application's `S3StorageService` interface to the new framework's `S3FileService`. This avoids rewriting the existing BR04/BR05 services around a new interface.

## Configuration

The existing `application.yml` already contains the framework configuration:

- `S3_ENABLED`
- `S3_BUCKET_NAME`
- `AWS_REGION`
- `AWS_ACCESS_KEY_ID`
- `AWS_SECRET_ACCESS_KEY`
- `S3_ENDPOINT`
- `S3_PATH_STYLE_ACCESS_ENABLED`
- `S3_KEY_PREFIX`

Keep `S3_ENABLED=false` when you want the application to run without S3. Set it to `true` and provide the bucket/credentials when using AWS S3.

## S3 key layout

Profile pictures:

`<key-prefix>/staff/profile-pictures/<staff-uuid>/<random-file-name>`

Application documents:

`<key-prefix>/policy-applications/documents/<application-uuid>/<random-file-name>`

Files are not stored as binary data in PostgreSQL. PostgreSQL stores only the S3 key and metadata.

## Dependency compatibility change

The S3 framework parent Spring Boot version was aligned from `3.5.5` to `3.2.5` to match the application. This avoids pulling a different Spring Framework generation into the application through the framework dependency.

## Build verification

The environment used to prepare this package did not have Maven installed, so a real `mvn clean install` could not be executed here. XML parsing and Java brace/syntax-structure smoke checks were performed. Run the project's normal `run.ps1` on a machine with JDK 17 and Maven to perform the actual Maven compilation.

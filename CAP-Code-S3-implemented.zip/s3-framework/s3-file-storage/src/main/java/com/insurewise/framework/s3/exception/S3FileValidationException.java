package com.insurewise.framework.s3.exception;

public class S3FileValidationException extends RuntimeException {
    public S3FileValidationException(String message) {
        super(message);
    }
}

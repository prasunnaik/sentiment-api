package com.insurewise.framework.s3.exception;

public class S3FileStorageException extends RuntimeException {
    public S3FileStorageException(String message) {
        super(message);
    }

    public S3FileStorageException(String message, Throwable cause) {
        super(message, cause);
    }
}

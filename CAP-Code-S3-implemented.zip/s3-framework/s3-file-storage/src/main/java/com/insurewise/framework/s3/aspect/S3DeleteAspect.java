package com.insurewise.framework.s3.aspect;

import com.insurewise.framework.s3.annotation.EnableS3Delete;
import com.insurewise.framework.s3.annotation.S3FileField;
import com.insurewise.framework.s3.service.S3FileService;
import java.lang.reflect.Field;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class S3DeleteAspect {

    private final S3FileService fileService;

    public S3DeleteAspect(S3FileService fileService) {
        this.fileService = fileService;
    }

    @Around("@annotation(enableS3Delete)")
    public Object delete(
            ProceedingJoinPoint joinPoint,
            EnableS3Delete enableS3Delete) throws Throwable {

        for (Object argument : joinPoint.getArgs()) {
            if (argument == null) {
                continue;
            }

            String key = findS3FileField(argument);
            if (key != null && !key.isBlank()) {
                fileService.delete(key);
            }
        }

        return joinPoint.proceed();
    }

    private String findS3FileField(Object target)
            throws IllegalAccessException {

        for (Field field : target.getClass().getDeclaredFields()) {
            if (!field.isAnnotationPresent(S3FileField.class)
                    || field.getType() != String.class) {
                continue;
            }

            field.setAccessible(true);
            Object value = field.get(target);
            return value instanceof String string ? string : null;
        }

        return null;
    }
}

package com.insurewise.policy.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Table(name = "application_documents")
public class PolicyApplicationDocument {

    @Id
    @GeneratedValue
    private UUID id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "policy_application_id", nullable = false)
    private PolicyApplication policyApplication;

    @Column(name = "file_name", nullable = false, length = 255)
    private String fileName;

    @Column(name = "content_type", length = 100)
    private String contentType;

    @Column(name = "s3_key", nullable = false, length = 600)
    private String s3Key;

    @Column(name = "uploaded_by", nullable = false)
    private UUID uploadedBy;

    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;

    protected PolicyApplicationDocument() {
    }

    public PolicyApplicationDocument(
            PolicyApplication policyApplication,
            String fileName,
            String contentType,
            String s3Key,
            UUID uploadedBy) {
        this.policyApplication = policyApplication;
        this.fileName = fileName;
        this.contentType = contentType;
        this.s3Key = s3Key;
        this.uploadedBy = uploadedBy;
    }

    @PrePersist
    void initialize() {
        if (createdAt == null) {
            createdAt = LocalDateTime.now();
        }
    }

    public UUID getId() {
        return id;
    }

    public PolicyApplication getPolicyApplication() {
        return policyApplication;
    }

    public String getFileName() {
        return fileName;
    }

    public String getContentType() {
        return contentType;
    }

    public String getS3Key() {
        return s3Key;
    }

    public UUID getUploadedBy() {
        return uploadedBy;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }
}

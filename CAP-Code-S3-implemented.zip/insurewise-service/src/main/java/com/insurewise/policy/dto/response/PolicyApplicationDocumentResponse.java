package com.insurewise.policy.dto.response;

import java.time.LocalDateTime;
import java.util.UUID;

public record PolicyApplicationDocumentResponse(
        UUID id,
        UUID applicationId,
        String fileName,
        String contentType,
        String downloadUrl,
        UUID uploadedBy,
        LocalDateTime createdAt
) {
}

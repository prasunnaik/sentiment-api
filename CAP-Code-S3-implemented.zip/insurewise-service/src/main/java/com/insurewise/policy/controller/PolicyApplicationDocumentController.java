package com.insurewise.policy.controller;

import com.insurewise.common.security.JwtPrincipal;
import com.insurewise.policy.dto.response.PolicyApplicationDocumentResponse;
import com.insurewise.policy.service.PolicyApplicationDocumentService;
import java.util.List;
import java.util.UUID;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/api/applications/{applicationId}/documents")
@PreAuthorize("hasRole('STAFF')")
public class PolicyApplicationDocumentController {

    private final PolicyApplicationDocumentService service;

    public PolicyApplicationDocumentController(
            PolicyApplicationDocumentService service) {
        this.service = service;
    }

    @PostMapping(consumes = "multipart/form-data")
    public PolicyApplicationDocumentResponse upload(
            @PathVariable UUID applicationId,
            @AuthenticationPrincipal JwtPrincipal principal,
            @RequestPart("file") MultipartFile file) {

        return service.upload(
                applicationId,
                principal.userId(),
                file);
    }

    @GetMapping
    public List<PolicyApplicationDocumentResponse> list(
            @PathVariable UUID applicationId) {
        return service.list(applicationId);
    }

    @DeleteMapping("/{documentId}")
    public void delete(
            @PathVariable UUID applicationId,
            @PathVariable UUID documentId) {
        service.delete(applicationId, documentId);
    }
}

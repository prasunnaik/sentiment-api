package com.insurewise.policy.service;

import com.insurewise.common.service.S3StorageService;
import com.insurewise.policy.dto.response.PolicyApplicationDocumentResponse;
import com.insurewise.policy.entity.PolicyApplication;
import com.insurewise.policy.entity.PolicyApplicationDocument;
import com.insurewise.policy.repository.PolicyApplicationDocumentRepository;
import com.insurewise.policy.exception.ApplicationDocumentNotFoundException;
import java.util.List;
import java.util.UUID;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

@Service
@Transactional
public class PolicyApplicationDocumentService {

    private final PolicyApplicationDocumentRepository repository;
    private final PolicyApplicationService applicationService;
    private final S3StorageService storageService;

    public PolicyApplicationDocumentService(
            PolicyApplicationDocumentRepository repository,
            PolicyApplicationService applicationService,
            S3StorageService storageService) {
        this.repository = repository;
        this.applicationService = applicationService;
        this.storageService = storageService;
    }

    public PolicyApplicationDocumentResponse upload(
            UUID applicationId,
            UUID uploadedBy,
            MultipartFile file) {

        try {
            PolicyApplication application =
                    applicationService
                            .getApplicationEntityForInternalUse(
                                    applicationId);

            String fileName = file.getOriginalFilename();
            if (fileName == null || fileName.isBlank()) {
                fileName = "document";
            }

            String contentType = file.getContentType();
            if (contentType == null || contentType.isBlank()) {
                contentType = "application/octet-stream";
            }

            String s3Key = storageService.upload(
                    file,
                    "policy-applications/documents",
                    applicationId);

            PolicyApplicationDocument document =
                    new PolicyApplicationDocument(
                            application,
                            fileName,
                            contentType,
                            s3Key,
                            uploadedBy);

            return toResponse(repository.save(document));

        } catch (Exception exception) {
            System.err.println(
                    "Error in PolicyApplicationDocumentService.upload: "
                            + exception.getMessage());
            throw exception;
        }
    }

    @Transactional(readOnly = true)
    public List<PolicyApplicationDocumentResponse> list(
            UUID applicationId) {

        try {
            applicationService
                    .getApplicationEntityForInternalUse(applicationId);

            return repository
                    .findByPolicyApplicationIdOrderByCreatedAtDesc(
                            applicationId)
                    .stream()
                    .map(this::toResponse)
                    .toList();

        } catch (Exception exception) {
            System.err.println(
                    "Error in PolicyApplicationDocumentService.list: "
                            + exception.getMessage());
            throw exception;
        }
    }

    public void delete(UUID applicationId, UUID documentId) {

        try {
            PolicyApplicationDocument document =
                    repository.findById(documentId)
                            .orElseThrow(() ->
                                    new ApplicationDocumentNotFoundException(
                                            documentId));

            if (!document.getPolicyApplication().getId().equals(applicationId)) {
                throw new ApplicationDocumentNotFoundException(documentId);
            }

            storageService.delete(document.getS3Key());
            repository.delete(document);

        } catch (Exception exception) {
            System.err.println(
                    "Error in PolicyApplicationDocumentService.delete: "
                            + exception.getMessage());
            throw exception;
        }
    }

    private PolicyApplicationDocumentResponse toResponse(
            PolicyApplicationDocument document) {

        String downloadUrl = storageService
                .getPresignedDownloadUrl(document.getS3Key())
                .url();

        return new PolicyApplicationDocumentResponse(
                document.getId(),
                document.getPolicyApplication().getId(),
                document.getFileName(),
                document.getContentType(),
                downloadUrl,
                document.getUploadedBy(),
                document.getCreatedAt());
    }
}

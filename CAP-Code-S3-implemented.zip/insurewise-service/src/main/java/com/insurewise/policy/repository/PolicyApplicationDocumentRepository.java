package com.insurewise.policy.repository;

import com.insurewise.policy.entity.PolicyApplicationDocument;
import java.util.List;
import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PolicyApplicationDocumentRepository
        extends JpaRepository<PolicyApplicationDocument, UUID> {

    List<PolicyApplicationDocument>
    findByPolicyApplicationIdOrderByCreatedAtDesc(
            UUID policyApplicationId);
}

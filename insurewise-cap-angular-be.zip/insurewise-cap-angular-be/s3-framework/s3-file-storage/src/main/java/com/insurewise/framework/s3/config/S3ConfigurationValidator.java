package com.insurewise.framework.s3.config;

import com.amazonaws.AmazonServiceException;
import com.amazonaws.services.s3.AmazonS3;
import com.insurewise.framework.s3.exception.S3ConfigurationException;
import jakarta.annotation.PostConstruct;
import java.util.Locale;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.env.Environment;
import org.springframework.util.StringUtils;

public class S3ConfigurationValidator {
    private static final Logger log = LoggerFactory.getLogger(S3ConfigurationValidator.class);

    private final AmazonS3 amazonS3;
    private final S3FileStorageProperties properties;
    private final Environment environment;

    public S3ConfigurationValidator(
            AmazonS3 amazonS3,
            S3FileStorageProperties properties,
            Environment environment) {
        this.amazonS3 = amazonS3;
        this.properties = properties;
        this.environment = environment;
    }

    @PostConstruct
    void validate() {
        if (!properties.enabled()) {
            return;
        }

        String bucket = requireValidBucket(properties.bucket());
        String region = normalizeRegion(properties.region());
        String endpoint = normalizeEndpoint(properties.endpoint());
        boolean startupValidationEnabled = properties.effectiveValidateBucketOnStartup();

        log.info(
                "S3 storage configuration: bucket='{}', region='{}', endpoint='{}', pathStyleAccessEnabled={}, startupBucketValidationEnabled={}, activeProfiles={}",
                bucket,
                region,
                sanitizeEndpoint(endpoint),
                properties.pathStyleAccessEnabled(),
                startupValidationEnabled,
                String.join(",", environment.getActiveProfiles()));

        if (!StringUtils.hasText(bucket)) {
            throw new S3ConfigurationException("S3 bucket configuration is missing. Set the S3_BUCKET environment variable.");
        }

        if (!StringUtils.hasText(region)) {
            throw new S3ConfigurationException("AWS region configuration is missing. Set AWS_REGION or insurewise.storage.region.");
        }

        validateEndpoint(endpoint);

        if (!startupValidationEnabled) {
            return;
        }

        try {
            if (!amazonS3.doesBucketExistV2(bucket)) {
                throw new S3ConfigurationException(
                        "Configured S3 bucket '" + bucket + "' does not exist or is not accessible in region '" + region + "'.");
            }

            String bucketLocation = amazonS3.getBucketLocation(bucket);
            String normalizedBucketRegion = normalizeBucketRegion(bucketLocation);
            if (StringUtils.hasText(normalizedBucketRegion)
                    && !region.equalsIgnoreCase(normalizedBucketRegion)) {
                throw new S3ConfigurationException(
                        "Configured AWS region '" + region + "' does not match bucket region '" + normalizedBucketRegion + "' for bucket '" + bucket + "'.");
            }
        } catch (AmazonServiceException exception) {
            throw new S3ConfigurationException(
                    "Unable to access configured S3 bucket '"
                            + bucket
                            + "' in region '"
                            + region
                            + "'. Verify bucket name, region, credentials, endpoint, and AWS account.",
                    exception);
        }
    }

    static String normalizeBucket(String bucket) {
        return bucket == null ? null : bucket.trim();
    }

    static String normalizeRegion(String region) {
        return region == null ? null : region.trim();
    }

    static String sanitizeEndpoint(String endpoint) {
        return StringUtils.hasText(endpoint) ? endpoint.trim() : "<aws-default>";
    }

    private String requireValidBucket(String bucketValue) {
        String bucket = normalizeBucket(bucketValue);
        if (!StringUtils.hasText(bucket)) {
            return bucket;
        }
        if (bucket.startsWith("s3://") || bucket.startsWith("http://") || bucket.startsWith("https://")) {
            throw new S3ConfigurationException(
                    "S3 bucket must be a bare bucket name without s3:// or URL syntax. Current value: '" + bucketValue + "'.");
        }
        if (bucket.contains("/")) {
            throw new S3ConfigurationException(
                    "S3 bucket must not contain path segments. Current value: '" + bucketValue + "'.");
        }
        return bucket;
    }

    private String normalizeEndpoint(String endpoint) {
        return endpoint == null ? null : endpoint.trim();
    }

    private void validateEndpoint(String endpoint) {
        if (!StringUtils.hasText(endpoint)) {
            return;
        }
        if (!(endpoint.startsWith("http://") || endpoint.startsWith("https://"))) {
            throw new S3ConfigurationException(
                    "S3 endpoint must start with http:// or https:// when configured.");
        }
    }

    private String normalizeBucketRegion(String bucketLocation) {
        if (!StringUtils.hasText(bucketLocation)) {
            return "";
        }
        String normalized = bucketLocation.trim().toLowerCase(Locale.ROOT);
        if ("us".equals(normalized)) {
            return "us-east-1";
        }
        return normalized;
    }
}

package com.insurewise.framework.s3.config;

import com.amazonaws.auth.DefaultAWSCredentialsProviderChain;
import com.amazonaws.client.builder.AwsClientBuilder;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.insurewise.framework.s3.service.AwsS3FileStorageService;
import com.insurewise.framework.s3.service.S3FileStorageService;
import java.net.URI;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.core.env.Environment;
/**
 * Represents the class S3 File Storage Auto Configuration.
*/

@AutoConfiguration
@ConditionalOnClass(AmazonS3.class)
@ConditionalOnProperty(
        prefix = "insurewise.storage",
        name = "enabled",
        havingValue = "true")
@EnableConfigurationProperties(S3FileStorageProperties.class)
public class S3FileStorageAutoConfiguration {
/**
 * Amazon S3.
 * @param properties the value supplied for the properties.
 * @return the result of the operation.
*/

    @Bean(destroyMethod = "shutdown")
    @ConditionalOnMissingBean
    public AmazonS3 amazonS3(
            S3FileStorageProperties properties) {
        String region = properties.region();
        AmazonS3ClientBuilder builder =
                AmazonS3ClientBuilder.standard()
                        .withRegion(region)
                        .withCredentials(
                                DefaultAWSCredentialsProviderChain
                                        .getInstance())
                        .withPathStyleAccessEnabled(
                                properties.pathStyleAccessEnabled());

        if (properties.endpoint() != null
                && !properties.endpoint().isBlank()) {
            builder.withEndpointConfiguration(
                    new AwsClientBuilder.EndpointConfiguration(
                            URI.create(properties.endpoint())
                                    .toString(),
                            region));
        }

        return builder.build();
    }
/**
 * S3 File Storage Service.
 * @param amazonS3 the value supplied for the amazonS3.
 * @param properties the value supplied for the properties.
 * @return the result of the operation.
*/

    @Bean
    @ConditionalOnMissingBean
    public S3FileStorageService s3FileStorageService(
            AmazonS3 amazonS3,
            S3FileStorageProperties properties) {

        return new AwsS3FileStorageService(
                amazonS3,
                properties);
    }

    @Bean
    @ConditionalOnMissingBean
    public S3ConfigurationValidator s3ConfigurationValidator(
            AmazonS3 amazonS3,
            S3FileStorageProperties properties,
            Environment environment) {
        return new S3ConfigurationValidator(amazonS3, properties, environment);
    }
}

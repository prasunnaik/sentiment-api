package com.insurewise.framework.s3.exception;

public class S3ConfigurationException extends RuntimeException {
    public S3ConfigurationException(String message) {
        super(message);
    }

    public S3ConfigurationException(String message, Throwable cause) {
        super(message, cause);
    }
}

package com.insurewise.framework.s3.service;

import java.time.Instant;
/**
 * Represents the record S3 Presigned Url.
*/

public record S3PresignedUrl(
        String url,
        Instant expiresAt
) {
}

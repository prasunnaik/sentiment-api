package com.insurewise.framework.s3.exception;

public class S3StorageException extends RuntimeException {
    private final String bucket;
    private final String region;
    private final String objectKey;
/**
 * S3 Storage Exception.
 * @param message the value supplied for the message.
 * @return the result of the operation.
*/

    public S3StorageException(String message) {
        super(message);
        this.bucket = null;
        this.region = null;
        this.objectKey = null;
    }
/**
 * S3 Storage Exception.
 * @param message the value supplied for the message.
 * @param cause the value supplied for the cause.
 * @return the result of the operation.
*/

    public S3StorageException(
            String message,
            Throwable cause) {
        super(message, cause);
        this.bucket = null;
        this.region = null;
        this.objectKey = null;
    }

    public S3StorageException(
            String message,
            String bucket,
            String region,
            String objectKey,
            Throwable cause) {
        super(message, cause);
        this.bucket = bucket;
        this.region = region;
        this.objectKey = objectKey;
    }

    public String getBucket() {
        return bucket;
    }

    public String getRegion() {
        return region;
    }

    public String getObjectKey() {
        return objectKey;
    }
}

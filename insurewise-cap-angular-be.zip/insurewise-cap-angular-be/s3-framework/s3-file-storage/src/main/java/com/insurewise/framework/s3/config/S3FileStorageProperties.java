package com.insurewise.framework.s3.config;

import java.time.Duration;
import org.springframework.boot.context.properties.ConfigurationProperties;
/**
 * Represents the record S3 File Storage Properties.
*/

@ConfigurationProperties(prefix = "insurewise.storage")
public record S3FileStorageProperties(
        boolean enabled,
        String bucket,
        String region,
        String keyPrefix,
        Duration presignedUrlTtl,
        String endpoint,
        boolean pathStyleAccessEnabled,
        boolean validateBucketOnStartup
) {
/**
 * Effective Presigned Url Ttl.
 * @return the result of the operation.
*/
    public Duration effectivePresignedUrlTtl() {
        return presignedUrlTtl == null
                ? Duration.ofMinutes(15)
                : presignedUrlTtl;
    }

    public boolean effectiveValidateBucketOnStartup() {
        return validateBucketOnStartup;
    }
}

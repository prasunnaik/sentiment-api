package com.insurewise.framework.s3.config;

import com.amazonaws.services.s3.AmazonS3;
import com.insurewise.framework.s3.exception.S3ConfigurationException;
import java.time.Duration;
import org.junit.jupiter.api.Test;
import org.springframework.mock.env.MockEnvironment;

import static org.assertj.core.api.Assertions.assertThatCode;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verifyNoInteractions;

class S3ConfigurationValidatorTest {

    @Test
    void rejectsMissingBucketWithClearVariableName() {
        AmazonS3 amazonS3 = mock(AmazonS3.class);
        S3ConfigurationValidator validator =
                new S3ConfigurationValidator(
                        amazonS3,
                        properties("", "us-east-1", null, false),
                        new MockEnvironment());

        assertThatThrownBy(validator::validate)
                .isInstanceOf(S3ConfigurationException.class)
                .hasMessageContaining("S3_BUCKET");
        verifyNoInteractions(amazonS3);
    }

    @Test
    void acceptsValidBucketWithoutNetworkCallWhenStartupValidationDisabled() {
        AmazonS3 amazonS3 = mock(AmazonS3.class);
        S3ConfigurationValidator validator =
                new S3ConfigurationValidator(
                        amazonS3,
                        properties("example-bucket", "us-east-1", null, false),
                        new MockEnvironment());

        assertThatCode(validator::validate).doesNotThrowAnyException();
        verifyNoInteractions(amazonS3);
    }

    @Test
    void rejectsBucketUrlSyntax() {
        AmazonS3 amazonS3 = mock(AmazonS3.class);
        S3ConfigurationValidator validator =
                new S3ConfigurationValidator(
                        amazonS3,
                        properties("s3://example-bucket", "us-east-1", null, false),
                        new MockEnvironment());

        assertThatThrownBy(validator::validate)
                .isInstanceOf(S3ConfigurationException.class)
                .hasMessageContaining("bare bucket name");
        verifyNoInteractions(amazonS3);
    }

    @Test
    void rejectsInvalidEndpointScheme() {
        AmazonS3 amazonS3 = mock(AmazonS3.class);
        S3ConfigurationValidator validator =
                new S3ConfigurationValidator(
                        amazonS3,
                        properties("local-bucket", "us-east-1", "localhost:4566", false),
                        new MockEnvironment().withProperty("spring.profiles.active", "local"));

        assertThatThrownBy(validator::validate)
                .isInstanceOf(S3ConfigurationException.class)
                .hasMessageContaining("http:// or https://");
        verifyNoInteractions(amazonS3);
    }

    @Test
    void acceptsLocalProfilePlaceholderConfiguration() {
        AmazonS3 amazonS3 = mock(AmazonS3.class);
        S3ConfigurationValidator validator =
                new S3ConfigurationValidator(
                        amazonS3,
                        properties("local-insurewise-documents", "us-east-1", "http://localhost:4566", false),
                        localEnvironment());

        assertThatCode(validator::validate).doesNotThrowAnyException();
        verifyNoInteractions(amazonS3);
    }

    private S3FileStorageProperties properties(
            String bucket,
            String region,
            String endpoint,
            boolean validateBucketOnStartup) {
        return new S3FileStorageProperties(
                true,
                bucket,
                region,
                "insurewise",
                Duration.ofMinutes(15),
                endpoint,
                endpoint != null,
                validateBucketOnStartup);
    }

    private MockEnvironment localEnvironment() {
        MockEnvironment environment = new MockEnvironment();
        environment.setActiveProfiles("local");
        return environment;
    }
}

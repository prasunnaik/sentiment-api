package com.insurewise.payments.dto.response;

import java.math.BigDecimal;
/**
 * Represents the record Payment Summary Response.
*/

public record PaymentSummaryResponse(
        BigDecimal totalRevenue,
        long successfulPayments,
        long failedPayments,
        long pendingPayments
) {
}
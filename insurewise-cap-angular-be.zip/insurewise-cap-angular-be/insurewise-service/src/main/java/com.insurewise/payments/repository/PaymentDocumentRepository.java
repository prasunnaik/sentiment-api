package com.insurewise.payments.repository;

import com.insurewise.payments.entity.PaymentDocument;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PaymentDocumentRepository
        extends JpaRepository<PaymentDocument, UUID> {

    List<PaymentDocument> findByPaymentIdOrderByCreatedAtDesc(
            UUID paymentId);

    Optional<PaymentDocument>
    findFirstByPaymentIdAndSystemGeneratedTrueOrderByCreatedAtDesc(
            UUID paymentId);
}

package com.insurewise.payments.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import java.time.LocalDateTime;
import java.util.UUID;
/**
 * Represents the class Payment Document.
*/

@Entity
@Table(name = "payment_documents")
public class PaymentDocument {

    @Id
    @GeneratedValue
    private UUID id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "payment_id", nullable = false)
    private Payment payment;

    @Column(name = "file_name", nullable = false, length = 255)
    private String fileName;

    @Column(name = "content_type", length = 100)
    private String contentType;

    @Column(name = "s3_key", nullable = false, length = 600)
    private String s3Key;

    @Column(name = "uploaded_by", nullable = false)
    private UUID uploadedBy;

    @Column(name = "system_generated", nullable = false)
    private boolean systemGenerated;

    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;
/**
 * Payment Document.
 * @return the result of the operation.
*/

    protected PaymentDocument() {
    }
/**
 * Payment Document.
 * @param payment the value supplied for the payment.
 * @param fileName the value supplied for the fileName.
 * @param contentType the value supplied for the contentType.
 * @param s3Key the value supplied for the s3Key.
 * @param uploadedBy the value supplied for the uploadedBy.
 * @param systemGenerated the value supplied for the systemGenerated.
 * @return the result of the operation.
*/

    public PaymentDocument(
            Payment payment,
            String fileName,
            String contentType,
            String s3Key,
            UUID uploadedBy,
            boolean systemGenerated) {

        this.payment = payment;
        this.fileName = fileName;
        this.contentType = contentType;
        this.s3Key = s3Key;
        this.uploadedBy = uploadedBy;
        this.systemGenerated = systemGenerated;
    }

    @PrePersist
    void initialize() {
        if (createdAt == null) {
            createdAt = LocalDateTime.now();
        }
    }
/**
 * Get Id.
 * @return the result of the operation.
*/

    public UUID getId() {
        return id;
    }
/**
 * Get Payment.
 * @return the result of the operation.
*/

    public Payment getPayment() {
        return payment;
    }
/**
 * Get File Name.
 * @return the result of the operation.
*/

    public String getFileName() {
        return fileName;
    }
/**
 * Get Content Type.
 * @return the result of the operation.
*/

    public String getContentType() {
        return contentType;
    }
/**
 * Get S3 Key.
 * @return the result of the operation.
*/

    public String getS3Key() {
        return s3Key;
    }
/**
 * Get Uploaded By.
 * @return the result of the operation.
*/

    public UUID getUploadedBy() {
        return uploadedBy;
    }
/**
 * Is System Generated.
 * @return the result of the operation.
*/

    public boolean isSystemGenerated() {
        return systemGenerated;
    }
/**
 * Get Created At.
 * @return the result of the operation.
*/

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }
}

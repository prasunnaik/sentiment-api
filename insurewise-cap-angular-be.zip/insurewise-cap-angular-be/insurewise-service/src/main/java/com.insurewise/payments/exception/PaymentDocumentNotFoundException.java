package com.insurewise.payments.exception;

import com.insurewise.common.exception.ResourceNotFoundException;
import java.util.UUID;

public class PaymentDocumentNotFoundException
        extends ResourceNotFoundException {
/**
 * Payment Document Not Found Exception.
 * @param id the value supplied for the id.
 * @return the result of the operation.
*/

    public PaymentDocumentNotFoundException(UUID id) {
        super("PAYMENT_DOCUMENT_NOT_FOUND", "Payment document not found: " + id);
    }
}
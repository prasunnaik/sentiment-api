package com.insurewise.payments.dto.response;

import com.insurewise.common.dto.PresignedUrlResponse;
import java.time.LocalDateTime;
import java.util.UUID;
/**
 * Represents the record Payment Document Response.
*/

public record PaymentDocumentResponse(
        UUID id,
        UUID paymentId,
        String fileName,
        String contentType,
        PresignedUrlResponse preview,
        PresignedUrlResponse download,
        UUID uploadedBy,
        boolean systemGenerated,
        LocalDateTime createdAt
) {
}
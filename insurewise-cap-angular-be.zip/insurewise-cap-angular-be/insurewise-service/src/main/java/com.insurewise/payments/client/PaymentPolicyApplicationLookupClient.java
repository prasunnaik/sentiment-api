package com.insurewise.payments.client;

import com.insurewise.policy.entity.ApplicationStatus;
import com.insurewise.policy.entity.PolicyApplication;
import com.insurewise.policy.exception.ApplicationNotFoundException;
import com.insurewise.policy.repository.PolicyApplicationRepository;
import java.util.UUID;
import org.springframework.stereotype.Component;
/**
 * Represents the class Payment Policy Application Lookup Client.
*/

@Component
public class PaymentPolicyApplicationLookupClient {
    private final PolicyApplicationRepository repository;
/**
 * Payment Policy Application Lookup Client.
 * @param repository the value supplied for the repository.
 * @return the result of the operation.
*/

    public PaymentPolicyApplicationLookupClient(
            PolicyApplicationRepository repository) {
        this.repository = repository;
    }
/**
 * Get Active Application For Customer.
 * @param applicationId the value supplied for the applicationId.
 * @param customerId the value supplied for the customerId.
 * @return the result of the operation.
*/

    public PaymentPolicyApplicationSnapshot
    getActiveApplicationForCustomer(
            UUID applicationId,
            UUID customerId) {

        PolicyApplication application = repository.findById(applicationId)
                .filter(item -> item.isOwnedBy(customerId))
                .filter(item -> item.getStatus() == ApplicationStatus.APPROVED)
                .orElseThrow(() -> new ApplicationNotFoundException(
                        applicationId));

        return new PaymentPolicyApplicationSnapshot(
                application.getId(),
                customerId,
                application.getPolicy().getName(),
                true);
    }
}
package com.insurewise.payments.service;

import com.insurewise.common.dto.PresignedUrlResponse;
import com.insurewise.common.exception.InvalidFileException;
import com.insurewise.common.security.JwtPrincipal;
import com.insurewise.common.security.JwtRole;
import com.insurewise.common.service.S3StorageService;
import com.insurewise.payments.dto.response.PaymentDocumentResponse;
import com.insurewise.payments.entity.Payment;
import com.insurewise.payments.entity.PaymentDocument;
import com.insurewise.payments.entity.PaymentStatus;
import com.insurewise.payments.exception.PaymentDocumentNotFoundException;
import com.insurewise.payments.exception.PaymentDocumentStateException;
import com.insurewise.payments.exception.PaymentNotFoundException;
import com.insurewise.payments.exception.PaymentStateException;
import com.insurewise.payments.repository.PaymentDocumentRepository;
import com.insurewise.payments.repository.PaymentRepository;
import java.nio.charset.StandardCharsets;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;
/**
 * Represents the class Payment Document Service.
*/

@Service
@Transactional
public class PaymentDocumentService {

    private static final Logger log =
            LoggerFactory.getLogger(PaymentDocumentService.class);

    private static final String S3_FOLDER = "payment-documents";
    private static final String RECEIPT_PREFIX = "receipt-";

    private static final DateTimeFormatter RECEIPT_DATE_FORMAT =
            DateTimeFormatter.ISO_LOCAL_DATE_TIME;

    private static final Set<String> ALLOWED_TYPES = Set.of(
            "application/pdf",
            "image/jpeg",
            "image/png",
            "image/webp");

    private final PaymentRepository paymentRepository;
    private final PaymentDocumentRepository documentRepository;
    private final S3StorageService storageService;
/**
 * Payment Document Service.
 * @param paymentRepository the value supplied for the paymentRepository.
 * @param documentRepository the value supplied for the documentRepository.
 * @param storageService the value supplied for the storageService.
 * @return the result of the operation.
*/

    public PaymentDocumentService(
            PaymentRepository paymentRepository,
            PaymentDocumentRepository documentRepository,
            S3StorageService storageService) {

        this.paymentRepository = paymentRepository;
        this.documentRepository = documentRepository;
        this.storageService = storageService;
    }
/**
 * Upload Document.
 * @param principal the value supplied for the principal.
 * @param paymentId the value supplied for the paymentId.
 * @param file the value supplied for the file.
 * @return the result of the operation.
*/

    public PaymentDocumentResponse uploadDocument(
            JwtPrincipal principal,
            UUID paymentId,
            MultipartFile file) {

        Payment payment = requirePaymentAccess(
                principal,
                paymentId);

        validateFile(file);

        String fileName = file.getOriginalFilename() == null
                ? "payment-document"
                : file.getOriginalFilename();

        String s3Key = storageService.upload(
                file,
                S3_FOLDER,
                principal.userId());

        try {
            PaymentDocument document =
                    documentRepository.saveAndFlush(
                            new PaymentDocument(
                                    payment,
                                    fileName,
                                    file.getContentType(),
                                    s3Key,
                                    principal.userId(),
                                    false));

            return toResponse(document);

        } catch (RuntimeException exception) {
            deleteQuietly(s3Key);
            throw exception;
        }
    }
/**
 * List Documents.
 * @param principal the value supplied for the principal.
 * @param paymentId the value supplied for the paymentId.
 * @return the result of the operation.
*/

    @Transactional(readOnly = true)
    public List<PaymentDocumentResponse> listPaymentDocuments(
            JwtPrincipal principal,
            UUID paymentId) {

        requirePaymentAccess(principal, paymentId);

        return documentRepository
                .findByPaymentIdOrderByCreatedAtDesc(paymentId)
                .stream()
                .map(this::toResponse)
                .toList();
    }

    @Transactional(readOnly = true)
    public PresignedUrlResponse previewDocument(
            JwtPrincipal principal,
            UUID paymentId,
            UUID documentId) {
        PaymentDocument document = requireDocumentAccess(principal, paymentId, documentId);
        return storageService.getPresignedPreviewUrl(document.getS3Key());
    }

    @Transactional(readOnly = true)
    public PresignedUrlResponse downloadDocument(
            JwtPrincipal principal,
            UUID paymentId,
            UUID documentId) {
        PaymentDocument document = requireDocumentAccess(principal, paymentId, documentId);
        return storageService.getPresignedDownloadUrl(document.getS3Key());
    }
/**
 * Delete Document.
 * @param principal the value supplied for the principal.
 * @param paymentId the value supplied for the paymentId.
 * @param documentId the value supplied for the documentId.
*/

    public void deleteDocument(
            JwtPrincipal principal,
            UUID paymentId,
            UUID documentId) {

        requirePaymentAccess(principal, paymentId);

        PaymentDocument document =
                documentRepository.findById(documentId)
                        .filter(item -> item.getPayment().getId()
                                .equals(paymentId))
                        .orElseThrow(() ->
                                new PaymentDocumentNotFoundException(
                                        documentId));

        if (document.isSystemGenerated()) {
            throw new PaymentDocumentStateException(
                    "System-generated receipts cannot be deleted.");
        }

        storageService.delete(document.getS3Key());
        documentRepository.delete(document);
    }
/**
 * Create System Receipt.
 * @param paymentId the value supplied for the paymentId.
 * @return the result of the operation.
*/

    public PaymentDocumentResponse createSystemReceipt(
            UUID paymentId) {

        Payment payment = paymentRepository.findById(paymentId)
                .orElseThrow(() ->
                        new PaymentNotFoundException(paymentId));

        if (payment.getStatus() != PaymentStatus.SUCCESS) {
            throw new PaymentStateException(
                    "Receipt requires a successful payment.");
        }

        return documentRepository
                .findFirstByPaymentIdAndSystemGeneratedTrueOrderByCreatedAtDesc(
                        paymentId)
                .map(this::toResponse)
                .orElseGet(() -> createReceipt(payment));
    }
/**
 * Create Receipt.
 * @param payment the value supplied for the payment.
 * @return the result of the operation.
*/

    private PaymentDocumentResponse createReceipt(
            Payment payment) {

        String fileName = "receipt-"
                + payment.getTransactionRef()
                + ".txt";

        String receipt = """
                InsureWise Payment Receipt
                --------------------------
                Transaction: %s
                Payment ID: %s
                Customer ID: %s
                Policy: %s
                Amount: %s
                Method: %s
                Status: %s
                Paid At: %s
                """.formatted(
                payment.getTransactionRef(),
                payment.getId(),
                payment.getCustomerId(),
                payment.getPolicyNameSnapshot(),
                payment.getAmount(),
                payment.getMethod(),
                payment.getStatus(),
                payment.getPaidAt()
                        .format(RECEIPT_DATE_FORMAT));

        String s3Key = storageService.uploadGenerated(
                receipt.getBytes(StandardCharsets.UTF_8),
                fileName,
                "text/plain",
                S3_FOLDER,
                payment.getCustomerId());

        try {
            PaymentDocument document =
                    documentRepository.saveAndFlush(
                            new PaymentDocument(
                                    payment,
                                    fileName,
                                    "text/plain",
                                    s3Key,
                                    payment.getCustomerId(),
                                    true));

            return toResponse(document);

        } catch (RuntimeException exception) {
            deleteQuietly(s3Key);
            throw exception;
        }
    }
/**
 * Require Payment Access.
 * @param principal the value supplied for the principal.
 * @param paymentId the value supplied for the paymentId.
 * @return the result of the operation.
*/

    private Payment requirePaymentAccess(
            JwtPrincipal principal,
            UUID paymentId) {

        Payment payment = paymentRepository.findById(paymentId)
                .orElseThrow(() ->
                        new PaymentNotFoundException(paymentId));

        if (principal.role() == JwtRole.CUSTOMER
                && !payment.isOwnedBy(principal.userId())) {
            throw new PaymentNotFoundException(paymentId);
        }

        return payment;
    }
/**
 * Validate File.
 * @param file the value supplied for the file.
*/

    private void validateFile(MultipartFile file) {

        if (file == null || file.isEmpty()) {
            throw new InvalidFileException(
                    "A non-empty payment document is required.");
        }

        if (file.getContentType() == null
                || !ALLOWED_TYPES.contains(
                file.getContentType())) {
            throw new InvalidFileException(
                    "Only PDF, JPEG, PNG, and WebP files are allowed.");
        }
    }
/**
 * To Response.
 * @param document the value supplied for the document.
 * @return the result of the operation.
*/

    private PaymentDocumentResponse toResponse(
            PaymentDocument document) {

        PresignedUrlResponse preview =
                storageService.getPresignedPreviewUrl(
                        document.getS3Key());
        PresignedUrlResponse download =
                storageService.getPresignedDownloadUrl(
                        document.getS3Key());

        return new PaymentDocumentResponse(
                document.getId(),
                document.getPayment().getId(),
                document.getFileName(),
                document.getContentType(),
                preview,
                download,
                document.getUploadedBy(),
                document.isSystemGenerated(),
                document.getCreatedAt());
    }

    private PaymentDocument requireDocumentAccess(
            JwtPrincipal principal,
            UUID paymentId,
            UUID documentId) {
        requirePaymentAccess(principal, paymentId);

        return documentRepository.findById(documentId)
                .filter(item -> item.getPayment().getId().equals(paymentId))
                .orElseThrow(() -> new PaymentDocumentNotFoundException(documentId));
    }
/**
 * Delete Quietly.
 * @param s3Key the value supplied for the s3Key.
*/

    private void deleteQuietly(String s3Key) {
        try {
            storageService.delete(s3Key);
        } catch (RuntimeException exception) {
            log.warn(
                    "Could not clean up S3 object. key={}",
                    s3Key,
                    exception);
        }
    }
}

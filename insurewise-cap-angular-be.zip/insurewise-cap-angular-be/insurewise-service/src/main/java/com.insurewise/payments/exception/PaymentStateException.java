package com.insurewise.payments.exception;

import com.insurewise.common.exception.BusinessException;
import org.springframework.http.HttpStatus;

public class PaymentStateException extends BusinessException {
/**
 * Payment State Exception.
 * @param message the value supplied for the message.
 * @return the result of the operation.
*/

    public PaymentStateException(String message) {
        super("PAYMENT_STATE_ERROR", HttpStatus.CONFLICT, message);
    }
}
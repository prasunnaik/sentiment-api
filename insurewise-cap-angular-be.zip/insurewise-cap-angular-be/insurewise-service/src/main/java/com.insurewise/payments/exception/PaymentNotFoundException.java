package com.insurewise.payments.exception;

import com.insurewise.common.exception.ResourceNotFoundException;
import java.util.UUID;

public class PaymentNotFoundException extends ResourceNotFoundException {
/**
 * Payment Not Found Exception.
 * @param id the value supplied for the id.
 * @return the result of the operation.
*/

    public PaymentNotFoundException(UUID id) {
        super("PAYMENT_NOT_FOUND", "Payment not found: " + id);
    }
/**
 * Payment Not Found Exception.
 * @return the result of the operation.
*/

    public PaymentNotFoundException() {
        super("PAYMENT_NOT_FOUND", "Payment not found");
    }
}
package com.insurewise.payments.entity;
/**
 * Represents the enum Payment Method.
*/

public enum PaymentMethod {
    CREDIT_CARD,
    DEBIT_CARD,
    UPI,
    NET_BANKING
}
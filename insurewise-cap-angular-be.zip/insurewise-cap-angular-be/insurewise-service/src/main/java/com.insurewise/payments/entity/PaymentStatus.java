package com.insurewise.payments.entity;
/**
 * Represents the enum Payment Status.
*/

public enum PaymentStatus {
    SUCCESS,
    FAILED,
    PENDING
}
package com.insurewise.payments.exception;

import com.insurewise.common.exception.BusinessException;
import org.springframework.http.HttpStatus;

public class PaymentDocumentStateException
        extends BusinessException {
/**
 * Payment Document State Exception.
 * @param message the value supplied for the message.
 * @return the result of the operation.
*/

    public PaymentDocumentStateException(String message) {
        super("PAYMENT_DOCUMENT_STATE_ERROR", HttpStatus.CONFLICT, message);
    }
}
package com.insurewise.payments.dto.response;

import com.insurewise.payments.entity.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.UUID;
/**
 * Represents the record Payment Response.
*/

public record PaymentResponse(
        UUID id,
        String idempotencyKey,
        UUID customerId,
        UUID policyApplicationId,
        String policyName,
        BigDecimal amount,
        PaymentMethod method,
        PaymentStatus status,
        String transactionRef,
        LocalDateTime paidAt,
        LocalDateTime createdAt
) {
}
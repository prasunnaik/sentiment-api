package com.insurewise.payments.client;

import java.util.UUID;
/**
 * Represents the record Payment Policy Application Snapshot.
*/

public record PaymentPolicyApplicationSnapshot(
        UUID applicationId,
        UUID customerId,
        String policyName,
        boolean active
) {
}

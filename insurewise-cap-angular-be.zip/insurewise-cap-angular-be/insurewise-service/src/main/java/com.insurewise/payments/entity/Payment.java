package com.insurewise.payments.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.UUID;
import lombok.Getter;

@Entity
@Table(
        name = "payments",
        uniqueConstraints = {
                @UniqueConstraint(name = "uq_payments_idempotency_key",
                        columnNames = "idempotency_key"),
                @UniqueConstraint(name = "uq_payments_transaction_ref",
                        columnNames = "transaction_ref")
        })
/**
 * Represents the class Payment.
*/
@Getter
public class Payment {
    @Id
    @GeneratedValue
    private UUID id;

    @Column(name = "idempotency_key", nullable = false, length = 80)
    private String idempotencyKey;

    @Column(name = "customer_id", nullable = false)
    private UUID customerId;

    @Column(name = "policy_application_id", nullable = false)
    private UUID policyApplicationId;

    @Column(name = "policy_name_snapshot", nullable = false, length = 120)
    private String policyNameSnapshot;

    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal amount;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private PaymentMethod method;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private PaymentStatus status;

    @Column(name = "transaction_ref", nullable = false, length = 40)
    private String transactionRef;

    @Column(name = "paid_at", nullable = false)
    private LocalDateTime paidAt;

    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;

    protected Payment() {
    }

/**
 * Payment.
 * @param idempotencyKey the value supplied for the idempotencyKey.
 * @param customerId the value supplied for the customerId.
 * @param policyApplicationId the value supplied for the policyApplicationId.
 * @param policyNameSnapshot the value supplied for the policyNameSnapshot.
 * @param amount the value supplied for the amount.
 * @param method the value supplied for the method.
 * @return the result of the operation.
*/

    public Payment(
            String idempotencyKey,
            UUID customerId,
            UUID policyApplicationId,
            String policyNameSnapshot,
            BigDecimal amount,
            PaymentMethod method) {
        this.idempotencyKey = idempotencyKey;
        this.customerId = customerId;
        this.policyApplicationId = policyApplicationId;
        this.policyNameSnapshot = policyNameSnapshot;
        this.amount = amount;
        this.method = method;
        this.status = PaymentStatus.PENDING;
    }

    @PrePersist
    void initialize() {
        if (createdAt == null) {
            createdAt = LocalDateTime.now();
        }
    }
/**
 * Mark Success.
 * @param transactionRef the value supplied for the transactionRef.
*/

    public void markSuccess(String transactionRef) {
        if (status != PaymentStatus.PENDING) {
            throw new IllegalStateException("Payment is already processed");
        }
        this.status = PaymentStatus.SUCCESS;
        this.transactionRef = transactionRef;
        this.paidAt = LocalDateTime.now();
    }
/**
 * Mark Failed.
 * @param transactionRef the value supplied for the transactionRef.
*/

    public void markFailed(String transactionRef) {
        if (status != PaymentStatus.PENDING) {
            throw new IllegalStateException("Payment is already processed");
        }
        this.status = PaymentStatus.FAILED;
        this.transactionRef = transactionRef;
        this.paidAt = LocalDateTime.now();
    }
/**
 * Is Owned By.
 * @param customerId the value supplied for the customerId.
 * @return the result of the operation.
*/

    public boolean isOwnedBy(UUID customerId) {
        return this.customerId.equals(customerId);
    }

    public UUID getId() {
        return id;
    }

    public String getIdempotencyKey() {
        return idempotencyKey;
    }

    public UUID getCustomerId() {
        return customerId;
    }

    public UUID getPolicyApplicationId() {
        return policyApplicationId;
    }

    public String getPolicyNameSnapshot() {
        return policyNameSnapshot;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public PaymentMethod getMethod() {
        return method;
    }

    public PaymentStatus getStatus() {
        return status;
    }

    public String getTransactionRef() {
        return transactionRef;
    }

    public LocalDateTime getPaidAt() {
        return paidAt;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }
}
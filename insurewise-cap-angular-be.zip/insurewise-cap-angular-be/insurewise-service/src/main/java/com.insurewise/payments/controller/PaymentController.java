package com.insurewise.payments.controller;

import com.insurewise.common.dto.PageResponse;
import com.insurewise.common.dto.PresignedUrlResponse;
import com.insurewise.common.security.JwtPrincipal;
import com.insurewise.payments.dto.request.PaymentCreateRequest;
import com.insurewise.payments.dto.response.PaymentDocumentResponse;
import com.insurewise.payments.dto.response.PaymentResponse;
import com.insurewise.payments.dto.response.PaymentSummaryResponse;
import com.insurewise.payments.entity.PaymentStatus;
import com.insurewise.payments.service.PaymentDocumentService;
import com.insurewise.payments.service.PaymentService;
import jakarta.validation.Valid;
import java.util.List;
import jakarta.validation.constraints.*;
import java.util.UUID;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
/**
 * Exposes payment and payment-document endpoints for customer and staff workflows.
 *
*/
@RestController
@RequestMapping("/api/payments")
@Validated
public class PaymentController {
    private final PaymentService paymentService;
    private final PaymentDocumentService paymentDocumentService;

/**
 * Creates the payment controller with the service dependencies for payment lifecycle and document handling.
 *
 * @param paymentService the payment service used to create, list, and review transactions
 * @param paymentDocumentService the document service used for payment receipts and proof uploads
*/
    public PaymentController(
            PaymentService paymentService,
            PaymentDocumentService paymentDocumentService) {
        this.paymentService = paymentService;
        this.paymentDocumentService = paymentDocumentService;
    }

/**
 * Creates a new payment transaction for the authenticated customer.
 *
 * @param principal the customer initiating the payment
 * @param request the payment request with policy, amount, method, and reference information
 * @return the created payment response containing status and transaction metadata
*/
@PostMapping
@PreAuthorize("hasRole('CUSTOMER')")
public PaymentResponse makePayment(
        @AuthenticationPrincipal JwtPrincipal principal,
        @Valid @RequestBody PaymentCreateRequest request) {
    return paymentService.makePayment(principal.userId(), request);
}

/**
 * Lists payments visible to the caller with optional status filtering and pagination.
 *
 * @param principal the authenticated customer or staff user
 * @param status optional payment status filter
 * @param limit maximum number of payment records to return
 * @param offset zero-based offset for pagination
 * @return a paginated list of payments for the caller's access scope
*/
@GetMapping
@PreAuthorize("hasAnyRole('CUSTOMER', 'STAFF')")
public PageResponse<PaymentResponse> listPayments(
        @AuthenticationPrincipal JwtPrincipal principal,
        @RequestParam(required = false) PaymentStatus status,
        @RequestParam(defaultValue = "10") @Min(1) @Max(100) int limit,
        @RequestParam(defaultValue = "0") @Min(0) int offset) {
    return paymentService.listPayments(principal, status, limit, offset);
    }

/**
 * Retrieves the aggregate summary metrics used by the staff payment dashboard.
 *
 * @return payment summary statistics for all visible transactions
*/
@GetMapping("/summary")
@PreAuthorize("hasRole('STAFF')")
public PaymentSummaryResponse summary() {
    return paymentService.getSummary();
}

/**
 * Retrieves a single payment record in the authenticated user's permitted scope.
 *
 * @param principal the customer or staff user requesting the payment details
 * @param id the unique payment identifier
 * @return the matching payment response
*/
@GetMapping("/{id}")
@PreAuthorize("hasAnyRole('CUSTOMER', 'STAFF')")
public PaymentResponse getPayment(
        @AuthenticationPrincipal JwtPrincipal principal,
        @PathVariable UUID id) {
    return paymentService.getPayment(principal, id);
}

/**
 * Lists all documents associated with the specified payment in the caller's access scope.
 *
 * @param principal the authenticated user requesting document metadata
 * @param paymentId the payment identifier whose documents should be listed
 * @return a list of uploaded payment document responses
*/
@GetMapping("/{paymentId}/documents")
@PreAuthorize("hasAnyRole('CUSTOMER', 'STAFF')")
public List<PaymentDocumentResponse> listPaymentDocuments(
        @AuthenticationPrincipal JwtPrincipal principal,
        @PathVariable UUID paymentId) {
    return paymentDocumentService.listPaymentDocuments(principal, paymentId);
}

@GetMapping("/{paymentId}/documents/{documentId}/preview")
@PreAuthorize("hasAnyRole('CUSTOMER', 'STAFF')")
public PresignedUrlResponse previewDocument(
        @AuthenticationPrincipal JwtPrincipal principal,
        @PathVariable UUID paymentId,
        @PathVariable UUID documentId) {
    return paymentDocumentService.previewDocument(principal, paymentId, documentId);
}

@GetMapping("/{paymentId}/documents/{documentId}/download")
@PreAuthorize("hasAnyRole('CUSTOMER', 'STAFF')")
public PresignedUrlResponse downloadDocument(
        @AuthenticationPrincipal JwtPrincipal principal,
        @PathVariable UUID paymentId,
        @PathVariable UUID documentId) {
    return paymentDocumentService.downloadDocument(principal, paymentId, documentId);
}
}
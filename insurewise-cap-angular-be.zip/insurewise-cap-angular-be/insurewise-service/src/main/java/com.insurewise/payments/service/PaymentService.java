package com.insurewise.payments.service;

import com.insurewise.common.dto.PageResponse;
import com.insurewise.common.dto.PaginationMetadata;
import com.insurewise.common.exception.BusinessException;
import com.insurewise.common.exception.IdempotencyKeyConflictException;
import com.insurewise.common.security.JwtPrincipal;
import com.insurewise.common.security.JwtRole;
import com.insurewise.payments.client.PaymentPolicyApplicationLookupClient;
import com.insurewise.payments.client.PaymentPolicyApplicationSnapshot;
import com.insurewise.payments.dto.request.PaymentCreateRequest;
import com.insurewise.payments.dto.response.PaymentResponse;
import com.insurewise.payments.dto.response.PaymentSummaryResponse;
import com.insurewise.payments.entity.Payment;
import com.insurewise.payments.entity.PaymentStatus;
import com.insurewise.payments.exception.PaymentNotFoundException;
import com.insurewise.payments.repository.PaymentRepository;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class PaymentService {
    private static final Logger log = LoggerFactory.getLogger(PaymentService.class);
    private static final DateTimeFormatter REF_TIME =
            DateTimeFormatter.ofPattern("yyyyMMddHHmmss");

    private final PaymentRepository paymentRepository;
    private final PaymentPolicyApplicationLookupClient applicationClient;
    private final PaymentDocumentService paymentDocumentService;

    /**
     * Creates the payment service with the repository and dependent services needed to process and audit
     * customer payments.
     *
     * @param paymentRepository payment persistence repository
     * @param applicationClient lookup client for the active policy application tied to the payment
     * @param paymentDocumentService service responsible for generating invoice and receipt documents
     */
    public PaymentService(
            PaymentRepository paymentRepository,
            PaymentPolicyApplicationLookupClient applicationClient,
            PaymentDocumentService paymentDocumentService) {
        this.paymentRepository = paymentRepository;
        this.applicationClient = applicationClient;
        this.paymentDocumentService = paymentDocumentService;
    }

    /**
     * Creates or reuses a payment record for the customer and returns the persisted payment result.
     *
     * @param customerId authenticated customer id making the payment
     * @param request payment payload with idempotency key, application, amount, and method
     * @return stored payment response
     */
    public PaymentResponse makePayment(UUID customerId, PaymentCreateRequest request) {
        try {
            Payment existing = paymentRepository.findByIdempotencyKey(request.idempotencyKey()).orElse(null);

            if (existing != null) {
                if (!existing.isOwnedBy(customerId)) {
                    throw new IdempotencyKeyConflictException(
                            "Idempotency key belongs to another customer.");
                }

                if (existing.getStatus() == PaymentStatus.SUCCESS) {
                    paymentDocumentService.createSystemReceipt(existing.getId());
                }
                return toResponse(existing);
            }

            PaymentPolicyApplicationSnapshot application =
                    applicationClient.getActiveApplicationForCustomer(
                            request.policyApplicationId(), customerId);

            Payment payment = new Payment(
                    request.idempotencyKey(),
                    customerId,
                    application.applicationId(),
                    application.policyName(),
                    request.amount(),
                    request.method());

            payment.markSuccess(generateTransactionRef());
            Payment savedPayment = paymentRepository.saveAndFlush(payment);
            paymentDocumentService.createSystemReceipt(savedPayment.getId());

            return toResponse(savedPayment);
        } catch (BusinessException exception) {
            throw exception;
        } catch (RuntimeException exception) {
            log.error("Failed to create payment for customerId={}, applicationId={}",
                    customerId, request.policyApplicationId(), exception);
            throw new BusinessException(
                    "PAYMENT_CREATE_FAILED",
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unable to process payment at this time.",
                    exception);
        }
    }

    /**
     * Lists payments for the current user with optional status filtering and page-based paging.
     *
     * @param principal caller identity including role and user id
     * @param status optional status filter; null returns all payment states
     * @param limit requested page size capped to 100
     * @param offset zero-based offset into the result set
     * @return paginated payment response
     */
    @Transactional(readOnly = true)
    public PageResponse<PaymentResponse> listPayments(
            JwtPrincipal principal, PaymentStatus status, int limit, int offset) {
        try {
            int safeLimit = Math.min(Math.max(limit, 1), 100);
            int safeOffset = Math.max(offset, 0);
            Pageable pageable = PageRequest.of(
                    safeOffset / safeLimit,
                    safeLimit,
                    Sort.by(Sort.Direction.DESC, "createdAt"));

            Page<Payment> page;

            if (principal.role() == JwtRole.CUSTOMER) {
                page = status == null
                        ? paymentRepository.findByCustomerId(principal.userId(), pageable)
                        : paymentRepository.findByCustomerIdAndStatus(principal.userId(), status, pageable);
            } else {
                page = status == null
                        ? paymentRepository.findAll(pageable)
                        : paymentRepository.findByStatus(status, pageable);
            }

            List<PaymentResponse> data = page.getContent()
                    .stream()
                    .map(this::toResponse)
                    .toList();

            return new PageResponse<>(
                    data,
                    new PaginationMetadata(
                            safeLimit,
                            safeOffset,
                            page.getTotalElements(),
                            safeOffset + data.size() < page.getTotalElements()));
        } catch (BusinessException exception) {
            throw exception;
        } catch (RuntimeException exception) {
            log.error("Failed to list payments for userId={}, role={}, status={}",
                    principal.userId(), principal.role(), status, exception);
            throw new BusinessException(
                    "PAYMENT_LIST_FAILED",
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unable to load payments at this time.",
                    exception);
        }
    }

    /**
     * Fetches a payment record and enforces customer ownership if the caller is a customer.
     *
     * @param principal authenticated caller context
     * @param paymentId payment id to fetch
     * @return payment response payload
     */
    @Transactional(readOnly = true)
    public PaymentResponse getPayment(JwtPrincipal principal, UUID paymentId) {
        try {
            Payment payment = paymentRepository.findById(paymentId)
                    .orElseThrow(() -> new PaymentNotFoundException(paymentId));

            if (principal.role() == JwtRole.CUSTOMER && !payment.isOwnedBy(principal.userId())) {
                throw new PaymentNotFoundException();
            }

            return toResponse(payment);
        } catch (PaymentNotFoundException | BusinessException exception) {
            throw exception;
        } catch (RuntimeException exception) {
            log.error("Failed to fetch payment paymentId={} for userId={}", paymentId, principal.userId(), exception);
            throw new BusinessException(
                    "PAYMENT_GET_FAILED",
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unable to load payment at this time.",
                    exception);
        }
    }

    /**
     * Returns the dashboard summary for total revenue and the counts of successful, failed, and pending
     * payments.
     *
     * @return aggregate payment summary
     */
    @Transactional(readOnly = true)
    public PaymentSummaryResponse getSummary() {
        try {
            BigDecimal totalRevenue = paymentRepository.sumSuccessfulPayments();

            return new PaymentSummaryResponse(
                    totalRevenue == null ? BigDecimal.ZERO : totalRevenue,
                    paymentRepository.countByStatus(PaymentStatus.SUCCESS),
                    paymentRepository.countByStatus(PaymentStatus.FAILED),
                    paymentRepository.countByStatus(PaymentStatus.PENDING));
        } catch (BusinessException exception) {
            throw exception;
        } catch (RuntimeException exception) {
            log.error("Failed to build payment summary", exception);
            throw new BusinessException(
                    "PAYMENT_SUMMARY_FAILED",
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unable to load payment summary at this time.",
                    exception);
        }
    }

    /**
     * Generates a unique transaction reference used to identify a successful payment submission.
     *
     * @return transaction reference in the format TXN-yyyymmddHHmmss-random
     */
    private String generateTransactionRef() {
        int suffix = ThreadLocalRandom.current().nextInt(100000, 1000000);
        return "TXN-" + LocalDateTime.now().format(REF_TIME) + "-" + suffix;
    }

    /**
     * Maps a payment entity to the API response DTO used in the customer and staff views.
     *
     * @param payment persisted payment entity
     * @return payment DTO for API responses
     */
    private PaymentResponse toResponse(Payment payment) {
        return new PaymentResponse(
                payment.getId(),
                payment.getIdempotencyKey(),
                payment.getCustomerId(),
                payment.getPolicyApplicationId(),
                payment.getPolicyNameSnapshot(),
                payment.getAmount(),
                payment.getMethod(),
                payment.getStatus(),
                payment.getTransactionRef(),
                payment.getPaidAt(),
                payment.getCreatedAt());
    }
}

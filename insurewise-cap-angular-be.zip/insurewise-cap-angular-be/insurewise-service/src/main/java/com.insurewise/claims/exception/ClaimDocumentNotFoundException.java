package com.insurewise.claims.exception;

import com.insurewise.common.exception.ResourceNotFoundException;
import java.util.UUID;

public class ClaimDocumentNotFoundException extends ResourceNotFoundException {
/**
 * Claim Document Not Found Exception.
 * @param id the value supplied for the id.
 * @return the result of the operation.
*/

    public ClaimDocumentNotFoundException(UUID id) {
        super("CLAIM_DOCUMENT_NOT_FOUND", "Claim document not found: " + id);
    }
}
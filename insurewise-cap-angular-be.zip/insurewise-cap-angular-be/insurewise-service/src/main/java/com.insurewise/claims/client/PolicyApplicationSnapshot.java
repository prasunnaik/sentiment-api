package com.insurewise.claims.client;

import com.insurewise.policy.entity.ApplicationStatus;
import java.util.UUID;
/**
 * Represents the record Policy Application Snapshot.
*/

public record PolicyApplicationSnapshot(
        UUID applicationId,
        UUID customerId,
        String policyName,
        ApplicationStatus status,
        boolean active
) {
}
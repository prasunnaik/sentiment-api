package com.insurewise.claims.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.UUID;
/**
 * Represents the class Claim Document.
*/

@Entity
@Table(name = "claim_documents")
public class ClaimDocument {
    @Id
    @GeneratedValue
    private UUID id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "claim_id", nullable = false)
    private Claim claim;

    @Column(name = "file_name", nullable = false, length = 255)
    private String fileName;

    @Column(name = "content_type", length = 100)
    private String contentType;

    @Column(name = "s3_key", nullable = false, length = 600)
    private String s3Key;

    @Column(name = "uploaded_by", nullable = false)
    private UUID uploadedBy;

    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;
/**
 * Claim Document.
 * @return the result of the operation.
*/

    protected ClaimDocument() {
    }
/**
 * Claim Document.
 * @param claim the value supplied for the claim.
 * @param fileName the value supplied for the fileName.
 * @param contentType the value supplied for the contentType.
 * @param s3Key the value supplied for the s3Key.
 * @param uploadedBy the value supplied for the uploadedBy.
 * @return the result of the operation.
*/

    public ClaimDocument(
            Claim claim,
            String fileName,
            String contentType,
            String s3Key,
            UUID uploadedBy) {
        this.claim = claim;
        this.fileName = fileName;
        this.contentType = contentType;
        this.s3Key = s3Key;
        this.uploadedBy = uploadedBy;
    }

    @PrePersist
    void initialize() {
        if (createdAt == null) {
            createdAt = LocalDateTime.now();
        }
    }
/**
 * Get Id.
 * @return the result of the operation.
*/

    public UUID getId() {
        return id;
    }
/**
 * Get Claim.
 * @return the result of the operation.
*/

    public Claim getClaim() {
        return claim;
    }
/**
 * Get File Name.
 * @return the result of the operation.
*/

    public String getFileName() {
        return fileName;
    }
/**
 * Get Content Type.
 * @return the result of the operation.
*/

    public String getContentType() {
        return contentType;
    }
/**
 * Get S3 Key.
 * @return the result of the operation.
*/

    public String getS3Key() {
        return s3Key;
    }
/**
 * Get Uploaded By.
 * @return the result of the operation.
*/

    public UUID getUploadedBy() {
        return uploadedBy;
    }
/**
 * Get Created At.
 * @return the result of the operation.
*/

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }
}
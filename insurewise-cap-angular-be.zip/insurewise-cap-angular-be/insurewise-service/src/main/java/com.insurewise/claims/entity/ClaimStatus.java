package com.insurewise.claims.entity;
/**
 * Represents the enum Claim Status.
*/

public enum ClaimStatus {
    PENDING,
    UNDER_REVIEW,
    APPROVED,
    REJECTED
}
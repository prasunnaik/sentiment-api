package com.insurewise.claims.entity;

import com.insurewise.policy.entity.Gender;
import com.insurewise.policy.entity.Relationship;
import jakarta.persistence.*;
import java.time.LocalDate;
import java.util.UUID;
/**
 * Represents the class Claim Dependent.
*/

@Entity
@Table(name = "claim_dependents")
public class ClaimDependent {
    @Id
    @GeneratedValue
    private UUID id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "claim_id", nullable = false)
    private Claim claim;

    @Column(name = "full_name", nullable = false, length = 120)
    private String fullName;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private Relationship relationship;

    @Column(name = "date_of_birth", nullable = false)
    private LocalDate dateOfBirth;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 10)
    private Gender gender;
/**
 * Claim Dependent.
 * @return the result of the operation.
*/

    protected ClaimDependent() {
    }
/**
 * Claim Dependent.
 * @param claim the value supplied for the claim.
 * @param fullName the value supplied for the fullName.
 * @param relationship the value supplied for the relationship.
 * @param dateOfBirth the value supplied for the dateOfBirth.
 * @param gender the value supplied for the gender.
 * @return the result of the operation.
*/

    public ClaimDependent(
            Claim claim,
            String fullName,
            Relationship relationship,
            LocalDate dateOfBirth,
            Gender gender) {
        this.claim = claim;
        this.fullName = fullName;
        this.relationship = relationship;
        this.dateOfBirth = dateOfBirth;
        this.gender = gender;
    }
/**
 * Get Id.
 * @return the result of the operation.
*/

    public UUID getId() {
        return id;
    }
/**
 * Get Claim.
 * @return the result of the operation.
*/

    public Claim getClaim() {
        return claim;
    }
/**
 * Get Full Name.
 * @return the result of the operation.
*/

    public String getFullName() {
        return fullName;
    }
/**
 * Get Relationship.
 * @return the result of the operation.
*/

    public Relationship getRelationship() {
        return relationship;
    }
/**
 * Get Date Of Birth.
 * @return the result of the operation.
*/

    public LocalDate getDateOfBirth() {
        return dateOfBirth;
    }
/**
 * Get Gender.
 * @return the result of the operation.
*/

    public Gender getGender() {
        return gender;
    }
}
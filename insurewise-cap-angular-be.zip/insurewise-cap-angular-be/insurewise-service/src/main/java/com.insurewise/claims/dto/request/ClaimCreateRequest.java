package com.insurewise.claims.dto.request;

import com.insurewise.claims.entity.IncidentType;
import jakarta.validation.constraints.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.UUID;
/**
 * Represents the record Claim Create Request.
*/

public record ClaimCreateRequest(
        @NotBlank
        @Size(max = 80)
        String idempotencyKey,

        @NotNull
        UUID policyApplicationId,

        @NotNull
        IncidentType incidentType,

        @NotNull
        @PastOrPresent
        LocalDate incidentDate,

        @NotNull
        @DecimalMin("0.01")
        BigDecimal amount,

        @NotBlank
        @Size(max = 1000)
        String description,

        @Size(max = 300)
        String documentRef
) {
}

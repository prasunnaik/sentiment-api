package com.insurewise.claims.dto.response;

import com.insurewise.common.dto.PresignedUrlResponse;
import java.time.LocalDateTime;
import java.util.UUID;
/**
 * Represents the record Claim Document Response.
*/

public record ClaimDocumentResponse(
        UUID id,
        UUID claimId,
        String fileName,
        String contentType,
        PresignedUrlResponse preview,
        PresignedUrlResponse download,
        UUID uploadedBy,
        String uploadedByName,
        LocalDateTime createdAt
) {
}
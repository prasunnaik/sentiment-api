package com.insurewise.claims.controller;

import com.insurewise.claims.dto.request.ClaimDependentRequest;
import com.insurewise.claims.dto.response.ClaimDependentResponse;
import com.insurewise.claims.service.ClaimDependentService;
import com.insurewise.common.security.JwtPrincipal;
import jakarta.validation.Valid;
import java.util.List;
import java.util.UUID;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/claims/{id}/dependents")
@PreAuthorize("hasRole('CUSTOMER')")
/**
 * Represents the class Claim Dependent Controller.
*/
public class ClaimDependentController {
    private final ClaimDependentService service;
/**
 * Claim Dependent Controller.
 * @param service the value supplied for the service.
 * @return the result of the operation.
*/

    public ClaimDependentController(
            ClaimDependentService service) {
        this.service = service;
    }
/**
 * Add.
 * @param principal the value supplied for the principal.
 * @param id the value supplied for the id.
 * @param request the value supplied for the request.
 * @return the result of the operation.
*/

    @PostMapping
    public ClaimDependentResponse addClaimDependent(
            @AuthenticationPrincipal JwtPrincipal principal,
            @PathVariable UUID id,
            @Valid @RequestBody ClaimDependentRequest request) {

        return service.addDependent(
                principal.userId(),
                id,
                request);
    }
/**
 * List.
 * @param principal the value supplied for the principal.
 * @param id the value supplied for the id.
 * @return the result of the operation.
*/

    @GetMapping
    public List<ClaimDependentResponse> listClaimDependents(
            @AuthenticationPrincipal JwtPrincipal principal,
            @PathVariable UUID id) {

        return service.listDependents(
                principal.userId(),
                id);
    }
}

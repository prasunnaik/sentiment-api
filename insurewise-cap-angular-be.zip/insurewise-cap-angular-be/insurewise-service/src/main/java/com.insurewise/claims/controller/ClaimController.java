package com.insurewise.claims.controller;

import com.insurewise.claims.dto.request.ClaimCreateRequest;
import com.insurewise.claims.dto.response.ClaimDetailResponse;
import com.insurewise.claims.dto.response.ClaimDocumentContentResponse;
import com.insurewise.claims.dto.response.ClaimDocumentResponse;
import com.insurewise.claims.dto.response.ClaimResponse;
import com.insurewise.claims.dto.response.ClaimSubmissionResponse;
import com.insurewise.common.dto.PresignedUrlResponse;
import com.insurewise.claims.entity.ClaimStatus;
import com.insurewise.claims.service.ClaimDocumentService;
import com.insurewise.claims.service.ClaimService;
import com.insurewise.common.dto.PageResponse;
import com.insurewise.common.security.JwtPrincipal;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.UUID;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.http.MediaType;
/**
 * Exposes claim submission and lifecycle endpoints for customers and staff.
 *
*/
@RestController
@RequestMapping("/api/claims")
@Validated
public class ClaimController {
    private final ClaimService claimService;
    private final ClaimDocumentService claimDocumentService;

/**
 * Creates the claim controller with the service layer used for claim and document operations.
 *
 * @param claimService the business service managing claim creation, review, and status updates
 * @param claimDocumentService the service handling document upload and retrieval for claims
*/
public ClaimController(
        ClaimService claimService,
        ClaimDocumentService claimDocumentService) {
    this.claimService = claimService;
    this.claimDocumentService = claimDocumentService;
}

/**
 * Submits a new claim request for the authenticated customer.
 *
 * @param principal the authenticated customer making the claim submission
 * @param request the claim payload containing policy, incident, and claim details
 * @return the newly created claim response
*/
@PostMapping
@PreAuthorize("hasRole('CUSTOMER')")
public ClaimResponse fileClaim(
        @AuthenticationPrincipal JwtPrincipal principal,
        @Valid @RequestBody ClaimCreateRequest request) {
    return claimService.fileClaim(principal.userId(), request);
}

/**
 * Creates a claim together with the initial uploaded supporting document in a multipart request.
 *
 * @param principal the authenticated customer filing the claim
 * @param request the claim request payload as a multipart part
 * @param file the supporting document attached to the claim
 * @return the submitted claim response with confirmation data
*/
@PostMapping(value = "/with-document", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
@PreAuthorize("hasRole('CUSTOMER')")
public ClaimSubmissionResponse createClaimWithDocument(
            @AuthenticationPrincipal JwtPrincipal principal,
        @RequestPart("claim") @Valid ClaimCreateRequest request,
        @RequestPart("file") MultipartFile file) {
    return claimService.fileClaimWithDocument(principal.userId(), request, file);
}

/**
 * Retrieves a filtered list of claims visible to the authenticated user.
 *
 * @param principal the customer or staff user making the request
 * @param status optional claim status filter for narrowing the result set
 * @param limit maximum number of results to return
 * @param offset zero-based offset for pagination
 * @return paginated claim list for the current user scope
*/
@GetMapping
@PreAuthorize("hasAnyRole('CUSTOMER', 'STAFF')")
public PageResponse<ClaimResponse> listClaims(
        @AuthenticationPrincipal JwtPrincipal principal,
        @RequestParam(required = false) ClaimStatus status,
        @RequestParam(defaultValue = "10") @Min(1) @Max(100) int limit,
        @RequestParam(defaultValue = "0") @Min(0) int offset) {
    return claimService.listClaims(principal, status, limit, offset);
}

/**
 * Fetches a single claim for either a customer or staff member depending on the caller role.
 *
 * @param principal the authenticated user requesting the claim details
 * @param id the unique claim identifier
 * @return the matching claim response with access-scoped details
*/
@GetMapping("/{id}")
@PreAuthorize("hasAnyRole('CUSTOMER', 'STAFF')")
public ClaimDetailResponse getClaim(
        @AuthenticationPrincipal JwtPrincipal principal,
        @PathVariable UUID id) {
    if (principal.role().name().equals("STAFF")) {
        return claimService.getClaimForStaff(id);
    }
    return claimService.getClaimForCustomer(principal.userId(), id);
}

/**
 * Uploads a supporting document for a claim owned by the authenticated customer.
 *
 * @param principal the customer uploading the claim document
 * @param id the claim identifier the document belongs to
 * @param file the document file being uploaded
 * @return the saved document metadata and presigned download link
*/
@PostMapping("/{id}/documents")
@PreAuthorize("hasRole('CUSTOMER')")
public ClaimDocumentResponse uploadDocument(
        @AuthenticationPrincipal JwtPrincipal principal,
        @PathVariable UUID id,
        @RequestParam("file") MultipartFile file) {
    return claimDocumentService.uploadDocument(principal.userId(), id, file);
}

/**
 * Lists all uploaded documents for a claim in the caller's authorized scope.
 *
 * @param principal the authenticated user requesting the documents
 * @param id the claim identifier for which documents are being retrieved
 * @return all claim document responses available for the claim
*/
@GetMapping("/{id}/documents")
@PreAuthorize("hasAnyRole('CUSTOMER', 'STAFF')")
public List<ClaimDocumentResponse> listClaimDocuments(
        @AuthenticationPrincipal JwtPrincipal principal,
        @PathVariable UUID id) {
    if (principal.role().name().equals("STAFF")) {
        return claimDocumentService.listClaimDocumentsForStaff(id);
    }
    return claimDocumentService.listClaimDocuments(principal.userId(), id);
}

@GetMapping("/{id}/documents/{documentId}/preview")
@PreAuthorize("hasRole('STAFF')")
public PresignedUrlResponse previewDocumentForStaff(
        @PathVariable UUID id,
        @PathVariable UUID documentId) {
    return claimDocumentService.previewDocumentForStaff(id, documentId);
}

@GetMapping("/{id}/documents/{documentId}/download")
@PreAuthorize("hasRole('STAFF')")
public PresignedUrlResponse downloadDocumentForStaff(
        @PathVariable UUID id,
        @PathVariable UUID documentId) {
    return claimDocumentService.downloadDocumentForStaff(id, documentId);
}

/**
 * Streams the raw bytes of a claim document directly from the backend so the browser downloads
 * the file without needing to fetch it from S3 directly (avoiding S3 CORS restrictions).
 *
 * @param id the claim identifier that owns the document
 * @param documentId the document to download
 * @return the document content with a forced-download response header
*/
@GetMapping("/{id}/documents/{documentId}/content")
@PreAuthorize("hasRole('STAFF')")
public ResponseEntity<byte[]> downloadDocumentContentForStaff(
        @PathVariable UUID id,
        @PathVariable UUID documentId) {
    ClaimDocumentContentResponse content = claimDocumentService.downloadDocumentContentForStaff(id, documentId);

    MediaType mediaType;
    try {
        mediaType = MediaType.parseMediaType(content.contentType());
    } catch (RuntimeException exception) {
        mediaType = MediaType.APPLICATION_OCTET_STREAM;
    }

    return ResponseEntity.ok()
            .contentType(mediaType)
            .header(
                    HttpHeaders.CONTENT_DISPOSITION,
                    ContentDisposition.attachment()
                            .filename(content.fileName(), StandardCharsets.UTF_8)
                            .build()
                            .toString())
            .body(content.content());
}

/**
 * Deletes a claim document uploaded by the current customer.
 *
 * @param principal the customer deleting the document
 * @param id the claim identifier that owns the document
 * @param documentId the document to delete
*/
@DeleteMapping("/{id}/documents/{documentId}")
@PreAuthorize("hasRole('CUSTOMER')")
public void deleteDocument(
        @AuthenticationPrincipal JwtPrincipal principal,
        @PathVariable UUID id,
        @PathVariable UUID documentId) {
    claimDocumentService.deleteDocument(principal.userId(), id, documentId);
}

/**
 * Approves a pending claim as part of the staff review workflow.
 *
 * @param principal the authenticated staff user performing the approval
 * @param id the claim identifier being approved
 * @return the updated claim state after approval
*/
@PutMapping("/{id}/approve")
@PreAuthorize("hasRole('STAFF')")
public ClaimResponse approveClaim(
        @AuthenticationPrincipal JwtPrincipal principal,
        @PathVariable UUID id) {
    return claimService.approveClaim(principal.userId(), id);
}

/**
 * Rejects a submitted claim during the staff review process.
 *
 * @param principal the authenticated staff user performing the rejection
 * @param id the claim identifier being rejected
 * @return the updated claim after the rejection decision
*/
@PutMapping("/{id}/reject")
@PreAuthorize("hasRole('STAFF')")
public ClaimResponse rejectClaim(
        @AuthenticationPrincipal JwtPrincipal principal,
        @PathVariable UUID id) {
    return claimService.rejectClaim(principal.userId(), id);
}
}
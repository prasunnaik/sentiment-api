package com.insurewise.claims.entity;
/**
 * Represents the enum Incident Type.
*/

public enum IncidentType {
    ACCIDENT,
    HOSPITALIZATION,
    THEFT,
    NATURAL_DISASTER,
    FIRE,
    DEATH,
    DISABILITY,
    PROPERTY_DAMAGE,
    OTHER
}
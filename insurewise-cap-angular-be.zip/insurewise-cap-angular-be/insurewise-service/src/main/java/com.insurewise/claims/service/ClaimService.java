package com.insurewise.claims.service;

import com.insurewise.auth.repository.StaffUserRepository;
import com.insurewise.auth.repository.CustomerRepository;
import com.insurewise.claims.client.ClaimApplicantLookupClient;
import com.insurewise.claims.client.ClaimApplicantSnapshot;
import com.insurewise.claims.client.PolicyApplicationLookupClient;
import com.insurewise.claims.client.PolicyApplicationSnapshot;
import com.insurewise.claims.dto.request.ClaimCreateRequest;
import com.insurewise.claims.dto.response.ClaimDetailResponse;
import com.insurewise.claims.dto.response.ClaimDocumentResponse;
import com.insurewise.claims.dto.response.ClaimResponse;
import com.insurewise.claims.dto.response.ClaimSubmissionResponse;
import com.insurewise.claims.entity.Claim;
import com.insurewise.claims.entity.ClaimDocument;
import com.insurewise.claims.entity.ClaimStatus;
import com.insurewise.claims.exception.ClaimNotFoundException;
import com.insurewise.claims.repository.ClaimDocumentRepository;
import com.insurewise.claims.repository.ClaimRepository;
import com.insurewise.common.dto.PageResponse;
import com.insurewise.common.dto.PaginationMetadata;
import com.insurewise.common.exception.BusinessException;
import com.insurewise.common.exception.FileStorageException;
import com.insurewise.common.exception.IdempotencyKeyConflictException;
import com.insurewise.common.exception.InvalidFileException;
import com.insurewise.common.security.JwtPrincipal;
import com.insurewise.common.security.JwtRole;
import com.insurewise.common.service.S3StorageService;
import java.util.List;
import java.util.UUID;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

@Service
@Transactional
public class ClaimService {
    private static final Logger log = LoggerFactory.getLogger(ClaimService.class);
    private final ClaimRepository claimRepository;
    private final PolicyApplicationLookupClient applicationClient;
    private final StaffUserRepository staffUserRepository;
    private final ClaimDocumentRepository claimDocumentRepository;
    private final S3StorageService storageService;
    private final ClaimApplicantLookupClient applicantLookupClient;
    private final CustomerRepository customerRepository;

    /**
     * Creates the claim service and wires in the application lookup, staff lookup, and document storage
     * dependencies required for claim submission and adjudication.
     *
     * @param claimRepository repository for claim persistence and lookup
     * @param applicationClient client used to resolve the currently active policy application for a customer
     * @param staffUserRepository repository used to resolve staff names for claim processing metadata
     * @param claimDocumentRepository repository for claim attachment records
     * @param storageService document storage service used to upload and download supporting files
     */
    public ClaimService(
            ClaimRepository claimRepository,
            PolicyApplicationLookupClient applicationClient,
            StaffUserRepository staffUserRepository,
            ClaimDocumentRepository claimDocumentRepository,
            S3StorageService storageService,
            ClaimApplicantLookupClient applicantLookupClient,
            CustomerRepository customerRepository) {
        this.claimRepository = claimRepository;
        this.applicationClient = applicationClient;
        this.staffUserRepository = staffUserRepository;
        this.claimDocumentRepository = claimDocumentRepository;
        this.storageService = storageService;
        this.applicantLookupClient = applicantLookupClient;
        this.customerRepository = customerRepository;
    }

    /**
     * Creates a claim after verifying that the idempotency key is unique for the customer and that the
     * referenced policy application is active.
     *
     * @param customerId authenticated customer requesting the claim
     * @param request claim creation payload
     * @return created claim response
     */
    public ClaimResponse fileClaim(UUID customerId, ClaimCreateRequest request) {
        try {
            var existing = claimRepository.findByIdempotencyKey(request.idempotencyKey());

            if (existing.isPresent()) {
                Claim claim = existing.get();
                if (!claim.isOwnedBy(customerId)) {
                    throw new IdempotencyKeyConflictException(
                            "Idempotency key belongs to another customer");
                }
                return toResponse(claim);
            }

            PolicyApplicationSnapshot application =
                    applicationClient.getActiveApplicationForCustomer(
                            request.policyApplicationId(), customerId);

            Long sequence = claimRepository.nextClaimCodeSequence();
            String claimCode = "CLM-" + sequence;

            Claim claim = new Claim(
                    claimCode,
                    request.idempotencyKey(),
                    customerId,
                    application.applicationId(),
                    application.policyName(),
                    request.incidentType(),
                    request.incidentDate(),
                    request.amount(),
                    request.description(),
                    request.documentRef());

            return toResponse(claimRepository.save(claim));
        } catch (BusinessException exception) {
            throw exception;
        } catch (RuntimeException exception) {
            log.error("Failed to file claim for customerId={}, policyApplicationId={}",
                    customerId, request.policyApplicationId(), exception);
            throw new BusinessException(
                    "CLAIM_CREATE_FAILED",
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unable to file claim at this time.",
                    exception);
        }
    }

    /**
     * Uploads a supporting document for a claim and returns both the claim and document metadata. The
     * method rolls back uploaded storage when document persistence fails.
     *
     * @param customerId authenticated customer submitting the claim
     * @param request claim payload used to create or reuse the claim record
     * @param file uploaded supporting document, which must be non-empty
     * @return claim submission response containing claim and document details
     */
    public ClaimSubmissionResponse fileClaimWithDocument(
            UUID customerId,
            ClaimCreateRequest request,
            MultipartFile file) {
        if (file == null || file.isEmpty()) {
            throw new InvalidFileException("A non-empty file is required");
        }

        Claim claim = claimRepository.findByIdempotencyKey(request.idempotencyKey()).orElse(null);

        if (claim != null && !claim.isOwnedBy(customerId)) {
            throw new IdempotencyKeyConflictException(
                    "Idempotency key belongs to another customer");
        }

        if (claim != null) {
            List<ClaimDocument> existingDocuments = claimDocumentRepository.findByClaimId(claim.getId());
            if (!existingDocuments.isEmpty()) {
                ClaimDocument existingDocument = existingDocuments.get(0);
                return new ClaimSubmissionResponse(
                        toResponse(claim),
                        toDocumentResponse(existingDocument));
            }
        }

        String s3Key = null;
        try {
            if (claim == null) {
                ClaimResponse claimResponse = fileClaim(customerId, request);
                claim = getClaimEntity(claimResponse.id());
            }

            s3Key = storageService.upload(file, "claim-documents", customerId);
            String fileName = file.getOriginalFilename() == null
                    ? "unnamed-file"
                    : file.getOriginalFilename();

            ClaimDocument document = claimDocumentRepository.saveAndFlush(
                    new ClaimDocument(
                            claim,
                            fileName,
                            file.getContentType(),
                            s3Key,
                            customerId));

            return new ClaimSubmissionResponse(toResponse(claim), toDocumentResponse(document));
        } catch (BusinessException exception) {
            throw exception;
        } catch (RuntimeException exception) {
            if (s3Key != null) {
                try {
                    storageService.delete(s3Key);
                } catch (FileStorageException cleanupException) {
                    exception.addSuppressed(cleanupException);
                    log.error("Failed to clean up uploaded claim file. key={}", s3Key, cleanupException);
                }
            }
            log.error("Failed to file claim with document for customerId={}, policyApplicationId={}",
                    customerId, request.policyApplicationId(), exception);
            throw new BusinessException(
                    "CLAIM_SUBMISSION_FAILED",
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unable to submit claim with document at this time.",
                    exception);
        }
    }

    /**
     * Converts a saved claim document to the API response DTO with a presigned download URL.
     *
     * @param document stored claim document entity
     * @return document DTO used in claim submissions and review screens
     */
    private ClaimDocumentResponse toDocumentResponse(ClaimDocument document) {
        return new ClaimDocumentResponse(
                document.getId(),
                document.getClaim().getId(),
                document.getFileName(),
                document.getContentType(),
                storageService.getPresignedPreviewUrl(document.getS3Key()),
                storageService.getPresignedDownloadUrl(document.getS3Key()),
                document.getUploadedBy(),
                resolveUploaderName(document.getUploadedBy()),
                document.getCreatedAt());
    }

    /**
     * Resolves the display name of the customer who uploaded a claim document, falling back to their
     * email and finally to the raw id when no customer record can be found.
     *
     * @param uploadedBy id of the customer who uploaded the document
     * @return a human-readable uploader label
     */
    private String resolveUploaderName(UUID uploadedBy) {
        if (uploadedBy == null) {
            return null;
        }

        return customerRepository.findById(uploadedBy)
                .map(customer -> {
                    String fullName = customer.getFullName();
                    return fullName != null && !fullName.isBlank() ? fullName : customer.getEmail();
                })
                .orElse(uploadedBy.toString());
    }

    /**
     * Approves a claim and marks the claim as processed by the staff member who reviewed it.
     *
     * @param staffUserId authenticated staff identifier approving the claim
     * @param claimId claim to approve
     * @return updated claim response
     */
    public ClaimResponse approveClaim(UUID staffUserId, UUID claimId) {
        try {
            Claim claim = getClaimEntity(claimId);
            claim.approve(staffUserId);
            return toResponse(claim);
        } catch (ClaimNotFoundException | BusinessException exception) {
            throw exception;
        } catch (RuntimeException exception) {
            log.error("Failed to approve claim id={} by staffUserId={}", claimId, staffUserId, exception);
            throw new BusinessException(
                    "CLAIM_APPROVE_FAILED",
                    HttpStatus.CONFLICT,
                    "Unable to approve claim.",
                    exception);
        }
    }

    /**
     * Rejects a claim and records the staff decision for audit tracking.
     *
     * @param staffUserId authenticated staff identifier rejecting the claim
     * @param claimId claim to reject
     * @return updated claim response
     */
    public ClaimResponse rejectClaim(UUID staffUserId, UUID claimId) {
        try {
            Claim claim = getClaimEntity(claimId);
            claim.reject(staffUserId);
            return toResponse(claim);
        } catch (ClaimNotFoundException | BusinessException exception) {
            throw exception;
        } catch (RuntimeException exception) {
            log.error("Failed to reject claim id={} by staffUserId={}", claimId, staffUserId, exception);
            throw new BusinessException(
                    "CLAIM_REJECT_FAILED",
                    HttpStatus.CONFLICT,
                    "Unable to reject claim.",
                    exception);
        }
    }

    /**
     * Lists claims filtered by the caller's role and the optional status filter, using paged results.
     *
     * @param principal authenticated caller context with role and user id
     * @param status optional claim status filter; null means all statuses
     * @param limit maximum page size requested by the client
     * @param offset zero-based start index for pagination
     * @return paged claim list response
     */
    @Transactional(readOnly = true)
    public PageResponse<ClaimResponse> listClaims(
            JwtPrincipal principal,
            ClaimStatus status,
            int limit,
            int offset) {
        try {
            int safeLimit = Math.min(Math.max(limit, 1), 100);
            int safeOffset = Math.max(offset, 0);

            Pageable pageable = PageRequest.of(
                    safeOffset / safeLimit,
                    safeLimit,
                    Sort.by(Sort.Direction.DESC, "createdAt"));

            Page<Claim> page;

            if (principal.role() == JwtRole.CUSTOMER) {
                page = status == null
                        ? claimRepository.findByCustomerId(principal.userId(), pageable)
                        : claimRepository.findByCustomerIdAndStatus(
                                principal.userId(), status, pageable);
            } else {
                page = status == null
                        ? claimRepository.findAll(pageable)
                        : claimRepository.findByStatus(status, pageable);
            }

            List<ClaimResponse> data = page.getContent()
                    .stream()
                    .map(this::toResponse)
                    .toList();

            return new PageResponse<>(
                    data,
                    new PaginationMetadata(
                            safeLimit,
                            safeOffset,
                            page.getTotalElements(),
                            safeOffset + data.size() < page.getTotalElements()));
        } catch (BusinessException exception) {
            throw exception;
        } catch (RuntimeException exception) {
            log.error("Failed to list claims for userId={}, role={}, status={}",
                    principal.userId(), principal.role(), status, exception);
            throw new BusinessException(
                    "CLAIM_LIST_FAILED",
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unable to load claims at this time.",
                    exception);
        }
    }

    /**
     * Fetches a single claim for a customer and validates ownership before returning the record.
     *
     * @param customerId authenticated customer id
     * @param claimId claim id requested by the customer
     * @return claim response if ownership matches
     */
    @Transactional(readOnly = true)
    public ClaimDetailResponse getClaimForCustomer(UUID customerId, UUID claimId) {
        try {
            Claim claim = getClaimEntity(claimId);
            if (!claim.isOwnedBy(customerId)) {
                throw new ClaimNotFoundException();
            }
            return toDetailResponse(claim);
        } catch (ClaimNotFoundException | BusinessException exception) {
            throw exception;
        } catch (RuntimeException exception) {
            log.error("Failed to fetch customer claim customerId={}, claimId={}", customerId, claimId, exception);
            throw new BusinessException(
                    "CLAIM_GET_FAILED",
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unable to load claim at this time.",
                    exception);
        }
    }

    /**
     * Fetches a claim for staff review without customer ownership validation.
     *
     * @param claimId claim id to review
     * @return claim response for staff consumption
     */
    @Transactional(readOnly = true)
    public ClaimDetailResponse getClaimForStaff(UUID claimId) {
        try {
            return toDetailResponse(getClaimEntity(claimId));
        } catch (ClaimNotFoundException | BusinessException exception) {
            throw exception;
        } catch (RuntimeException exception) {
            log.error("Failed to fetch staff claim claimId={}", claimId, exception);
            throw new BusinessException(
                    "CLAIM_GET_FAILED",
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unable to load claim at this time.",
                    exception);
        }
    }

    /**
     * Loads a claim entity by id or throws a domain-specific exception when the record is missing.
     *
     * @param claimId claim primary key
     * @return persisted claim entity
     */
    private Claim getClaimEntity(UUID claimId) {
        return claimRepository.findById(claimId)
                .orElseThrow(() -> new ClaimNotFoundException(claimId));
    }

    /**
     * Converts a claim entity to the public response model used by the UI and API clients.
     *
     * @param claim persisted claim entity
     * @return claim DTO for API responses
     */
    private ClaimResponse toResponse(Claim claim) {
        String processedByName = claim.getProcessedBy() == null
                ? null
                : staffUserRepository.findById(claim.getProcessedBy())
                        .map(staffUser -> staffUser.getFullName())
                        .orElse(null);

        return new ClaimResponse(
                claim.getId(),
                claim.getClaimCode(),
                claim.getCustomerId(),
                claim.getPolicyApplicationId(),
                claim.getPolicyNameSnapshot(),
                claim.getIncidentType(),
                claim.getIncidentDate(),
                claim.getAmount(),
                claim.getDescription(),
                claim.getDocumentRef(),
                claim.getStatus(),
                claim.getProcessedBy(),
                processedByName,
                claim.getProcessedAt(),
                claim.getCreatedAt());
    }

    /**
     * Converts a claim entity to the detailed response used by review screens, resolving the applicant
     * and policy application details so staff/customers do not see blank fields.
     *
     * @param claim persisted claim entity
     * @return claim detail DTO including applicant and application information
     */
    private ClaimDetailResponse toDetailResponse(Claim claim) {
        String processedByName = claim.getProcessedBy() == null
                ? null
                : staffUserRepository.findById(claim.getProcessedBy())
                        .map(staffUser -> staffUser.getFullName())
                        .orElse(null);

        ClaimApplicantSnapshot applicant = null;
        try {
            applicant = applicantLookupClient.lookup(claim.getCustomerId(), claim.getPolicyApplicationId());
        } catch (RuntimeException exception) {
            log.warn("Unable to resolve applicant details for claimId={}", claim.getId(), exception);
        }

        return new ClaimDetailResponse(
                claim.getId(),
                claim.getClaimCode(),
                claim.getStatus(),
                claim.getIncidentType(),
                claim.getIncidentDate(),
                claim.getAmount(),
                claim.getDescription(),
                null,
                applicant != null ? applicant.applicantName() : null,
                applicant != null ? applicant.applicantEmail() : null,
                applicant != null ? applicant.applicantPhone() : null,
                applicant != null ? applicant.applicationCode() : null,
                applicant != null ? applicant.policyName() : claim.getPolicyNameSnapshot(),
                applicant != null ? applicant.coverageAmount() : null,
                applicant != null ? applicant.premiumAmount() : null,
                claim.getProcessedBy(),
                processedByName,
                claim.getProcessedAt(),
                claim.getCreatedAt());
    }
}

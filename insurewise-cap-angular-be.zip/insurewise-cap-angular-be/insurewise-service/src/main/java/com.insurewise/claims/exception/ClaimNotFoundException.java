package com.insurewise.claims.exception;

import com.insurewise.common.exception.ResourceNotFoundException;
import java.util.UUID;

public class ClaimNotFoundException extends ResourceNotFoundException {
/**
 * Claim Not Found Exception.
 * @param id the value supplied for the id.
 * @return the result of the operation.
*/

    public ClaimNotFoundException(UUID id) {
        super("CLAIM_NOT_FOUND", "Claim not found: " + id);
    }
/**
 * Claim Not Found Exception.
 * @return the result of the operation.
*/

    public ClaimNotFoundException() {
        super("CLAIM_NOT_FOUND", "Claim not found");
    }
}
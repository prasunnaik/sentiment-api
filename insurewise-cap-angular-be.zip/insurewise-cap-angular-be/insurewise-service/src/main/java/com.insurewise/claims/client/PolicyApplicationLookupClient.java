package com.insurewise.claims.client;

import com.insurewise.policy.entity.PolicyApplication;
import com.insurewise.policy.exception.ApplicationNotFoundException;
import com.insurewise.policy.repository.PolicyApplicationRepository;
import java.util.UUID;
import org.springframework.stereotype.Component;
/**
 * Represents the class Policy Application Lookup Client.
*/

@Component
public class PolicyApplicationLookupClient {
    private final PolicyApplicationRepository repository;
/**
 * Policy Application Lookup Client.
 * @param repository the value supplied for the repository.
 * @return the result of the operation.
*/

    public PolicyApplicationLookupClient(
            PolicyApplicationRepository repository) {
        this.repository = repository;
    }
/**
 * Get Active Application For Customer.
 * @param applicationId the value supplied for the applicationId.
 * @param customerId the value supplied for the customerId.
 * @return the result of the operation.
*/

    public PolicyApplicationSnapshot getActiveApplicationForCustomer(
            UUID applicationId,
            UUID customerId) {

        PolicyApplication application = repository.findById(applicationId)
                .filter(item -> item.isOwnedBy(customerId))
                .filter(item -> item.getStatus()
                        == com.insurewise.policy.entity.ApplicationStatus.APPROVED)
                .orElseThrow(() -> new ApplicationNotFoundException(
                        applicationId));

        return snapshot(application);
    }
/**
 * Get Application Snapshot.
 * @param applicationId the value supplied for the applicationId.
 * @return the result of the operation.
*/

    public PolicyApplicationSnapshot getApplicationSnapshot(
            UUID applicationId) {

        return repository.findById(applicationId)
                .map(this::snapshot)
                .orElseThrow(() -> new ApplicationNotFoundException(
                        applicationId));
    }
/**
 * Snapshot.
 * @param application the value supplied for the application.
 * @return the result of the operation.
*/

    private PolicyApplicationSnapshot snapshot(
            PolicyApplication application) {

        return new PolicyApplicationSnapshot(
                application.getId(),
                application.getCustomerId(),
                application.getPolicy().getName(),
                application.getStatus(),
                application.getStatus()
                        == com.insurewise.policy.entity.ApplicationStatus.APPROVED);
    }
}
package com.insurewise.claims.dto.response;

public record ClaimSubmissionResponse(
        ClaimResponse claim,
        ClaimDocumentResponse document
) {
}

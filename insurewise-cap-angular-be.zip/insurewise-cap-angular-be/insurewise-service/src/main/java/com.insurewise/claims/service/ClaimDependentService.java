package com.insurewise.claims.service;

import com.insurewise.claims.dto.request.ClaimDependentRequest;
import com.insurewise.claims.dto.response.ClaimDependentResponse;
import com.insurewise.claims.entity.Claim;
import com.insurewise.claims.entity.ClaimDependent;
import com.insurewise.claims.exception.ClaimNotFoundException;
import com.insurewise.claims.repository.ClaimDependentRepository;
import com.insurewise.claims.repository.ClaimRepository;
import com.insurewise.common.exception.BusinessException;
import java.util.List;
import java.util.UUID;
import org.springframework.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
/**
 * Represents the class Claim Dependent Service.
*/


@Service
@Transactional
public class ClaimDependentService {
    private static final Logger log = LoggerFactory.getLogger(ClaimDependentService.class);
    private final ClaimRepository claimRepository;
    private final ClaimDependentRepository dependentRepository;
/**
 * Claim Dependent Service.
 * @param claimRepository the value supplied for the claimRepository.
 * @param dependentRepository the value supplied for the dependentRepository.
 * @return the result of the operation.
*/

    public ClaimDependentService(
            ClaimRepository claimRepository,
            ClaimDependentRepository dependentRepository) {
        this.claimRepository = claimRepository;
        this.dependentRepository = dependentRepository;
    }
/**
 * Add Dependent.
 * @param customerId the value supplied for the customerId.
 * @param claimId the value supplied for the claimId.
 * @param request the value supplied for the request.
 * @return the result of the operation.
*/

    public ClaimDependentResponse addDependent(
            UUID customerId,
            UUID claimId,
            ClaimDependentRequest request) {

        try {
            Claim claim = requireOwnedClaim(customerId, claimId);

            ClaimDependent dependent = dependentRepository.save(
                    new ClaimDependent(
                            claim,
                            request.fullName(),
                            request.relationship(),
                            request.dateOfBirth(),
                            request.gender()));

            return toResponse(dependent);
        } catch (BusinessException | ClaimNotFoundException exception) {
            throw exception;
        } catch (RuntimeException exception) {
            log.error("Failed to add claim dependent for customerId={}, claimId={}", customerId, claimId, exception);
            throw new BusinessException(
                    "CLAIM_DEPENDENT_CREATE_FAILED",
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unable to add claim dependent at this time.",
                    exception);
        }
    }
/**
 * List Dependents.
 * @param customerId the value supplied for the customerId.
 * @param claimId the value supplied for the claimId.
 * @return the result of the operation.
*/

    @Transactional(readOnly = true)
    public List<ClaimDependentResponse> listDependents(
            UUID customerId,
            UUID claimId) {

        try {
            requireOwnedClaim(customerId, claimId);

            return dependentRepository.findByClaimId(claimId)
                    .stream()
                    .map(this::toResponse)
                    .toList();
        } catch (BusinessException | ClaimNotFoundException exception) {
            throw exception;
        } catch (RuntimeException exception) {
            log.error("Failed to list claim dependents for customerId={}, claimId={}", customerId, claimId, exception);
            throw new BusinessException(
                    "CLAIM_DEPENDENT_LIST_FAILED",
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unable to load claim dependents at this time.",
                    exception);
        }
    }
/**
 * Require Owned Claim.
 * @param customerId the value supplied for the customerId.
 * @param claimId the value supplied for the claimId.
 * @return the result of the operation.
*/

    private Claim requireOwnedClaim(UUID customerId, UUID claimId) {
        return claimRepository.findById(claimId)
                .filter(claim -> claim.isOwnedBy(customerId))
                .orElseThrow(ClaimNotFoundException::new);
    }
/**
 * To Response.
 * @param dependent the value supplied for the dependent.
 * @return the result of the operation.
*/

    private ClaimDependentResponse toResponse(
            ClaimDependent dependent) {
        return new ClaimDependentResponse(
                dependent.getId(),
                dependent.getClaim().getId(),
                dependent.getFullName(),
                dependent.getRelationship(),
                dependent.getDateOfBirth(),
                dependent.getGender());
    }
}

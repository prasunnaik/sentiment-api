package com.insurewise.claims.dto.response;

/**
 * Carries the raw bytes and metadata of a claim document so it can be streamed directly by the
 * backend to a client, avoiding the need for the client to fetch the file from S3 directly (which
 * would require the S3 bucket to allow cross-origin browser requests).
 *
 * @param fileName the original file name of the document
 * @param contentType the MIME type of the document
 * @param content the raw bytes of the document
 */
public record ClaimDocumentContentResponse(
        String fileName,
        String contentType,
        byte[] content
) {
}

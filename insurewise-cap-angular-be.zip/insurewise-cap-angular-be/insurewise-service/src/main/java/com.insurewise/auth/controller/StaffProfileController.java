package com.insurewise.auth.controller;

import com.insurewise.auth.dto.response.StaffProfilePictureResponse;
import com.insurewise.auth.service.StaffProfilePictureService;
import com.insurewise.common.security.JwtPrincipal;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/api/staff/profile-picture")
@PreAuthorize("hasRole('STAFF')")
/**
 * Represents the class Staff Profile Controller.
*/
public class StaffProfileController {

    private final StaffProfilePictureService profilePictureService;
/**
 * Staff Profile Controller.
 * @param profilePictureService the value supplied for the profilePictureService.
 * @return the result of the operation.
*/

    public StaffProfileController(
            StaffProfilePictureService profilePictureService) {

        this.profilePictureService = profilePictureService;
    }

    @PostMapping(
            value = "/upload",
            consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<StaffProfilePictureResponse> uploadProfilePicture(
            @AuthenticationPrincipal JwtPrincipal principal,
            @RequestPart("file") MultipartFile file) {

        StaffProfilePictureResponse response =
                profilePictureService.uploadProfilePicture(
                        principal.userId(),
                        file);

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(response);
    }
/**
 * Get.
 * @param principal the value supplied for the principal.
 * @return the result of the operation.
*/

    @GetMapping
    public StaffProfilePictureResponse getProfilePicture(
            @AuthenticationPrincipal JwtPrincipal principal) {

        return profilePictureService.getProfilePicture(
                principal.userId());
    }
/**
 * Delete.
 * @param principal the value supplied for the principal.
 * @return the result of the operation.
*/

    @DeleteMapping
    public ResponseEntity<Void> deleteProfilePicture(
            @AuthenticationPrincipal JwtPrincipal principal) {

        profilePictureService.deleteProfilePicture(
                principal.userId());

        return ResponseEntity.noContent().build();
    }
}

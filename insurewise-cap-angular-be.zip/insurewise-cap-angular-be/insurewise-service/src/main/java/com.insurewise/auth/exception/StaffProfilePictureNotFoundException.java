package com.insurewise.auth.exception;

import java.util.UUID;

public class StaffProfilePictureNotFoundException
        extends RuntimeException {
/**
 * Staff Profile Picture Not Found Exception.
 * @param staffUserId the value supplied for the staffUserId.
 * @return the result of the operation.
*/

    public StaffProfilePictureNotFoundException(
            UUID staffUserId) {

        super("Profile picture not found for staff user: "
                + staffUserId);
    }
}

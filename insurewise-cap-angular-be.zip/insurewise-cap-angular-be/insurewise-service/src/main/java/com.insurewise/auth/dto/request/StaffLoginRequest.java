package auth.dto.request;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
/**
 * Represents the record Staff Login Request.
*/

public record StaffLoginRequest(
        @NotBlank
        @Email
        String email,

        @NotBlank
        String password
) {
}

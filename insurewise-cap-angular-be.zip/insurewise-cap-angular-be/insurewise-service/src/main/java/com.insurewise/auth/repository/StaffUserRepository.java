package com.insurewise.auth.repository;

import com.insurewise.auth.entity.StaffUser;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;
import java.util.UUID;

public interface StaffUserRepository extends JpaRepository<StaffUser, UUID> {
    boolean existsByEmailIgnoreCase(String email);

    Optional<StaffUser> findByEmailIgnoreCase(String email);
}

package com.insurewise.auth.service;

import com.insurewise.auth.dto.request.CustomerLoginRequest;
import com.insurewise.auth.dto.request.CustomerRegistrationRequest;
import com.insurewise.auth.dto.request.StaffLoginRequest;
import com.insurewise.auth.dto.response.AuthResponse;
import com.insurewise.auth.entity.Customer;
import com.insurewise.auth.entity.StaffUser;
import com.insurewise.auth.exception.DuplicateEmailException;
import com.insurewise.auth.exception.InvalidCredentialsException;
import com.insurewise.auth.repository.CustomerRepository;
import com.insurewise.auth.repository.StaffUserRepository;
import com.insurewise.common.exception.BusinessException;
import com.insurewise.common.security.JwtRole;
import com.insurewise.common.security.JwtService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class AuthService {
    private static final Logger log = LoggerFactory.getLogger(AuthService.class);
    private final CustomerRepository customerRepository;
    private final StaffUserRepository staffUserRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;

    /**
     * Creates the authentication service with the repositories and token generator used for
     * customer and staff sign-in flows.
     *
     * @param customerRepository repository for customer records used during registration and login
     * @param staffUserRepository repository for staff records used during staff authentication
     * @param passwordEncoder encoder used to hash and verify passwords
     * @param jwtService service responsible for generating bearer tokens
     */
    public AuthService(
            CustomerRepository customerRepository,
            StaffUserRepository staffUserRepository,
            PasswordEncoder passwordEncoder,
            JwtService jwtService) {
        this.customerRepository = customerRepository;
        this.staffUserRepository = staffUserRepository;
        this.passwordEncoder = passwordEncoder;
        this.jwtService = jwtService;
    }

    /**
     * Registers a new customer account and issues a JWT after successful persistence.
     *
     * @param request registration payload containing the customer's full name, phone, email, and password
     * @return signed authentication payload with the generated customer token
     */
    public AuthResponse registerCustomer(CustomerRegistrationRequest request) {
        try {
            String email = request.email().toLowerCase();

            if (customerRepository.existsByEmailIgnoreCase(email)
                    || staffUserRepository.existsByEmailIgnoreCase(email)) {
                throw new DuplicateEmailException(email);
            }

            Customer customer = new Customer(
                    request.fullName(),
                    request.phone(),
                    email,
                    passwordEncoder.encode(request.password()));

            customerRepository.save(customer);
            return createResponse(customer);
        } catch (BusinessException exception) {
            throw exception;
        } catch (RuntimeException exception) {
            log.error("Failed to register customer email={}, fullName={}", request.email(), request.fullName(), exception);
            throw new BusinessException(
                    "CUSTOMER_REGISTRATION_FAILED",
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unable to register customer at this time.",
                    exception);
        }
    }

    /**
     * Authenticates a customer using email and password and returns a signed JWT.
     *
     * @param request login payload with the customer's email and password
     * @return token payload for the authenticated customer
     */
    @Transactional(readOnly = true)
    public AuthResponse loginCustomer(CustomerLoginRequest request) {
        try {
            Customer customer = customerRepository
                    .findByEmailIgnoreCase(request.email())
                    .orElseThrow(InvalidCredentialsException::new);

            if (!passwordEncoder.matches(request.password(), customer.getPasswordHash())) {
                throw new InvalidCredentialsException();
            }

            return createResponse(customer);
        } catch (BusinessException exception) {
            throw exception;
        } catch (RuntimeException exception) {
            log.error("Failed to authenticate customer email={}", request.email(), exception);
            throw new BusinessException(
                    "CUSTOMER_LOGIN_FAILED",
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unable to complete customer login at this time.",
                    exception);
        }
    }

    /**
     * Authenticates a staff user using email and password and returns a staff JWT.
     *
     * @param request login payload with the staff email and password
     * @return token payload for the authenticated staff member
     */
    @Transactional(readOnly = true)
    public AuthResponse loginStaff(StaffLoginRequest request) {
        try {
            StaffUser staff = staffUserRepository
                    .findByEmailIgnoreCase(request.email())
                    .orElseThrow(InvalidCredentialsException::new);

            if (!passwordEncoder.matches(request.password(), staff.getPasswordHash())) {
                throw new InvalidCredentialsException();
            }

            String token = jwtService.generate(
                    staff.getId(),
                    staff.getEmail(),
                    JwtRole.STAFF);

            return new AuthResponse(
                    token,
                    "Bearer",
                    staff.getId(),
                    staff.getEmail(),
                    JwtRole.STAFF.name());
        } catch (BusinessException exception) {
            throw exception;
        } catch (RuntimeException exception) {
            log.error("Failed to authenticate staff email={}", request.email(), exception);
            throw new BusinessException(
                    "STAFF_LOGIN_FAILED",
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unable to complete staff login at this time.",
                    exception);
        }
    }

    /**
     * Builds a JWT-backed authentication response for an existing customer account.
     *
     * @param customer persisted customer entity used to generate the token payload
     * @return JWT response containing user identity and bearer token metadata
     */
    private AuthResponse createResponse(Customer customer) {
        String token = jwtService.generate(
                customer.getId(),
                customer.getEmail(),
                JwtRole.CUSTOMER);

        return new AuthResponse(
                token,
                "Bearer",
                customer.getId(),
                customer.getEmail(),
                JwtRole.CUSTOMER.name());
    }
}

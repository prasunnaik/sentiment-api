package com.insurewise.auth.dto.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.insurewise.common.dto.PresignedUrlResponse;
import java.util.UUID;
/**
 * Represents the record Profile Picture Response.
*/

public record ProfilePictureResponse(
        @JsonProperty("customer_id")
        UUID customerId,

        @JsonProperty("s3_key")
        String s3Key,

        PresignedUrlResponse download
) {
}

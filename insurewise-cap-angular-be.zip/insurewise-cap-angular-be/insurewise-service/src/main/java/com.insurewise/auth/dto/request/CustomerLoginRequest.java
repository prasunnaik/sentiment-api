package com.insurewise.auth.dto.request;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
/**
 * Represents the record Customer Login Request.
*/

public record CustomerLoginRequest(
        @NotBlank
        @Email
        String email,

        @NotBlank
        String password
) {
}

package com.insurewise.policy.repository;

import com.insurewise.policy.entity.Dependent;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.UUID;

public interface DependentRepository
        extends JpaRepository<Dependent, UUID> {

    List<Dependent> findByPolicyApplicationIdOrderByCreatedAtAsc(
            UUID policyApplicationId);
}
package com.insurewise.policy.controller;

import com.insurewise.common.dto.PresignedUrlResponse;
import com.insurewise.common.security.JwtPrincipal;
import com.insurewise.policy.dto.response.ApplicationDocumentContentResponse;
import com.insurewise.policy.dto.response.ApplicationDocumentResponse;
import com.insurewise.policy.service.ApplicationDocumentService;
import java.util.List;
import java.util.UUID;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

/**
 * Provides REST endpoints for uploading and reviewing application documents.
 *
*/
@RestController
@RequestMapping("/api/applications/{id}/documents")
public class ApplicationDocumentController {
    private final ApplicationDocumentService service;

    /**
     * Creates a controller with the application document service dependency.
     *
     * @param service the document service used to manage uploaded documents
*/
    public ApplicationDocumentController(ApplicationDocumentService service) {
        this.service = service;
    }

    /**
     * Uploads a PDF document for the specified application.
     *
     * @param principal the authenticated principal requesting the operation
     * @param id the policy application identifier
     * @param file the uploaded document content
     * @return the stored document response
*/
    @PostMapping(consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @PreAuthorize("hasRole('CUSTOMER')")
    public ApplicationDocumentResponse uploadApplicationDocument(
            @AuthenticationPrincipal JwtPrincipal principal,
            @PathVariable("id") UUID id,
            @RequestParam("file") MultipartFile file) {
        return service.uploadApplicationDocument(principal, id, file);
    }

    /**
     * Lists all uploaded documents for the specified application.
     *
     * @param principal the authenticated principal requesting the operation
     * @param id the policy application identifier
     * @return the documents associated with the application
*/
    @GetMapping
    @PreAuthorize("hasAnyRole('CUSTOMER', 'STAFF')")
    public List<ApplicationDocumentResponse> listApplicationDocuments(
            @AuthenticationPrincipal JwtPrincipal principal,
            @PathVariable("id") UUID id) {
        return service.listApplicationDocuments(principal, id);
    }

    @GetMapping("/{documentId}")
    @PreAuthorize("hasAnyRole('CUSTOMER', 'STAFF')")
    public ResponseEntity<ApplicationDocumentContentResponse> getDocument(
            @AuthenticationPrincipal JwtPrincipal principal,
            @PathVariable("id") UUID id,
            @PathVariable("documentId") UUID documentId) {
        return ResponseEntity.ok(service.getDocument(principal, id, documentId));
    }

    @GetMapping("/{documentId}/preview")
    @PreAuthorize("hasAnyRole('CUSTOMER', 'STAFF')")
    public ResponseEntity<PresignedUrlResponse> previewDocument(
            @AuthenticationPrincipal JwtPrincipal principal,
            @PathVariable("id") UUID id,
            @PathVariable("documentId") UUID documentId) {
        return ResponseEntity.ok(service.previewDocument(principal, id, documentId));
    }

    @GetMapping("/{documentId}/download")
    @PreAuthorize("hasAnyRole('CUSTOMER', 'STAFF')")
    public ResponseEntity<PresignedUrlResponse> downloadDocument(
            @AuthenticationPrincipal JwtPrincipal principal,
            @PathVariable("id") UUID id,
            @PathVariable("documentId") UUID documentId) {
        return ResponseEntity.ok(service.downloadDocument(principal, id, documentId));
    }

    /**
     * Deletes an uploaded document from the specified application.
     *
     * @param principal the authenticated principal requesting the operation
     * @param id the policy application identifier
     * @param documentId the document identifier to delete
*/
    @DeleteMapping("/{documentId}")
    @PreAuthorize("hasRole('CUSTOMER')")
    public void deleteApplicationDocument(
            @AuthenticationPrincipal JwtPrincipal principal,
            @PathVariable("id") UUID id,
            @PathVariable("documentId") UUID documentId) {
        service.deleteDocument(principal, id, documentId);
    }
}
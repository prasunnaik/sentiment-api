package com.insurewise.policy.repository;

import com.insurewise.policy.entity.ApplicationStatus;
import com.insurewise.policy.entity.PolicyApplication;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.UUID;

public interface PolicyApplicationRepository
        extends JpaRepository<PolicyApplication, UUID> {

    List<PolicyApplication> findByCustomerIdOrderByCreatedAtDesc(
            UUID customerId);

    List<PolicyApplication> findAllByOrderByCreatedAtDesc();

    List<PolicyApplication> findByStatusOrderByCreatedAtDesc(
            ApplicationStatus status);

    List<PolicyApplication> findByCustomerIdAndStatusOrderByCreatedAtDesc(
            UUID customerId,
            ApplicationStatus status);

    boolean existsByCustomerIdAndPolicyIdAndStatus(
            UUID customerId,
            UUID policyId,
            ApplicationStatus status);

    boolean existsByPolicyId(UUID policyId);

    @Query(
            value = "select nextval('application_code_seq')",
            nativeQuery = true)
    Long nextApplicationCodeSequence();

    long countByStatus(
            ApplicationStatus status);
}

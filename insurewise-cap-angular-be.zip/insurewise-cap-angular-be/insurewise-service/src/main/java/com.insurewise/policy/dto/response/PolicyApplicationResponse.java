package com.insurewise.policy.dto.response;

import com.insurewise.policy.entity.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.UUID;
/**
 * Represents the record Policy Application Response.
*/

public record PolicyApplicationResponse(
        UUID id,
        String applicationCode,
        UUID customerId,
        UUID policyId,
        String policyName,
        CoverageType coverageType,
        BigDecimal coverageAmount,
        BigDecimal premiumAmount,
        LocalDate dateOfBirth,
        String address,
        LocalDate preferredStartDate,
        String nomineeName,
        NomineeRelationship nomineeRelationship,
        LocalDate startDate,
        LocalDate endDate,
        ApplicationStatus status,
        UUID decidedBy,
        LocalDateTime decidedAt,
        LocalDateTime createdAt
) {
}

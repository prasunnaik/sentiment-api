package com.insurewise.policy.exception;

import com.insurewise.common.exception.ResourceNotFoundException;
import java.util.UUID;

public class PolicyNotFoundException extends ResourceNotFoundException {
/**
 * Policy Not Found Exception.
 * @param id the value supplied for the id.
 * @return the result of the operation.
*/

    public PolicyNotFoundException(UUID id) {
        super("POLICY_NOT_FOUND", "Policy not found: " + id);
    }
}
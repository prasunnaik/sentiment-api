package com.insurewise.policy.entity;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.UUID;
/**
 * Represents the class Dependent.
*/

@Entity
@Table(name = "dependents")
public class Dependent {
    @Id
    @GeneratedValue
    private UUID id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "policy_application_id", nullable = false)
    private PolicyApplication policyApplication;

    @Column(name = "full_name", nullable = false, length = 120)
    private String fullName;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private Relationship relationship;

    @Column(name = "date_of_birth", nullable = false)
    private LocalDate dateOfBirth;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 10)
    private Gender gender;

    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;
/**
 * Dependent.
 * @return the result of the operation.
*/

    protected Dependent() {
    }
/**
 * Dependent.
 * @param policyApplication the value supplied for the policyApplication.
 * @param fullName the value supplied for the fullName.
 * @param relationship the value supplied for the relationship.
 * @param dateOfBirth the value supplied for the dateOfBirth.
 * @param gender the value supplied for the gender.
 * @return the result of the operation.
*/

    public Dependent(
            PolicyApplication policyApplication,
            String fullName,
            Relationship relationship,
            LocalDate dateOfBirth,
            Gender gender) {
        this.policyApplication = policyApplication;
        this.fullName = fullName;
        this.relationship = relationship;
        this.dateOfBirth = dateOfBirth;
        this.gender = gender;
    }

    @PrePersist
    void initialize() {
        if (createdAt == null) {
            createdAt = LocalDateTime.now();
        }
    }
/**
 * Update.
 * @param fullName the value supplied for the fullName.
 * @param relationship the value supplied for the relationship.
 * @param dateOfBirth the value supplied for the dateOfBirth.
 * @param gender the value supplied for the gender.
*/

    public void update(
            String fullName,
            Relationship relationship,
            LocalDate dateOfBirth,
            Gender gender) {
        this.fullName = fullName;
        this.relationship = relationship;
        this.dateOfBirth = dateOfBirth;
        this.gender = gender;
    }
/**
 * Get Id.
 * @return the result of the operation.
*/

    public UUID getId() {
        return id;
    }
/**
 * Get Policy Application.
 * @return the result of the operation.
*/

    public PolicyApplication getPolicyApplication() {
        return policyApplication;
    }
/**
 * Get Full Name.
 * @return the result of the operation.
*/

    public String getFullName() {
        return fullName;
    }
/**
 * Get Relationship.
 * @return the result of the operation.
*/

    public Relationship getRelationship() {
        return relationship;
    }
/**
 * Get Date Of Birth.
 * @return the result of the operation.
*/

    public LocalDate getDateOfBirth() {
        return dateOfBirth;
    }
/**
 * Get Gender.
 * @return the result of the operation.
*/

    public Gender getGender() {
        return gender;
    }
/**
 * Get Created At.
 * @return the result of the operation.
*/

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }
}
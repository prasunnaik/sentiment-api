package com.insurewise.policy.entity;
/**
 * Represents the enum Policy Status.
*/

public enum PolicyStatus {
    DRAFT,
    ACTIVE,
    INACTIVE
}

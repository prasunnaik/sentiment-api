package com.insurewise.policy.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.UUID;
/**
 * Represents the class Policy Application.
*/

@Entity
@Table(name = "policy_applications")
public class PolicyApplication {
    @Id
    @GeneratedValue
    private UUID id;

    @Column(name = "application_code", nullable = false, unique = true, length = 40)
    private String applicationCode;

    @Column(name = "customer_id", nullable = false)
    private UUID customerId;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "policy_id", nullable = false)
    private Policy policy;

    @Enumerated(EnumType.STRING)
    @Column(name = "coverage_type", nullable = false, length = 20)
    private CoverageType coverageType;

    @Column(name = "coverage_amount", nullable = false, precision = 14, scale = 2)
    private BigDecimal coverageAmount;

    @Column(name = "premium_amount", nullable = false, precision = 10, scale = 2)
    private BigDecimal premiumAmount;

    @Column(name = "date_of_birth", nullable = false)
    private LocalDate dateOfBirth;

    @Column(nullable = false, length = 500)
    private String address;

    @Column(name = "preferred_start_date")
    private LocalDate preferredStartDate;

    @Column(name = "nominee_name", length = 120)
    private String nomineeName;

    @Enumerated(EnumType.STRING)
    @Column(name = "nominee_relationship", length = 20)
    private NomineeRelationship nomineeRelationship;

    @Column(name = "start_date")
    private LocalDate startDate;

    @Column(name = "end_date")
    private LocalDate endDate;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private ApplicationStatus status;

    @Column(name = "decided_by")
    private UUID decidedBy;

    @Column(name = "decided_at")
    private LocalDateTime decidedAt;

    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;
/**
 * Policy Application.
 * @return the result of the operation.
*/

    protected PolicyApplication() {
    }
/**
 * Policy Application.
 * @param applicationCode the value supplied for the applicationCode.
 * @param customerId the value supplied for the customerId.
 * @param policy the value supplied for the policy.
 * @param coverageType the value supplied for the coverageType.
 * @param dateOfBirth the value supplied for the dateOfBirth.
 * @param address the value supplied for the address.
 * @param preferredStartDate the value supplied for the preferredStartDate.
 * @param nomineeName the value supplied for the nomineeName.
 * @param nomineeRelationship the value supplied for the nomineeRelationship.
 * @return the result of the operation.
*/

    public PolicyApplication(
            String applicationCode,
            UUID customerId,
            Policy policy,
            CoverageType coverageType,
            LocalDate dateOfBirth,
            String address,
            LocalDate preferredStartDate,
            String nomineeName,
            NomineeRelationship nomineeRelationship) {
        this.applicationCode = applicationCode;
        this.customerId = customerId;
        this.policy = policy;
        this.coverageType = coverageType;
        this.coverageAmount = policy.getCoverageAmount();
        this.premiumAmount = policy.getPremiumAmount();
        this.dateOfBirth = dateOfBirth;
        this.address = address;
        this.preferredStartDate = preferredStartDate;
        this.nomineeName = nomineeName;
        this.nomineeRelationship = nomineeRelationship;
        this.status = ApplicationStatus.PENDING;
    }

    @PrePersist
    void initialize() {
        if (createdAt == null) {
            createdAt = LocalDateTime.now();
        }
    }
/**
 * Approve.
 * @param staffUserId the value supplied for the staffUserId.
 * @param startDate the value supplied for the startDate.
 * @param endDate the value supplied for the endDate.
*/

    public void approve(
            UUID staffUserId,
            LocalDate startDate,
            LocalDate endDate) {
        ensurePending();
        this.status = ApplicationStatus.APPROVED;
        this.decidedBy = staffUserId;
        this.decidedAt = LocalDateTime.now();
        this.startDate = startDate;
        this.endDate = endDate;
    }
/**
 * Reject.
 * @param staffUserId the value supplied for the staffUserId.
*/

    public void reject(UUID staffUserId) {
        ensurePending();
        this.status = ApplicationStatus.REJECTED;
        this.decidedBy = staffUserId;
        this.decidedAt = LocalDateTime.now();
    }
/**
 * Ensure Pending.
*/

    private void ensurePending() {
        if (status != ApplicationStatus.PENDING) {
            throw new IllegalStateException(
                    "Only pending applications can be decided");
        }
    }
/**
 * Is Owned By.
 * @param customerId the value supplied for the customerId.
 * @return the result of the operation.
*/

    public boolean isOwnedBy(UUID customerId) {
        return this.customerId.equals(customerId);
    }
/**
 * Is Active.
 * @return the result of the operation.
*/

    public boolean isActive() {
        return status == ApplicationStatus.APPROVED;
    }
/**
 * Get Id.
 * @return the result of the operation.
*/

    public UUID getId() {
        return id;
    }
/**
 * Get Application Code.
 * @return the result of the operation.
*/

    public String getApplicationCode() {
        return applicationCode;
    }
/**
 * Get Customer Id.
 * @return the result of the operation.
*/

    public UUID getCustomerId() {
        return customerId;
    }
/**
 * Get Policy.
 * @return the result of the operation.
*/

    public Policy getPolicy() {
        return policy;
    }
/**
 * Get Coverage Type.
 * @return the result of the operation.
*/

    public CoverageType getCoverageType() {
        return coverageType;
    }
/**
 * Get Coverage Amount.
 * @return the result of the operation.
*/

    public BigDecimal getCoverageAmount() {
        return coverageAmount;
    }
/**
 * Get Premium Amount.
 * @return the result of the operation.
*/

    public BigDecimal getPremiumAmount() {
        return premiumAmount;
    }
/**
 * Get Date Of Birth.
 * @return the result of the operation.
*/

    public LocalDate getDateOfBirth() {
        return dateOfBirth;
    }
/**
 * Get Address.
 * @return the result of the operation.
*/

    public String getAddress() {
        return address;
    }
/**
 * Get Preferred Start Date.
 * @return the result of the operation.
*/

    public LocalDate getPreferredStartDate() {
        return preferredStartDate;
    }
/**
 * Get Nominee Name.
 * @return the result of the operation.
*/

    public String getNomineeName() {
        return nomineeName;
    }
/**
 * Get Nominee Relationship.
 * @return the result of the operation.
*/

    public NomineeRelationship getNomineeRelationship() {
        return nomineeRelationship;
    }
/**
 * Get Start Date.
 * @return the result of the operation.
*/

    public LocalDate getStartDate() {
        return startDate;
    }
/**
 * Get End Date.
 * @return the result of the operation.
*/

    public LocalDate getEndDate() {
        return endDate;
    }
/**
 * Get Status.
 * @return the result of the operation.
*/

    public ApplicationStatus getStatus() {
        return status;
    }
/**
 * Get Decided By.
 * @return the result of the operation.
*/

    public UUID getDecidedBy() {
        return decidedBy;
    }
/**
 * Get Decided At.
 * @return the result of the operation.
*/

    public LocalDateTime getDecidedAt() {
        return decidedAt;
    }
/**
 * Get Created At.
 * @return the result of the operation.
*/

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }
}
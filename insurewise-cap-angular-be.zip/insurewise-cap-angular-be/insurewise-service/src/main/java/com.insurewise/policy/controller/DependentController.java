package com.insurewise.policy.controller;

import com.insurewise.common.security.JwtPrincipal;
import com.insurewise.policy.dto.request.DependentRequest;
import com.insurewise.policy.dto.response.DependentResponse;
import com.insurewise.policy.service.DependentService;
import jakarta.validation.Valid;
import java.util.List;
import java.util.UUID;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

/**
 * Provides REST endpoints for managing dependents linked to a policy application.
 *
*/
@RestController
@RequestMapping("/api/applications/{id}/dependents")
@PreAuthorize("hasRole('CUSTOMER')")
public class DependentController {
    private final DependentService service;

    /**
     * Creates a controller with the dependent service dependency.
     *
     * @param service the dependent service used to manage dependent records
*/
    public DependentController(DependentService service) {
        this.service = service;
    }

    /**
     * Creates a new dependent record for the specified policy application.
     *
     * @param principal the authenticated principal requesting the operation
     * @param id the policy application identifier
     * @param request the dependent request payload
     * @return the created dependent response
*/
    @PostMapping
    public DependentResponse createDependent(
            @AuthenticationPrincipal JwtPrincipal principal,
            @PathVariable("id") UUID id,
            @Valid @RequestBody DependentRequest request) {
        return service.addDependent(principal, id, request);
    }

    /**
     * Lists all dependents for the specified policy application.
     *
     * @param principal the authenticated principal requesting the operation
     * @param id the policy application identifier
     * @return the dependents associated with the application
*/
    @GetMapping
    public List<DependentResponse> listDependents(
            @AuthenticationPrincipal JwtPrincipal principal,
            @PathVariable("id") UUID id) {
        return service.listDependents(principal, id);
    }

    /**
     * Updates an existing dependent for the specified policy application.
     *
     * @param principal the authenticated principal requesting the operation
     * @param id the policy application identifier
     * @param dependentId the dependent identifier to update
     * @param request the dependent update payload
     * @return the updated dependent response
*/
    @PutMapping("/{dependentId}")
    public DependentResponse updateDependent(
            @AuthenticationPrincipal JwtPrincipal principal,
            @PathVariable("id") UUID id,
            @PathVariable("dependentId") UUID dependentId,
            @Valid @RequestBody DependentRequest request) {
        return service.updateDependent(principal, id, dependentId, request);
    }

    /**
     * Removes a dependent from the specified policy application.
     *
     * @param principal the authenticated principal requesting the operation
     * @param id the policy application identifier
     * @param dependentId the dependent identifier to remove
*/
    @DeleteMapping("/{dependentId}")
    public void deleteDependent(
            @AuthenticationPrincipal JwtPrincipal principal,
            @PathVariable("id") UUID id,
            @PathVariable("dependentId") UUID dependentId) {
        service.deleteDependent(principal, id, dependentId);
    }
}
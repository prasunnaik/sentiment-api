//(Browse Policies). The original class
// also contained staff-only create/update/delete methods (BR-05: Add
// Policy), which have been removed here since they are a teammate's
// requirement. Removing them also drops the CategoryService dependency,
// which was only used to resolve a policy's category on create/update.
package com.insurewise.policy.service;

import com.insurewise.common.exception.BusinessException;
import com.insurewise.policy.dto.request.PolicyCreateRequest;
import com.insurewise.policy.dto.request.PolicyUpdateRequest;
import com.insurewise.policy.dto.response.PolicyResponse;
import com.insurewise.policy.entity.Category;
import com.insurewise.policy.entity.Policy;
import com.insurewise.policy.entity.PolicyStatus;
import com.insurewise.policy.exception.PolicyDeletionException;
import com.insurewise.policy.exception.PolicyNotFoundException;
import com.insurewise.policy.repository.PolicyApplicationRepository;
import com.insurewise.policy.repository.PolicyRepository;
import java.util.List;
import java.util.UUID;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class PolicyService {
    private static final Logger log = LoggerFactory.getLogger(PolicyService.class);
    private final PolicyRepository policyRepository;
    private final PolicyApplicationRepository applicationRepository;
    private final CategoryService categoryService;

    /**
     * Creates the policy service with the repositories and category lookup dependency used for policy
     * creation and updates.
     *
     * @param policyRepository repository for policy persistence
     * @param applicationRepository repository used to block deletion when applications reference a policy
     * @param categoryService category lookup service used to validate requested category ids
     */
    public PolicyService(
            PolicyRepository policyRepository,
            PolicyApplicationRepository applicationRepository,
            CategoryService categoryService) {
        this.policyRepository = policyRepository;
        this.applicationRepository = applicationRepository;
        this.categoryService = categoryService;
    }

    /**
     * Creates a new policy after validating that the selected category exists.
     *
     * @param request policy creation payload containing category and pricing details
     * @return saved policy response DTO
     */
    public PolicyResponse createPolicy(PolicyCreateRequest request) {
        try {
            Category category = categoryService.find(request.categoryId());

            Policy policy = policyRepository.save(new Policy(
                    request.name(),
                    category,
                    request.coverageAmount(),
                    request.premiumAmount(),
                    request.durationLabel(),
                    request.status()));

            return toResponse(policy);
        } catch (BusinessException | PolicyNotFoundException exception) {
            throw exception;
        } catch (RuntimeException exception) {
            log.error("Failed to create policy name={}, categoryId={}", request.name(), request.categoryId(), exception);
            throw new BusinessException(
                    "POLICY_CREATE_FAILED",
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unable to create policy at this time.",
                    exception);
        }
    }

    /**
     * Returns all policy entries that are currently active and eligible for customer display.
     *
     * @return active policy response list ordered by most recent creation first
     */
    @Transactional(readOnly = true)
    public List<PolicyResponse> listActive() {
        try {
            return policyRepository
                    .findAllByStatusOrderByCreatedAtDesc(PolicyStatus.ACTIVE)
                    .stream()
                    .filter(Policy::isActiveForCustomer)
                    .map(this::toResponse)
                    .toList();
        } catch (BusinessException exception) {
            throw exception;
        } catch (RuntimeException exception) {
            log.error("Failed to load active policies", exception);
            throw new BusinessException(
                    "POLICY_LIST_FAILED",
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unable to load policies at this time.",
                    exception);
        }
    }

    /**
     * Fetches a single policy for customer or staff use using its unique identifier.
     *
     * @param id policy primary key
     * @return policy details DTO
     */
    @Transactional(readOnly = true)
    public PolicyResponse getPolicy(UUID id) {
        try {
            return toResponse(find(id));
        } catch (PolicyNotFoundException | BusinessException exception) {
            throw exception;
        } catch (RuntimeException exception) {
            log.error("Failed to fetch policy id={}", id, exception);
            throw new BusinessException(
                    "POLICY_GET_FAILED",
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unable to load policy at this time.",
                    exception);
        }
    }

    /**
     * Updates an existing policy and rebinds it to the selected category if the category changed.
     *
     * @param id current policy id
     * @param request updated policy payload
     * @return updated policy response DTO
     */
    public PolicyResponse updatePolicy(UUID id, PolicyUpdateRequest request) {
        try {
            Policy policy = find(id);
            Category category = categoryService.find(request.categoryId());

            policy.update(
                    request.name(),
                    category,
                    request.coverageAmount(),
                    request.premiumAmount(),
                    request.durationLabel(),
                    request.status());

            return toResponse(policy);
        } catch (BusinessException | PolicyNotFoundException exception) {
            throw exception;
        } catch (RuntimeException exception) {
            log.error("Failed to update policy id={}, categoryId={}", id, request.categoryId(), exception);
            throw new BusinessException(
                    "POLICY_UPDATE_FAILED",
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unable to update policy at this time.",
                    exception);
        }
    }

    /**
     * Deletes a policy only if no applications are currently attached to it.
     *
     * @param id policy id to remove
     */
    public void deletePolicy(UUID id) {
        try {
            Policy policy = find(id);

            if (applicationRepository.existsByPolicyId(id)) {
                throw new PolicyDeletionException(
                        "Policy cannot be deleted because applications exist for it");
            }

            policyRepository.delete(policy);
        } catch (PolicyNotFoundException | BusinessException exception) {
            throw exception;
        } catch (RuntimeException exception) {
            log.error("Failed to delete policy id={}", id, exception);
            throw new BusinessException(
                    "POLICY_DELETE_FAILED",
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unable to delete policy at this time.",
                    exception);
        }
    }

    /**
     * Looks up a policy entity by id and throws a domain-specific not-found error when absent.
     *
     * @param id policy primary key
     * @return persisted policy entity
     */
    public Policy find(UUID id) {
        return policyRepository.findById(id)
                .orElseThrow(() -> new PolicyNotFoundException(id));
    }

    /**
     * Maps the entity model into the API response contract used by the frontend.
     *
     * @param policy persisted policy entity
     * @return policy DTO shown to clients
     */
    private PolicyResponse toResponse(Policy policy) {
        return new PolicyResponse(
                policy.getId(),
                policy.getName(),
                policy.getCategory().getId(),
                policy.getCategory().getName(),
                policy.getCoverageAmount(),
                policy.getPremiumAmount(),
                policy.getDurationLabel(),
                policy.getStatus());
    }
}

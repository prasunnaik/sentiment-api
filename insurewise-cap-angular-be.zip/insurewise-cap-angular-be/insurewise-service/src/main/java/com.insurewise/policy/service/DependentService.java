package com.insurewise.policy.service;

import com.insurewise.common.security.JwtPrincipal;
import com.insurewise.common.security.JwtRole;
import com.insurewise.common.exception.BusinessException;
import com.insurewise.policy.dto.request.DependentRequest;
import com.insurewise.policy.dto.response.DependentResponse;
import com.insurewise.policy.entity.Dependent;
import com.insurewise.policy.entity.PolicyApplication;
import com.insurewise.policy.exception.ApplicationNotFoundException;
import com.insurewise.policy.exception.DependentNotFoundException;
import com.insurewise.policy.repository.DependentRepository;
import java.util.List;
import java.util.UUID;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Provides operations for managing dependents on policy applications.
 *
*/
@Service
@Transactional
public class DependentService {
    private static final Logger log = LoggerFactory.getLogger(DependentService.class);
    private final DependentRepository dependentRepository;
    private final PolicyApplicationService applicationService;

    /**
     * Creates a service instance with the required repositories and application lookup dependency.
     *
     * @param dependentRepository the repository used to persist dependent records
     * @param applicationService the policy application service used to validate application access
*/
    public DependentService(
            DependentRepository dependentRepository,
            PolicyApplicationService applicationService) {
        this.dependentRepository = dependentRepository;
        this.applicationService = applicationService;
    }

    /**
     * Creates a dependent for the specified policy application.
     *
     * @param principal the authenticated principal requesting the operation
     * @param applicationId the policy application identifier
     * @param request the dependent request payload
     * @return the created dependent response
*/
    public DependentResponse addDependent(
            JwtPrincipal principal,
            UUID applicationId,
            DependentRequest request) {
        try {
            PolicyApplication application = requireApplicationAccess(principal, applicationId);

            Dependent dependent = dependentRepository.save(new Dependent(
                   application,
                   request.fullName(),
                   request.relationship(),
                   request.dateOfBirth(),
                   request.gender()));

            return toResponse(dependent);
        } catch (ApplicationNotFoundException | DependentNotFoundException | BusinessException exception) {
            throw exception;
        } catch (RuntimeException exception) {
            log.error("Failed to add dependent for applicationId={}, userId={}", applicationId, principal.userId(), exception);
            throw new BusinessException(
                    "DEPENDENT_CREATE_FAILED",
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unable to add dependent at this time.",
                    exception);
        }
    }

    /**
     * Lists all dependents for the specified policy application.
     *
     * @param principal the authenticated principal requesting the operation
     * @param applicationId the policy application identifier
     * @return all dependents for the requested application
*/
    @Transactional(readOnly = true)
    public List<DependentResponse> listDependents(
            JwtPrincipal principal,
            UUID applicationId) {
        try {
            requireApplicationAccess(principal, applicationId);

            return dependentRepository
                   .findByPolicyApplicationIdOrderByCreatedAtAsc(applicationId)
                   .stream()
                   .map(this::toResponse)
                   .toList();
        } catch (ApplicationNotFoundException | BusinessException exception) {
            throw exception;
        } catch (RuntimeException exception) {
            log.error("Failed to list dependents for applicationId={}, userId={}", applicationId, principal.userId(), exception);
            throw new BusinessException(
                    "DEPENDENT_LIST_FAILED",
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unable to load dependents at this time.",
                    exception);
        }
    }

    /**
     * Updates an existing dependent record.
     *
     * @param principal the authenticated principal requesting the operation
     * @param applicationId the policy application identifier
     * @param dependentId the dependent identifier
     * @param request the dependent update payload
     * @return the updated dependent response
*/
    public DependentResponse updateDependent(
            JwtPrincipal principal,
            UUID applicationId,
            UUID dependentId,
            DependentRequest request) {
        try {
            requireApplicationAccess(principal, applicationId);

            Dependent dependent = requireDependent(applicationId, dependentId);

            dependent.update(
                   request.fullName(),
                   request.relationship(),
                   request.dateOfBirth(),
                   request.gender());

            return toResponse(dependent);
        } catch (ApplicationNotFoundException | DependentNotFoundException | BusinessException exception) {
            throw exception;
        } catch (RuntimeException exception) {
            log.error(
                    "Failed to update dependent for applicationId={}, dependentId={}, userId={}",
                    applicationId,
                    dependentId,
                    principal.userId(),
                    exception);
            throw new BusinessException(
                    "DEPENDENT_UPDATE_FAILED",
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unable to update dependent at this time.",
                    exception);
        }
    }

    /**
     * Deletes a dependent from the specified policy application.
     *
     * @param principal the authenticated principal requesting the operation
     * @param applicationId the policy application identifier
     * @param dependentId the dependent identifier
*/
    public void deleteDependent(
            JwtPrincipal principal,
            UUID applicationId,
            UUID dependentId) {
        try {
            requireApplicationAccess(principal, applicationId);
            dependentRepository.delete(requireDependent(applicationId, dependentId));
        } catch (ApplicationNotFoundException | DependentNotFoundException | BusinessException exception) {
            throw exception;
        } catch (RuntimeException exception) {
            log.error(
                    "Failed to delete dependent for applicationId={}, dependentId={}, userId={}",
                    applicationId,
                    dependentId,
                    principal.userId(),
                    exception);
            throw new BusinessException(
                    "DEPENDENT_DELETE_FAILED",
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unable to delete dependent at this time.",
                    exception);
        }
    }

    /**
     * Validates whether the principal may access the specified policy application.
     *
     * @param principal the authenticated principal requesting the operation
     * @param applicationId the policy application identifier
     * @return the application entity when access is valid
     * @throws ApplicationNotFoundException when the customer does not own the application
*/
    private PolicyApplication requireApplicationAccess(
            JwtPrincipal principal,
            UUID applicationId) {
        PolicyApplication application =
               applicationService.getApplicationEntityForInternalUse(applicationId);

        if (principal.role() == JwtRole.CUSTOMER && !application.isOwnedBy(principal.userId())) {
            throw new ApplicationNotFoundException(applicationId);
        }

        return application;
    }

    /**
     * Resolves a dependent that belongs to the specified application.
     *
     * @param applicationId the policy application identifier
     * @param dependentId the dependent identifier
     * @return the matching dependent entity
     * @throws DependentNotFoundException when the dependent does not belong to the application
*/
    private Dependent requireDependent(UUID applicationId, UUID dependentId) {
        return dependentRepository.findById(dependentId)
               .filter(dependent -> dependent.getPolicyApplication().getId().equals(applicationId))
               .orElseThrow(() -> new DependentNotFoundException(dependentId));
    }

    /**
     * Converts a dependent entity into a response model.
     *
     * @param dependent the dependent entity to convert
     * @return the API response representation
*/
    private DependentResponse toResponse(Dependent dependent) {
        return new DependentResponse(
               dependent.getId(),
               dependent.getPolicyApplication().getId(),
               dependent.getFullName(),
               dependent.getRelationship(),
               dependent.getDateOfBirth(),
               dependent.getGender(),
               dependent.getCreatedAt());
    }
}
package com.insurewise.policy.dto.request;

import com.insurewise.policy.entity.ApplicationStatus;
import jakarta.validation.constraints.NotNull;
/**
 * Represents the record Policy Application Decision Request.
*/

public record PolicyApplicationDecisionRequest(
        @NotNull
        ApplicationStatus status
) {
}

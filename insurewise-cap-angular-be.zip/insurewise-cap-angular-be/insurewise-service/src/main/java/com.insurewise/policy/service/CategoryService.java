package com.insurewise.policy.service;

import com.insurewise.common.exception.BusinessException;
import com.insurewise.policy.dto.request.CategoryCreateRequest;
import com.insurewise.policy.dto.request.CategoryUpdateRequest;
import com.insurewise.policy.dto.response.CategoryResponse;
import com.insurewise.policy.entity.Category;
import com.insurewise.policy.exception.CategoryNotFoundException;
import com.insurewise.policy.repository.CategoryRepository;
import java.util.List;
import java.util.UUID;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class CategoryService {
    private static final Logger log = LoggerFactory.getLogger(CategoryService.class);
    private final CategoryRepository repository;

    /**
     * Creates the category management service using the repository responsible for policy category data.
     *
     * @param repository category persistence repository
     */
    public CategoryService(CategoryRepository repository) {
        this.repository = repository;
    }

    /**
     * Creates a new policy category using the supplied category metadata.
     *
     * @param request category creation payload
     * @return saved category response
     */
    public CategoryResponse createCategory(CategoryCreateRequest request) {
        try {
            Category category = repository.save(new Category(
                    request.name(),
                    request.description(),
                    request.status()));
            return toResponse(category);
        } catch (BusinessException exception) {
            throw exception;
        } catch (RuntimeException exception) {
            log.error("Failed to create category name={}", request.name(), exception);
            throw new BusinessException(
                    "CATEGORY_CREATE_FAILED",
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unable to create category at this time.",
                    exception);
        }
    }

    /**
     * Returns all categories currently persisted in the system.
     *
     * @return list of category response objects
     */
    @Transactional(readOnly = true)
    public List<CategoryResponse> listCategories() {
        try {
            return repository.findAll()
                    .stream()
                    .map(this::toResponse)
                    .toList();
        } catch (BusinessException exception) {
            throw exception;
        } catch (RuntimeException exception) {
            log.error("Failed to load categories", exception);
            throw new BusinessException(
                    "CATEGORY_LIST_FAILED",
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unable to load categories at this time.",
                    exception);
        }
    }

    /**
     * Updates the details of an existing category while preserving the category id.
     *
     * @param id category id to update
     * @param request updated category fields
     * @return updated category response
     */
    public CategoryResponse updateCategory(UUID id, CategoryUpdateRequest request) {
        try {
            Category category = find(id);
            category.update(request.name(), request.description(), request.status());
            return toResponse(category);
        } catch (CategoryNotFoundException | BusinessException exception) {
            throw exception;
        } catch (RuntimeException exception) {
            log.error("Failed to update category id={}, name={}", id, request.name(), exception);
            throw new BusinessException(
                    "CATEGORY_UPDATE_FAILED",
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unable to update category at this time.",
                    exception);
        }
    }

    /**
     * Deletes a category after ensuring it exists in the repository.
     *
     * @param id category id to delete
     */
    public void deleteCategory(UUID id) {
        try {
            repository.delete(find(id));
        } catch (CategoryNotFoundException | BusinessException exception) {
            throw exception;
        } catch (RuntimeException exception) {
            log.error("Failed to delete category id={}", id, exception);
            throw new BusinessException(
                    "CATEGORY_DELETE_FAILED",
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unable to delete category at this time.",
                    exception);
        }
    }

    /**
     * Retrieves a category entity by id or throws a not-found exception when absent.
     *
     * @param id category primary key
     * @return category entity
     */
    public Category find(UUID id) {
        return repository.findById(id)
                .orElseThrow(() -> new CategoryNotFoundException(id));
    }

    /**
     * Converts a category entity to the API response model used by the frontend.
     *
     * @param category persisted category entity
     * @return category response DTO
     */
    private CategoryResponse toResponse(Category category) {
        return new CategoryResponse(
                category.getId(),
                category.getName(),
                category.getDescription(),
                category.getStatus());
    }
}

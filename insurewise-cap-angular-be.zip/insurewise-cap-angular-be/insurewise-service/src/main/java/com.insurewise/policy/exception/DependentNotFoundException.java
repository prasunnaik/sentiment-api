package com.insurewise.policy.exception;

import com.insurewise.common.exception.ResourceNotFoundException;
import java.util.UUID;

public class DependentNotFoundException extends ResourceNotFoundException {
/**
 * Dependent Not Found Exception.
 * @param id the value supplied for the id.
 * @return the result of the operation.
*/

    public DependentNotFoundException(UUID id) {
        super("DEPENDENT_NOT_FOUND", "Dependent not found: " + id);
    }
}
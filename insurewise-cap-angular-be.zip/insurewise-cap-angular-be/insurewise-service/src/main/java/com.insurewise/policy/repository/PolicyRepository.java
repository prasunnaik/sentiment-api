package com.insurewise.policy.repository;

import com.insurewise.policy.entity.Policy;
import com.insurewise.policy.entity.PolicyStatus;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.UUID;

public interface PolicyRepository extends JpaRepository<Policy, UUID> {
    List<Policy> findAllByStatusOrderByCreatedAtDesc(PolicyStatus status);
    long countByStatus(
            PolicyStatus status);
}



package com.insurewise.policy.dto.response;

import com.insurewise.policy.entity.PolicyStatus;
import java.math.BigDecimal;
import java.util.UUID;
/**
 * Represents the record Policy Response.
*/

public record PolicyResponse(
        UUID id,
        String name,
        UUID categoryId,
        String categoryName,
        BigDecimal coverageAmount,
        BigDecimal premiumAmount,
        String durationLabel,
        PolicyStatus status
) {
}

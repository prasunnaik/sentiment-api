package com.insurewise.policy.repository;

import com.insurewise.policy.entity.ApplicationDocument;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.UUID;

public interface ApplicationDocumentRepository
        extends JpaRepository<ApplicationDocument, UUID> {

    List<ApplicationDocument> findByPolicyApplicationIdOrderByUploadedAtDesc(
            UUID policyApplicationId);

    java.util.Optional<ApplicationDocument> findByIdAndPolicyApplicationId(
            UUID id,
            UUID policyApplicationId);
}
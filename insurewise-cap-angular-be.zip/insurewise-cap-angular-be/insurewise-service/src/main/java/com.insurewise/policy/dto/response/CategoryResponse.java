package com.insurewise.policy.dto.response;

import com.insurewise.policy.entity.CategoryStatus;

import java.util.UUID;
/**
 * Represents the record Category Response.
*/

public record CategoryResponse(
        UUID id,
        String name,
        String description,
        CategoryStatus status
) {
}

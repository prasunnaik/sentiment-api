package com.insurewise.policy.service;

import com.insurewise.common.dto.PresignedUrlResponse;
import com.insurewise.common.exception.FileStorageException;
import com.insurewise.common.exception.InvalidFileException;
import com.insurewise.common.security.JwtPrincipal;
import com.insurewise.common.security.JwtRole;
import com.insurewise.common.service.S3StorageService;
import com.insurewise.policy.dto.response.ApplicationDocumentContentResponse;
import com.insurewise.policy.dto.response.ApplicationDocumentResponse;
import com.insurewise.policy.entity.ApplicationDocument;
import com.insurewise.policy.entity.PolicyApplication;
import com.insurewise.policy.exception.ApplicationDocumentNotFoundException;
import com.insurewise.policy.exception.ApplicationNotFoundException;
import com.insurewise.policy.repository.ApplicationDocumentRepository;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

/**
 * Provides operations for uploading and managing application documents.
 *
*/
@Service
@Transactional
public class ApplicationDocumentService {
    private static final Logger log = LoggerFactory.getLogger(ApplicationDocumentService.class);
    private static final long MAX_FILE_SIZE = 10L * 1024 * 1024;
    private static final Set<String> ALLOWED_EXTENSIONS = Set.of("pdf");
    private static final Set<String> ALLOWED_CONTENT_TYPES = Set.of("application/pdf");
    private static final String S3_FOLDER = "application-documents";

    private final ApplicationDocumentRepository documentRepository;
    private final PolicyApplicationService applicationService;
    private final S3StorageService storageService;

    /**
     * Creates a document service with the required repositories and storage dependencies.
     *
     * @param documentRepository the repository used to persist document records
     * @param applicationService the application service used to validate access
     * @param storageService the S3-backed storage service used to persist files
*/
    public ApplicationDocumentService(
            ApplicationDocumentRepository documentRepository,
            PolicyApplicationService applicationService,
            S3StorageService storageService) {
        this.documentRepository = documentRepository;
        this.applicationService = applicationService;
        this.storageService = storageService;
    }

    /**
     * Uploads and stores a PDF document for the specified application.
     *
     * @param principal the authenticated principal requesting the operation
     * @param applicationId the policy application identifier
     * @param file the file to upload
     * @return the stored document response
*/
    public ApplicationDocumentResponse uploadApplicationDocument(
            JwtPrincipal principal,
            UUID applicationId,
            MultipartFile file) {
        PolicyApplication application = requireApplicationAccess(principal, applicationId);

        validateFile(file);

        String originalFilename = originalFilename(file);
        String objectKey = buildObjectKey(applicationId, originalFilename);
        String contentType = file.getContentType();

        storageService.upload(file, S3_FOLDER, principal.userId(), objectKey);

        try {
            ApplicationDocument document = documentRepository.saveAndFlush(
                    new ApplicationDocument(
                            application,
                            originalFilename,
                            contentType,
                            objectKey,
                            file.getSize(),
                            principal.userId()));

            return toResponse(document);
        } catch (RuntimeException exception) {
            deleteQuietly(objectKey);
            throw exception;
        }
    }

    /**
     * Lists all documents for the specified policy application.
     *
     * @param principal the authenticated principal requesting the operation
     * @param applicationId the policy application identifier
     * @return the documents associated with the application
*/
    @Transactional(readOnly = true)
    public List<ApplicationDocumentResponse> listApplicationDocuments(
            JwtPrincipal principal,
            UUID applicationId) {
        requireApplicationAccess(principal, applicationId);

        return documentRepository
                .findByPolicyApplicationIdOrderByUploadedAtDesc(applicationId)
                .stream()
                .map(this::toResponse)
                .toList();
    }

    @Transactional(readOnly = true)
    public ApplicationDocumentContentResponse getDocument(
            JwtPrincipal principal,
            UUID applicationId,
            UUID documentId) {
        requireApplicationAccess(principal, applicationId);
        ApplicationDocument document = requireDocument(applicationId, documentId);
        PresignedUrlResponse download = storageService.getPresignedDownloadUrl(document.getS3Key());
        return new ApplicationDocumentContentResponse(
                document.getId(),
                document.getPolicyApplication().getId(),
                document.getFileName(),
                document.getS3Key(),
                document.getContentType(),
                document.getFileSize(),
                download,
                document.getUploadedBy(),
                document.getUploadedAt());
    }

    @Transactional(readOnly = true)
    public PresignedUrlResponse previewDocument(
            JwtPrincipal principal,
            UUID applicationId,
            UUID documentId) {
        requireApplicationAccess(principal, applicationId);
        ApplicationDocument document = requireDocument(applicationId, documentId);
        return storageService.getPresignedPreviewUrl(document.getS3Key());
    }

    @Transactional(readOnly = true)
    public PresignedUrlResponse downloadDocument(
            JwtPrincipal principal,
            UUID applicationId,
            UUID documentId) {
        requireApplicationAccess(principal, applicationId);
        ApplicationDocument document = requireDocument(applicationId, documentId);
        return storageService.getPresignedDownloadUrl(document.getS3Key());
    }

    /**
     * Deletes an uploaded document from the specified policy application.
     *
     * @param principal the authenticated principal requesting the operation
     * @param applicationId the policy application identifier
     * @param documentId the document identifier to delete
*/
    public void deleteDocument(
            JwtPrincipal principal,
            UUID applicationId,
            UUID documentId) {
        requireApplicationAccess(principal, applicationId);

        ApplicationDocument document = requireDocument(applicationId, documentId);

        storageService.delete(document.getS3Key());
        documentRepository.delete(document);
    }

    /**
     * Validates document constraints such as size and extension.
     *
     * @param file the uploaded document
     * @throws InvalidFileException when the file is empty, too large, or not a PDF
*/
    private void validateFile(MultipartFile file) {
        if (file == null) {
            throw new InvalidFileException("A document file is required");
        }
        if (file.isEmpty()) {
            throw new InvalidFileException("A non-empty document is required");
        }
        if (file.getSize() > MAX_FILE_SIZE) {
            throw new InvalidFileException("Document size cannot exceed 10MB");
        }
        String fileName = file.getOriginalFilename();
        int extensionSeparator = fileName == null ? -1 : fileName.lastIndexOf('.');
        String extension = extensionSeparator < 0
               ? ""
               : fileName.substring(extensionSeparator + 1).toLowerCase(Locale.ROOT);
        if (!ALLOWED_EXTENSIONS.contains(extension)) {
            throw new InvalidFileException("Document must be a .pdf file");
        }
        String contentType = file.getContentType();
        if (contentType == null || !ALLOWED_CONTENT_TYPES.contains(contentType.toLowerCase(Locale.ROOT))) {
            throw new InvalidFileException("Document content type must be application/pdf");
        }
    }

    /**
     * Confirms that the principal can access the specified application.
     *
     * @param principal the authenticated principal requesting the operation
     * @param applicationId the policy application identifier
     * @return the application entity when access is valid
     * @throws ApplicationNotFoundException when the customer does not own the application
*/
    private PolicyApplication requireApplicationAccess(
            JwtPrincipal principal,
            UUID applicationId) {
        try {
            PolicyApplication application =
                    applicationService.getApplicationEntityForInternalUse(applicationId);

            if (principal.role() == JwtRole.CUSTOMER && !application.isOwnedBy(principal.userId())) {
                throw new ApplicationNotFoundException(applicationId);
            }

            return application;
        } catch (ApplicationNotFoundException exception) {
            if (principal.role() == JwtRole.CUSTOMER) {
                throw new org.springframework.security.access.AccessDeniedException(
                        "Customer is not authorized to access this application",
                        exception);
            }
            throw exception;
        }
    }

    private ApplicationDocument requireDocument(
            UUID applicationId,
            UUID documentId) {
        return documentRepository.findByIdAndPolicyApplicationId(documentId, applicationId)
                .orElseThrow(() -> new ApplicationDocumentNotFoundException(documentId));
    }

    /**
     * Converts a stored document entity into an API response model.
     *
     * @param document the document entity to convert
     * @return the API response representation
*/
    private ApplicationDocumentResponse toResponse(ApplicationDocument document) {
        return toResponse(document, true);
    }

    private ApplicationDocumentResponse toResponse(
            ApplicationDocument document,
            boolean includeDownloadUrl) {
        PresignedUrlResponse download = includeDownloadUrl
                ? storageService.getPresignedDownloadUrl(document.getS3Key())
                : null;

        return new ApplicationDocumentResponse(
                document.getId(),
                document.getPolicyApplication().getId(),
                document.getFileName(),
                document.getS3Key(),
                document.getContentType(),
                document.getFileSize(),
                download,
                document.getUploadedBy(),
                document.getUploadedAt());
    }

    private String originalFilename(MultipartFile file) {
        return file.getOriginalFilename() == null || file.getOriginalFilename().isBlank()
                ? "unnamed-file.pdf"
                : file.getOriginalFilename();
    }

    private String buildObjectKey(UUID applicationId, String fileName) {
        String extension = ".pdf";
        int extensionSeparator = fileName.lastIndexOf('.');
        if (extensionSeparator >= 0) {
            extension = fileName.substring(extensionSeparator).toLowerCase(Locale.ROOT);
        }
        return "insurewise/" + S3_FOLDER + "/" + applicationId + "/" + UUID.randomUUID() + extension;
    }

    private void deleteQuietly(String objectKey) {
        try {
            storageService.delete(objectKey);
        } catch (FileStorageException exception) {
            log.error("Failed to clean up uploaded S3 object after database failure. key={}", objectKey, exception);
        }
    }
}
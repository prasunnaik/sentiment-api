package com.insurewise.policy.entity;
/**
 * Represents the enum Application Status.
*/

public enum ApplicationStatus {
    PENDING,
    APPROVED,
    REJECTED
}

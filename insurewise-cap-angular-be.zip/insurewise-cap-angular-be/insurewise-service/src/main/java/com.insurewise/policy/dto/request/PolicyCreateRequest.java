package com.insurewise.policy.dto.request;

import com.insurewise.policy.entity.PolicyStatus;
import jakarta.validation.constraints.*;
import java.math.BigDecimal;
import java.util.UUID;
/**
 * Represents the record Policy Create Request.
*/

public record PolicyCreateRequest(
        @NotBlank
        @Size(max = 120)
        String name,

        @NotNull
        UUID categoryId,

        @NotNull
        @DecimalMin("0.01")
        BigDecimal coverageAmount,

        @NotNull
        @DecimalMin("0.01")
        BigDecimal premiumAmount,

        @NotBlank
        @Size(max = 40)
        String durationLabel,

        @NotNull
        PolicyStatus status
) {
}

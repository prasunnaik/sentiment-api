package com.insurewise.common.service;

import com.insurewise.framework.s3.service.S3FileStorageService;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class S3StorageConfig {

    @Bean
    @ConditionalOnMissingBean(S3StorageService.class)
    @ConditionalOnProperty(prefix = "insurewise.storage", name = "enabled", havingValue = "true")
    S3StorageService activeS3StorageService(S3FileStorageService delegate) {
        return new ActiveS3StorageService(delegate);
    }

    @Bean
    @ConditionalOnMissingBean(S3StorageService.class)
    @ConditionalOnProperty(prefix = "insurewise.storage", name = "enabled", havingValue = "false", matchIfMissing = true)
    S3StorageService disabledS3StorageService() {
        return new DisabledS3StorageService();
    }
}

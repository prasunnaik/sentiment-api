package com.insurewise.common.exception;

import org.springframework.http.HttpStatus;

public class FileStorageException extends BusinessException {
    private final String bucket;
    private final String region;
    private final String objectKey;
/**
 * File Storage Exception.
 * @param message the value supplied for the message.
 * @return the result of the operation.
*/

    public FileStorageException(String message) {
        super("FILE_STORAGE_UNAVAILABLE", HttpStatus.INTERNAL_SERVER_ERROR, message);
        this.bucket = null;
        this.region = null;
        this.objectKey = null;
    }
/**
 * File Storage Exception.
 * @param message the value supplied for the message.
 * @param cause the value supplied for the cause.
 * @return the result of the operation.
*/

    public FileStorageException(
            String message,
            Throwable cause) {
        super("FILE_STORAGE_UNAVAILABLE", HttpStatus.INTERNAL_SERVER_ERROR, message, cause);
        this.bucket = null;
        this.region = null;
        this.objectKey = null;
    }

    public String getBucket() {
        return bucket;
    }

    public String getRegion() {
        return region;
    }

    public String getObjectKey() {
        return objectKey;
    }
}

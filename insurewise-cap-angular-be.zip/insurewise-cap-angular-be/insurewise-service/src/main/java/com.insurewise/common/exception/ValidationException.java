package com.insurewise.common.exception;

import org.springframework.http.HttpStatus;

public class ValidationException extends ApiException {
    public ValidationException(String errorCode, String message) {
        super(errorCode, HttpStatus.BAD_REQUEST, message);
    }

    public ValidationException(String errorCode, String message, Throwable cause) {
        super(errorCode, HttpStatus.BAD_REQUEST, message, cause);
    }
}

package com.insurewise.common.security;

import java.util.UUID;
/**
 * Represents the record Jwt Principal.
*/

public record JwtPrincipal(UUID userId, JwtRole role, String email) {}

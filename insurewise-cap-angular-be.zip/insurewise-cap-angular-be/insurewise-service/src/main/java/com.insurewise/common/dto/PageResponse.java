package com.insurewise.common.dto;

import java.util.List;

public record PageResponse<T>(
        List<T> data,
        PaginationMetadata pagination
) {
}

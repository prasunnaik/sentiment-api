package com.insurewise.common.service;

import com.insurewise.common.dto.PresignedUrlResponse;
import java.util.UUID;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

/**
 * Disables storage operations when the application is configured not to persist
 * files to S3.
 */
@Service
@ConditionalOnProperty(
        prefix = "insurewise.storage",
        name = "enabled",
        havingValue = "false",
        matchIfMissing = true)
public class DisabledS3StorageService implements S3StorageService {

    /**
     * Uploads a file to storage when the feature is disabled.
     *
     * @param file the file content to upload
     * @param folder the logical folder or path inside the bucket
     * @param ownerId the owner identifier associated with the file
     * @return this method never returns normally when storage is disabled
     */
    @Override
    public String upload(
            MultipartFile file,
            String folder,
            UUID ownerId) {
        throw disabledException();
    }

    /**
     * Uploads a file using a caller-provided object key when storage is disabled.
     *
     * @param file the file content to upload
     * @param folder the logical folder or path inside the bucket
     * @param ownerId the owner identifier associated with the file
     * @param objectKey the explicit object key to persist in storage
     * @return this method never returns normally when storage is disabled
     */
    @Override
    public String upload(
            MultipartFile file,
            String folder,
            UUID ownerId,
            String objectKey) {
        throw disabledException();
    }

    /**
     * Uploads generated content when storage is disabled.
     *
     * @param content the raw bytes to save
     * @param fileName the destination file name
     * @param contentType the MIME type of the file
     * @param folder the logical folder or path inside the bucket
     * @param ownerId the owner identifier associated with the file
     * @return this method never returns normally when storage is disabled
     */
    @Override
    public String uploadGenerated(
            byte[] content,
            String fileName,
            String contentType,
            String folder,
            UUID ownerId) {
        throw disabledException();
    }

    /**
     * Builds a presigned download URL when storage is disabled.
     *
     * @param s3Key the storage key of the object to download
     * @return this method never returns normally when storage is disabled
     */
    @Override
    public PresignedUrlResponse getPresignedDownloadUrl(String s3Key) {
        throw disabledException();
    }

    /**
     * Builds a presigned preview URL when storage is disabled.
     *
     * @param s3Key the storage key of the object to preview
     * @return this method never returns normally when storage is disabled
     */
    @Override
    public PresignedUrlResponse getPresignedPreviewUrl(String s3Key) {
        throw disabledException();
    }

    /**
     * Removes an object from storage when the feature is disabled.
     *
     * @param s3Key the storage key of the object to delete
     */
    @Override
    public void delete(String s3Key) {
        throw disabledException();
    }

    /**
     * Downloads an object from storage when the feature is disabled.
     *
     * @param s3Key the storage key of the object to download
     * @return this method never returns normally when storage is disabled
     */
    @Override
    public byte[] downloadObject(String s3Key) {
        throw disabledException();
    }

    /**
     * Creates the storage-disabled exception raised by this service.
     *
     * @return an illegal state exception explaining that the storage feature is disabled
     */
    private IllegalStateException disabledException() {
        return new IllegalStateException(
                "S3 storage is disabled. Set S3_ENABLED=true.");
    }
}

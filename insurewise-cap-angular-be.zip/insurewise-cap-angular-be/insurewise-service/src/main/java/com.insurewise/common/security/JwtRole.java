package com.insurewise.common.security;
/**
 * Represents the enum Jwt Role.
*/

public enum JwtRole {
    CUSTOMER,
    STAFF
}

package com.insurewise.common.exception;

import org.springframework.http.HttpStatus;

public class BusinessException extends ApiException {
    public BusinessException(String errorCode, HttpStatus status, String message) {
        super(errorCode, status, message);
    }

    public BusinessException(String errorCode, HttpStatus status, String message, Throwable cause) {
        super(errorCode, status, message, cause);
    }
}

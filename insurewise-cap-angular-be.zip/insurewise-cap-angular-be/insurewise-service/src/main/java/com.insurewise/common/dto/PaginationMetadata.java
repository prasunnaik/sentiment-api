package com.insurewise.common.dto;
/**
 * Represents the record Pagination Metadata.
*/

public record PaginationMetadata(
        int limit,
        int offset,
        long total,
        boolean hasMore
) {
}

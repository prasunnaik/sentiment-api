package com.insurewise.common.service;

import com.insurewise.common.dto.PresignedUrlResponse;
import com.insurewise.framework.s3.service.S3FileStorageService;
import com.insurewise.framework.s3.service.S3PresignedUrl;
import java.util.UUID;
import org.springframework.web.multipart.MultipartFile;

/**
 * Delegates storage operations to the configured S3 file storage implementation when
 * the application storage feature is enabled.
 */
public class ActiveS3StorageService implements S3StorageService {

    /** The underlying S3 file storage service used to perform storage operations. */
    private final S3FileStorageService delegate;

    /**
     * Creates the active S3 storage service with the underlying delegate.
     *
     * @param delegate the S3 storage implementation to delegate to
     */
    public ActiveS3StorageService(S3FileStorageService delegate) {
        this.delegate = delegate;
    }

    /**
     * Uploads a file to the configured storage bucket.
     *
     * @param file the file content to upload
     * @param folder the logical folder or path inside the bucket
     * @param ownerId the owner identifier associated with the file
     * @return the storage key assigned to the uploaded file
     */
    @Override
    public String upload(MultipartFile file, String folder, UUID ownerId) {
        return delegate.upload(file, folder, ownerId);
    }

    /**
     * Uploads a file using a caller-provided object key.
     *
     * @param file the file content to upload
     * @param folder the logical folder or path inside the bucket
     * @param ownerId the owner identifier associated with the file
     * @param objectKey the explicit object key to persist in storage
     * @return the storage key assigned to the uploaded file
     */
    @Override
    public String upload(MultipartFile file, String folder, UUID ownerId, String objectKey) {
        return delegate.upload(file, folder, ownerId, objectKey);
    }

    /**
     * Uploads generated content as a file object.
     *
     * @param content the raw bytes to save
     * @param fileName the destination file name
     * @param contentType the MIME type of the file
     * @param folder the logical folder or path inside the bucket
     * @param ownerId the owner identifier associated with the file
     * @return the storage key assigned to the uploaded file
     */
    @Override
    public String uploadGenerated(byte[] content, String fileName, String contentType, String folder, UUID ownerId) {
        return delegate.uploadGenerated(content, fileName, contentType, folder, ownerId);
    }

    /**
     * Builds a presigned download URL for the supplied object key.
     *
     * @param s3Key the storage key of the object to download
     * @return the presigned URL response containing the URL and expiry timestamp
     */
    @Override
    public PresignedUrlResponse getPresignedDownloadUrl(String s3Key) {
        S3PresignedUrl presignedUrl = delegate.getPresignedDownloadUrl(s3Key);
        return new PresignedUrlResponse(presignedUrl.url(), presignedUrl.expiresAt());
    }

    /**
     * Builds a presigned preview URL for the supplied object key.
     *
     * @param s3Key the storage key of the object to preview
     * @return the presigned URL response containing the URL and expiry timestamp
     */
    @Override
    public PresignedUrlResponse getPresignedPreviewUrl(String s3Key) {
        S3PresignedUrl presignedUrl = delegate.getPresignedPreviewUrl(s3Key);
        return new PresignedUrlResponse(presignedUrl.url(), presignedUrl.expiresAt());
    }

    /**
     * Removes an object from storage by key.
     *
     * @param s3Key the storage key of the object to delete
     */
    @Override
    public void delete(String s3Key) {
        delegate.delete(s3Key);
    }

    /**
     * Downloads the raw bytes of an object from storage by key.
     *
     * @param s3Key the storage key of the object to download
     * @return the raw bytes of the object
     */
    @Override
    public byte[] downloadObject(String s3Key) {
        return delegate.downloadObject(s3Key);
    }
}

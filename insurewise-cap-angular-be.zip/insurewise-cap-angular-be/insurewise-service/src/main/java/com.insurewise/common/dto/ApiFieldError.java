package com.insurewise.common.dto;

public record ApiFieldError(
        String field,
        String message
) {
}

package com.insurewise.common.exception;

import org.springframework.http.HttpStatus;

public class IdempotencyKeyConflictException
        extends BusinessException {
/**
 * Idempotency Key Conflict Exception.
 * @param message the value supplied for the message.
 * @return the result of the operation.
*/

    public IdempotencyKeyConflictException(String message) {
        super("IDEMPOTENCY_KEY_CONFLICT", HttpStatus.CONFLICT, message);
    }

    public IdempotencyKeyConflictException(String message, Throwable cause) {
        super("IDEMPOTENCY_KEY_CONFLICT", HttpStatus.CONFLICT, message, cause);
    }
}
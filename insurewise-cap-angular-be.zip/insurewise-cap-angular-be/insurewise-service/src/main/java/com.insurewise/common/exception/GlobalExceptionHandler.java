package com.insurewise.common.exception;

import com.insurewise.common.dto.ApiErrorResponse;
import com.insurewise.common.dto.ApiFieldError;
import jakarta.servlet.http.HttpServletRequest;
import java.time.Instant;
import java.util.Arrays;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.servlet.resource.NoResourceFoundException;

@RestControllerAdvice
public class GlobalExceptionHandler {
    private static final Logger log = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    @ExceptionHandler(ApiException.class)
    ResponseEntity<ApiErrorResponse> handleApiException(
            ApiException exception,
            HttpServletRequest request) {
        logException(exception, request, exception.getStatus());
        return build(
                exception.getStatus(),
                exception.getErrorCode(),
                exception.getMessage(),
                request,
                null);
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    ResponseEntity<ApiErrorResponse> handleValidation(
            MethodArgumentNotValidException exception,
            HttpServletRequest request) {
        List<ApiFieldError> fieldErrors = exception.getBindingResult()
                .getFieldErrors()
                .stream()
                .map(this::toFieldError)
                .toList();
        logException(exception, request, HttpStatus.BAD_REQUEST);
        return build(
                HttpStatus.BAD_REQUEST,
                "VALIDATION_ERROR",
                "Request validation failed.",
                request,
                fieldErrors);
    }

    @ExceptionHandler(HttpMessageNotReadableException.class)
    ResponseEntity<ApiErrorResponse> handleBadJson(
            HttpMessageNotReadableException exception,
            HttpServletRequest request) {
        String message = "Invalid request payload.";
        Throwable rootCause = getRootCause(exception);
        if (rootCause.getMessage() != null && rootCause.getMessage().contains("ApplicationStatus")) {
            message = "status: must be one of [PENDING, APPROVED, REJECTED]";
        }
        logException(exception, request, HttpStatus.BAD_REQUEST);
        return build(
                HttpStatus.BAD_REQUEST,
                "MALFORMED_REQUEST",
                message,
                request,
                null);
    }

    @ExceptionHandler(MethodArgumentTypeMismatchException.class)
    ResponseEntity<ApiErrorResponse> handleTypeMismatch(
            MethodArgumentTypeMismatchException exception,
            HttpServletRequest request) {
        String message = exception.getName() + ": invalid value";
        if (exception.getRequiredType() != null && exception.getRequiredType().isEnum()) {
            Object[] constants = exception.getRequiredType().getEnumConstants();
            message = exception.getName() + ": must be one of " + Arrays.toString(constants);
        }
        logException(exception, request, HttpStatus.BAD_REQUEST);
        return build(
                HttpStatus.BAD_REQUEST,
                "TYPE_MISMATCH",
                message,
                request,
                null);
    }

    @ExceptionHandler(AccessDeniedException.class)
    ResponseEntity<ApiErrorResponse> handleAccessDenied(
            AccessDeniedException exception,
            HttpServletRequest request) {
        logException(exception, request, HttpStatus.FORBIDDEN);
        return build(
                HttpStatus.FORBIDDEN,
                "ACCESS_DENIED",
                "Access is denied.",
                request,
                null);
    }

    @ExceptionHandler(NoResourceFoundException.class)
    ResponseEntity<ApiErrorResponse> handleMissingEndpoint(
            NoResourceFoundException exception,
            HttpServletRequest request) {
        logException(exception, request, HttpStatus.NOT_FOUND);
        return build(
                HttpStatus.NOT_FOUND,
                "ENDPOINT_NOT_FOUND",
                "Endpoint not found.",
                request,
                null);
    }

    @ExceptionHandler(Exception.class)
    ResponseEntity<ApiErrorResponse> handleGenericException(
            Exception exception,
            HttpServletRequest request) {
        logException(exception, request, HttpStatus.INTERNAL_SERVER_ERROR);
        return build(
                HttpStatus.INTERNAL_SERVER_ERROR,
                "INTERNAL_SERVER_ERROR",
                "An unexpected server error occurred.",
                request,
                null);
    }

    private ResponseEntity<ApiErrorResponse> build(
            HttpStatus status,
            String errorCode,
            String message,
            HttpServletRequest request,
            List<ApiFieldError> fieldErrors) {
        ApiErrorResponse response = new ApiErrorResponse(
                Instant.now(),
                status.value(),
                errorCode,
                message,
                request.getRequestURI(),
                correlationId(request),
                fieldErrors == null || fieldErrors.isEmpty() ? null : fieldErrors);
        return ResponseEntity.status(status).body(response);
    }

    private void logException(Exception exception, HttpServletRequest request, HttpStatus status) {
        Throwable rootCause = getRootCause(exception);
        log.error(
                "Request failed. correlationId={}, method={}, path={}, status={}, exceptionType={}, rootCauseType={}, rootCauseMessage={}",
                correlationId(request),
                request.getMethod(),
                request.getRequestURI(),
                status.value(),
                exception.getClass().getName(),
                rootCause.getClass().getName(),
                rootCause.getMessage(),
                exception);
    }

    private Throwable getRootCause(Throwable throwable) {
        Throwable current = throwable;
        while (current.getCause() != null && current.getCause() != current) {
            current = current.getCause();
        }
        return current;
    }

    private String correlationId(HttpServletRequest request) {
        Object correlationId = request.getAttribute(CorrelationIdFilter.CORRELATION_ID_KEY);
        if (correlationId instanceof String value && !value.isBlank()) {
            return value;
        }
        String mdcValue = MDC.get(CorrelationIdFilter.CORRELATION_ID_KEY);
        return mdcValue == null || mdcValue.isBlank() ? "unknown" : mdcValue;
    }

    private ApiFieldError toFieldError(FieldError error) {
        return new ApiFieldError(error.getField(), error.getDefaultMessage());
    }
}

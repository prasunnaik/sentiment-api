package com.insurewise.common.dto;

import java.time.Instant;
import java.time.LocalDateTime;
import java.util.List;
/**
 * Represents the record Api Error Response.
*/

public record ApiErrorResponse(
        Instant timestamp,
        int status,
        String errorCode,
        String message,
        String path,
        String correlationId,
        List<ApiFieldError> fieldErrors
) {
}

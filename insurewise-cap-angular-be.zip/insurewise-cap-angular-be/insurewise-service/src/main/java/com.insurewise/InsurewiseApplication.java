package com.insurewise;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
/**
 * Represents the class Insurewise Application.
*/

@SpringBootApplication
public class InsurewiseApplication {
/**
 * Main.
 * @param args the value supplied for the args.
*/

    public static void main(String[] args) {
        SpringApplication.run(InsurewiseApplication.class, args);
    }
}

package com.insurewise.auth.controller;

import com.insurewise.auth.entity.Customer;
import com.insurewise.auth.repository.CustomerRepository;
import com.insurewise.common.dto.PresignedUrlResponse;
import com.insurewise.common.security.JwtRole;
import com.insurewise.common.security.JwtService;
import com.insurewise.common.service.S3StorageService;
import java.time.Instant;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@Transactional
@TestPropertySource(properties = {
        "spring.datasource.url=jdbc:h2:mem:profile-controller-test;MODE=PostgreSQL;DB_CLOSE_DELAY=-1;DATABASE_TO_UPPER=false",
        "spring.datasource.driver-class-name=org.h2.Driver",
        "spring.datasource.username=sa",
        "spring.datasource.password=",
        "spring.jpa.hibernate.ddl-auto=create-drop",
        "spring.jpa.properties.hibernate.dialect=org.hibernate.dialect.H2Dialect",
        "spring.flyway.enabled=false",
        "insurewise.storage.enabled=false"
})
class ProfileControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private JwtService jwtService;

    @Autowired
    private CustomerRepository customerRepository;

    @MockBean
    private S3StorageService storageService;

    private Customer customerWithPicture;
    private Customer customerWithoutPicture;
    private String customerToken;
    private String noPictureToken;
    private String invalidCustomerToken;
    private String staffToken;

    @BeforeEach
    void setUp() {
        customerRepository.deleteAll();

        customerWithPicture = customerRepository.save(new Customer(
                "Customer One",
                "9999999999",
                "customer1@example.com",
                "encoded-password"));
        customerWithPicture.setProfilePictureS3Key("profile-pictures/customer-one.png");
        customerRepository.save(customerWithPicture);

        customerWithoutPicture = customerRepository.save(new Customer(
                "Customer Two",
                "8888888888",
                "customer2@example.com",
                "encoded-password"));

        when(storageService.getPresignedDownloadUrl(anyString()))
                .thenReturn(new PresignedUrlResponse(
                        "https://example.com/profile-picture.png",
                        Instant.parse("2030-01-01T00:00:00Z")));

        customerToken = bearerToken(customerWithPicture.getId(), JwtRole.CUSTOMER);
        noPictureToken = bearerToken(customerWithoutPicture.getId(), JwtRole.CUSTOMER);
        invalidCustomerToken = bearerToken(UUID.randomUUID(), JwtRole.CUSTOMER);
        staffToken = bearerToken(UUID.randomUUID(), JwtRole.STAFF);
    }

    @Test
    void returnsExistingProfilePictureForAuthenticatedCustomer() throws Exception {
        mockMvc.perform(get("/auth/profile-picture")
                        .header("Authorization", customerToken))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.customer_id").value(customerWithPicture.getId().toString()))
                .andExpect(jsonPath("$.s3_key").value("profile-pictures/customer-one.png"))
                .andExpect(jsonPath("$.download.url").value("https://example.com/profile-picture.png"));
    }

    @Test
    void returnsNoContentWhenProfilePictureIsMissing() throws Exception {
        mockMvc.perform(get("/auth/profile-picture")
                        .header("Authorization", noPictureToken))
                .andExpect(status().isNoContent());
    }

    @Test
    void returnsServerErrorForInvalidCustomer() throws Exception {
        mockMvc.perform(get("/auth/profile-picture")
                        .header("Authorization", invalidCustomerToken))
                .andExpect(status().isInternalServerError());
    }

    @Test
    void rejectsUnauthorizedAccess() throws Exception {
        mockMvc.perform(get("/auth/profile-picture"))
                .andExpect(status().isForbidden());
    }

    @Test
    void rejectsStaffAccessToCustomerProfilePictureEndpoint() throws Exception {
        mockMvc.perform(get("/auth/profile-picture")
                        .header("Authorization", staffToken))
                .andExpect(status().isForbidden());
    }

    private String bearerToken(UUID userId, JwtRole role) {
        return "Bearer " + jwtService.generate(
                userId,
                role.name().toLowerCase() + "@example.com",
                role);
    }
}

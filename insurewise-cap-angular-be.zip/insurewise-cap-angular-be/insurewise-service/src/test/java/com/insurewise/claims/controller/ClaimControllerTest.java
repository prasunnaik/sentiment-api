package com.insurewise.claims.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.insurewise.claims.dto.request.ClaimCreateRequest;
import com.insurewise.claims.dto.response.ClaimDocumentResponse;
import com.insurewise.claims.dto.response.ClaimResponse;
import com.insurewise.claims.dto.response.ClaimSubmissionResponse;
import com.insurewise.claims.entity.ClaimStatus;
import com.insurewise.claims.entity.IncidentType;
import com.insurewise.claims.service.ClaimDocumentService;
import com.insurewise.claims.service.ClaimService;
import com.insurewise.common.dto.PresignedUrlResponse;
import com.insurewise.common.security.JwtRole;
import com.insurewise.common.security.JwtService;
import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;
import java.util.List;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.multipart;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@Transactional
@org.springframework.test.context.TestPropertySource(properties = {
        "insurewise.storage.enabled=false"
})
class ClaimControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private JwtService jwtService;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private ClaimService claimService;

    @MockBean
    private ClaimDocumentService claimDocumentService;

    @Test
    void customerCanCreateClaimWithDocument() throws Exception {
        UUID customerId = UUID.randomUUID();
        ClaimCreateRequest request = new ClaimCreateRequest(
                "idem-1",
                UUID.randomUUID(),
                IncidentType.ACCIDENT,
                LocalDate.now(),
                new BigDecimal("100.00"),
                "Description",
                null);
        MockMultipartFile claimPart = new MockMultipartFile(
                "claim",
                "",
                MediaType.APPLICATION_JSON_VALUE,
                objectMapper.writeValueAsBytes(request));
        MockMultipartFile filePart = new MockMultipartFile(
                "file",
                "claim.pdf",
                MediaType.APPLICATION_PDF_VALUE,
                "payload".getBytes());

        when(claimService.fileClaimWithDocument(eq(customerId), any(), any()))
                .thenReturn(new ClaimSubmissionResponse(
                        new ClaimResponse(
                                UUID.randomUUID(),
                                "CLM-1000",
                                customerId,
                                request.policyApplicationId(),
                                "Health Policy",
                                request.incidentType(),
                                request.incidentDate(),
                                request.amount(),
                                request.description(),
                                null,
                                ClaimStatus.PENDING,
                                null,
                                null,
                                null,
                                java.time.LocalDateTime.now()),
                        new ClaimDocumentResponse(
                                UUID.randomUUID(),
                                UUID.randomUUID(),
                                "claim.pdf",
                                "application/pdf",
                                new PresignedUrlResponse("https://example.com", Instant.now()),
                                new PresignedUrlResponse("https://example.com", Instant.now()),
                                customerId,
                                "Test Customer",
                                java.time.LocalDateTime.now())));

        mockMvc.perform(multipart("/api/claims/with-document")
                        .file(claimPart)
                        .file(filePart)
                        .header("Authorization", bearerToken(customerId, JwtRole.CUSTOMER)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.claim.claimCode").value("CLM-1000"))
                .andExpect(jsonPath("$.document.fileName").value("claim.pdf"));
    }

    @Test
    void customerCanListOwnedClaimDocuments() throws Exception {
        UUID claimId = UUID.randomUUID();
        UUID customerId = UUID.randomUUID();
        when(claimDocumentService.listClaimDocuments(customerId, claimId))
                .thenReturn(List.of(new ClaimDocumentResponse(
                        UUID.randomUUID(),
                        claimId,
                        "owned-file.pdf",
                        "application/pdf",
                        new PresignedUrlResponse("https://example.com/owned", Instant.now()),
                        new PresignedUrlResponse("https://example.com/owned", Instant.now()),
                        customerId,
                        "Test Customer",
                        java.time.LocalDateTime.now())));

        mockMvc.perform(get("/api/claims/{id}/documents", claimId)
                        .header("Authorization", bearerToken(customerId, JwtRole.CUSTOMER)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].fileName").value("owned-file.pdf"));
    }

    @Test
    void staffCanListClaimDocuments() throws Exception {
        UUID claimId = UUID.randomUUID();
        UUID staffId = UUID.randomUUID();
        when(claimDocumentService.listClaimDocumentsForStaff(claimId))
                .thenReturn(List.of(new ClaimDocumentResponse(
                        UUID.randomUUID(),
                        claimId,
                        "file.pdf",
                        "application/pdf",
                        new PresignedUrlResponse("https://example.com/download", Instant.now()),
                        new PresignedUrlResponse("https://example.com/download", Instant.now()),
                        staffId,
                        "Test Customer",
                        java.time.LocalDateTime.now())));

        mockMvc.perform(get("/api/claims/{id}/documents", claimId)
                        .header("Authorization", bearerToken(staffId, JwtRole.STAFF)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].download.url").value("https://example.com/download"));
    }

    @Test
    void staffCanPreviewClaimDocument() throws Exception {
        UUID claimId = UUID.randomUUID();
        UUID documentId = UUID.randomUUID();
        UUID staffId = UUID.randomUUID();
        when(claimDocumentService.previewDocumentForStaff(claimId, documentId))
                .thenReturn(new PresignedUrlResponse("https://example.com/preview", Instant.now()));

        mockMvc.perform(get("/api/claims/{id}/documents/{documentId}/preview", claimId, documentId)
                        .header("Authorization", bearerToken(staffId, JwtRole.STAFF)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.url").value("https://example.com/preview"));
    }

    @Test
    void staffCanDownloadClaimDocument() throws Exception {
        UUID claimId = UUID.randomUUID();
        UUID documentId = UUID.randomUUID();
        UUID staffId = UUID.randomUUID();
        when(claimDocumentService.downloadDocumentForStaff(claimId, documentId))
                .thenReturn(new PresignedUrlResponse("https://example.com/download-file", Instant.now()));

        mockMvc.perform(get("/api/claims/{id}/documents/{documentId}/download", claimId, documentId)
                        .header("Authorization", bearerToken(staffId, JwtRole.STAFF)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.url").value("https://example.com/download-file"));
    }

    @Test
    void staffJwtRoleIsStaff() {
        UUID staffId = UUID.randomUUID();
        String token = jwtService.generate(staffId, "staff@example.com", JwtRole.STAFF);

        assertEquals(JwtRole.STAFF, jwtService.parse(token).role());
    }

    private String bearerToken(UUID userId, JwtRole role) {
        return "Bearer " + jwtService.generate(userId, role.name().toLowerCase() + "@example.com", role);
    }
}

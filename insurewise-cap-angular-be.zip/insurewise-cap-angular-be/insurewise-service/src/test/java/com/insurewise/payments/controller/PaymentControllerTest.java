package com.insurewise.payments.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.insurewise.common.dto.PresignedUrlResponse;
import com.insurewise.common.security.JwtRole;
import com.insurewise.common.security.JwtService;
import com.insurewise.payments.dto.request.PaymentCreateRequest;
import com.insurewise.payments.entity.Payment;
import com.insurewise.payments.entity.PaymentMethod;
import com.insurewise.payments.entity.PaymentStatus;
import com.insurewise.payments.entity.PaymentDocument;
import com.insurewise.payments.repository.PaymentDocumentRepository;
import com.insurewise.payments.repository.PaymentRepository;
import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@Transactional
@TestPropertySource(properties = {
        "spring.datasource.url=jdbc:h2:mem:payment-controller-test;MODE=PostgreSQL;DB_CLOSE_DELAY=-1;DATABASE_TO_UPPER=false",
        "spring.datasource.driver-class-name=org.h2.Driver",
        "spring.datasource.username=sa",
        "spring.datasource.password=",
        "spring.jpa.hibernate.ddl-auto=create-drop",
        "spring.jpa.properties.hibernate.dialect=org.hibernate.dialect.H2Dialect",
        "spring.flyway.enabled=false",
        "insurewise.storage.enabled=false"
})
class PaymentControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private JwtService jwtService;

    @Autowired
    private PaymentRepository paymentRepository;

    @Autowired
    private PaymentDocumentRepository paymentDocumentRepository;

    @MockBean
    private com.insurewise.payments.client.PaymentPolicyApplicationLookupClient applicationClient;

    @MockBean
    private com.insurewise.common.service.S3StorageService storageService;

    private UUID customerId;
    private UUID paymentId;
    private String customerToken;
    private String otherCustomerToken;
    private String staffToken;

    @BeforeEach
    void setUp() {
        paymentDocumentRepository.deleteAll();
        paymentRepository.deleteAll();

        customerId = UUID.randomUUID();

        Payment payment = new Payment(
                "idem-1",
                customerId,
                UUID.randomUUID(),
                "Gold Plan",
                new BigDecimal("1200.00"),
                PaymentMethod.CREDIT_CARD);
        payment.markSuccess("TXN-123456");
        paymentId = paymentRepository.saveAndFlush(payment).getId();

        paymentDocumentRepository.saveAndFlush(new PaymentDocument(
                paymentRepository.getReferenceById(paymentId),
                "receipt-TXN-123456.txt",
                "text/plain",
                "payment-documents/receipt-TXN-123456.txt",
                customerId,
                true));

        when(storageService.getPresignedDownloadUrl(anyString()))
                .thenReturn(new PresignedUrlResponse(
                        "https://example.com/download/receipt.txt",
                        Instant.parse("2030-01-01T00:00:00Z")));
        when(storageService.getPresignedPreviewUrl(anyString()))
                .thenReturn(new PresignedUrlResponse(
                        "https://example.com/preview/receipt.txt",
                        Instant.parse("2030-01-01T00:00:00Z")));
        when(storageService.uploadGenerated(any(), anyString(), anyString(), anyString(), any()))
                .thenReturn("payment-documents/generated-receipt.txt");

        when(applicationClient.getActiveApplicationForCustomer(any(), any()))
                .thenAnswer(invocation -> new com.insurewise.payments.client.PaymentPolicyApplicationSnapshot(
                        invocation.getArgument(0),
                        invocation.getArgument(1),
                        "Gold Plan",
                        true));

        customerToken = bearerToken(customerId, JwtRole.CUSTOMER);
        otherCustomerToken = bearerToken(UUID.randomUUID(), JwtRole.CUSTOMER);
        staffToken = bearerToken(UUID.randomUUID(), JwtRole.STAFF);
    }

    @Test
    void customerCanListOwnPaymentDocuments() throws Exception {
        mockMvc.perform(get("/api/payments/{paymentId}/documents", paymentId)
                        .header("Authorization", customerToken))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].paymentId").value(paymentId.toString()))
                .andExpect(jsonPath("$[0].preview.url").value("https://example.com/preview/receipt.txt"))
                .andExpect(jsonPath("$[0].download.url").value("https://example.com/download/receipt.txt"))
                .andExpect(jsonPath("$[0].systemGenerated").value(true));
    }

    @Test
    void staffCanListPaymentDocuments() throws Exception {
        mockMvc.perform(get("/api/payments/{paymentId}/documents", paymentId)
                        .header("Authorization", staffToken))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].paymentId").value(paymentId.toString()))
                .andExpect(jsonPath("$[0].preview.url").value("https://example.com/preview/receipt.txt"))
                .andExpect(jsonPath("$[0].systemGenerated").value(true));
    }

    @Test
    void staffCanPreviewPaymentDocument() throws Exception {
        UUID documentId = paymentDocumentRepository.findAll().get(0).getId();

        mockMvc.perform(get("/api/payments/{paymentId}/documents/{documentId}/preview", paymentId, documentId)
                        .header("Authorization", staffToken))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.url").value("https://example.com/preview/receipt.txt"));
    }

    @Test
    void staffCanDownloadPaymentDocument() throws Exception {
        UUID documentId = paymentDocumentRepository.findAll().get(0).getId();

        mockMvc.perform(get("/api/payments/{paymentId}/documents/{documentId}/download", paymentId, documentId)
                        .header("Authorization", staffToken))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.url").value("https://example.com/download/receipt.txt"));
    }

    @Test
    void rejectsUnauthorizedPaymentDocumentAccess() throws Exception {
        mockMvc.perform(get("/api/payments/{paymentId}/documents", paymentId))
                .andExpect(status().isForbidden());
    }

    @Test
    void hidesMissingOrForeignPaymentFromCustomer() throws Exception {
        mockMvc.perform(get("/api/payments/{paymentId}/documents", paymentId)
                        .header("Authorization", otherCustomerToken))
                .andExpect(status().isNotFound());
    }

    @Test
    void returnsNotFoundForMissingPayment() throws Exception {
        mockMvc.perform(get("/api/payments/{paymentId}/documents", UUID.randomUUID())
                        .header("Authorization", staffToken))
                .andExpect(status().isNotFound());
    }

    @Test
    void missingPaymentReturnsStructuredErrorResponse() throws Exception {
        mockMvc.perform(get("/api/payments/{paymentId}/documents", UUID.randomUUID())
                        .header("Authorization", staffToken))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.timestamp").exists())
                .andExpect(jsonPath("$.status").value(404))
                .andExpect(jsonPath("$.errorCode").value("PAYMENT_NOT_FOUND"))
                .andExpect(jsonPath("$.message").exists())
                .andExpect(jsonPath("$.path").exists())
                .andExpect(jsonPath("$.correlationId").isNotEmpty());
    }

    @Test
    void successfulPaymentCreationCreatesSystemReceipt() throws Exception {
        UUID applicationId = UUID.randomUUID();
        String response = mockMvc.perform(post("/api/payments")
                        .header("Authorization", customerToken)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(
                                new PaymentCreateRequest(
                                        "idem-new",
                                        applicationId,
                                        new BigDecimal("1500.00"),
                                        PaymentMethod.CREDIT_CARD))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value(PaymentStatus.SUCCESS.name()))
                .andReturn()
                .getResponse()
                .getContentAsString();

        UUID createdPaymentId = UUID.fromString(
                objectMapper.readTree(response).path("id").asText());

        mockMvc.perform(get("/api/payments/{paymentId}/documents", createdPaymentId)
                        .header("Authorization", customerToken))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].systemGenerated").value(true))
                .andExpect(jsonPath("$[0].download.url").value("https://example.com/download/receipt.txt"));
    }

    private String bearerToken(UUID userId, JwtRole role) {
        return "Bearer " + jwtService.generate(
                userId,
                role.name().toLowerCase() + "@example.com",
                role);
    }
}

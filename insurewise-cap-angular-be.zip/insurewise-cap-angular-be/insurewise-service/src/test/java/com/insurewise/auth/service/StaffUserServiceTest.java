package com.insurewise.auth.service;

import com.insurewise.auth.dto.response.StaffProfileResponse;
import com.insurewise.auth.entity.StaffUser;
import com.insurewise.auth.exception.StaffUserNotFoundException;
import com.insurewise.auth.repository.CustomerRepository;
import com.insurewise.auth.repository.StaffUserRepository;
import com.insurewise.common.service.S3StorageService;
import java.util.Optional;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.crypto.password.PasswordEncoder;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class StaffUserServiceTest {

    @Mock
    private StaffUserRepository staffUserRepository;

    @Mock
    private CustomerRepository customerRepository;

    @Mock
    private PasswordEncoder passwordEncoder;

    @Mock
    private S3StorageService storageService;

    private StaffUserService service;

    @BeforeEach
    void setUp() {
        service = new StaffUserService(
                staffUserRepository,
                customerRepository,
                passwordEncoder,
                storageService);
    }

    @Test
    void returnsCurrentStaffProfile() {
        UUID staffUserId = UUID.randomUUID();
        StaffUser staffUser = new StaffUser(
                "Local Staff Admin",
                "staff.local@insurewise.com",
                "InsureWise HQ",
                "encoded-password");

        setId(staffUser, staffUserId);
        when(staffUserRepository.findById(staffUserId)).thenReturn(Optional.of(staffUser));

        StaffProfileResponse response = service.getCurrentStaffProfile(staffUserId);

        assertThat(response.id()).isEqualTo(staffUserId);
        assertThat(response.fullName()).isEqualTo("Local Staff Admin");
        assertThat(response.email()).isEqualTo("staff.local@insurewise.com");
        assertThat(response.address()).isEqualTo("InsureWise HQ");
    }

    @Test
    void throwsWhenCurrentStaffProfileDoesNotExist() {
        UUID staffUserId = UUID.randomUUID();
        when(staffUserRepository.findById(staffUserId)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> service.getCurrentStaffProfile(staffUserId))
                .isInstanceOf(StaffUserNotFoundException.class);
    }

    private void setId(StaffUser staffUser, UUID id) {
        try {
            java.lang.reflect.Field field = StaffUser.class.getDeclaredField("id");
            field.setAccessible(true);
            field.set(staffUser, id);
        } catch (ReflectiveOperationException exception) {
            throw new IllegalStateException(exception);
        }
    }
}

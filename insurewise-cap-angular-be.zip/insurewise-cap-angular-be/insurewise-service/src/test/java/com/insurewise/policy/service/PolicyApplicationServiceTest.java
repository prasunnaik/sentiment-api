package com.insurewise.policy.service;

import com.insurewise.policy.dto.request.PolicyApplicationCreateRequest;
import com.insurewise.policy.entity.ApplicationStatus;
import com.insurewise.policy.entity.Category;
import com.insurewise.policy.entity.CategoryStatus;
import com.insurewise.policy.entity.CoverageType;
import com.insurewise.policy.entity.NomineeRelationship;
import com.insurewise.policy.entity.Policy;
import com.insurewise.policy.entity.PolicyStatus;
import com.insurewise.policy.exception.ApplicationStateException;
import com.insurewise.policy.repository.CategoryRepository;
import com.insurewise.policy.repository.PolicyApplicationRepository;
import com.insurewise.policy.repository.PolicyRepository;
import jakarta.persistence.EntityManager;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.transaction.annotation.Transactional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

@SpringBootTest
@Transactional
@TestPropertySource(properties = {
        "spring.datasource.url=jdbc:h2:mem:policy-application-service-test;MODE=PostgreSQL;DB_CLOSE_DELAY=-1;DATABASE_TO_UPPER=false",
        "spring.datasource.driver-class-name=org.h2.Driver",
        "spring.datasource.username=sa",
        "spring.datasource.password=",
        "spring.jpa.hibernate.ddl-auto=create-drop",
        "spring.jpa.properties.hibernate.dialect=org.hibernate.dialect.H2Dialect",
        "spring.flyway.enabled=false"
})
class PolicyApplicationServiceTest {

    @Autowired
    private PolicyApplicationService service;

    @Autowired
    private PolicyApplicationRepository applicationRepository;

    @Autowired
    private PolicyRepository policyRepository;

    @Autowired
    private CategoryRepository categoryRepository;

    @Autowired
    private EntityManager entityManager;

    private Policy policy;

    @BeforeEach
    void setUp() {
        entityManager.createNativeQuery("CREATE SEQUENCE IF NOT EXISTS application_code_seq START WITH 1000 INCREMENT BY 1")
                .executeUpdate();
        applicationRepository.deleteAll();
        policyRepository.deleteAll();
        categoryRepository.deleteAll();

        Category category = categoryRepository.save(new Category(
                "Health",
                "Health coverage",
                CategoryStatus.ACTIVE));
        policy = policyRepository.save(new Policy(
                "Silver Plan",
                category,
                new BigDecimal("500000.00"),
                new BigDecimal("1200.00"),
                "1 Year",
                PolicyStatus.ACTIVE));
    }

    @Test
    void createApplicationGeneratesSequentialApplicationCodes() {
        UUID firstCustomer = UUID.randomUUID();
        UUID secondCustomer = UUID.randomUUID();

        String firstCode = service.createApplication(firstCustomer, validRequest()).applicationCode();
        String secondCode = service.createApplication(secondCustomer, validRequest()).applicationCode();

        assertEquals("APP-1000", firstCode);
        assertEquals("APP-1001", secondCode);
    }

    @Test
    void createApplicationRejectsBlankNomineeNameWhenRelationshipProvided() {
        PolicyApplicationCreateRequest request = new PolicyApplicationCreateRequest(
                policy.getId(),
                CoverageType.SINGLE,
                LocalDate.now().minusYears(30),
                "123 Main Street",
                LocalDate.now().plusDays(10),
                "   ",
                NomineeRelationship.SPOUSE);

        ApplicationStateException exception = assertThrows(
                ApplicationStateException.class,
                () -> service.createApplication(UUID.randomUUID(), request));

        assertEquals("nomineeName is required when nomineeRelationship is provided", exception.getMessage());
    }

    @Test
    void createApplicationStoresPendingStatus() {
        ApplicationStatus status = service.createApplication(UUID.randomUUID(), validRequest()).status();
        assertEquals(ApplicationStatus.PENDING, status);
    }

    private PolicyApplicationCreateRequest validRequest() {
        return new PolicyApplicationCreateRequest(
                policy.getId(),
                CoverageType.SINGLE,
                LocalDate.now().minusYears(30),
                "123 Main Street",
                LocalDate.now().plusDays(10),
                "Nominee Name",
                NomineeRelationship.SPOUSE);
    }
}

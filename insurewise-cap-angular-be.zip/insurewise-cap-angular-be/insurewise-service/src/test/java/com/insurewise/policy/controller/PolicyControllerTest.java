package com.insurewise.policy.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.insurewise.common.security.JwtRole;
import com.insurewise.common.security.JwtService;
import com.insurewise.policy.dto.request.PolicyCreateRequest;
import com.insurewise.policy.dto.request.PolicyUpdateRequest;
import com.insurewise.policy.entity.CategoryStatus;
import com.insurewise.policy.entity.PolicyStatus;
import com.insurewise.policy.repository.CategoryRepository;
import com.insurewise.policy.repository.PolicyRepository;
import java.math.BigDecimal;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.web.servlet.MockMvc;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@TestPropertySource(properties = {
        "spring.datasource.url=jdbc:h2:mem:policy-controller-test;MODE=PostgreSQL;DB_CLOSE_DELAY=-1;DATABASE_TO_UPPER=false",
        "spring.datasource.driver-class-name=org.h2.Driver",
        "spring.datasource.username=sa",
        "spring.datasource.password=",
        "spring.jpa.hibernate.ddl-auto=create-drop",
        "spring.flyway.enabled=false"
})
class PolicyControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private JwtService jwtService;

    @Autowired
    private CategoryRepository categoryRepository;

    @Autowired
    private PolicyRepository policyRepository;

    private String staffToken;
    private String customerToken;
    private UUID categoryId;

    @BeforeEach
    void setUp() {
        policyRepository.deleteAll();
        categoryRepository.deleteAll();

        var category = categoryRepository.save(
                new com.insurewise.policy.entity.Category(
                        "Health",
                        "Health coverage",
                        CategoryStatus.ACTIVE));
        categoryId = category.getId();
        staffToken = bearerToken(JwtRole.STAFF);
        customerToken = bearerToken(JwtRole.CUSTOMER);
    }

    @Test
    void createPolicyReturnsCreated() throws Exception {
        PolicyCreateRequest request = new PolicyCreateRequest(
                "Silver Plan",
                categoryId,
                new BigDecimal("500000.00"),
                new BigDecimal("1200.00"),
                "1 Year",
                PolicyStatus.ACTIVE);

        mockMvc.perform(post("/api/policies")
                        .header("Authorization", staffToken)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.name").value("Silver Plan"))
                .andExpect(jsonPath("$.categoryId").value(categoryId.toString()))
                .andExpect(jsonPath("$.status").value("ACTIVE"));

        assertThat(policyRepository.findAll()).hasSize(1);
    }

    @Test
    void updatePolicyReturnsUpdatedPolicy() throws Exception {
        var category = categoryRepository.findById(categoryId).orElseThrow();
        var policy = policyRepository.save(new com.insurewise.policy.entity.Policy(
                "Silver Plan",
                category,
                new BigDecimal("500000.00"),
                new BigDecimal("1200.00"),
                "1 Year",
                PolicyStatus.ACTIVE));

        PolicyUpdateRequest request = new PolicyUpdateRequest(
                "Gold Plan",
                categoryId,
                new BigDecimal("750000.00"),
                new BigDecimal("1600.00"),
                "2 Years",
                PolicyStatus.INACTIVE);

        mockMvc.perform(put("/api/policies/{id}", policy.getId())
                        .header("Authorization", staffToken)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("Gold Plan"))
                .andExpect(jsonPath("$.status").value("INACTIVE"));
    }

    @Test
    void deletePolicyReturnsNoContent() throws Exception {
        var category = categoryRepository.findById(categoryId).orElseThrow();
        var policy = policyRepository.save(new com.insurewise.policy.entity.Policy(
                "Silver Plan",
                category,
                new BigDecimal("500000.00"),
                new BigDecimal("1200.00"),
                "1 Year",
                PolicyStatus.ACTIVE));

        mockMvc.perform(delete("/api/policies/{id}", policy.getId())
                        .header("Authorization", staffToken))
                .andExpect(status().isNoContent());

        assertThat(policyRepository.findById(policy.getId())).isEmpty();
    }

    @Test
    void createPolicyRejectsInvalidRequest() throws Exception {
        PolicyCreateRequest request = new PolicyCreateRequest(
                "",
                null,
                new BigDecimal("0.00"),
                new BigDecimal("0.00"),
                "",
                null);

        mockMvc.perform(post("/api/policies")
                        .header("Authorization", staffToken)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest());
    }

    @Test
    void staffEndpointsRequireAuthorization() throws Exception {
        PolicyCreateRequest request = new PolicyCreateRequest(
                "Silver Plan",
                categoryId,
                new BigDecimal("500000.00"),
                new BigDecimal("1200.00"),
                "1 Year",
                PolicyStatus.ACTIVE);

        mockMvc.perform(post("/api/policies")
                        .header("Authorization", customerToken)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isForbidden());
    }

    @Test
    void updatePolicyReturnsNotFoundForMissingId() throws Exception {
        PolicyUpdateRequest request = new PolicyUpdateRequest(
                "Gold Plan",
                categoryId,
                new BigDecimal("750000.00"),
                new BigDecimal("1600.00"),
                "2 Years",
                PolicyStatus.ACTIVE);

        mockMvc.perform(put("/api/policies/{id}", UUID.randomUUID())
                        .header("Authorization", staffToken)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isNotFound());
    }

    private String bearerToken(JwtRole role) {
        return "Bearer " + jwtService.generate(
                UUID.randomUUID(),
                role.name().toLowerCase() + "@example.com",
                role);
    }
}

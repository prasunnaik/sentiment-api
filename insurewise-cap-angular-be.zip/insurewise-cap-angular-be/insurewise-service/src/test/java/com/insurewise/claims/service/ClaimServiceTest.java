package com.insurewise.claims.service;

import com.insurewise.claims.client.ClaimApplicantLookupClient;
import com.insurewise.claims.client.PolicyApplicationLookupClient;
import com.insurewise.claims.client.PolicyApplicationSnapshot;
import com.insurewise.auth.entity.StaffUser;
import com.insurewise.auth.repository.StaffUserRepository;
import com.insurewise.auth.repository.CustomerRepository;
import com.insurewise.claims.dto.request.ClaimCreateRequest;
import com.insurewise.claims.entity.Claim;
import com.insurewise.claims.entity.ClaimDocument;
import com.insurewise.claims.entity.IncidentType;
import com.insurewise.claims.repository.ClaimDocumentRepository;
import com.insurewise.claims.repository.ClaimRepository;
import com.insurewise.common.dto.PresignedUrlResponse;
import com.insurewise.common.exception.BusinessException;
import com.insurewise.common.exception.InvalidFileException;
import com.insurewise.common.service.S3StorageService;
import com.insurewise.policy.entity.ApplicationStatus;
import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;
import java.util.Optional;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.Mockito;
import org.springframework.mock.web.MockMultipartFile;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ClaimServiceTest {

    @Mock
    private ClaimRepository claimRepository;

    @Mock
    private PolicyApplicationLookupClient applicationClient;

        @Mock
        private StaffUserRepository staffUserRepository;

    @Mock
    private ClaimDocumentRepository claimDocumentRepository;

    @Mock
    private S3StorageService storageService;

    @Mock
    private ClaimApplicantLookupClient applicantLookupClient;

    @Mock
    private CustomerRepository customerRepository;

    @InjectMocks
    private ClaimService service;

    private UUID customerId;
    private ClaimCreateRequest request;
    private PolicyApplicationSnapshot applicationSnapshot;

    @BeforeEach
    void setUp() {
        customerId = UUID.randomUUID();
        request = new ClaimCreateRequest(
                "idem-1",
                UUID.randomUUID(),
                IncidentType.ACCIDENT,
                LocalDate.now(),
                new BigDecimal("100.00"),
                "Claim description",
                null);
        applicationSnapshot = new PolicyApplicationSnapshot(
                UUID.randomUUID(),
                customerId,
                "Policy",
                ApplicationStatus.APPROVED,
                true);
        Mockito.lenient().when(applicationClient.getActiveApplicationForCustomer(eq(request.policyApplicationId()), eq(customerId)))
                .thenReturn(applicationSnapshot);
        Mockito.lenient().when(claimRepository.nextClaimCodeSequence()).thenReturn(1000L);
        Mockito.lenient().when(claimRepository.save(any())).thenAnswer(invocation -> invocation.getArgument(0));
    }

    @Test
    void createsClaimAndDocumentAtomically() {
        MockMultipartFile file = new MockMultipartFile("file", "claim.pdf", "application/pdf", "payload".getBytes());
        Claim persistedClaim = new Claim(
                "CLM-1000",
                request.idempotencyKey(),
                customerId,
                applicationSnapshot.applicationId(),
                applicationSnapshot.policyName(),
                request.incidentType(),
                request.incidentDate(),
                request.amount(),
                request.description(),
                request.documentRef());
        when(claimRepository.findByIdempotencyKey(request.idempotencyKey())).thenReturn(Optional.empty());
        when(claimDocumentRepository.saveAndFlush(any())).thenAnswer(invocation -> invocation.getArgument(0));
        when(claimRepository.findById(any())).thenReturn(Optional.of(persistedClaim));
        when(storageService.upload(eq(file), eq("claim-documents"), eq(customerId))).thenReturn("s3/object-key");
        when(storageService.getPresignedDownloadUrl("s3/object-key"))
                .thenReturn(new PresignedUrlResponse("https://example.com/download", Instant.parse("2030-01-01T00:00:00Z")));

        service.fileClaimWithDocument(customerId, request, file);

        verify(storageService).upload(eq(file), eq("claim-documents"), eq(customerId));
    }

    @Test
    void deletesUploadedObjectWhenDocumentPersistenceFails() {
        MockMultipartFile file = new MockMultipartFile("file", "claim.pdf", "application/pdf", "payload".getBytes());
        when(claimRepository.findByIdempotencyKey(request.idempotencyKey())).thenReturn(Optional.empty());
        when(claimRepository.findById(any())).thenAnswer(invocation -> Optional.of(new Claim(
                "CLM-1000",
                request.idempotencyKey(),
                customerId,
                applicationSnapshot.applicationId(),
                applicationSnapshot.policyName(),
                request.incidentType(),
                request.incidentDate(),
                request.amount(),
                request.description(),
                request.documentRef())));
        when(storageService.upload(eq(file), eq("claim-documents"), eq(customerId))).thenReturn("s3/object-key");
        when(claimDocumentRepository.saveAndFlush(any())).thenThrow(new IllegalStateException("db failure"));

        assertThatThrownBy(() -> service.fileClaimWithDocument(customerId, request, file))
                .isInstanceOf(BusinessException.class)
                .hasCauseInstanceOf(IllegalStateException.class);

        verify(storageService).delete("s3/object-key");
    }

    @Test
    void rejectsMissingFile() {
        assertThatThrownBy(() -> service.fileClaimWithDocument(customerId, request, null))
                .isInstanceOf(InvalidFileException.class);
        verify(storageService, never()).upload(any(), any(), any());
    }

        @Test
        void resolvesProcessedStaffNameForCustomerResponse() {
                UUID staffId = UUID.fromString("a0000000-0000-0000-0000-000000000001");
                Claim claim = new Claim(
                                "CLM-1006",
                                request.idempotencyKey(),
                                customerId,
                                applicationSnapshot.applicationId(),
                                applicationSnapshot.policyName(),
                                request.incidentType(),
                                request.incidentDate(),
                                request.amount(),
                                request.description(),
                                request.documentRef());
                claim.approve(staffId);
                StaffUser staffUser = new StaffUser(
                                "System Admin",
                                "admin@insurewise.com",
                                "InsureWise HQ",
                                "password-hash");

                when(claimRepository.findById(claim.getId())).thenReturn(Optional.of(claim));
                when(staffUserRepository.findById(staffId)).thenReturn(Optional.of(staffUser));

                var response = service.getClaimForCustomer(customerId, claim.getId());

                assertThat(response.processedBy()).isEqualTo(staffId);
                assertThat(response.processedByName()).isEqualTo("System Admin");
        }
}

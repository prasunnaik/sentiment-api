package com.insurewise.policy.controller;

import com.insurewise.common.dto.PresignedUrlResponse;
import com.insurewise.common.security.JwtRole;
import com.insurewise.common.security.JwtService;
import com.insurewise.common.service.S3StorageService;
import com.insurewise.policy.entity.Category;
import com.insurewise.policy.entity.CategoryStatus;
import com.insurewise.policy.entity.CoverageType;
import com.insurewise.policy.entity.NomineeRelationship;
import com.insurewise.policy.entity.Policy;
import com.insurewise.policy.entity.PolicyApplication;
import com.insurewise.policy.entity.PolicyStatus;
import com.insurewise.policy.repository.ApplicationDocumentRepository;
import com.insurewise.policy.repository.CategoryRepository;
import com.insurewise.policy.repository.PolicyApplicationRepository;
import com.insurewise.policy.repository.PolicyRepository;
import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;
import java.util.UUID;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.multipart;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@Transactional
@TestPropertySource(properties = {
        "spring.datasource.url=jdbc:h2:mem:application-document-controller-test;MODE=PostgreSQL;DB_CLOSE_DELAY=-1;DATABASE_TO_UPPER=false",
        "spring.datasource.driver-class-name=org.h2.Driver",
        "spring.datasource.username=sa",
        "spring.datasource.password=",
        "spring.jpa.hibernate.ddl-auto=create-drop",
        "spring.jpa.properties.hibernate.dialect=org.hibernate.dialect.H2Dialect",
        "spring.flyway.enabled=false",
        "insurewise.storage.enabled=false"
})
class ApplicationDocumentControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private JwtService jwtService;

    @Autowired
    private CategoryRepository categoryRepository;

    @Autowired
    private PolicyRepository policyRepository;

    @Autowired
    private PolicyApplicationRepository applicationRepository;

    @Autowired
    private ApplicationDocumentRepository documentRepository;

    @MockBean
    private S3StorageService storageService;

    private UUID customerId;
    private String customerToken;
    private String otherCustomerToken;
    private String staffToken;
    private PolicyApplication application;

    @BeforeEach
    void setUp() {
        documentRepository.deleteAll();
        applicationRepository.deleteAll();
        policyRepository.deleteAll();
        categoryRepository.deleteAll();

        when(storageService.upload(any(), eq("application-documents"), any(), any()))
                .thenReturn("insurewise/application-documents/test-application/test.pdf");
        when(storageService.getPresignedDownloadUrl(any()))
                .thenReturn(new PresignedUrlResponse(
                        "https://example.com/documents/test.pdf",
                        Instant.parse("2030-01-01T00:00:00Z")));
        when(storageService.getPresignedPreviewUrl(any()))
                .thenReturn(new PresignedUrlResponse(
                        "https://example.com/documents/test-preview.pdf",
                        Instant.parse("2030-01-01T00:00:00Z")));

        Category category = categoryRepository.save(new Category(
                "Health",
                "Health coverage",
                CategoryStatus.ACTIVE));
        Policy policy = policyRepository.save(new Policy(
                "Silver Plan",
                category,
                new BigDecimal("500000.00"),
                new BigDecimal("1200.00"),
                "1 Year",
                PolicyStatus.ACTIVE));

        customerId = UUID.randomUUID();
        application = applicationRepository.save(new PolicyApplication(
                "APP-2000",
                customerId,
                policy,
                CoverageType.SINGLE,
                LocalDate.now().minusYears(30),
                "123 Main Street",
                LocalDate.now().plusDays(10),
                "Nominee Name",
                NomineeRelationship.SPOUSE));

        customerToken = bearerToken(customerId, JwtRole.CUSTOMER);
        otherCustomerToken = bearerToken(UUID.randomUUID(), JwtRole.CUSTOMER);
        staffToken = bearerToken(UUID.randomUUID(), JwtRole.STAFF);
    }

    @Test
    void staffCanListApplicationDocuments() throws Exception {
        UUID documentId = uploadDocument();

        mockMvc.perform(get("/api/applications/{id}/documents", application.getId())
                        .header("Authorization", staffToken))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(documentId.toString()))
                .andExpect(jsonPath("$[0].fileName").value("policy.pdf"))
                .andExpect(jsonPath("$[0].objectKey", Matchers.containsString(application.getId().toString())))
                .andExpect(jsonPath("$[0].fileSize").value(9))
                .andExpect(jsonPath("$[0].download.url").value("https://example.com/documents/test.pdf"));
    }

    @Test
    void staffCanViewSpecificDocument() throws Exception {
        UUID documentId = uploadDocument();

        mockMvc.perform(get("/api/applications/{id}/documents/{documentId}", application.getId(), documentId)
                        .header("Authorization", staffToken))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(documentId.toString()))
                .andExpect(jsonPath("$.applicationId").value(application.getId().toString()))
                .andExpect(jsonPath("$.objectKey", Matchers.containsString(application.getId().toString())))
                .andExpect(jsonPath("$.contentType").value(MediaType.APPLICATION_PDF_VALUE))
                .andExpect(jsonPath("$.fileSize").value(9))
                .andExpect(jsonPath("$.download.url").value("https://example.com/documents/test.pdf"));
    }

    @Test
    void staffCanPreviewSpecificDocument() throws Exception {
        UUID documentId = uploadDocument();

        mockMvc.perform(get("/api/applications/{id}/documents/{documentId}/preview", application.getId(), documentId)
                        .header("Authorization", staffToken))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.url").value("https://example.com/documents/test-preview.pdf"));
    }

    @Test
    void staffCanDownloadSpecificDocument() throws Exception {
        UUID documentId = uploadDocument();

        mockMvc.perform(get("/api/applications/{id}/documents/{documentId}/download", application.getId(), documentId)
                        .header("Authorization", staffToken))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.url").value("https://example.com/documents/test.pdf"));
    }

    @Test
    void documentEndpointReturnsNotFoundForMissingDocument() throws Exception {
        mockMvc.perform(get("/api/applications/{id}/documents/{documentId}", application.getId(), UUID.randomUUID())
                        .header("Authorization", staffToken))
                .andExpect(status().isNotFound());
    }

    @Test
    void documentEndpointReturnsNotFoundForMissingApplication() throws Exception {
        mockMvc.perform(get("/api/applications/{id}/documents", UUID.randomUUID())
                        .header("Authorization", staffToken))
                .andExpect(status().isNotFound());
    }

    @Test
    void otherCustomerCannotAccessAnotherCustomersDocuments() throws Exception {
        UUID documentId = uploadDocument();

        mockMvc.perform(get("/api/applications/{id}/documents/{documentId}", application.getId(), documentId)
                        .header("Authorization", otherCustomerToken))
                .andExpect(status().isForbidden())
                .andExpect(jsonPath("$.errorCode").value("ACCESS_DENIED"));
    }

    @Test
    void uploadRejectsInvalidContentType() throws Exception {
        MockMultipartFile file = new MockMultipartFile(
                "file",
                "policy.pdf",
                MediaType.TEXT_PLAIN_VALUE,
                "dummy".getBytes());

        mockMvc.perform(multipart("/api/applications/{id}/documents", application.getId())
                        .file(file)
                        .header("Authorization", customerToken))
                .andExpect(status().isBadRequest());
    }

    @Test
    void invalidUploadReturnsStructuredErrorResponse() throws Exception {
        MockMultipartFile file = new MockMultipartFile(
                "file",
                "policy.pdf",
                MediaType.TEXT_PLAIN_VALUE,
                "dummy".getBytes());

        mockMvc.perform(multipart("/api/applications/{id}/documents", application.getId())
                        .file(file)
                        .header("Authorization", customerToken))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.timestamp").exists())
                .andExpect(jsonPath("$.status").value(400))
                .andExpect(jsonPath("$.errorCode").value("INVALID_FILE"))
                .andExpect(jsonPath("$.message").exists())
                .andExpect(jsonPath("$.path").value("/api/applications/" + application.getId() + "/documents"))
                .andExpect(jsonPath("$.correlationId").isNotEmpty());
    }

    @Test
    void uploadRejectsOversizedFile() throws Exception {
        byte[] oversized = new byte[(int) (10L * 1024 * 1024 + 1)];
        MockMultipartFile file = new MockMultipartFile(
                "file",
                "policy.pdf",
                MediaType.APPLICATION_PDF_VALUE,
                oversized);

        mockMvc.perform(multipart("/api/applications/{id}/documents", application.getId())
                        .file(file)
                        .header("Authorization", customerToken))
                .andExpect(status().isBadRequest());
    }

    @Test
    void customerCanPreviewOwnDocument() throws Exception {
        UUID documentId = uploadDocument();

        mockMvc.perform(get("/api/applications/{id}/documents/{documentId}/preview", application.getId(), documentId)
                        .header("Authorization", customerToken))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.url").value("https://example.com/documents/test-preview.pdf"));
    }

    private UUID uploadDocument() throws Exception {
        MockMultipartFile file = new MockMultipartFile(
                "file",
                "policy.pdf",
                MediaType.APPLICATION_PDF_VALUE,
                "dummy-pdf".getBytes());

        String response = mockMvc.perform(multipart("/api/applications/{id}/documents", application.getId())
                        .file(file)
                        .header("Authorization", customerToken))
                .andExpect(status().isOk())
                .andReturn()
                .getResponse()
                .getContentAsString();

        return UUID.fromString(response.replaceAll(".*\"id\":\"([^\"]+)\".*", "$1"));
    }

    private String bearerToken(UUID userId, JwtRole role) {
        return "Bearer " + jwtService.generate(
                userId,
                role.name().toLowerCase() + "@example.com",
                role);
    }
}
